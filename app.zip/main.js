(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/ApplicationModule.ts":
/*!**************************************!*\
  !*** ./src/app/ApplicationModule.ts ***!
  \**************************************/
/*! exports provided: ApplicationModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplicationModule", function() { return ApplicationModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../../node_modules/tslib/tslib.es6.js");
/* harmony import */ var forms42__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! forms42 */ "../../node_modules/forms42/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ApplicationRoot__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ApplicationRoot */ "./src/app/ApplicationRoot.ts");
/* harmony import */ var _BlockDefinitions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./BlockDefinitions */ "./src/app/BlockDefinitions.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ "../../node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser/animations */ "../../node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/animations.js");
/* harmony import */ var _forms_KundeService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./forms/KundeService */ "./src/app/forms/KundeService.ts");







// Formsdefinitions


let ApplicationModule = class ApplicationModule {
};
ApplicationModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ApplicationModule, bootstrap: [_ApplicationRoot__WEBPACK_IMPORTED_MODULE_3__["ApplicationRoot"]] });
ApplicationModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ factory: function ApplicationModule_Factory(t) { return new (t || ApplicationModule)(); }, providers: [], imports: [[
            forms42__WEBPACK_IMPORTED_MODULE_1__["FormsLibrary"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["BrowserModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["BrowserAnimationsModule"]
        ]] });
ApplicationModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["form"])(_forms_KundeService__WEBPACK_IMPORTED_MODULE_7__["KundeService"], "kundeservice", "/kundeservice")
], ApplicationModule);

(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ApplicationModule, { declarations: [_ApplicationRoot__WEBPACK_IMPORTED_MODULE_3__["ApplicationRoot"],
        _BlockDefinitions__WEBPACK_IMPORTED_MODULE_4__["BlockDefinitions"],
        _forms_KundeService__WEBPACK_IMPORTED_MODULE_7__["KundeService"]], imports: [forms42__WEBPACK_IMPORTED_MODULE_1__["FormsLibrary"],
        _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["BrowserModule"],
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["BrowserAnimationsModule"]] }); })();
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵsetClassMetadata"](ApplicationModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"],
        args: [{
                declarations: [
                    _ApplicationRoot__WEBPACK_IMPORTED_MODULE_3__["ApplicationRoot"],
                    _BlockDefinitions__WEBPACK_IMPORTED_MODULE_4__["BlockDefinitions"],
                    _forms_KundeService__WEBPACK_IMPORTED_MODULE_7__["KundeService"]
                ],
                imports: [
                    forms42__WEBPACK_IMPORTED_MODULE_1__["FormsLibrary"],
                    _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["BrowserModule"],
                    _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["BrowserAnimationsModule"]
                ],
                providers: [],
                bootstrap: [_ApplicationRoot__WEBPACK_IMPORTED_MODULE_3__["ApplicationRoot"]]
            }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/ApplicationRoot.ts":
/*!************************************!*\
  !*** ./src/app/ApplicationRoot.ts ***!
  \************************************/
/*! exports provided: ApplicationRoot */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApplicationRoot", function() { return ApplicationRoot; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var forms42__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! forms42 */ "../../node_modules/forms42/__ivy_ngcc__/fesm2015/forms.js");




class ApplicationRoot {
    constructor(app) {
        this.app = app;
        this.sidenav = false;
        let theme = new forms42__WEBPACK_IMPORTED_MODULE_1__["defaultTheme"]();
        theme.topbar = "#1d252c";
        app.theme = theme;
    }
    get form() {
        return (this.app.form);
    }
    get popup() {
        var _a;
        return ((_a = this.app.form) === null || _a === void 0 ? void 0 : _a.popup);
    }
    get barcolor() {
        return (this.app.colors.topbar);
    }
    get btncolor() {
        return (this.app.colors.menuoption);
    }
    close() {
        this.app.closeform(true);
    }
}
ApplicationRoot.ɵfac = function ApplicationRoot_Factory(t) { return new (t || ApplicationRoot)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](forms42__WEBPACK_IMPORTED_MODULE_1__["Application"])); };
ApplicationRoot.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ApplicationRoot, selectors: [["forms-app"]], decls: 20, vars: 4, consts: [[1, "page"], [1, "topbar"], [1, "toggle-button", 3, "click"], ["fill", "#fff", "width", "20", "height", "20", "viewBox", "0 0 20 20", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "d", "M3 7a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 13a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z", "clip-rule", "evenodd"], [1, "menu"], [1, "close-button", 3, "click"], ["colspan", "2"], [1, "formlist"], ["root", "forms"], [1, "form"], [1, "formarea-container"]], template: function ApplicationRoot_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "table", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "tr", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationRoot_Template_button_click_3_listener() { return ctx.sidenav = !ctx.sidenav; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "svg", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "path", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "td", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "menuarea");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function ApplicationRoot_Template_button_click_10_listener() { return ctx.close(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "\u00D7");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "td", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "table", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "formlist", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](16, "td", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "table", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](18, "formarea");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](19, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", ctx.sidenav ? "200px" : "1px")("display", ctx.sidenav ? "block" : "none");
    } }, directives: [forms42__WEBPACK_IMPORTED_MODULE_1__["MenuArea"], forms42__WEBPACK_IMPORTED_MODULE_1__["FormList"], forms42__WEBPACK_IMPORTED_MODULE_1__["FormArea"]], styles: [".page[_ngcontent-%COMP%] {\r\n  top: 0;\r\n  left: 0;\r\n  width: 100vw;\r\n  max-width: 100%;\r\n  position: absolute;\r\n  overflow-x: scroll;\r\n  border-collapse: collapse;\r\n  background: #edf2f6;\r\n}\r\n\r\n.topbar[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  height: 1.5em;\r\n  background: #1d252c;\r\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);\r\n  border-top: 4px solid #e0e536;\r\n}\r\n\r\n.toggle-button[_ngcontent-%COMP%] {\r\n  z-index: 1;\r\n  width: 20px;\r\n  border: none;\r\n  outline: none;\r\n  cursor: pointer;\r\n  padding: 8px;\r\n  display: inline-block;\r\n  text-decoration: none;\r\n  background: transparent;\r\n}\r\n\r\n.close-button[_ngcontent-%COMP%] {\r\n  background: transparent;\r\n  color: #fff;\r\n  font-size: 24px;\r\n  z-index: 1;\r\n  border: none;\r\n  outline: none;\r\n  cursor: pointer;\r\n  margin-right: auto;\r\n  text-decoration: none;\r\n}\r\n\r\n.line[_ngcontent-%COMP%] {\r\n  width: 16px;\r\n  height: 2px;\r\n  margin-top: 1px;\r\n  margin-bottom: 1px;\r\n  border-bottom: 2px solid white;\r\n}\r\n\r\n.menu[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  margin: auto;\r\n  display: grid;\r\n  place-items: center;\r\n  height: 56px;\r\n  font-size: 16px;\r\n  font-weight: 700;\r\n}\r\n\r\n.formlist[_ngcontent-%COMP%] {\r\n  vertical-align: top;\r\n  font-size: 14px;\r\n}\r\n\r\n.formarea-container[_ngcontent-%COMP%] {\r\n  padding: 12px 12px 24px 12px;\r\n  border-radius: 8px;\r\n  background: #fff;\r\n  margin: 24px auto;\r\n  box-shadow: 0 15px 35px 0 rgb(60 66 87 / 8%), 0 5px 15px 0 rgb(0 0 0 / 12%);\r\n  width: 100%;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3RzL2Zvcm1zNDIvc3JjL2FwcC9BcHBsaWNhdGlvblJvb3QuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsTUFBTTtFQUNOLE9BQU87RUFDUCxZQUFZO0VBQ1osZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIseUJBQXlCO0VBQ3pCLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLHdDQUF3QztFQUN4Qyw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSxVQUFVO0VBQ1YsV0FBVztFQUNYLFlBQVk7RUFDWixhQUFhO0VBQ2IsZUFBZTtFQUNmLFlBQVk7RUFDWixxQkFBcUI7RUFDckIscUJBQXFCO0VBQ3JCLHVCQUF1QjtBQUN6Qjs7QUFFQTtFQUNFLHVCQUF1QjtFQUN2QixXQUFXO0VBQ1gsZUFBZTtFQUNmLFVBQVU7RUFDVixZQUFZO0VBQ1osYUFBYTtFQUNiLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIscUJBQXFCO0FBQ3ZCOztBQUVBO0VBQ0UsV0FBVztFQUNYLFdBQVc7RUFDWCxlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLDhCQUE4QjtBQUNoQzs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osYUFBYTtFQUNiLG1CQUFtQjtFQUNuQixZQUFZO0VBQ1osZUFBZTtFQUNmLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLG1CQUFtQjtFQUNuQixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsNEJBQTRCO0VBQzVCLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLDJFQUEyRTtFQUMzRSxXQUFXO0FBQ2IiLCJmaWxlIjoicHJvamVjdHMvZm9ybXM0Mi9zcmMvYXBwL0FwcGxpY2F0aW9uUm9vdC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucGFnZSB7XHJcbiAgdG9wOiAwO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEwMHZ3O1xyXG4gIG1heC13aWR0aDogMTAwJTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgb3ZlcmZsb3cteDogc2Nyb2xsO1xyXG4gIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgYmFja2dyb3VuZDogI2VkZjJmNjtcclxufVxyXG5cclxuLnRvcGJhciB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxLjVlbTtcclxuICBiYWNrZ3JvdW5kOiAjMWQyNTJjO1xyXG4gIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2JhKDAsIDAsIDAsIDAuNCk7XHJcbiAgYm9yZGVyLXRvcDogNHB4IHNvbGlkICNlMGU1MzY7XHJcbn1cclxuXHJcbi50b2dnbGUtYnV0dG9uIHtcclxuICB6LWluZGV4OiAxO1xyXG4gIHdpZHRoOiAyMHB4O1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBvdXRsaW5lOiBub25lO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBwYWRkaW5nOiA4cHg7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLmNsb3NlLWJ1dHRvbiB7XHJcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgZm9udC1zaXplOiAyNHB4O1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIG1hcmdpbi1yaWdodDogYXV0bztcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuXHJcbi5saW5lIHtcclxuICB3aWR0aDogMTZweDtcclxuICBoZWlnaHQ6IDJweDtcclxuICBtYXJnaW4tdG9wOiAxcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMXB4O1xyXG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCB3aGl0ZTtcclxufVxyXG5cclxuLm1lbnUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1hcmdpbjogYXV0bztcclxuICBkaXNwbGF5OiBncmlkO1xyXG4gIHBsYWNlLWl0ZW1zOiBjZW50ZXI7XHJcbiAgaGVpZ2h0OiA1NnB4O1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBmb250LXdlaWdodDogNzAwO1xyXG59XHJcblxyXG4uZm9ybWxpc3Qge1xyXG4gIHZlcnRpY2FsLWFsaWduOiB0b3A7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG4uZm9ybWFyZWEtY29udGFpbmVyIHtcclxuICBwYWRkaW5nOiAxMnB4IDEycHggMjRweCAxMnB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gIG1hcmdpbjogMjRweCBhdXRvO1xyXG4gIGJveC1zaGFkb3c6IDAgMTVweCAzNXB4IDAgcmdiKDYwIDY2IDg3IC8gOCUpLCAwIDVweCAxNXB4IDAgcmdiKDAgMCAwIC8gMTIlKTtcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG4iXX0= */"] });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ApplicationRoot, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{
                selector: 'forms-app',
                templateUrl: './ApplicationRoot.html',
                styleUrls: ['./ApplicationRoot.css']
            }]
    }], function () { return [{ type: forms42__WEBPACK_IMPORTED_MODULE_1__["Application"] }]; }, null); })();


/***/ }),

/***/ "./src/app/BlockDefinitions.ts":
/*!*************************************!*\
  !*** ./src/app/BlockDefinitions.ts ***!
  \*************************************/
/*! exports provided: BlockDefinitions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlockDefinitions", function() { return BlockDefinitions; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


/*
    Typescript doesn't like classes with annotations/decorators (@)
    that are not referenced. The only purpose of this class, is to hold
    a dummy reference to all blocks.
*/
class BlockDefinitions {
}
BlockDefinitions.ɵfac = function BlockDefinitions_Factory(t) { return new (t || BlockDefinitions)(); };
BlockDefinitions.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: BlockDefinitions, selectors: [["ng-component"]], decls: 0, vars: 0, template: function BlockDefinitions_Template(rf, ctx) { }, encapsulation: 2 });
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BlockDefinitions, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"],
        args: [{ template: '' }]
    }], null, null); })();


/***/ }),

/***/ "./src/app/blocks/Kunder.ts":
/*!**********************************!*\
  !*** ./src/app/blocks/Kunder.ts ***!
  \**********************************/
/*! exports provided: Kunder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Kunder", function() { return Kunder; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../../node_modules/tslib/tslib.es6.js");
/* harmony import */ var forms42__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! forms42 */ "../../node_modules/forms42/__ivy_ngcc__/fesm2015/forms.js");


let Kunder = class Kunder extends forms42__WEBPACK_IMPORTED_MODULE_1__["Block"] {
    adresse(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let adresse = "";
            adresse += this.getValue(event.record, "gadenavn") + " ";
            adresse += this.getValue(event.record, "hus_nr") + " ";
            adresse += this.getValue(event.record, "litra") + " ";
            adresse += this.getValue(event.record, "etage") + " ";
            adresse += this.getValue(event.record, "postnr") + " ";
            adresse += this.getValue(event.record, "postdistrikt") + " ";
            this.setValue(event.record, "adresse", adresse.replace(/\s{2,}/g, ' '));
            return (true);
        });
    }
};
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["trigger"])(forms42__WEBPACK_IMPORTED_MODULE_1__["Trigger"].PostChange, ["gadenavn", "hus_nr", "litra", "etage", "postnr", "postdistrikt"])
], Kunder.prototype, "adresse", null);
Kunder = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["key"])("primary", true, "id"),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["table"])({ name: "ks.bk_kunder", limit: 'limit 100' }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "id", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "abon_nr", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "konto_nr", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "navn", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "co_navn", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "supl_adr", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "afleverings_kode", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "afleverings_tekst", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "gadenavn", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "hus_nr", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "litra", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "etage", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "side_lejlighed", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "postnr", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "postdistrikt", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "abde_id", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["field"])({ name: "adresse", type: forms42__WEBPACK_IMPORTED_MODULE_1__["FieldType"].text }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["database"])({ query: true, insert: false, update: false, delete: false })
], Kunder);



/***/ }),

/***/ "./src/app/blocks/Ordrer.ts":
/*!**********************************!*\
  !*** ./src/app/blocks/Ordrer.ts ***!
  \**********************************/
/*! exports provided: Ordrer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Ordrer", function() { return Ordrer; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../../node_modules/tslib/tslib.es6.js");
/* harmony import */ var forms42__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! forms42 */ "../../node_modules/forms42/__ivy_ngcc__/fesm2015/forms.js");


let Ordrer = class Ordrer extends forms42__WEBPACK_IMPORTED_MODULE_1__["Block"] {
};
Ordrer = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["alias"])("ordrer"),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["table"])({ name: "ks.bk_ordrer", order: "dist_dato", where: "bkku_id is not null" }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "id", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer, mandatory: true }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "bkku_id", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer, mandatory: true }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "dist_dato", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].date, mandatory: true }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "udkomst_dato", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].date, mandatory: true }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "abol_id", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "ordf_id", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "konto_nr", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "abonnr", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "subtype", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "ordre_type", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "afleveringskode", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "afleverings_tekst", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "produkt_nr", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer, mandatory: true }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "produkt_navn", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].varchar, mandatory: true }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["column"])({ name: "leverings_antal", type: forms42__WEBPACK_IMPORTED_MODULE_1__["Column"].integer }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["key"])("primary", true, "id"),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["key"])("kunde", true, "bkku_id"),
    Object(forms42__WEBPACK_IMPORTED_MODULE_1__["database"])({ query: true, insert: false, update: false, delete: false })
], Ordrer);



/***/ }),

/***/ "./src/app/forms/KundeService.ts":
/*!***************************************!*\
  !*** ./src/app/forms/KundeService.ts ***!
  \***************************************/
/*! exports provided: KundeService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KundeService", function() { return KundeService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _blocks_Kunder__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../blocks/Kunder */ "./src/app/blocks/Kunder.ts");
/* harmony import */ var _blocks_Ordrer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../blocks/Ordrer */ "./src/app/blocks/Ordrer.ts");
/* harmony import */ var forms42__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! forms42 */ "../../node_modules/forms42/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "../../node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");








function KundeService_tr_26_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "field", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "field", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const row_r5 = ctx.index;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("display", ctx_r0.showRowIndicator("kunder", row_r5) ? "inline-block" : "none");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("row", row_r5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("row", row_r5);
} }
function KundeService_span_76_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, " Distribueret ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function KundeService_span_76_Template_button_click_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r6.ordrer.showDatePicker("dist_dato"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "svg", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "path", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function KundeService_span_78_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, " Udkommet ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function KundeService_span_78_Template_button_click_2_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r8.ordrer.showDatePicker("udkomst_dato"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "svg", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "path", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function KundeService_ul_83_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "field", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "field", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](8, "field", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "field", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "li");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](11, "field", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const row_r11 = ctx.index;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("display", ctx_r3.showRowIndicator("ordrer", row_r11) ? "inline-block" : "none");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("row", row_r11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("row", row_r11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("row", row_r11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("row", row_r11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("row", row_r11);
} }
const _c0 = function () { return []; };
let KundeService = class KundeService extends forms42__WEBPACK_IMPORTED_MODULE_4__["Form"] {
    constructor() {
        super(...arguments);
        this.kunder = null;
        this.ordrer = null;
    }
    clrctrl(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (event.block == 'ctrl')
                return (false);
            return (true);
        });
    }
    clrform(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.clear();
            this.kunder.enterquery();
            return (false);
        });
    }
    ctrlChange(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.connected && !this.kunder.querymode)
                this.ordrer.executequery();
            return (true);
        });
    }
    alwaysQuery(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (event.block == "kunder") {
                yield this.kunder.executequery();
                if (this.kunder.empty())
                    this.kunder.enterquery(true);
                return (false);
            }
            if (event.block == "ordrer") {
                this.kunder.sendKey(forms42__WEBPACK_IMPORTED_MODULE_4__["keymap"].executequery);
                return (false);
            }
            return (true);
        });
    }
    prequeryKunder(event) {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let ok = false;
            this.kunder.searchfilter.forEach((filter) => {
                if (filter.name == "navn")
                    ok = true;
                if (filter.name == "adresse")
                    ok = true;
                if (filter.name == "abon_nr")
                    ok = true;
                if (filter.name == "konto_nr")
                    ok = true;
            });
            if (!ok) {
                this.alert("Der skal søges på mindst et af felterne navn, adresse, abonent eller konto");
                return (false);
            }
            // Adresse is not a database field
            // and not set as condition
            this.kunder.searchfilter.forEach((filter) => {
                if (filter.name == 'adresse')
                    event.stmt.whand(filter.name, '"' + filter.value + '"');
            });
            let conditions = (_a = event.stmt.getCondition()) === null || _a === void 0 ? void 0 : _a.split();
            if (conditions)
                conditions.forEach((cond) => {
                    if (cond.column == 'navn')
                        cond.setCondition("to_tsvector('danish',navn) @@ websearch_to_tsquery('danish',:" + cond.placeholder + ")");
                    if (cond.column == 'adresse')
                        cond.setCondition("to_tsvector('danish',coalesce(gadenavn,' ')||' '||coalesce(postnr,' ')||' '||coalesce(postdistrikt,' ')||' '||coalesce(hus_nr::varchar,' ')||' '||coalesce(litra,' ')||' '||coalesce(etage,' ')) @@ websearch_to_tsquery('danish',:" + cond.placeholder + ")");
                });
            return (true);
        });
    }
    prequeryOrdrer(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let dates = new forms42__WEBPACK_IMPORTED_MODULE_4__["DateUtils"]();
            let ctrl = this.getBlock("ctrl");
            let datefr = ">= " + dates.format(ctrl.getValue(0, "fra_dato"));
            let dateto = "<= " + dates.format(ctrl.getValue(0, "til_dato"));
            event.stmt.whand("udkomst_dato", datefr, forms42__WEBPACK_IMPORTED_MODULE_4__["Column"].date);
            event.stmt.whand("udkomst_dato", dateto, forms42__WEBPACK_IMPORTED_MODULE_4__["Column"].date);
            let type = ctrl.getValue(0, "type");
            if (type != null && type.length > 0)
                event.stmt.whand("subtype", type.toUpperCase());
            return (true);
        });
    }
    onConnect() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.kunder.enterquery();
            return (true);
        });
    }
    init() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let ctrl = this.getBlock("ctrl");
            yield ctrl.createControlRecord();
            ctrl.setFieldDefinition({ name: "type", type: forms42__WEBPACK_IMPORTED_MODULE_4__["FieldType"].dropdown });
            let types = new Set();
            types.add("");
            types.add("Salg");
            types.add("Abon");
            types.add("Post");
            types.add("Depo");
            ctrl.setPossibleValues("type", types, true);
            let fra = new Date();
            let til = new Date();
            fra.setDate(fra.getDate() - 7);
            ctrl.setValue(0, "fra_dato", fra);
            ctrl.setValue(0, "til_dato", til);
            return (true);
        });
    }
};
KundeService.ɵfac = function KundeService_Factory(t) { return ɵKundeService_BaseFactory(t || KundeService); };
KundeService.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: KundeService, selectors: [["ng-component"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 84, vars: 6, consts: [[1, "ctrl"], [1, "ctrl-item"], [1, "label-ctrl"], ["name", "type", "block", "ctrl"], ["width", "18", "height", "18", "fill", "#5F6971", "viewBox", "0 0 20 20", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "d", "M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z", "clip-rule", "evenodd"], ["name", "fra_dato", "size", "13", "block", "ctrl"], ["name", "til_dato", "size", "13", "block", "ctrl"], [1, "kunder"], [1, "kunder-table"], [4, "ngFor", "ngForOf"], [1, "kunder-detail"], [1, "label-kd"], ["name", "abon_nr", "size", "8", "id", "detail", "block", "kunder"], ["name", "konto_nr", "size", "8", "id", "detail", "block", "kunder"], ["name", "co_navn", "size", "20", "id", "detail", "block", "kunder"], ["name", "supl_adr", "size", "20", "id", "detail", "block", "kunder"], ["name", "afleverings_kode", "size", "6", "id", "detail", "block", "kunder"], ["name", "afleverings_tekst", "size", "20", "id", "detail", "block", "kunder"], [1, "tabs"], ["href", "#a", "onclick", "return false;", 1, "active"], ["href", "#a", "onclick", "return false;"], [1, "ordrer"], [1, "ordrer-head"], [4, "ngIf"], [1, "indicator"], ["name", "navn", "size", "35", "id", "table", "block", "kunder", 3, "row"], ["name", "adresse", "size", "35", "id", "table", "block", "kunder", 3, "row"], [3, "click"], ["width", "16", "height", "16", "fill", "#5F6971", "viewBox", "0 0 20 20", "xmlns", "http://www.w3.org/2000/svg"], ["name", "dist_dato", "size", "12", "block", "ordrer", 3, "row"], ["name", "udkomst_dato", "size", "12", "block", "ordrer", 3, "row"], ["name", "produkt_nr", "size", "3", "block", "ordrer", 3, "row"], ["name", "produkt_navn", "size", "20", "block", "ordrer", 3, "row"], ["name", "leverings_antal", "size", "2", "block", "ordrer", 3, "row"]], template: function KundeService_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "field", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7, "Fra");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "svg", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "path", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "field", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, "Til");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "svg", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "path", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceHTML"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "field", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "table");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](21, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](23, "Navn");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "Adresse");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](26, KundeService_tr_26_Template, 7, 4, "tr", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](27, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](28, "table");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](29, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](30, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](32, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34, "Abon# ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](35, "field", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](36, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](37, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](38, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](39, "Konto# ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](40, "field", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](41, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](42, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](43, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](44, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](45, "Co ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](46, "field", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](47, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](48, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](49, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](50, "Adresse ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](51, "field", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](52, "tr");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](53, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](54, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](55, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](56, "Kode ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](57, "field", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](58, "td");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](59, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](60, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](61, "Tekst ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](62, "field", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](63, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](64, "ul");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](65, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](66, "a", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](67, "Planlagt");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](68, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](69, "a", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](70, "Leveret");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](71, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](72, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](73, "ul", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](74, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](75, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](76, KundeService_span_76_Template, 5, 0, "span", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](77, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](78, KundeService_span_78_Template, 5, 0, "span", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](79, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](80, "Produkt");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](81, "li");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](82, "Antal");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](83, KundeService_ul_83_Template, 12, 7, "ul", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](4, _c0).constructor(5));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](50);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](5, _c0).constructor(6));
    } }, directives: [forms42__WEBPACK_IMPORTED_MODULE_4__["FieldInstance"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"]], styles: [".tabs[_ngcontent-%COMP%] {\r\n  margin: 6px 6px 16px 6px;\r\n}\r\n\r\n.tabs[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  align-items: center;\r\n  list-style: none;\r\n  margin: 0;\r\n  padding: 0;\r\n}\r\n\r\n.tabs[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\r\n  margin-right: 4px;\r\n}\r\n\r\n.tabs[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\r\n  display: block;\r\n  padding: 8px 12px;\r\n  font-size: 16px;\r\n  text-decoration: none;\r\n  border-bottom: 3px solid transparent;\r\n  background: transparent;\r\n  color: #374151;\r\n  transition: all 0.18s;\r\n}\r\n\r\n.tabs[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\r\n  border-bottom: 3px solid #d5e2ec;\r\n}\r\n\r\n.tabs[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:active {\r\n  background: #e0e536;\r\n  border-top-right-radius: 4px;\r\n  border-top-left-radius: 4px;\r\n}\r\n\r\n.tabs[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%] {\r\n  border-bottom: 3px solid #e0e536;\r\n  color: #374151;\r\n  font-weight: 600;\r\n}\r\n\r\n.ctrl[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  align-items: center;\r\n  margin-bottom: 24px;\r\n  background: #e3ecf2;\r\n  padding: 8px;\r\n  border-radius: 4px;\r\n  font-size: 14px;\r\n}\r\n\r\n.ctrl-item[_ngcontent-%COMP%] {\r\n  margin-right: 24px;\r\n  display: flex;\r\n  align-items: center;\r\n  position: relative;\r\n}\r\n\r\n.ctrl-item[_ngcontent-%COMP%]   svg[_ngcontent-%COMP%] {\r\n  position: absolute;\r\n  right: 22px;\r\n  top: 9px;\r\n}\r\n\r\n.kunder[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  margin-bottom: 24px;\r\n}\r\n\r\n.kunder-table[_ngcontent-%COMP%] {\r\n  display: flex;\r\n}\r\n\r\n.kunder-table[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-child   input[type=\"text\"][_ngcontent-%COMP%] {\r\n  border: 2px solid red;\r\n}\r\n\r\n.kunder-detail[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  margin-left: 32px;\r\n}\r\n\r\n.kunder-detail[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%] {\r\n  margin-bottom: 4px;\r\n}\r\n\r\n.ordrer[_ngcontent-%COMP%] {\r\n  padding: 16px 12px;\r\n  border-radius: 4px;\r\n  background: #f2f6f9;\r\n  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.23), 0px 8px 16px rgba(0, 0, 0, 0.08);\r\n}\r\n\r\n.ordrer[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\r\n  list-style: none;\r\n  margin: 0;\r\n  padding: 0;\r\n  display: grid;\r\n  grid-template-columns: 20px 180px 180px 325px 80px;\r\n  align-items: center;\r\n}\r\n\r\n.ordrer[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\r\n  margin-bottom: 4px;\r\n}\r\n\r\n.ordrer-head[_ngcontent-%COMP%] {\r\n  font-weight: 600;\r\n  color: #374151;\r\n  font-size: 14px;\r\n}\r\n\r\n.ordrer[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\r\n  display: inline-flex;\r\n  align-items: center;\r\n  background: #e3ecf2;\r\n  color: #374151;\r\n  border: none;\r\n  font-size: 13px;\r\n  padding: 6px;\r\n  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.13);\r\n  border-radius: 4px;\r\n  font-weight: 700;\r\n  margin-left: 8px;\r\n}\r\n\r\n.ordrer[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover {\r\n  cursor: pointer;\r\n  background: #f2f6f9;\r\n}\r\n\r\n.ordrer[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:active {\r\n  background: #d5e2ec;\r\n}\r\n\r\n.indicator[_ngcontent-%COMP%] {\r\n  width: 10px;\r\n  height: 10px;\r\n  border-radius: 50%;\r\n  background: #e0e536;\r\n  display: inline-block;\r\n  margin-right: 4px;\r\n  box-shadow: 0 0 0 2px rgba(224, 229, 54, 0.2);\r\n}\r\n\r\n.label-kd[_ngcontent-%COMP%] {\r\n  font-weight: 600;\r\n  display: block;\r\n  font-size: 0.8em;\r\n  margin-bottom: 4px;\r\n  color: #374151;\r\n}\r\n\r\n.label-ctrl[_ngcontent-%COMP%] {\r\n  margin-right: 8px;\r\n  font-weight: 600;\r\n  display: inline-block;\r\n}\r\n\r\ntable[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n}\r\n\r\nth[_ngcontent-%COMP%] {\r\n  text-align: left;\r\n  padding-bottom: 8px;\r\n  font-weight: 600;\r\n  color: #374151;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3RzL2Zvcm1zNDIvc3JjL2FwcC9mb3Jtcy9rdW5kZXNlcnZpY2UuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usd0JBQXdCO0FBQzFCOztBQUVBO0VBQ0UsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQixnQkFBZ0I7RUFDaEIsU0FBUztFQUNULFVBQVU7QUFDWjs7QUFFQTtFQUNFLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxpQkFBaUI7RUFDakIsZUFBZTtFQUNmLHFCQUFxQjtFQUNyQixvQ0FBb0M7RUFDcEMsdUJBQXVCO0VBQ3ZCLGNBQWM7RUFDZCxxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRSxnQ0FBZ0M7QUFDbEM7O0FBRUE7RUFDRSxtQkFBbUI7RUFDbkIsNEJBQTRCO0VBQzVCLDJCQUEyQjtBQUM3Qjs7QUFFQTtFQUNFLGdDQUFnQztFQUNoQyxjQUFjO0VBQ2QsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UsYUFBYTtFQUNiLG1CQUFtQjtFQUNuQixtQkFBbUI7RUFDbkIsbUJBQW1CO0VBQ25CLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsUUFBUTtBQUNWOztBQUVBO0VBQ0UsYUFBYTtFQUNiLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLGFBQWE7QUFDZjs7QUFFQTtFQUNFLHFCQUFxQjtBQUN2Qjs7QUFFQTtFQUNFLGFBQWE7RUFDYixpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSxrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQiw2RUFBNkU7QUFDL0U7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsU0FBUztFQUNULFVBQVU7RUFDVixhQUFhO0VBQ2Isa0RBQWtEO0VBQ2xELG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixjQUFjO0VBQ2QsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLG9CQUFvQjtFQUNwQixtQkFBbUI7RUFDbkIsbUJBQW1CO0VBQ25CLGNBQWM7RUFDZCxZQUFZO0VBQ1osZUFBZTtFQUNmLFlBQVk7RUFDWiwyQ0FBMkM7RUFDM0Msa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0UsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLHFCQUFxQjtFQUNyQixpQkFBaUI7RUFDakIsNkNBQTZDO0FBQy9DOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLGNBQWM7QUFDaEI7O0FBRUE7RUFDRSxpQkFBaUI7RUFDakIsZ0JBQWdCO0VBQ2hCLHFCQUFxQjtBQUN2Qjs7QUFFQTtFQUNFLFdBQVc7QUFDYjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLGNBQWM7QUFDaEIiLCJmaWxlIjoicHJvamVjdHMvZm9ybXM0Mi9zcmMvYXBwL2Zvcm1zL2t1bmRlc2VydmljZS5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGFicyB7XHJcbiAgbWFyZ2luOiA2cHggNnB4IDE2cHggNnB4O1xyXG59XHJcblxyXG4udGFicyB1bCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIHBhZGRpbmc6IDA7XHJcbn1cclxuXHJcbi50YWJzIHVsIGxpIHtcclxuICBtYXJnaW4tcmlnaHQ6IDRweDtcclxufVxyXG5cclxuLnRhYnMgdWwgbGkgYSB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgcGFkZGluZzogOHB4IDEycHg7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgY29sb3I6ICMzNzQxNTE7XHJcbiAgdHJhbnNpdGlvbjogYWxsIDAuMThzO1xyXG59XHJcblxyXG4udGFicyB1bCBsaSBhOmhvdmVyIHtcclxuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgI2Q1ZTJlYztcclxufVxyXG5cclxuLnRhYnMgdWwgbGkgYTphY3RpdmUge1xyXG4gIGJhY2tncm91bmQ6ICNlMGU1MzY7XHJcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDRweDtcclxuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA0cHg7XHJcbn1cclxuXHJcbi50YWJzIHVsIGxpIGEuYWN0aXZlIHtcclxuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgI2UwZTUzNjtcclxuICBjb2xvcjogIzM3NDE1MTtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG59XHJcblxyXG4uY3RybCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIG1hcmdpbi1ib3R0b206IDI0cHg7XHJcbiAgYmFja2dyb3VuZDogI2UzZWNmMjtcclxuICBwYWRkaW5nOiA4cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLmN0cmwtaXRlbSB7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyNHB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5jdHJsLWl0ZW0gc3ZnIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgcmlnaHQ6IDIycHg7XHJcbiAgdG9wOiA5cHg7XHJcbn1cclxuXHJcbi5rdW5kZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjRweDtcclxufVxyXG5cclxuLmt1bmRlci10YWJsZSB7XHJcbiAgZGlzcGxheTogZmxleDtcclxufVxyXG5cclxuLmt1bmRlci10YWJsZSB0YWJsZSB0ciB0ZDpmaXJzdC1jaGlsZCBpbnB1dFt0eXBlPVwidGV4dFwiXSB7XHJcbiAgYm9yZGVyOiAycHggc29saWQgcmVkO1xyXG59XHJcblxyXG4ua3VuZGVyLWRldGFpbCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBtYXJnaW4tbGVmdDogMzJweDtcclxufVxyXG5cclxuLmt1bmRlci1kZXRhaWwgdHIge1xyXG4gIG1hcmdpbi1ib3R0b206IDRweDtcclxufVxyXG5cclxuLm9yZHJlciB7XHJcbiAgcGFkZGluZzogMTZweCAxMnB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBiYWNrZ3JvdW5kOiAjZjJmNmY5O1xyXG4gIGJveC1zaGFkb3c6IDBweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4yMyksIDBweCA4cHggMTZweCByZ2JhKDAsIDAsIDAsIDAuMDgpO1xyXG59XHJcblxyXG4ub3JkcmVyIHVsIHtcclxuICBsaXN0LXN0eWxlOiBub25lO1xyXG4gIG1hcmdpbjogMDtcclxuICBwYWRkaW5nOiAwO1xyXG4gIGRpc3BsYXk6IGdyaWQ7XHJcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAyMHB4IDE4MHB4IDE4MHB4IDMyNXB4IDgwcHg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLm9yZHJlciB1bCBsaSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG59XHJcblxyXG4ub3JkcmVyLWhlYWQge1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgY29sb3I6ICMzNzQxNTE7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG4ub3JkcmVyIGJ1dHRvbiB7XHJcbiAgZGlzcGxheTogaW5saW5lLWZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kOiAjZTNlY2YyO1xyXG4gIGNvbG9yOiAjMzc0MTUxO1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgcGFkZGluZzogNnB4O1xyXG4gIGJveC1zaGFkb3c6IDBweCAycHggMnB4IHJnYmEoMCwgMCwgMCwgMC4xMyk7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgbWFyZ2luLWxlZnQ6IDhweDtcclxufVxyXG5cclxuLm9yZHJlciBidXR0b246aG92ZXIge1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBiYWNrZ3JvdW5kOiAjZjJmNmY5O1xyXG59XHJcblxyXG4ub3JkcmVyIGJ1dHRvbjphY3RpdmUge1xyXG4gIGJhY2tncm91bmQ6ICNkNWUyZWM7XHJcbn1cclxuXHJcbi5pbmRpY2F0b3Ige1xyXG4gIHdpZHRoOiAxMHB4O1xyXG4gIGhlaWdodDogMTBweDtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgYmFja2dyb3VuZDogI2UwZTUzNjtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgbWFyZ2luLXJpZ2h0OiA0cHg7XHJcbiAgYm94LXNoYWRvdzogMCAwIDAgMnB4IHJnYmEoMjI0LCAyMjksIDU0LCAwLjIpO1xyXG59XHJcblxyXG4ubGFiZWwta2Qge1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgZm9udC1zaXplOiAwLjhlbTtcclxuICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbiAgY29sb3I6ICMzNzQxNTE7XHJcbn1cclxuXHJcbi5sYWJlbC1jdHJsIHtcclxuICBtYXJnaW4tcmlnaHQ6IDhweDtcclxuICBmb250LXdlaWdodDogNjAwO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG5cclxudGFibGUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG50aCB7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxuICBwYWRkaW5nLWJvdHRvbTogOHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgY29sb3I6ICMzNzQxNTE7XHJcbn1cclxuIl19 */"] });
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["block"])({ component: _blocks_Kunder__WEBPACK_IMPORTED_MODULE_2__["Kunder"] })
], KundeService.prototype, "kunder", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["block"])({ component: _blocks_Ordrer__WEBPACK_IMPORTED_MODULE_3__["Ordrer"] })
], KundeService.prototype, "ordrer", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["keytrigger"])(forms42__WEBPACK_IMPORTED_MODULE_4__["keymap"].clearblock)
], KundeService.prototype, "clrctrl", null);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["keytrigger"])(forms42__WEBPACK_IMPORTED_MODULE_4__["keymap"].clearform)
], KundeService.prototype, "clrform", null);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["trigger"])(forms42__WEBPACK_IMPORTED_MODULE_4__["Trigger"].PostChange, "ctrl")
], KundeService.prototype, "ctrlChange", null);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["keytrigger"])(forms42__WEBPACK_IMPORTED_MODULE_4__["keymap"].executequery)
], KundeService.prototype, "alwaysQuery", null);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["trigger"])(forms42__WEBPACK_IMPORTED_MODULE_4__["Trigger"].PreQuery, "kunder")
], KundeService.prototype, "prequeryKunder", null);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["trigger"])(forms42__WEBPACK_IMPORTED_MODULE_4__["Trigger"].PreQuery, "ordrer")
], KundeService.prototype, "prequeryOrdrer", null);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    forms42__WEBPACK_IMPORTED_MODULE_4__["connect"]
], KundeService.prototype, "onConnect", null);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    forms42__WEBPACK_IMPORTED_MODULE_4__["show"]
], KundeService.prototype, "init", null);
KundeService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["field"])({ name: "ctrl.type", type: forms42__WEBPACK_IMPORTED_MODULE_4__["FieldType"].text }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["field"])({ name: "ctrl.fra_dato", type: forms42__WEBPACK_IMPORTED_MODULE_4__["FieldType"].date }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["field"])({ name: "ctrl.til_dato", type: forms42__WEBPACK_IMPORTED_MODULE_4__["FieldType"].date }),
    Object(forms42__WEBPACK_IMPORTED_MODULE_4__["join"])({ master: { alias: "kunder", key: "primary" }, detail: { alias: "ordrer", key: "kunde" } })
], KundeService);

const ɵKundeService_BaseFactory = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](KundeService);
/*@__PURE__*/ (function () { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](KundeService, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"],
        args: [{
                templateUrl: "kundeservice.html",
                styleUrls: ['kundeservice.css']
            }]
    }], null, { kunder: [], ordrer: [], clrctrl: [], clrform: [], ctrlChange: [], alwaysQuery: [], prequeryKunder: [], prequeryOrdrer: [], onConnect: [], init: [] }); })();


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "../../node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_ApplicationModule__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/ApplicationModule */ "./src/app/ApplicationModule.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "../../node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModule(_app_ApplicationModule__WEBPACK_IMPORTED_MODULE_2__["ApplicationModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Forms42\projects\forms42\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map