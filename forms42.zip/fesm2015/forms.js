import { __awaiter } from 'tslib';
import { ɵɵdefineInjectable, Injectable, Component, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, ElementRef, Input, ɵɵinject, ComponentFactoryResolver, INJECTOR, ApplicationRef, Injector, NgModule } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

class Utils {
    getName(component) {
        if (component == null)
            return (null);
        let name = component.constructor.name;
        if (name == "String")
            name = component;
        if (name == "Function")
            name = component.name;
        return (name.toLowerCase());
    }
    clone(obj) {
        let clone = {};
        if (obj == null)
            return (null);
        Object.keys(obj).forEach((key) => { clone[key] = obj[key]; });
        return (clone);
    }
    getType(component) {
        let type = null;
        let code = component.toString();
        if (code == "[object Object]")
            code = component.constructor.toString();
        if (code.startsWith("class")) {
            code = code.substring(0, code.indexOf("{"));
            let pos = code.indexOf("extends");
            if (pos > 0) {
                let pos1 = code.indexOf("[", pos);
                let pos2 = code.indexOf("]", pos1);
                type = code.substring(pos1 + 2, pos2 - 1);
            }
        }
        return (type);
    }
    getParams(func) {
        let code = func.toString();
        code = code.replace(/\/\*[\s\S]*?\*\//g, '')
            .replace(/\/\/(.)*/g, '')
            .replace(/{[\s\S]*}/, '')
            .replace(/=>/g, '')
            .trim();
        let end = code.length - 1;
        let start = code.indexOf("(") + 1;
        let params = [];
        let tokens = code.substring(start, end).split(", ");
        tokens.forEach((element) => {
            // Removing any default value
            element = element.replace(/=[\s\S]*/g, '').trim();
            if (element.length > 0)
                params.push(element);
        });
        return (params);
    }
}

class BlockDefinitions {
    static setDefaultAlias(block, alias) {
        if (alias == null)
            alias = block;
        BlockDefinitions.alias.set(block, alias);
    }
    static getDefaultAlias(alias) {
        alias = alias.toLowerCase();
        let bname = BlockDefinitions.alias.get(alias);
        if (bname == null)
            bname = alias;
        return (bname);
    }
    static setBlock(form, def) {
        let blocks = BlockDefinitions.blocks.get(form.toLowerCase());
        if (blocks == null) {
            blocks = [];
            BlockDefinitions.blocks.set(form.toLowerCase(), blocks);
        }
        if (def.prop != null)
            blocks.push(def);
        else
            blocks.unshift(def);
    }
    static getBlocks(form) {
        let blocks = BlockDefinitions.blocks.get(form.toLowerCase());
        if (blocks == null)
            blocks = [];
        return (blocks);
    }
    static setKey(block, def) {
        let keys = BlockDefinitions.keys.get(block.toLowerCase());
        if (keys == null) {
            keys = [];
            BlockDefinitions.keys.set(block.toLowerCase(), keys);
        }
        keys.unshift(def);
    }
    static getKeys(block) {
        let keys = BlockDefinitions.keys.get(block.toLowerCase());
        if (keys == null)
            keys = [];
        return (keys);
    }
}
BlockDefinitions.alias = new Map();
BlockDefinitions.blocks = new Map();
BlockDefinitions.keys = new Map();

const key = (name, unique, columns) => {
    function define(comp) {
        let utils = new Utils();
        let cname = utils.getName(comp);
        let ctype = utils.getType(comp);
        if (ctype != "Block") {
            console.log("@key(" + name + ") can only be used on blocks");
            return;
        }
        let arr = true;
        let cols = [];
        if (columns.constructor.name == "String")
            arr = false;
        if (arr)
            cols = columns;
        else
            cols.push(columns);
        let lccols = [];
        cols.forEach((col) => { lccols.push(col.toLowerCase()); });
        let def = { name: name.toLowerCase(), unique: unique, columns: lccols };
        BlockDefinitions.setKey(cname, def);
    }
    return (define);
};

class FormDefinitions {
    static setForm(def) {
        FormDefinitions.forms.unshift(def);
    }
    static getForms() {
        return (FormDefinitions.forms);
    }
    static getWindowOpts(form) {
        let wopts = FormDefinitions.windowopts.get(form);
        if (wopts == null) {
            wopts = {};
            FormDefinitions.windowopts.set(form, wopts);
        }
        return (wopts);
    }
    static setOnInit(form, func) {
        let funcs = FormDefinitions.oninit.get(form);
        if (funcs == null)
            funcs = [];
        funcs.push(func);
        FormDefinitions.oninit.set(form, funcs);
    }
    static setOnShow(form, func) {
        let funcs = FormDefinitions.onshow.get(form);
        if (funcs == null)
            funcs = [];
        funcs.push(func);
        FormDefinitions.onshow.set(form, funcs);
    }
    static setOnHide(form, func) {
        let funcs = FormDefinitions.onhide.get(form);
        if (funcs == null)
            funcs = [];
        funcs.push(func);
        FormDefinitions.onhide.set(form, funcs);
    }
    static setOnConnect(form, func) {
        let funcs = FormDefinitions.onconn.get(form);
        if (funcs == null)
            funcs = [];
        funcs.push(func);
        FormDefinitions.onconn.set(form, funcs);
    }
    static setOnDisconnect(form, func) {
        let funcs = FormDefinitions.ondisc.get(form);
        if (funcs == null)
            funcs = [];
        funcs.push(func);
        FormDefinitions.ondisc.set(form, funcs);
    }
    static setOnDestroy(form, func) {
        let funcs = FormDefinitions.ondest.get(form);
        if (funcs == null)
            funcs = [];
        funcs.push(func);
        FormDefinitions.ondest.set(form, funcs);
    }
    static getOnInit(form) {
        let funcs = FormDefinitions.oninit.get(form);
        if (funcs == null)
            funcs = [];
        return (funcs);
    }
    static getOnShow(form) {
        let funcs = FormDefinitions.onshow.get(form);
        if (funcs == null)
            funcs = [];
        return (funcs);
    }
    static getOnHide(form) {
        let funcs = FormDefinitions.onhide.get(form);
        if (funcs == null)
            funcs = [];
        return (funcs);
    }
    static getOnConnect(form) {
        let funcs = FormDefinitions.onconn.get(form);
        if (funcs == null)
            funcs = [];
        return (funcs);
    }
    static getOnDisconnect(form) {
        let funcs = FormDefinitions.ondisc.get(form);
        if (funcs == null)
            funcs = [];
        return (funcs);
    }
    static getOnDestroy(form) {
        let funcs = FormDefinitions.ondest.get(form);
        if (funcs == null)
            funcs = [];
        return (funcs);
    }
}
FormDefinitions.forms = [];
FormDefinitions.oninit = new Map();
FormDefinitions.onshow = new Map();
FormDefinitions.onhide = new Map();
FormDefinitions.onconn = new Map();
FormDefinitions.ondisc = new Map();
FormDefinitions.ondest = new Map();
FormDefinitions.windowopts = new Map();

const form = (component, title, path, navigable) => {
    function define(_comp) {
        let def = {
            path: path,
            title: title,
            component: component,
        };
        if (navigable != undefined)
            def["navigable"] = navigable;
        FormDefinitions.setForm(def);
    }
    return (define);
};

const init = (form, func) => {
    let utils = new Utils();
    let fname = utils.getName(form);
    let ctype = utils.getType(form);
    if (ctype != "Form") {
        console.log("@init can only be used on forms, found on '" + fname + "'");
        return;
    }
    FormDefinitions.setOnInit(fname, func);
};

const show = (form, func) => {
    let utils = new Utils();
    let fname = utils.getName(form);
    let ctype = utils.getType(form);
    if (ctype != "Form") {
        console.log("@show can only be used on forms, found on '" + fname + "'");
        return;
    }
    FormDefinitions.setOnShow(fname, func);
};

const hide = (form, func) => {
    let utils = new Utils();
    let fname = utils.getName(form);
    let ctype = utils.getType(form);
    if (ctype != "Form") {
        console.log("@hide can only be used on forms, found on '" + fname + "'");
        return;
    }
    FormDefinitions.setOnHide(fname, func);
};

class JOINDefinitions {
    static add(form, def) {
        let joins = JOINDefinitions.defs.get(form);
        if (joins == null) {
            joins = [];
            JOINDefinitions.defs.set(form, joins);
        }
        joins.unshift(def);
    }
    static get(form) {
        return (JOINDefinitions.defs.get(form.toLowerCase()));
    }
}
JOINDefinitions.defs = new Map();

const join = (definition) => {
    function define(comp) {
        let utils = new Utils();
        let form = utils.getName(comp);
        let ctype = utils.getType(comp);
        if (ctype != "Form") {
            console.log("@join(" + JSON.stringify(definition) + ") can only be used on forms");
            return;
        }
        definition.master.key = definition.master.key.toLowerCase();
        definition.master.alias = definition.master.alias.toLowerCase();
        definition.detail.key = definition.detail.key.toLowerCase();
        definition.detail.alias = definition.detail.alias.toLowerCase();
        JOINDefinitions.add(form.toLowerCase(), definition);
    }
    return (define);
};

const block = (definition) => {
    function define(comp, prop) {
        let utils = new Utils();
        let name = utils.getName(comp);
        let type = utils.getType(comp);
        if (type != "Form" && prop == null) {
            console.log("@block can only be used with forms");
            return;
        }
        if (definition.alias != null)
            definition.alias = definition.alias.toLowerCase();
        let def = {
            prop: prop,
            alias: definition.alias,
            component: definition.component,
            databaseopts: definition.databaseopts
        };
        BlockDefinitions.setBlock(name, def);
    }
    return (define);
};

const alias = (alias) => {
    function define(comp) {
        let utils = new Utils();
        let cname = utils.getName(comp);
        let ctype = utils.getType(comp);
        if (ctype != "Block") {
            console.log("@alias(" + alias + ") can only be used on blocks");
            return;
        }
        if (alias == null) {
            console.log("@alias(" + alias + ") cannot be null");
            return;
        }
        BlockDefinitions.setDefaultAlias(cname, alias.toLowerCase());
    }
    return (define);
};

class TableDefinitions {
    static set(block, table) {
        let def = TableDefinitions.index.get(block.toLowerCase());
        if (def != null) {
            if (table.hasOwnProperty("name"))
                def.name = table.name;
            if (table.hasOwnProperty("order"))
                def.order = table.order;
        }
        else {
            TableDefinitions.index.set(block.toLowerCase(), table);
        }
    }
    static get(block) {
        return (TableDefinitions.index.get(block.toLowerCase()));
    }
}
TableDefinitions.index = new Map();

const table = (definition) => {
    function define(comp) {
        let utils = new Utils();
        let cname = utils.getName(comp);
        let ctype = utils.getType(comp);
        if (ctype != "Block") {
            console.log("@table(" + definition.name + ") can only be used on blocks");
            return;
        }
        TableDefinitions.set(cname, definition);
    }
    return (define);
};

class FieldDefinitions {
    static add(form, comp, def) {
        let parts = FieldDefinitions.split(def.name);
        if (form) {
            if (parts.length < 2 || parts.length > 3) {
                console.log("Form field " + def.name + " must be on the form block.field[.id], field definition ignored");
                return;
            }
            def.name = parts[1];
            let id = null;
            let block = parts[0];
            if (parts.length > 2)
                id = parts[2];
            if (id != null)
                FieldDefinitions.addformid(comp, block, id, def);
            else
                FieldDefinitions.addformfield(comp, block, def);
        }
        else {
            if (parts.length > 2) {
                console.log("Block field " + def.name + " must be on the form field[.id], field definition ignored");
                return;
            }
            let id = null;
            if (parts.length > 1) {
                id = parts[1];
                def.name = parts[0];
            }
            if (id != null)
                FieldDefinitions.addblockid(comp, id, def);
            else
                FieldDefinitions.addblockfield(comp, def);
        }
    }
    static addformfield(form, block, def) {
        let formbfd = FieldDefinitions.ffd.get(form);
        let formbfx = FieldDefinitions.ffx.get(form);
        let formbcx = FieldDefinitions.fcx.get(form);
        if (formbfd == null) {
            formbfd = new Map();
            FieldDefinitions.ffd.set(form, formbfd);
            formbfx = new Map();
            FieldDefinitions.ffx.set(form, formbfx);
            formbcx = new Map();
            FieldDefinitions.fcx.set(form, formbcx);
        }
        let fields = formbfd.get(block);
        let index = formbfx.get(block);
        let columns = formbcx.get(block);
        if (fields == null) {
            fields = [];
            formbfd.set(block, fields);
            index = new Map();
            formbfx.set(block, index);
            columns = new Map();
            formbcx.set(block, columns);
        }
        if (index.get(def.name) != null) {
            console.log("Field " + def.name + " defined twice on block '" + form + "." + block + "', ignored");
            return;
        }
        if (columns.get(def.name) != null) {
            console.log("Column " + def.column + " bound to more than 1 field on block '" + form + "." + block + "', ignored");
            def.column = null;
        }
        fields.unshift(def);
        index.set(def.name, def);
        if (def.column != null)
            columns.set(def.column, def);
    }
    static addblockfield(block, def) {
        let fields = FieldDefinitions.bfd.get(block);
        let index = FieldDefinitions.bfx.get(block);
        let columns = FieldDefinitions.bcx.get(block);
        if (fields == null) {
            fields = [];
            FieldDefinitions.bfd.set(block, fields);
            index = new Map();
            FieldDefinitions.bfx.set(block, index);
            columns = new Map();
            FieldDefinitions.bcx.set(block, columns);
        }
        if (def.hasOwnProperty("column")) {
            if (def.column != null)
                def.column = def.column.toLowerCase();
        }
        if (index.get(def.name) != null) {
            console.log("Field " + def.name + " defined twice on block '" + block + "', ignored");
            return;
        }
        if (columns.get(def.name) != null) {
            console.log("Column " + def.column + " bound to more than 1 field on block '" + block + "', ignored");
            def.column = null;
        }
        fields.unshift(def);
        index.set(def.name, def);
        if (def.column != null)
            columns.set(def.column, def);
    }
    static addformid(form, block, id, def) {
        let formids = FieldDefinitions.fidx.get(form);
        if (formids == null) {
            formids = new Map();
            FieldDefinitions.fidx.set(form, formids);
        }
        let blockids = formids.get(block);
        if (blockids == null) {
            blockids = new Map();
            formids.set(block, blockids);
        }
        if (blockids.get(def.name + "." + id) != null) {
            console.log("Field " + form + "." + def.name + "." + id + " defined twice, ignored");
            return;
        }
        if (def.column != null) {
            console.log("Field " + form + "." + def.name + "." + id + " cannot override column definition, ignored");
            def.column = null;
        }
        blockids.set(def.name + "." + id, def);
    }
    static addblockid(block, id, def) {
        let blockids = FieldDefinitions.bidx.get(block);
        if (blockids == null) {
            blockids = new Map();
            FieldDefinitions.bidx.set(block, blockids);
        }
        if (blockids.get(def.name + "." + id) != null) {
            console.log("Field " + def.name + "." + id + " defined twice, ignored");
            return;
        }
        if (def.column != null) {
            console.log("Field " + def.name + "." + id + " cannot override column definition, ignored");
            def.column = null;
        }
        blockids.set(def.name + "." + id, def);
    }
    static getFormFieldOverride(form, block, fldid) {
        let formids = FieldDefinitions.fidx.get(form);
        if (formids == null)
            return (null);
        let blockids = formids.get(block.toLowerCase());
        if (blockids != null)
            return (blockids.get(fldid.toLowerCase()));
        return (null);
    }
    static getFieldOverride(block, fldid) {
        let blockids = FieldDefinitions.bidx.get(block.toLowerCase());
        if (blockids != null)
            return (blockids.get(fldid.toLowerCase()));
        return (null);
    }
    static getFormFields(form, block) {
        let formbfd = FieldDefinitions.ffd.get(form.toLowerCase());
        if (formbfd == null)
            return ([]);
        let fields = formbfd.get(block.toLowerCase());
        if (fields == null)
            return ([]);
        return (fields);
    }
    static getFields(block) {
        let fields = FieldDefinitions.bfd.get(block.toLowerCase());
        if (fields == null)
            return ([]);
        return (fields);
    }
    static getFormFieldIndex(form, block) {
        let formbfx = FieldDefinitions.ffx.get(form.toLowerCase());
        if (formbfx == null)
            return (new Map());
        let index = formbfx.get(block.toLowerCase());
        if (index == null)
            return (new Map());
        return (new Map(index));
    }
    static getFieldIndex(block) {
        let index = FieldDefinitions.bfx.get(block.toLowerCase());
        if (index == null)
            return (new Map());
        return (new Map(index));
    }
    static getFormColumnIndex(form, block) {
        let formbcx = FieldDefinitions.fcx.get(form.toLowerCase());
        if (formbcx == null)
            return (new Map());
        let index = formbcx.get(block.toLowerCase());
        if (index == null)
            return (new Map());
        return (new Map(index));
    }
    static getColumnIndex(block) {
        let index = FieldDefinitions.bcx.get(block.toLowerCase());
        if (index == null)
            index = new Map();
        return (new Map(index));
    }
    static split(name) {
        let tokens = name.split(".");
        for (let i = 0; i < tokens.length; i++)
            tokens[i] = tokens[i].trim().toLowerCase();
        return (tokens);
    }
}
// List and indexes for fields, columns and fields with id, respectively for form
FieldDefinitions.bfd = new Map();
FieldDefinitions.bfx = new Map();
FieldDefinitions.bcx = new Map();
FieldDefinitions.bidx = new Map();
FieldDefinitions.ffd = new Map();
FieldDefinitions.ffx = new Map();
FieldDefinitions.fcx = new Map();
FieldDefinitions.fidx = new Map();

const field = (definition) => {
    function define(comp) {
        let form = false;
        let utils = new Utils();
        let cname = utils.getName(comp);
        let ctype = utils.getType(comp);
        if (ctype != "Block" && ctype != "Form") {
            console.log("@field(" + JSON.stringify(definition) + ") can only be used on blocks and forms");
            return;
        }
        if (ctype == "Form")
            form = true;
        FieldDefinitions.add(form, cname, definition);
    }
    return (define);
};

class ColumnDefinitions {
    static add(block, def) {
        let columns = ColumnDefinitions.bcols.get(block);
        let index = ColumnDefinitions.bcidx.get(block);
        if (columns == null) {
            columns = [];
            ColumnDefinitions.bcols.set(block, columns);
            index = new Map();
            ColumnDefinitions.bcidx.set(block, index);
        }
        if (index.get(def.name) != null) {
            console.log("Block " + block + " column " + def.name + " defined twice, ignored");
            return;
        }
        columns.unshift(def);
        index.set(def.name, def);
    }
    static get(block) {
        let columns = ColumnDefinitions.bcols.get(block.toLowerCase());
        if (columns == null)
            columns = [];
        return (columns);
    }
    static getIndex(block) {
        let index = ColumnDefinitions.bcidx.get(block.toLowerCase());
        if (index == null)
            index = new Map();
        return (index);
    }
}
ColumnDefinitions.bcols = new Map();
ColumnDefinitions.bcidx = new Map();

const column = (definition) => {
    function define(comp) {
        let utils = new Utils();
        let cname = utils.getName(comp);
        let ctype = utils.getType(comp);
        if (ctype != "Block") {
            console.log("@column(" + definition.name + "," + definition.type + ") can only be used on blocks");
            return;
        }
        ColumnDefinitions.add(cname, definition);
        definition.name = definition.name.toLowerCase();
    }
    return (define);
};

const wizard = () => {
    function define(form) {
        let utils = new Utils();
        let fname = utils.getName(form);
        let ctype = utils.getType(form);
        if (ctype != "Form") {
            console.log("@wizard can only be used on forms");
            return;
        }
        let wopt = FormDefinitions.getWindowOpts(fname);
        wopt.wizard = true;
    }
    return (define);
};

const window$1 = (inherit, width, height, top, left) => {
    function define(form) {
        let utils = new Utils();
        let fname = utils.getName(form);
        let ctype = utils.getType(form);
        if (ctype != "Form") {
            console.log("@window can only be used on forms");
            return;
        }
        if (top != null && top.constructor.name == "Number")
            top += "px";
        if (left != null && left.constructor.name == "Number")
            left += "px";
        if (width != null && width.constructor.name == "Number")
            width += "px";
        if (height != null && height.constructor.name == "Number")
            height += "px";
        let wopt = FormDefinitions.getWindowOpts(fname);
        wopt.inherit = inherit;
        wopt.offsetTop = "" + top;
        wopt.width = "" + width;
        wopt.height = "" + height;
        wopt.offsetLeft = "" + left;
    }
    return (define);
};

const connect = (form, func) => {
    let utils = new Utils();
    let fname = utils.getName(form);
    let ctype = utils.getType(form);
    if (ctype != "Form") {
        console.log("@connect can only be used on forms, found on '" + fname + "'");
        return;
    }
    FormDefinitions.setOnConnect(fname, func);
};

const destroy = (form, func) => {
    let utils = new Utils();
    let fname = utils.getName(form);
    let ctype = utils.getType(form);
    if (ctype != "Form") {
        console.log("@destroy can only be used on forms, found on '" + fname + "'");
        return;
    }
    FormDefinitions.setOnDestroy(fname, func);
};

var keymap;
(function (keymap) {
    keymap[keymap["enter"] = 0] = "enter";
    keymap[keymap["escape"] = 1] = "escape";
    keymap[keymap["undo"] = 2] = "undo";
    keymap[keymap["paste"] = 3] = "paste";
    keymap[keymap["close"] = 4] = "close";
    keymap[keymap["listval"] = 5] = "listval";
    keymap[keymap["delete"] = 6] = "delete";
    keymap[keymap["dublicate"] = 7] = "dublicate";
    keymap[keymap["insertafter"] = 8] = "insertafter";
    keymap[keymap["insertbefore"] = 9] = "insertbefore";
    keymap[keymap["commit"] = 10] = "commit";
    keymap[keymap["rollback"] = 11] = "rollback";
    keymap[keymap["connect"] = 12] = "connect";
    keymap[keymap["disconnect"] = 13] = "disconnect";
    keymap[keymap["nextfield"] = 14] = "nextfield";
    keymap[keymap["prevfield"] = 15] = "prevfield";
    keymap[keymap["nextblock"] = 16] = "nextblock";
    keymap[keymap["prevblock"] = 17] = "prevblock";
    keymap[keymap["nextrecord"] = 18] = "nextrecord";
    keymap[keymap["prevrecord"] = 19] = "prevrecord";
    keymap[keymap["pageup"] = 20] = "pageup";
    keymap[keymap["pagedown"] = 21] = "pagedown";
    keymap[keymap["clearform"] = 22] = "clearform";
    keymap[keymap["clearblock"] = 23] = "clearblock";
    keymap[keymap["enterquery"] = 24] = "enterquery";
    keymap[keymap["executequery"] = 25] = "executequery";
    keymap[keymap["zoom"] = 26] = "zoom";
})(keymap || (keymap = {}));
class KeyMapper {
    static index(map) {
        Object.keys(map).forEach((key) => {
            let val = map[key];
            let km = keymap[key];
            KeyMapper.keys.set(val, km);
        });
    }
    static keymap(key) {
        return (KeyMapper.keys.get(key));
    }
    static map(key) {
        let sig = key.code + ":";
        sig += key.shift ? "t" : "f";
        sig += key.ctrl ? "t" : "f";
        sig += key.alt ? "t" : "f";
        sig += key.meta ? "t" : "f";
        return (sig);
    }
    static parse(key) {
        let pos = key.indexOf(":");
        let shf = key[pos + 1] == 't';
        let ctl = key[pos + 2] == 't';
        let alt = key[pos + 3] == 't';
        let mta = key[pos + 4] == 't';
        let code = +key.substring(0, pos);
        return ({ code: code, shift: shf, ctrl: ctl, alt: alt, meta: mta });
    }
}
KeyMapper.keys = new Map();

class TriggerEvents {
    constructor() {
        this.types = new Map();
        this.fields = new Map();
    }
}

var Trigger;
(function (Trigger) {
    Trigger[Trigger["Key"] = 0] = "Key";
    Trigger[Trigger["Lock"] = 1] = "Lock";
    Trigger[Trigger["Typing"] = 2] = "Typing";
    Trigger[Trigger["MouseClick"] = 3] = "MouseClick";
    Trigger[Trigger["MouseDoubleClick"] = 4] = "MouseDoubleClick";
    Trigger[Trigger["PreField"] = 5] = "PreField";
    Trigger[Trigger["PostField"] = 6] = "PostField";
    Trigger[Trigger["PostChange"] = 7] = "PostChange";
    Trigger[Trigger["KeyPrevField"] = 8] = "KeyPrevField";
    Trigger[Trigger["KeyNextField"] = 9] = "KeyNextField";
    Trigger[Trigger["KeyPrevBlock"] = 10] = "KeyPrevBlock";
    Trigger[Trigger["KeyNextBlock"] = 11] = "KeyNextBlock";
    Trigger[Trigger["KeyEnterQuery"] = 12] = "KeyEnterQuery";
    Trigger[Trigger["KeyExecuteQuery"] = 13] = "KeyExecuteQuery";
    Trigger[Trigger["WhenValidateField"] = 14] = "WhenValidateField";
    Trigger[Trigger["WhenValidateRecord"] = 15] = "WhenValidateRecord";
    Trigger[Trigger["PreQuery"] = 16] = "PreQuery";
    Trigger[Trigger["PostQuery"] = 17] = "PostQuery";
    Trigger[Trigger["PreInsert"] = 18] = "PreInsert";
    Trigger[Trigger["PreUpdate"] = 19] = "PreUpdate";
    Trigger[Trigger["PreDelete"] = 20] = "PreDelete";
})(Trigger || (Trigger = {}));
var FieldTrigger;
(function (FieldTrigger) {
    FieldTrigger[FieldTrigger["Key"] = 0] = "Key";
    FieldTrigger[FieldTrigger["Typing"] = 1] = "Typing";
    FieldTrigger[FieldTrigger["MouseClick"] = 2] = "MouseClick";
    FieldTrigger[FieldTrigger["MouseDoubleClick"] = 3] = "MouseDoubleClick";
    FieldTrigger[FieldTrigger["PreField"] = 4] = "PreField";
    FieldTrigger[FieldTrigger["PostField"] = 5] = "PostField";
    FieldTrigger[FieldTrigger["PostChange"] = 6] = "PostChange";
    FieldTrigger[FieldTrigger["WhenValidateField"] = 7] = "WhenValidateField";
    FieldTrigger[FieldTrigger["WhenValidateRecord"] = 8] = "WhenValidateRecord";
})(FieldTrigger || (FieldTrigger = {}));
class Triggers {
    constructor() {
        this.triggers = new TriggerEvents();
    }
    static init() {
        if (Triggers.fieldtriggers == null) {
            Triggers.fieldtriggers = new Set();
            Object.keys(FieldTrigger).forEach((type) => {
                if (isNaN(Number(type)))
                    Triggers.fieldtriggers.add(type);
            });
        }
    }
    addTrigger(instance, func, ttypes, tfields, tkeys) {
        let keys = [];
        let fields = [];
        let types = [];
        let tasa = false;
        if (ttypes.constructor.name == "Array")
            tasa = true;
        if (tasa)
            types = ttypes;
        else
            types.push(ttypes);
        if (tfields != null) {
            let fasa = false;
            if (tfields.constructor.name == "Array")
                fasa = true;
            if (fasa)
                fields = tfields;
            else
                fields.push(tfields);
        }
        if (tkeys != null) {
            let kasa = false;
            if (tkeys.constructor.name == "Array")
                kasa = true;
            if (kasa)
                keys = tkeys;
            else
                keys.push(tkeys);
        }
        if (fields.length > 0) {
            fields.forEach((field) => {
                field = field.toLowerCase();
                let triggers = this.triggers.fields.get(field);
                if (triggers == null) {
                    triggers = new Map();
                    this.triggers.fields.set(field, triggers);
                }
                types.forEach((type) => {
                    if (type == Trigger.Key) {
                        keys.forEach((key) => {
                            let code = this.keycode(key);
                            let lsnrs = triggers.get(code);
                            if (lsnrs == null) {
                                lsnrs = [];
                                triggers.set(code, lsnrs);
                            }
                            lsnrs.push({ inst: instance, func: func });
                        });
                    }
                    else if (this.isFieldTrigger(type)) {
                        let name = this.trgname(type);
                        let lsnrs = triggers.get(name);
                        if (lsnrs == null) {
                            lsnrs = [];
                            triggers.set(name, lsnrs);
                        }
                        lsnrs.push({ inst: instance, func: func });
                    }
                });
            });
        }
        else {
            types.forEach((type) => {
                if (type == Trigger.Key) {
                    keys.forEach((key) => {
                        let code = this.keycode(key);
                        let lsnrs = this.triggers.types.get(code);
                        if (lsnrs == null) {
                            lsnrs = [];
                            this.triggers.types.set(code, lsnrs);
                        }
                        lsnrs.push({ inst: instance, func: func });
                    });
                }
                else {
                    let name = this.trgname(type);
                    let lsnrs = this.triggers.types.get(name);
                    if (lsnrs == null) {
                        lsnrs = [];
                        this.triggers.types.set(name, lsnrs);
                    }
                    lsnrs.push({ inst: instance, func: func });
                }
            });
        }
    }
    invokeTriggers(type, event, key) {
        return __awaiter(this, void 0, void 0, function* () {
            event["type$"] = type;
            if (type == Trigger.Key && key != null) {
                let code = this.keycode(key);
                let lsnrs = this.triggers.types.get(code);
                if (lsnrs != null) {
                    for (let i = 0; i < lsnrs.length; i++)
                        if (!(yield this.execfunc(lsnrs[i], event)))
                            return (false);
                }
            }
            else {
                let name = this.trgname(type);
                let lsnrs = this.triggers.types.get(name);
                if (lsnrs != null) {
                    for (let i = 0; i < lsnrs.length; i++)
                        if (!(yield this.execfunc(lsnrs[i], event)))
                            return (false);
                }
            }
            return (true);
        });
    }
    invokeFieldTriggers(type, field, event, key) {
        return __awaiter(this, void 0, void 0, function* () {
            let triggers = this.triggers.fields.get(field);
            if (triggers == null)
                return (this.invokeTriggers(type, event, key));
            event["type$"] = type;
            if (type == Trigger.Key && key != null) {
                let code = this.keycode(key);
                let lsnrs = triggers.get(code);
                if (lsnrs != null) {
                    for (let i = 0; i < lsnrs.length; i++)
                        if (!(yield this.execfunc(lsnrs[i], event)))
                            return (false);
                }
            }
            else {
                let name = this.trgname(type);
                let lsnrs = triggers.get(name);
                if (lsnrs != null) {
                    for (let i = 0; i < lsnrs.length; i++)
                        if (!(yield this.execfunc(lsnrs[i], event)))
                            return (false);
                }
            }
            return (this.invokeTriggers(type, event, key));
        });
    }
    execfunc(lsnr, event) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return (yield lsnr.inst[lsnr.func.name](event));
            }
            catch (error) {
                console.log(error);
                return (false);
            }
        });
    }
    isFieldTrigger(trigger) {
        Triggers.init();
        return (Triggers.fieldtriggers.has(Trigger[trigger]));
    }
    trgname(trigger) {
        return (Trigger[trigger].toLowerCase());
    }
    keycode(key) {
        return (keymap[key].toLowerCase());
    }
}
Triggers.fieldtriggers = null;

class TriggerDefinitions {
    static add(isblock, cname, def) {
        if (def.key == null)
            this.addft(isblock, cname, def);
        else
            this.addkt(isblock, cname, def);
    }
    static addkt(isblock, cname, def) {
        if (isblock)
            TriggerDefinitions.addKeyTrigger(cname, def);
        else
            TriggerDefinitions.addFormKeyTrigger(cname, def);
    }
    static addft(isblock, cname, def) {
        let parts = TriggerDefinitions.split(def.field);
        if (isblock && parts.length > 1) {
            console.log("trigger must specify field without '.' or ' '");
            return;
        }
        if (!isblock && parts.length > 2) {
            console.log("trigger must specify blockalias.field without ' '");
            return;
        }
        let form = null;
        let block = null;
        let field = null;
        if (isblock) {
            block = cname;
            if (parts.length > 0)
                field = parts.shift();
        }
        else {
            form = cname;
            block = parts.shift();
            def.block = block;
            if (parts.length > 0)
                field = parts.shift();
        }
        def.field = field;
        if (isblock)
            TriggerDefinitions.addFieldTrigger(block, field, def);
        else
            TriggerDefinitions.addFormFieldTrigger(form, block, field, def);
    }
    static addFieldTrigger(block, field, def) {
        let triggers = TriggerDefinitions.bftriggers.get(block);
        if (triggers == null) {
            triggers = new Map();
            TriggerDefinitions.bftriggers.set(block, triggers);
        }
        triggers.set(field + "[" + Trigger[def.trigger] + "]", def);
    }
    static addKeyTrigger(block, def) {
        let triggers = TriggerDefinitions.bktriggers.get(block);
        if (triggers == null) {
            triggers = new Map();
            TriggerDefinitions.bktriggers.set(block, triggers);
        }
        triggers.set(keymap[def.key] + "[" + Trigger[def.trigger] + "]", def);
    }
    static addFormFieldTrigger(form, block, field, def) {
        if (block == null)
            block = "";
        let ftriggers = TriggerDefinitions.fftriggers.get(form);
        if (ftriggers == null) {
            ftriggers = new Map();
            TriggerDefinitions.fftriggers.set(form, ftriggers);
        }
        let triggers = ftriggers.get(block);
        if (triggers == null) {
            triggers = new Map();
            ftriggers.set(block, triggers);
        }
        triggers.set(field + "[" + Trigger[def.trigger] + "]", def);
    }
    static addFormKeyTrigger(form, def) {
        let triggers = TriggerDefinitions.fktriggers.get(form);
        if (triggers == null) {
            triggers = new Map();
            TriggerDefinitions.fktriggers.set(form, triggers);
        }
        triggers.set(keymap[def.key] + "[" + Trigger[def.trigger] + "]", def);
    }
    static getFieldTriggers(block) {
        return (new Map(TriggerDefinitions.bftriggers.get(block.toLowerCase())));
    }
    static getKeyTriggers(block) {
        return (new Map(TriggerDefinitions.bktriggers.get(block.toLowerCase())));
    }
    static getFormFieldTriggers(form, block) {
        if (block == null)
            block = "";
        let triggers = TriggerDefinitions.fftriggers.get(form.toLowerCase());
        if (triggers != null)
            return (new Map(triggers.get(block.toLowerCase())));
        return (new Map());
    }
    static getFormKeyTriggers(form) {
        return (new Map(TriggerDefinitions.fktriggers.get(form.toLowerCase())));
    }
    static split(name) {
        if (name == null)
            return ([]);
        let tokens = name.trim().split(".");
        for (let i = 0; i < tokens.length; i++)
            tokens[i] = tokens[i].trim().toLowerCase();
        return (tokens);
    }
}
TriggerDefinitions.bftriggers = new Map();
TriggerDefinitions.bktriggers = new Map();
TriggerDefinitions.fktriggers = new Map();
TriggerDefinitions.fftriggers = new Map();

const trigger = (trigger, field) => {
    function define(comp, func) {
        let utils = new Utils();
        let cname = utils.getName(comp);
        let ctype = utils.getType(comp);
        let params = utils.getParams(comp[func]);
        if (params.length != 1) {
            console.log("function " + func + " must take 1 TriggerEvent argument");
            return;
        }
        if (ctype != "Block" && ctype != "Form") {
            console.log("@trigger can only be applied on Block or Form");
            return;
        }
        let blktrg = false;
        if (ctype == "Block")
            blktrg = true;
        let fields = [];
        if (field == null)
            field = [null];
        if (field.constructor.name == "Array")
            fields = field;
        else
            fields.push(field);
        fields.forEach((fld) => {
            let trg = {
                field: fld,
                block: null,
                blktrg: blktrg,
                params: params,
                func: comp[func],
                trigger: trigger
            };
            TriggerDefinitions.add(blktrg, cname, trg);
        });
    }
    return (define);
};

class DBUsage {
    static merge(changes, base) {
        let utils = new Utils();
        if (changes == null)
            return (base);
        let merged = utils.clone(base);
        if (changes.hasOwnProperty("query"))
            merged.query = changes.query;
        if (changes.hasOwnProperty("insert"))
            merged.insert = changes.insert;
        if (changes.hasOwnProperty("update"))
            merged.update = changes.update;
        if (changes.hasOwnProperty("delete"))
            merged.delete = changes.delete;
        return (merged);
    }
    static override(overide, base) {
        let utils = new Utils();
        if (overide == null)
            return (base);
        let merged = utils.clone(base);
        if (overide.hasOwnProperty("query") && !overide.query)
            merged.query = false;
        if (overide.hasOwnProperty("insert") && !overide.insert)
            merged.insert = false;
        if (overide.hasOwnProperty("update") && !overide.update)
            merged.update = false;
        if (overide.hasOwnProperty("delete") && !overide.delete)
            merged.delete = false;
        return (merged);
    }
    static complete(base) {
        let utils = new Utils();
        if (base == null)
            base = {};
        else
            base = utils.clone(base);
        if (!base.hasOwnProperty("query"))
            base.query = true;
        if (!base.hasOwnProperty("insert"))
            base.insert = true;
        if (!base.hasOwnProperty("update"))
            base.update = true;
        if (!base.hasOwnProperty("delete"))
            base.delete = true;
        return (base);
    }
}

class DatabaseDefinitions {
    static setFormUsage(form, usage) {
        DatabaseDefinitions.fdefault.set(form, usage);
    }
    static getFormUsage(form) {
        let usage = DatabaseDefinitions.fdefault.get(form.toLowerCase());
        return (usage);
    }
    static setBlockDefault(block, usage) {
        DatabaseDefinitions.bdefault.set(block, usage);
    }
    static getBlockDefault(block) {
        let usage = null;
        let base = {
            query: true,
            insert: true,
            update: true,
            delete: true
        };
        if (block != null)
            usage = DatabaseDefinitions.bdefault.get(block.toLowerCase());
        return (DBUsage.merge(usage, base));
    }
}
DatabaseDefinitions.bdefault = new Map();
DatabaseDefinitions.fdefault = new Map();

const database = (usage) => {
    function define(component) {
        let utils = new Utils();
        let comp = utils.getName(component);
        let type = utils.getType(component);
        if (type == "Form") {
            DatabaseDefinitions.setFormUsage(comp, usage);
            return;
        }
        if (type == "Block") {
            DatabaseDefinitions.setBlockDefault(comp, usage);
            return;
        }
        console.log("@database can only be used in conjunction with Form or Block");
    }
    return (define);
};

const keytrigger = (key) => {
    function define(comp, func) {
        let utils = new Utils();
        let cname = utils.getName(comp);
        let ctype = utils.getType(comp);
        let params = utils.getParams(comp[func]);
        if (params.length != 1) {
            console.log("function " + func + " must take 1 TriggerEvent argument");
            return;
        }
        if (ctype != "Block" && ctype != "Form") {
            console.log("@keytrigger can only be applied on Block or Form");
            return;
        }
        let block = false;
        if (ctype == "Block")
            block = true;
        let keys = [];
        if (key.constructor.name == "Array")
            keys = key;
        else
            keys.push(key);
        keys.forEach((key) => {
            let trg = {
                key: key,
                block: null,
                blktrg: block,
                params: params,
                func: comp[func],
                trigger: Trigger.Key
            };
            TriggerDefinitions.add(block, cname, trg);
        });
    }
    return (define);
};

const disconnect = (form, func) => {
    let utils = new Utils();
    let fname = utils.getName(form);
    let ctype = utils.getType(form);
    if (ctype != "Form") {
        console.log("@disconnect can only be used on forms, found on '" + fname + "'");
        return;
    }
    FormDefinitions.setOnDisconnect(fname, func);
};

class LOVDefinitions {
    static add(isblock, cname, fieldspec, inst, func, params) {
        let form = null;
        let block = null;
        let field = null;
        let id = false;
        let parts = LOVDefinitions.split(fieldspec);
        if (isblock) {
            block = cname;
        }
        else {
            form = cname;
            block = parts.shift();
        }
        if (parts.length == 0 || parts.length > 2) {
            console.log("@listofvalues must specify [alias.]field[.id], not '" + fieldspec + "'");
            return;
        }
        field = parts.shift();
        if (parts.length > 0) {
            id = true;
            field += "." + parts.shift();
        }
        let def = {
            inst: inst,
            func: func,
            params: params
        };
        if (form != null) {
            if (!id)
                LOVDefinitions.addFormLov(form, block, field, def);
            else
                LOVDefinitions.addFormIdLov(form, block, field, def);
        }
        else {
            if (!id)
                LOVDefinitions.addBlockLov(block, field, def);
            else
                LOVDefinitions.addBlockIdLov(block, field, def);
        }
    }
    static addFormLov(form, block, field, def) {
        let fdefs = LOVDefinitions.fdefs.get(form);
        if (fdefs == null) {
            fdefs = new Map();
            LOVDefinitions.fdefs.set(form, fdefs);
        }
        let bdefs = fdefs.get(block);
        if (bdefs == null) {
            bdefs = new Map();
            fdefs.set(block, bdefs);
        }
        bdefs.set(field, def);
    }
    static addFormIdLov(form, block, field, def) {
        let fdefs = LOVDefinitions.fiddefs.get(form);
        if (fdefs == null) {
            fdefs = new Map();
            LOVDefinitions.fiddefs.set(form, fdefs);
        }
        let bdefs = fdefs.get(block);
        if (bdefs == null) {
            bdefs = new Map();
            fdefs.set(block, bdefs);
        }
        bdefs.set(field, def);
    }
    static addBlockLov(block, field, def) {
        let bdefs = LOVDefinitions.bdefs.get(block);
        if (bdefs == null) {
            bdefs = new Map();
            LOVDefinitions.bdefs.set(block, bdefs);
        }
        bdefs.set(field, def);
    }
    static addBlockIdLov(block, field, def) {
        let bdefs = LOVDefinitions.biddefs.get(block);
        if (bdefs == null) {
            bdefs = new Map();
            LOVDefinitions.biddefs.set(block, bdefs);
        }
        bdefs.set(field, def);
    }
    static getblock(block) {
        return (new Map(LOVDefinitions.bdefs.get(block.toLowerCase())));
    }
    static getblockid(block) {
        return (new Map(LOVDefinitions.biddefs.get(block.toLowerCase())));
    }
    static getform(form, block) {
        let fdefs = LOVDefinitions.fdefs.get(form.toLowerCase());
        if (fdefs != null)
            return (new Map(fdefs.get(block.toLowerCase())));
        return (new Map());
    }
    static getidform(form, block) {
        let fdefs = LOVDefinitions.fiddefs.get(form.toLowerCase());
        if (fdefs != null)
            return (new Map(fdefs.get(block.toLowerCase())));
        return (new Map());
    }
    static split(name) {
        let tokens = name.trim().split(".");
        for (let i = 0; i < tokens.length; i++)
            tokens[i] = tokens[i].trim().toLowerCase();
        return (tokens);
    }
}
LOVDefinitions.bdefs = new Map();
LOVDefinitions.biddefs = new Map();
LOVDefinitions.fdefs = new Map();
LOVDefinitions.fiddefs = new Map();

const listofvalues = (field) => {
    function define(comp, func) {
        let utils = new Utils();
        let cname = utils.getName(comp);
        let ctype = utils.getType(comp);
        let params = utils.getParams(comp[func]);
        if (ctype != "Block" && ctype != "Form") {
            console.log("@listofvalues can only be applied on Block or Form");
            return;
        }
        let block = false;
        if (ctype == "Block")
            block = true;
        let fields = [];
        if (field.constructor.name == "Array")
            fields = field;
        else
            fields.push(field);
        fields.forEach((fld) => { LOVDefinitions.add(block, cname, fld, comp, func, params); });
    }
    return (define);
};

var Origin;
(function (Origin) {
    Origin[Origin["Form"] = 0] = "Form";
    Origin[Origin["Block"] = 1] = "Block";
    Origin[Origin["Field"] = 2] = "Field";
})(Origin || (Origin = {}));
class TriggerEvent {
    constructor(block, record, jsevent) {
        this.block$ = block;
        this.record$ = record;
        this.event$ = jsevent;
    }
    get block() {
        return (this.block$);
    }
    get type() {
        return (this.type$);
    }
    get event() {
        return (this.event$);
    }
    get record() {
        return (this.record$);
    }
}
class KeyTriggerEvent extends TriggerEvent {
    constructor(origin, block, field, key, jsevent) {
        super(block, 0, jsevent);
        this.key$ = key;
        this.origin$ = origin;
        if (field != null) {
            this.field$ = field.name;
            this["record$"] = field.row;
        }
    }
    get key() {
        return (this.key$);
    }
    get field() {
        return (this.field$);
    }
    get origin() {
        return (this.origin$);
    }
}
class FieldTriggerEvent extends TriggerEvent {
    constructor(block, field, id, row, value, previous, jsevent) {
        super(block, row, jsevent);
        this.id$ = id;
        this.field$ = field;
        this.value$ = value;
        this.previous$ = previous;
    }
    get value() {
        return (this.value$);
    }
    get field() {
        return (this.field$);
    }
    get id() {
        return (this.id$);
    }
    get previous() {
        return (this.previous$);
    }
}
class SQLTriggerEvent extends TriggerEvent {
    constructor(block, row, stmt) {
        super(block, row, null);
        this.stmt$ = stmt;
    }
    get stmt() {
        return (this.stmt$);
    }
    set stmt(stmt) {
        this.stmt$ = stmt;
    }
}

class Context {
}
Context.ɵprov = ɵɵdefineInjectable({ factory: function Context_Factory() { return new Context(); }, token: Context, providedIn: "root" });
Context.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] }
];

class MenuArea {
    constructor(ctx, change) {
        this.change = change;
        this.app = ctx.app["_impl_"];
    }
    remove() {
        if (this.element != null) {
            let menuelem = this.menu.firstElementChild;
            if (menuelem != null)
                this.menu.removeChild(menuelem);
            this.app.builder.getAppRef().detachView(this.menuref.hostView);
        }
        this.change.detectChanges();
    }
    display(menu) {
        if (menu == null) {
            this.remove();
            return;
        }
        if (this.menu == null) {
            setTimeout(() => { this.display(menu); }, 10);
            return;
        }
        if (this.element != null) {
            let menuelem = this.menu.firstElementChild;
            if (menuelem != null)
                this.menu.removeChild(menuelem);
            this.app.builder.getAppRef().detachView(this.menuref.hostView);
        }
        this.menuref = menu;
        this.element = menu.hostView.rootNodes[0];
        this.app.builder.getAppRef().attachView(this.menuref.hostView);
        this.menu.appendChild(this.element);
        this.change.detectChanges();
    }
    ngAfterViewInit() {
        var _a;
        this.menu = (_a = this.elem) === null || _a === void 0 ? void 0 : _a.nativeElement;
        this.app.setMenuArea(this);
    }
}
MenuArea.decorators = [
    { type: Component, args: [{
                selector: 'menuarea',
                template: `
		<div #menu></div>
	`,
                changeDetection: ChangeDetectionStrategy.OnPush
            },] }
];
MenuArea.ctorParameters = () => [
    { type: Context },
    { type: ChangeDetectorRef }
];
MenuArea.propDecorators = {
    elem: [{ type: ViewChild, args: ["menu", { read: ElementRef },] }]
};

class MenuHandler {
    // dont rename __menu__ as it is set behind the scenes
    constructor() {
        this.__menu__ = null;
        this.guid$ = MenuHandler._id++;
    }
    get guid() {
        return (this.guid$);
    }
    get ready() {
        return (this.__menu__ != null);
    }
    get app() {
        return (this.__menu__.app);
    }
    enable(menu) {
        this.__menu__.enable(menu);
    }
    disable(menu) {
        this.__menu__.disable(menu);
    }
    get connected() {
        return (this.__menu__.isConnected());
    }
    get transaction() {
        return (this.app.transaction);
    }
    // For overwrite by application menus
    onFormChange(form) {
    }
}
MenuHandler._id = 0;

class DefaultMenuHandler extends MenuHandler {
    onInit() {
        this.init();
    }
    onConnect() {
        this.init();
    }
    onDisconnect() {
        this.init();
    }
    onFormChange(form) {
        this.form = form;
        if (this.ready)
            this.init();
    }
    onTransactionChange() {
        if (this.transaction)
            this.enable("/transaction");
        else
            this.disable("/transaction");
    }
    init() {
        this.disable();
        this.enable("/form/shortkeys");
        if (this.form != null) {
            this.enable("/form/close");
            this.enable("/section/next");
            this.enable("/section/previous");
            if (this.connected) {
                this.enable("/form");
                this.enable("/section");
                this.enable("/record");
                this.enable("/connection/disconnect");
            }
            else {
                this.enable("/connection/connect");
            }
        }
        else {
            if (this.connected) {
                this.enable("/connection/disconnect");
            }
            else {
                this.enable("/connection/connect");
            }
        }
        this.onTransactionChange();
    }
    connect() {
        this.app.connect();
        this.init();
    }
    disconnect() {
        this.app.disconnect();
        this.init();
    }
    commit() {
        this.app.commit();
    }
    rollback() {
        this.app.rollback();
    }
    clear() {
        var _a;
        (_a = this.form) === null || _a === void 0 ? void 0 : _a.sendKey(keymap.clearform);
    }
    cancel() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.cancel();
    }
    enterFormQuery() {
        var _a;
        (_a = this.form) === null || _a === void 0 ? void 0 : _a.enterquery();
    }
    executeFormQuery() {
        var _a;
        (_a = this.form) === null || _a === void 0 ? void 0 : _a.executequery();
    }
    enterQuery() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.sendKey(keymap.enterquery);
    }
    executeQuery() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.sendKey(keymap.executequery);
    }
    deleteRecord() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.delete();
    }
    insertRecordAfter() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.insert(false);
    }
    insertRecordBefore() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.insert(true);
    }
    nextRecord() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.nextrecord();
    }
    prevRecord() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.prevrecord();
    }
    nextBlock() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.nextblock();
    }
    prevBlock() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.prevblock();
    }
    pageUp() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.pageup();
    }
    pageDown() {
        var _a, _b;
        (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.pagedown();
    }
    close() {
        var _a;
        (_a = this.form) === null || _a === void 0 ? void 0 : _a.close(false);
        this.init();
    }
    showkeymap() {
        this.app.showKeyMap();
    }
}

class DefaultMenu {
    constructor() {
        this.entries =
            [
                {
                    name: "Form", title: "Form actions", options: [
                        { name: "enter query", action: "enterFormQuery" },
                        { name: "execute query", action: "executeFormQuery" },
                        { name: "clear", action: "clear" },
                        { name: "close", action: "close" },
                        { name: "shortkeys", action: "showkeymap" },
                    ]
                },
                {
                    name: "Section", title: "Block actions", options: [
                        { name: "enter query", action: "enterQuery" },
                        { name: "execute query", action: "executeQuery" },
                        { name: "clear filter", action: "executeQuery" },
                        { name: "next", action: "nextBlock" },
                        { name: "previous", action: "prevBlock" },
                    ]
                },
                {
                    name: "Record", title: "Record actions", options: [
                        { name: "insert below", action: "insertRecordAfter" },
                        { name: "insert above", action: "insertRecordBefore" },
                        { name: "delete", action: "deleteRecord" },
                        { name: "next", action: "nextRecord" },
                        { name: "previous", action: "prevRecord" },
                        { name: "pagedown", action: "pageDown" },
                        { name: "pageup", action: "pageUp" },
                    ]
                },
                {
                    name: "Transaction", title: "Transaction Menu", options: [
                        { name: "commit", action: "commit" },
                        { name: "rollback", action: "rollback" },
                    ]
                },
                {
                    name: "Connection", title: "Connection to database", options: [
                        { name: "connect", action: "connect" },
                        { name: "disconnect", action: "disconnect" },
                    ]
                }
            ];
        this.handler = new DefaultMenuHandler();
    }
    getHandler() {
        return (this.handler);
    }
    getEntries() {
        return (this.entries);
    }
}

class Key {
    constructor(name) {
        this.name = name;
        this.values$ = [];
        this.columns$ = [];
        this.index = new Map();
    }
    get(part) {
        let col = -1;
        if (part.constructor.name == "Number")
            col = +part;
        else
            col = this.index.get("" + part);
        return (this.values$[col]);
    }
    partof(part) {
        return (this.columns$.includes(part, 0));
    }
    set(name, value) {
        let col = -1;
        if (name.constructor.name == "Number")
            col = +name;
        else
            col = this.index.get("" + name);
        this.values$[col] = value;
    }
    addColumn(name) {
        this.index.set(name, this.columns$.length);
        this.values$.push(name);
        this.columns$.push(name);
    }
    columns() {
        return (this.columns$);
    }
    get values() {
        let map = [];
        for (let i = 0; i < this.columns$.length; i++)
            map.push({ name: this.columns$[i], value: this.values$[i] });
        return (map);
    }
    toString() {
        let str = this.name + " [";
        for (let i = 0; i < this.columns$.length; i++)
            str += this.columns$[i] + " = " + this.values$[i] + ", ";
        return (str.substring(0, str.length - 2) + "]");
    }
}

var RecordState;
(function (RecordState) {
    RecordState[RecordState["na"] = 0] = "na";
    RecordState[RecordState["qmode"] = 1] = "qmode";
    RecordState[RecordState["insert"] = 2] = "insert";
    RecordState[RecordState["update"] = 3] = "update";
})(RecordState || (RecordState = {}));
class Record {
    constructor(row, fields, index) {
        this.row$ = 0;
        this.fields$ = [];
        this.current$ = false;
        this.enabled$ = false;
        this.state$ = RecordState.na;
        this.index = new Map();
        this.row$ = row;
        this.index = index;
        this.fields$ = fields;
    }
    set row(row) {
        this.row$ = row;
    }
    get row() {
        return (this.row$);
    }
    get fields() {
        return (this.fields$);
    }
    focus() {
        for (let i = 0; i < this.fields$.length; i++)
            if (this.fields$[i].focus())
                return;
    }
    set current(flag) {
        this.current$ = flag;
        this.fields$.forEach((field) => { field.current = flag; });
    }
    get current() {
        return (this.current$);
    }
    clear() {
        this.fields$.forEach((field) => { field.value = null; field.disable(); });
        if (this.current)
            this.fields$.forEach((field) => { field.current = true; field.disable(); });
    }
    set state(state) {
        this.state$ = state;
        this.fields$.forEach((field) => { field.state = state; });
    }
    get state() {
        return (this.state$);
    }
    get enabled() {
        return (this.enabled$);
    }
    get readonly() {
        for (let i = 0; i < this.fields$.length; i++)
            if (!this.fields$[i].readonly)
                return (false);
        return (true);
    }
    enable(readonly) {
        this.enabled$ = true;
        this.fields$.forEach((field) => {
            field.state = this.state$;
            field.enable(readonly);
        });
    }
    disable() {
        this.enabled$ = false;
        this.fields$.forEach((field) => { field.disable(); });
    }
    getField(name) {
        if (name == null)
            return (null);
        return (this.index.get(name.toLowerCase()));
    }
    getFieldByGuid(name, guid) {
        let field = this.index.get(name.toLowerCase());
        if (field != null)
            return (field.getInstance(guid));
        return (null);
    }
}

class TextField {
    get html() {
        return ("<input type='text'></input>");
    }
    set size(size) {
        this.element$.size = size;
    }
    get tabindex() {
        return (this.element$.tabIndex);
    }
    get element() {
        return (this.element$);
    }
    set tabindex(seq) {
        this.element$.tabIndex = seq;
    }
    set element(element) {
        this.element$ = element;
    }
    get enable() {
        return (!this.element$.disabled);
    }
    set enable(flag) {
        this.element$.disabled = !flag;
    }
    get readonly() {
        return (this.element$.readOnly);
    }
    set readonly(flag) {
        this.element$.readOnly = flag;
    }
    get value() {
        return (this.element$.value);
    }
    set value(value) {
        this.element$.value = value;
    }
    focus() {
        this.element$.focus();
        this.element$.select();
    }
    validate() {
        return (true);
    }
}

class DropDown extends TextField {
    get html() {
        return ("<select></select>");
    }
    focus() {
        this.element$.focus();
    }
}

class Password extends TextField {
    get html() {
        return ("<input type='password'></input>");
    }
}

class CheckBox extends TextField {
    constructor() {
        super(...arguments);
        this.actvalue = null;
        this.chkvalue = null;
    }
    get html() {
        return ("<input type='checkbox'></input>");
    }
    get value() {
        return (this.actvalue);
    }
    set value(value) {
        if (this.chkvalue == null) {
            this.chkvalue = value;
            return;
        }
        this.actvalue = value;
        // cheat compiler
        let checkbox = this.element;
        if (value == this.chkvalue)
            checkbox.checked = true;
        else
            checkbox.checked = false;
    }
}

const token = /d{1,4}|M{1,4}|YY(?:YY)?|S{1,3}|Do|ZZ|Z|([HhMsDm])\1?|[aA]|"[^"]*"|'[^']*'/g;
const twoDigitsOptional = "[1-9]\\d?";
const twoDigits = "\\d\\d";
const threeDigits = "\\d{3}";
const fourDigits = "\\d{4}";
const word = "[^\\s]+";
const literal = /\[([^]*?)\]/gm;
function shorten(arr, sLen) {
    const newArr = [];
    for (let i = 0, len = arr.length; i < len; i++) {
        newArr.push(arr[i].substr(0, sLen));
    }
    return newArr;
}
const monthUpdate = (arrName) => (v, i18n) => {
    const lowerCaseArr = i18n[arrName].map(v => v.toLowerCase());
    const index = lowerCaseArr.indexOf(v.toLowerCase());
    if (index > -1) {
        return index;
    }
    return null;
};
const ɵ0 = monthUpdate;
function assign(origObj, ...args) {
    for (const obj of args) {
        for (const key in obj) {
            // @ts-ignore ex
            origObj[key] = obj[key];
        }
    }
    return origObj;
}
const dayNames = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
];
const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
];
const monthNamesShort = shorten(monthNames, 3);
const dayNamesShort = shorten(dayNames, 3);
const defaultI18n = {
    dayNamesShort,
    dayNames,
    monthNamesShort,
    monthNames,
    amPm: ["am", "pm"],
    DoFn(dayOfMonth) {
        return (dayOfMonth +
            ["th", "st", "nd", "rd"][dayOfMonth % 10 > 3
                ? 0
                : ((dayOfMonth - (dayOfMonth % 10) !== 10 ? 1 : 0) * dayOfMonth) % 10]);
    }
};
let globalI18n = assign({}, defaultI18n);
const setGlobalDateI18n = (i18n) => (globalI18n = assign(globalI18n, i18n));
const ɵ1 = setGlobalDateI18n;
const regexEscape = (str) => str.replace(/[|\\{()[^$+*?.-]/g, "\\$&");
const ɵ2 = regexEscape;
const pad = (val, len = 2) => {
    val = String(val);
    while (val.length < len) {
        val = "0" + val;
    }
    return val;
};
const ɵ3 = pad;
const ɵ4 = (dateObj) => String(dateObj.getDate()), ɵ5 = (dateObj) => pad(dateObj.getDate()), ɵ6 = (dateObj, i18n) => i18n.DoFn(dateObj.getDate()), ɵ7 = (dateObj) => String(dateObj.getDay()), ɵ8 = (dateObj) => pad(dateObj.getDay()), ɵ9 = (dateObj, i18n) => i18n.dayNamesShort[dateObj.getDay()], ɵ10 = (dateObj, i18n) => i18n.dayNames[dateObj.getDay()], ɵ11 = (dateObj) => String(dateObj.getMonth() + 1), ɵ12 = (dateObj) => pad(dateObj.getMonth() + 1), ɵ13 = (dateObj, i18n) => i18n.monthNamesShort[dateObj.getMonth()], ɵ14 = (dateObj, i18n) => i18n.monthNames[dateObj.getMonth()], ɵ15 = (dateObj) => pad(String(dateObj.getFullYear()), 4).substr(2), ɵ16 = (dateObj) => pad(dateObj.getFullYear(), 4), ɵ17 = (dateObj) => String(dateObj.getHours() % 12 || 12), ɵ18 = (dateObj) => pad(dateObj.getHours() % 12 || 12), ɵ19 = (dateObj) => String(dateObj.getHours()), ɵ20 = (dateObj) => pad(dateObj.getHours()), ɵ21 = (dateObj) => String(dateObj.getMinutes()), ɵ22 = (dateObj) => pad(dateObj.getMinutes()), ɵ23 = (dateObj) => String(dateObj.getSeconds()), ɵ24 = (dateObj) => pad(dateObj.getSeconds()), ɵ25 = (dateObj) => String(Math.round(dateObj.getMilliseconds() / 100)), ɵ26 = (dateObj) => pad(Math.round(dateObj.getMilliseconds() / 10), 2), ɵ27 = (dateObj) => pad(dateObj.getMilliseconds(), 3), ɵ28 = (dateObj, i18n) => dateObj.getHours() < 12 ? i18n.amPm[0] : i18n.amPm[1], ɵ29 = (dateObj, i18n) => dateObj.getHours() < 12
    ? i18n.amPm[0].toUpperCase()
    : i18n.amPm[1].toUpperCase();
const formatFlags = {
    D: ɵ4,
    DD: ɵ5,
    Do: ɵ6,
    d: ɵ7,
    dd: ɵ8,
    ddd: ɵ9,
    dddd: ɵ10,
    M: ɵ11,
    MM: ɵ12,
    MMM: ɵ13,
    MMMM: ɵ14,
    YY: ɵ15,
    YYYY: ɵ16,
    h: ɵ17,
    hh: ɵ18,
    H: ɵ19,
    HH: ɵ20,
    m: ɵ21,
    mm: ɵ22,
    s: ɵ23,
    ss: ɵ24,
    S: ɵ25,
    SS: ɵ26,
    SSS: ɵ27,
    a: ɵ28,
    A: ɵ29,
    ZZ(dateObj) {
        const offset = dateObj.getTimezoneOffset();
        return ((offset > 0 ? "-" : "+") +
            pad(Math.floor(Math.abs(offset) / 60) * 100 + (Math.abs(offset) % 60), 4));
    },
    Z(dateObj) {
        const offset = dateObj.getTimezoneOffset();
        return ((offset > 0 ? "-" : "+") +
            pad(Math.floor(Math.abs(offset) / 60), 2) +
            ":" +
            pad(Math.abs(offset) % 60, 2));
    }
};
const monthParse = (v) => +v - 1;
const ɵ30 = monthParse;
const emptyDigits = [null, twoDigitsOptional];
const emptyWord = [null, word];
const ɵ31 = (v, i18n) => {
    const val = v.toLowerCase();
    if (val === i18n.amPm[0]) {
        return 0;
    }
    else if (val === i18n.amPm[1]) {
        return 1;
    }
    return null;
};
const amPm = [
    "isPm",
    word,
    ɵ31
];
const ɵ32 = (v) => {
    const parts = (v + "").match(/([+-]|\d\d)/gi);
    if (parts) {
        const minutes = +parts[1] * 60 + parseInt(parts[2], 10);
        return parts[0] === "+" ? minutes : -minutes;
    }
    return 0;
};
const timezoneOffset = [
    "timezoneOffset",
    "[^\\s]*?[\\+\\-]\\d\\d:?\\d\\d|[^\\s]*?Z?",
    ɵ32
];
const ɵ33 = (v) => parseInt(v, 10), ɵ34 = (v) => {
    const now = new Date();
    const cent = +("" + now.getFullYear()).substr(0, 2);
    return +("" + (+v > 68 ? cent - 1 : cent) + v);
}, ɵ35 = (v) => +v * 100, ɵ36 = (v) => +v * 10;
const parseFlags = {
    D: ["day", twoDigitsOptional],
    DD: ["day", twoDigits],
    Do: ["day", twoDigitsOptional + word, ɵ33],
    M: ["month", twoDigitsOptional, monthParse],
    MM: ["month", twoDigits, monthParse],
    YY: [
        "year",
        twoDigits,
        ɵ34
    ],
    h: ["hour", twoDigitsOptional, undefined, "isPm"],
    hh: ["hour", twoDigits, undefined, "isPm"],
    H: ["hour", twoDigitsOptional],
    HH: ["hour", twoDigits],
    m: ["minute", twoDigitsOptional],
    mm: ["minute", twoDigits],
    s: ["second", twoDigitsOptional],
    ss: ["second", twoDigits],
    YYYY: ["year", fourDigits],
    S: ["millisecond", "\\d", ɵ35],
    SS: ["millisecond", twoDigits, ɵ36],
    SSS: ["millisecond", threeDigits],
    d: emptyDigits,
    dd: emptyDigits,
    ddd: emptyWord,
    dddd: emptyWord,
    MMM: ["month", word, monthUpdate("monthNamesShort")],
    MMMM: ["month", word, monthUpdate("monthNames")],
    a: amPm,
    A: amPm,
    ZZ: timezoneOffset,
    Z: timezoneOffset
};
// Some common format strings
const globalMasks = {
    default: "ddd MMM DD YYYY HH:mm:ss",
    shortDate: "M/D/YY",
    mediumDate: "MMM D, YYYY",
    longDate: "MMMM D, YYYY",
    fullDate: "dddd, MMMM D, YYYY",
    isoDate: "YYYY-MM-DD",
    isoDateTime: "YYYY-MM-DDTHH:mm:ssZ",
    shortTime: "HH:mm",
    mediumTime: "HH:mm:ss",
    longTime: "HH:mm:ss.SSS"
};
const setGlobalDateMasks = (masks) => assign(globalMasks, masks);
const ɵ37 = setGlobalDateMasks;
/***
 * Format a date
 * @method format
 * @param {Date|number} dateObj
 * @param {string} mask Format of the date, i.e. 'mm-dd-yy' or 'shortDate'
 * @returns {string} Formatted date string
 */
const format = (dateObj, mask = globalMasks["default"], i18n = {}) => {
    if (typeof dateObj === "number") {
        dateObj = new Date(dateObj);
    }
    if (Object.prototype.toString.call(dateObj) !== "[object Date]" ||
        isNaN(dateObj.getTime())) {
        throw new Error("Invalid Date pass to format");
    }
    mask = globalMasks[mask] || mask;
    const literals = [];
    // Make literals inactive by replacing them with @@@
    mask = mask.replace(literal, function ($0, $1) {
        literals.push($1);
        return "@@@";
    });
    const combinedI18nSettings = assign(assign({}, globalI18n), i18n);
    // Apply formatting rules
    mask = mask.replace(token, $0 => formatFlags[$0](dateObj, combinedI18nSettings));
    // Inline literal values back into the formatted value
    return mask.replace(/@@@/g, () => literals.shift());
};
const ɵ38 = format;
/**
 * Parse a date string into a Javascript Date object /
 * @method parse
 * @param {string} dateStr Date string
 * @param {string} format Date parse format
 * @param {i18n} I18nSettingsOptional Full or subset of I18N settings
 * @returns {Date|null} Returns Date object. Returns null what date string is invalid or doesn't match format
 */
function parse(dateStr, format, i18n = {}) {
    if (typeof format !== "string") {
        throw new Error("Invalid format in fecha parse");
    }
    // Check to see if the format is actually a mask
    format = globalMasks[format] || format;
    // Avoid regular expression denial of service, fail early for really long strings
    // https://www.owasp.org/index.php/Regular_expression_Denial_of_Service_-_ReDoS
    if (dateStr.length > 1000) {
        return null;
    }
    // Default to the beginning of the year.
    const today = new Date();
    const dateInfo = {
        year: today.getFullYear(),
        month: 0,
        day: 1,
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0,
        isPm: null,
        timezoneOffset: null
    };
    const parseInfo = [];
    const literals = [];
    // Replace all the literals with @@@. Hopefully a string that won't exist in the format
    let newFormat = format.replace(literal, ($0, $1) => {
        literals.push(regexEscape($1));
        return "@@@";
    });
    const specifiedFields = {};
    const requiredFields = {};
    // Change every token that we find into the correct regex
    newFormat = regexEscape(newFormat).replace(token, $0 => {
        const info = parseFlags[$0];
        const [field, regex, , requiredField] = info;
        // Check if the person has specified the same field twice. This will lead to confusing results.
        if (specifiedFields[field]) {
            throw new Error(`Invalid format. ${field} specified twice in format`);
        }
        specifiedFields[field] = true;
        // Check if there are any required fields. For instance, 12 hour time requires AM/PM specified
        if (requiredField) {
            requiredFields[requiredField] = true;
        }
        parseInfo.push(info);
        return "(" + regex + ")";
    });
    // Check all the required fields are present
    Object.keys(requiredFields).forEach(field => {
        if (!specifiedFields[field]) {
            throw new Error(`Invalid format. ${field} is required in specified format`);
        }
    });
    // Add back all the literals after
    newFormat = newFormat.replace(/@@@/g, () => literals.shift());
    // Check if the date string matches the format. If it doesn't return null
    const matches = dateStr.match(new RegExp(newFormat, "i"));
    if (!matches) {
        return null;
    }
    const combinedI18nSettings = assign(assign({}, globalI18n), i18n);
    // For each match, call the parser function for that date part
    for (let i = 1; i < matches.length; i++) {
        const [field, , parser] = parseInfo[i - 1];
        const value = parser
            ? parser(matches[i], combinedI18nSettings)
            : +matches[i];
        // If the parser can't make sense of the value, return null
        if (value == null) {
            return null;
        }
        dateInfo[field] = value;
    }
    if (dateInfo.isPm === 1 && dateInfo.hour != null && +dateInfo.hour !== 12) {
        dateInfo.hour = +dateInfo.hour + 12;
    }
    else if (dateInfo.isPm === 0 && +dateInfo.hour === 12) {
        dateInfo.hour = 0;
    }
    const dateWithoutTZ = new Date(dateInfo.year, dateInfo.month, dateInfo.day, dateInfo.hour, dateInfo.minute, dateInfo.second, dateInfo.millisecond);
    const validateFields = [
        ["month", "getMonth"],
        ["day", "getDate"],
        ["hour", "getHours"],
        ["minute", "getMinutes"],
        ["second", "getSeconds"]
    ];
    for (let i = 0, len = validateFields.length; i < len; i++) {
        // Check to make sure the date field is within the allowed range. Javascript dates allows values
        // outside the allowed range. If the values don't match the value was invalid
        if (specifiedFields[validateFields[i][0]] &&
            dateInfo[validateFields[i][0]] !== dateWithoutTZ[validateFields[i][1]]()) {
            return null;
        }
    }
    if (dateInfo.timezoneOffset == null) {
        return dateWithoutTZ;
    }
    return new Date(Date.UTC(dateInfo.year, dateInfo.month, dateInfo.day, dateInfo.hour, dateInfo.minute - dateInfo.timezoneOffset, dateInfo.second, dateInfo.millisecond));
}
var fecha = {
    format,
    parse,
    defaultI18n,
    setGlobalDateI18n,
    setGlobalDateMasks
};

class dates {
    static init(format) {
        dates.deffmt = format;
        this.tokens$ = dates.split(format, "-/:. ");
        for (let i = 0; i < this.tokens$.length; i++) {
            if (this.tokens$[i].delim != " ") {
                dates.delim = this.tokens$[i].delim;
                break;
            }
        }
        dates.formattokens = new Set();
        dates.formattokens.add("m");
        dates.formattokens.add("d");
        dates.formattokens.add("o");
        dates.formattokens.add("d");
        dates.formattokens.add("y");
        dates.formattokens.add("a");
        dates.formattokens.add("h");
        dates.formattokens.add("s");
        dates.formattokens.add("z");
    }
    static setFormat(format) {
        dates.init(format);
    }
    static parse(datestr, format) {
        if (format == null)
            format = dates.deffmt;
        if (datestr == null || datestr.trim().length == 0)
            return (null);
        let date = parse(datestr, format);
        if (date == null)
            datestr = dates.reformat(datestr);
        if (datestr == null)
            return (null);
        return (parse(datestr, format));
    }
    static format(date, format$1) {
        if (format$1 == null)
            format$1 = dates.deffmt;
        return (format(date, format$1));
    }
    static reformat(datestr) {
        let ndate = "";
        if (!isNaN(+datestr)) {
            let pos = 0;
            for (let i = 0; i < 3; i++) {
                let len = dates.tokens$[i].token.length;
                ndate += datestr.substring(pos, pos + len) + dates.tokens$[i].delim;
                pos += len;
            }
            return (ndate);
        }
        if (dates.delim != "-")
            datestr = dates.replaceAll(datestr, "-", dates.delim);
        if (dates.delim != "/")
            datestr = dates.replaceAll(datestr, "/", dates.delim);
        if (dates.delim != ".")
            datestr = dates.replaceAll(datestr, ".", dates.delim);
        let parts = dates.split(datestr, dates.delim + ": ");
        for (let i = 0; i < parts.length; i++) {
            let numeric = !isNaN(+parts[i].token);
            if (numeric && parts[i].token.length == 1)
                parts[i].token = "0" + parts[i].token;
        }
        parts.forEach((part) => { ndate += part.token + part.delim; });
        return (ndate);
    }
    static split(str, splitter) {
        let parts = [];
        let delimiters = new Set();
        for (let i = 0; i < splitter.length; i++)
            delimiters.add(splitter[i] + "");
        let pos = 0;
        for (let i = 0; i < str.length; i++) {
            if (delimiters.has(str[i] + "")) {
                parts.push({ token: str.substring(pos, i), delim: str[i] });
                pos = i + 1;
            }
        }
        if (pos < str.length)
            parts.push({ token: str.substring(pos, str.length), delim: "" });
        return (parts);
    }
    static replaceAll(str, search, replace) {
        while (str.indexOf(search) >= 0)
            str = str.replace(search, replace);
        return (str);
    }
}
// Current implementation from
// https://github.com/taylorhakes/fecha/blob/master/README.md
dates.delim = null;
dates.deffmt = null;
dates.tokens$ = null;
dates.formattokens = null;

class DateField extends TextField {
    constructor() {
        super(...arguments);
        this.dateval = null;
        this.formatted = null;
    }
    get value() {
        if (this.element$.value == this.formatted) {
            // Invalid date
            if (this.formatted.length > 0 && this.dateval == null)
                return (this.formatted);
            return (this.dateval);
        }
        return (this.element$.value);
    }
    set value(value) {
        if (value == null || value.constructor.name != "Date") {
            if (value != this.formatted || value != this.element$.value) {
                this.dateval = null;
                this.formatted = value;
                this.element$.value = value;
            }
        }
        else {
            this.dateval = value;
            this.formatted = dates.format(value);
            this.element$.value = this.formatted;
        }
    }
    validate() {
        let strval = this.element$.value;
        if (strval == this.formatted) {
            if (strval != null && dates.parse(strval) == null)
                return (false);
            return (true);
        }
        this.formatted = null;
        this.dateval = dates.parse(strval);
        if (this.dateval == null && strval != null)
            return (false);
        if (this.dateval != null)
            this.formatted = dates.format(this.dateval);
        this.element$.value = this.formatted;
        return (true);
    }
}

class RadioButton extends TextField {
    constructor() {
        super(...arguments);
        this.actvalue = null;
        this.chkvalue = null;
    }
    get html() {
        return ("<input type='radio'></input>");
    }
    get value() {
        return (this.actvalue);
    }
    set value(value) {
        if (this.chkvalue == null) {
            this.chkvalue = value;
            return;
        }
        this.actvalue = value;
        // cheat compiler
        let radio = this.element;
        if (value == this.chkvalue)
            radio.checked = true;
        else
            radio.checked = false;
    }
}

var Column;
(function (Column) {
    Column[Column["int"] = 0] = "int";
    Column[Column["date"] = 1] = "date";
    Column[Column["decimal"] = 2] = "decimal";
    Column[Column["integer"] = 3] = "integer";
    Column[Column["varchar"] = 4] = "varchar";
    Column[Column["datetime"] = 5] = "datetime";
})(Column || (Column = {}));

var FieldType;
(function (FieldType) {
    FieldType[FieldType["date"] = 0] = "date";
    FieldType[FieldType["text"] = 1] = "text";
    FieldType[FieldType["radio"] = 2] = "radio";
    FieldType[FieldType["integer"] = 3] = "integer";
    FieldType[FieldType["decimal"] = 4] = "decimal";
    FieldType[FieldType["checkbox"] = 5] = "checkbox";
    FieldType[FieldType["datetime"] = 6] = "datetime";
    FieldType[FieldType["password"] = 7] = "password";
    FieldType[FieldType["dropdown"] = 8] = "dropdown";
})(FieldType || (FieldType = {}));
class FieldImplementation {
    static init() {
        if (FieldImplementation.impl != null)
            return;
        FieldImplementation.impl = new Map();
        Object.keys(FieldType).forEach((type) => {
            if (isNaN(Number(type)))
                FieldImplementation.impl.set(type, TextField);
        });
        FieldImplementation.impl.set(FieldType[FieldType.date], DateField);
        FieldImplementation.impl.set(FieldType[FieldType.radio], RadioButton);
        FieldImplementation.impl.set(FieldType[FieldType.checkbox], CheckBox);
        FieldImplementation.impl.set(FieldType[FieldType.password], Password);
        FieldImplementation.impl.set(FieldType[FieldType.dropdown], DropDown);
        FieldImplementation.impl.set(FieldType[FieldType.datetime], DateField);
    }
    static getClass(type) {
        FieldImplementation.init();
        return (FieldImplementation.impl.get(type));
    }
    static guess(type) {
        let ftype = FieldType.text;
        if (type != null) {
            ftype = FieldType.text;
            if (type == Column.date)
                ftype = FieldType.date;
            if (type == Column.integer)
                ftype = FieldType.integer;
            if (type == Column.decimal)
                ftype = FieldType.decimal;
            if (type == Column.datetime)
                ftype = FieldType.datetime;
        }
        return (ftype);
    }
}
FieldImplementation.impl = null;

var FormState;
(function (FormState) {
    FormState[FormState["normal"] = 0] = "normal";
    FormState[FormState["entqry"] = 1] = "entqry";
    FormState[FormState["exeqry"] = 2] = "exeqry";
})(FormState || (FormState = {}));

class KeyCodes {
}
KeyCodes.backspace = 8;
KeyCodes.tab = 9;
KeyCodes.enter = 13;
KeyCodes.escape = 27;
KeyCodes.pageup = 33;
KeyCodes.pagedown = 34;
KeyCodes.end = 35;
KeyCodes.home = 36;
KeyCodes.up = 38;
KeyCodes.down = 40;
KeyCodes.left = 37;
KeyCodes.right = 39;
KeyCodes.insert = 45;
KeyCodes.delete = 46;
KeyCodes.f1 = 112;
KeyCodes.f2 = 113;
KeyCodes.f3 = 114;
KeyCodes.f4 = 115;
KeyCodes.f5 = 116;
KeyCodes.f6 = 117;
KeyCodes.f7 = 118;
KeyCodes.f8 = 119;
KeyCodes.f9 = 120;
KeyCodes.f10 = 121;
KeyCodes.f11 = 122;
KeyCodes.f12 = 123;

class WindowListener {
    constructor() { }
    static add(id, clazz, event) {
        let events = WindowListener.events.get(event);
        if (events == null) {
            events = new Map();
            WindowListener.events.set(event, events);
            let listener = new WindowListener();
            listener.start(event);
        }
        events.set(id, clazz);
    }
    static remove(id, event) {
        let events = WindowListener.events.get(event);
        events.delete(id);
    }
    start(eventtype) {
        window.addEventListener(eventtype, (event) => { this.onEvent(event); });
    }
    onEvent(event) {
        let events = WindowListener.events.get(event.type);
        events.forEach((clazz) => { clazz.onEvent(event); });
    }
}
WindowListener.events = new Map();

class PopupWindow {
    constructor(ctx, change) {
        this.change = change;
        this.top = null;
        this.left = null;
        this.width = "300px";
        this.height = "200px";
        this.tmargin = "8px";
        this.minw = 0;
        this.minh = 0;
        this.offx = 0;
        this.offy = 0;
        this.move = false;
        this.resz = false;
        this.resizex = false;
        this.resizey = false;
        this.app = ctx.app["_impl_"];
    }
    get tcolor() {
        return (this.app.config.colors.title);
    }
    get bcolor() {
        return (this.app.config.colors.topbar);
    }
    get btncolor() {
        return (this.app.config.colors.buttontext);
    }
    set title(title) {
        this.title$ = title;
    }
    setPopup(pinst) {
        this.pinst = pinst;
        this.popup = pinst.popupref.instance;
        this.popup.setWin(this);
        this.title$ = this.popup.title;
        if (this.popup.hasOwnProperty("top"))
            this.top = this.popup.top;
        if (this.popup.hasOwnProperty("left"))
            this.left = this.popup.left;
        if (this.popup.hasOwnProperty("width"))
            this.width = this.popup.width;
        if (this.popup.hasOwnProperty("height"))
            this.height = this.popup.height;
    }
    resize(width, height) {
        this.width = width;
        this.height = height;
        this.change.detectChanges();
    }
    setWinRef(winref) {
        this.winref = winref;
    }
    close(cancel) {
        this.closeWindow();
        this.popup.close(cancel);
    }
    closeWindow() {
        if (this.winref == null)
            return;
        WindowListener.remove("modal", "mouseup");
        WindowListener.remove("modal", "mousemove");
        WindowListener.remove("modal", "mousedown");
        let formelem = this.content.firstElementChild;
        if (formelem != null)
            this.content.removeChild(formelem);
        this.app.builder.getAppRef().detachView(this.pinst.popupref.hostView);
        let element = this.winref.hostView.rootNodes[0];
        document.body.removeChild(element);
        this.app.builder.getAppRef().detachView(this.winref.hostView);
        this.winref.destroy();
        this.winref = null;
    }
    display() {
        if (this.pinst == null) {
            setTimeout(() => { this.display(); }, 10);
            return;
        }
        this.element = this.pinst.popupref.hostView.rootNodes[0];
        this.app.builder.getAppRef().attachView(this.pinst.popupref.hostView);
        this.content.appendChild(this.element);
        this.minh = 150;
        this.minw = 250;
        this.titlebar.innerHTML = this.title$;
        this.change.detectChanges();
        this.posy = this.window.offsetTop;
        this.posx = this.window.offsetLeft;
        this.sizex = this.window.offsetWidth;
        this.sizey = this.window.offsetHeight;
        let resize = false;
        if (this.sizex < this.minw) {
            resize = true;
            this.sizex = this.minw;
            this.width = this.sizex + "px";
        }
        if (this.sizey < this.minh) {
            resize = true;
            this.sizey = this.minh;
            this.height = this.sizey + "px";
        }
        if (this.top == null || this.top.trim.length == 0) {
            resize = true;
            this.top = ((+window.innerHeight - this.sizey) / 3) + "px";
        }
        if (this.left == null || this.left.trim.length == 0) {
            resize = true;
            this.left = ((+window.innerWidth - this.sizex) / 1.5) + "px";
        }
        if (resize) {
            this.change.detectChanges();
            this.posy = this.window.offsetTop;
            this.posx = this.window.offsetLeft;
            this.sizex = this.window.offsetWidth;
            this.sizey = this.window.offsetHeight;
        }
    }
    ngAfterViewInit() {
        var _a, _b, _c, _d;
        this.window = (_a = this.windowElement) === null || _a === void 0 ? void 0 : _a.nativeElement;
        this.topbar = (_b = this.topbarElement) === null || _b === void 0 ? void 0 : _b.nativeElement;
        this.content = (_c = this.contentElement) === null || _c === void 0 ? void 0 : _c.nativeElement;
        this.titlebar = (_d = this.titlebarElement) === null || _d === void 0 ? void 0 : _d.nativeElement;
        this.display();
        WindowListener.add("modal", this, "mouseup");
        WindowListener.add("modal", this, "mousemove");
        WindowListener.add("modal", this, "mousedown");
        this.topbar.addEventListener("mousedown", (event) => { this.startmove(event); });
    }
    onEvent(event) {
        switch (event.type) {
            case "mouseup":
                this.mouseup();
                break;
            case "mousemove":
                this.movePopup(event);
                this.resizePopup(event);
                this.resizemousemove(event);
                break;
            case "mousedown":
                this.startresize(event);
                break;
        }
    }
    startmove(event) {
        if (this.resizexy)
            return;
        this.move = true;
        event = event || window.event;
        event.preventDefault();
        this.offy = +event.clientY - this.posy;
        this.offx = +event.clientX - this.posx;
    }
    mouseup() {
        if (!this.move && !this.resz)
            return;
        this.move = false;
        this.resz = false;
        this.resizexy = false;
        this.window.style.cursor = "default";
        document.body.style.cursor = "default";
    }
    movePopup(event) {
        if (!this.move)
            return;
        event = event || window.event;
        let deltay = +event.clientY - this.posy;
        let deltax = +event.clientX - this.posx;
        this.posy += (deltay - this.offy);
        this.posx += (deltax - this.offx);
        if (this.posy > 0)
            this.top = this.posy + "px";
        if (this.posx > 0)
            this.left = this.posx + "px";
        this.change.detectChanges();
    }
    resizemousemove(event) {
        if (this.resz)
            return;
        event = event || window.event;
        let posx = +event.clientX;
        let posy = +event.clientY;
        let offx = this.posx + this.sizex - posx;
        let offy = this.posy + this.sizey - posy;
        let before = false;
        if (this.resizex || this.resizey)
            before = true;
        this.resizex = false;
        this.resizey = false;
        if (offx > -7 && offx < 10 && posy > this.posy - 7 && posy < this.posy + this.sizey + 7)
            this.resizex = true;
        if (offy > -7 && offy < 10 && posx > this.posx - 7 && posx < this.posx + this.sizex + 7)
            this.resizey = true;
        if (this.resizex && this.resizey) {
            this.resizex = true;
            this.resizey = true;
        }
        if (this.resizex && !this.resizey) {
            this.window.style.cursor = "e-resize";
            document.body.style.cursor = "e-resize";
        }
        if (this.resizey && !this.resizex) {
            this.window.style.cursor = "s-resize";
            document.body.style.cursor = "s-resize";
        }
        if (this.resizex && this.resizey) {
            this.window.style.cursor = "se-resize";
            document.body.style.cursor = "se-resize";
        }
        if (before && !this.resizexy) {
            this.window.style.cursor = "default";
            document.body.style.cursor = "default";
        }
    }
    startresize(event) {
        if (!this.resizexy)
            return;
        this.resz = true;
        event = event || window.event;
        event.preventDefault();
        this.offy = +event.clientY;
        this.offx = +event.clientX;
    }
    resizePopup(event) {
        if (!this.resz)
            return;
        event = event || window.event;
        let deltay = +event.clientY - this.offy;
        let deltax = +event.clientX - this.offx;
        if (this.resizex && (this.sizex > this.minw || deltax > 0)) {
            this.sizex += deltax;
            this.width = this.sizex + "px";
        }
        if (this.resizey && (this.sizey > this.minh || deltay > 0)) {
            this.sizey += deltay;
            this.height = this.sizey + "px";
        }
        this.offy = +event.clientY;
        this.offx = +event.clientX;
        this.change.detectChanges();
    }
    get resizexy() {
        if (this.resizex || this.resizey)
            return (true);
        return (false);
    }
    set resizexy(on) {
        this.resizex = on;
        this.resizey = on;
    }
}
PopupWindow.decorators = [
    { type: Component, args: [{
                selector: 'popupwindow',
                template: `
    <div class="popupwindow">
      <div #window class="popupwindow-modal-block" style="top: {{top}}; left: {{left}}">
        <div class="popupwindow-container" style="width: {{width}}; height: {{height}};">
		  <div #topbar class="popupwindow-topbar" style="color: {{tcolor}}; background-color: {{bcolor}}">
		    <span class="popupwindow-center" style="color: {{tcolor}};">
				<span class="popupwindow-corner"></span>
				<div #title></div>
                <span class="popupwindow-close">
                    <button class="popupwindow-button" style="color: {{btncolor}};" (click)="close(true)">X</button>
                </span>
			</span>
		   </div>
          <div class="popupwindow-block" style="margin-top: {{tmargin}};"><div #content></div></div>
        </div>
      </div>
    </div>
  `,
                changeDetection: ChangeDetectionStrategy.OnPush,
                styles: [`
    .popupwindow
    {
        top: 0;
        left: 0;
        z-index: 1;
        width: 100%;
        height: 100%;
        display: block;
        overflow: auto;
        position: fixed;
    }

    .popupwindow-modal-block
    {
      position: absolute;
      background-color: #fefefe;
    }

    .popupwindow-container
    {
        position: relative;
        border: 2px solid black;
    }

    .popupwindow-topbar
    {
        height: 1.70em;
        margin-left: 0;
        margin-right: 0;
        cursor:default;
		justify-content: center;
        border-bottom: 2px solid black;
    }

	.popupwindow-corner
	{
		width: 1.5em;
		display: block;
		position: relative;
	}

	.popupwindow-close
	{
		top: 0;
		right: 0;
		width: 1.75em;
		height: 1.70em;
		position: absolute;
		border-left: 1px solid black;
	}

	.popupwindow-button
	{
		top: 50%;
		width: 100%;
		height: 100%;
		outline:none;
		font-size: 0.75em;
		font-weight: bold;
		position: relative;
		background: transparent;
		transform: translateY(-50%);
		border: 0px solid transparent;
		box-shadow: 0px 0px 0px transparent;
		text-shadow: 0px 0px 0px transparent;
	}

	.popupwindow-center
	{
		top: 0;
		bottom: 0;
		width: 93%;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
	}

    .popupwindow-block
    {
        left: 0;
        top: 3vh;
        right: 0;
        bottom: 0;
		display: flex;
        overflow: auto;
        position: absolute;
		justify-content: center;
    }
`]
            },] }
];
PopupWindow.ctorParameters = () => [
    { type: Context },
    { type: ChangeDetectorRef }
];
PopupWindow.propDecorators = {
    titlebarElement: [{ type: ViewChild, args: ["title", { read: ElementRef },] }],
    windowElement: [{ type: ViewChild, args: ["window", { read: ElementRef },] }],
    topbarElement: [{ type: ViewChild, args: ["topbar", { read: ElementRef },] }],
    contentElement: [{ type: ViewChild, args: ['content', { read: ElementRef },] }]
};

class PopupInstance {
    display(app, popup) {
        this.popupref = app.builder.createComponent(popup);
        let winref = app.builder.createComponent(PopupWindow);
        let win = winref.instance;
        win.setPopup(this);
        win.setWinRef(winref);
        let element = winref.hostView.rootNodes[0];
        app.builder.getAppRef().attachView(winref.hostView);
        document.body.appendChild(element);
    }
    popup() {
        return (this.popupref.instance);
    }
}

class DatePicker {
    constructor(ctx) {
        this.ctx = ctx;
        this.top = null;
        this.left = null;
        this.title = null;
        this.width = "256px";
        this.height = "256px";
        this.cdate = null;
        this.win = null;
        this.cal = null;
        this.days = null;
        this.years = null;
        this.months = null;
        this.app = ctx.app["_impl_"];
        this.title = ctx.conf.calendarname;
    }
    static show(app, impl, record, field, date) {
        let pinst = new PopupInstance();
        pinst.display(app, DatePicker);
        let datepicker = pinst.popup();
        datepicker.date = date;
        datepicker.setDestination(impl, record, field);
    }
    close(_cancel) {
        this.win.closeWindow();
    }
    set date(date) {
        if (date == null)
            date = new Date();
        this.cdate = date;
    }
    setDestination(impl, record, field) {
        this.impl = impl;
        this.field = field;
        this.record = record;
    }
    pick(event) {
        let year = +this.years.value;
        let month = +this.months.value;
        let day = +event.target.innerHTML;
        let cday = this.cdate.getUTCDate();
        let cmonth = this.cdate.getUTCMonth();
        let cyear = this.cdate.getUTCFullYear();
        if (year != cyear || month != cmonth || day != cday) {
            this.cdate = new Date(Date.UTC(year, month - 1, day));
            // Truncate
            this.cdate = new Date(this.cdate.toDateString());
            this.impl.setValue(this.record, this.field, this.cdate);
            this.impl.focus();
        }
        this.close(false);
    }
    setWin(win) {
        this.win = win;
    }
    ngAfterViewInit() {
        var _a;
        this.cal = (_a = this.calelem) === null || _a === void 0 ? void 0 : _a.nativeElement;
        this.build(this.cdate, 75, 75);
    }
    navigate(event) {
        if (event.keyCode == KeyCodes.tab) {
            event.preventDefault();
            if (event.target.name == "months")
                this.years.focus();
            else
                this.months.focus();
            return;
        }
        if (event.keyCode == KeyCodes.escape)
            this.close(true);
    }
    weekdays(locale) {
        let fmt = new Intl.DateTimeFormat(locale, { weekday: "short" }).format;
        let names = [...Array(7).keys()].map((d) => fmt(new Date(Date.UTC(2021, 1, d))));
        for (let i = 0; i < 7; i++) {
            if (names[i].endsWith("."))
                names[i] = names[i].substring(0, names[i].length - 1);
        }
        let sun = names[0];
        names.shift();
        names.push(sun);
        return (names);
    }
    monthnames(locale) {
        let fmt = new Intl.DateTimeFormat(locale, { month: "short" }).format;
        let names = [...Array(12).keys()].map((m) => fmt(new Date(Date.UTC(2021, m))));
        for (let i = 0; i < 12; i++) {
            if (names[i].endsWith("."))
                names[i] = names[i].substring(0, names[i].length - 1);
        }
        return (names);
    }
    build(date, bef, aft) {
        this.styles();
        let month = date.getUTCMonth();
        let year = date.getUTCFullYear();
        let months = this.monthnames(this.ctx.conf.locale);
        this.years = document.createElement("select");
        this.months = document.createElement("select");
        this.years.name = "years";
        this.months.name = "months";
        this.addFieldTriggers(this.years);
        this.addFieldTriggers(this.months);
        this.months.classList.add("datepicker-month");
        for (let i = 0; i < 12; i++) {
            let option = document.createElement("option");
            option.text = months[i];
            option.value = (i + 1) + "";
            this.months.appendChild(option);
        }
        this.months.selectedIndex = month;
        this.cal.appendChild(this.months);
        this.years.classList.add("datepicker-year");
        for (let i = year - bef; i < year + aft; i++) {
            let option = document.createElement("option");
            option.text = i + "";
            option.value = i + "";
            this.years.appendChild(option);
        }
        this.years.selectedIndex = bef;
        this.cal.appendChild(this.years);
        this.days = document.createElement("div");
        this.days.classList.add("datepicker-days");
        this.cal.appendChild(this.days);
        this.draw();
        let width = (1.25 * this.cal.offsetWidth) + "px";
        let height = (1.10 * this.cal.offsetHeight + 32) + "px";
        this.win.resize(width, height);
        this.months.focus();
    }
    draw() {
        let cday = this.cdate.getDate();
        let cmonth = this.cdate.getMonth();
        let cyear = this.cdate.getFullYear();
        let year = +this.years.value;
        let month = +this.months.value;
        if (year != cyear || month != +cmonth + +1)
            cday = 0;
        let days = new Date(Date.UTC(year, month, 0)).getUTCDate();
        let first = new Date(Date.UTC(year, month - 1, 1)).getUTCDay();
        let last = new Date(Date.UTC(year, month - 1, days)).getUTCDay();
        last = last == 0 ? 7 : last;
        first = first == 0 ? 7 : first;
        let squares = [];
        for (let i = 1; i < first; i++)
            squares.push([false, 0]);
        for (let i = 0; i < days; i++)
            squares.push([true, i]);
        while (squares.length % 7 != 0)
            squares.push([false, 0]);
        let names = this.weekdays(this.ctx.conf.locale);
        let table = document.createElement("table");
        table.classList.add("datepicker-table");
        let row = table.insertRow();
        names.forEach((day) => {
            let cell = row.insertCell();
            cell.classList.add("datepicker-head");
            cell.innerHTML = day;
        });
        for (let i = 0; i < squares.length; i++) {
            if (i % 7 == 0)
                row = table.insertRow();
            let cell = row.insertCell();
            if (squares[i][0]) {
                let dom = +squares[i][1] + +1;
                cell.innerHTML = dom + "";
                cell.classList.add("datepicker-day");
                if (dom == cday)
                    cell.classList.add("datepicker-current");
                this.addDayTriggers(cell);
            }
            else {
                cell.classList.add("datepicker-blank");
            }
        }
        this.days.innerHTML = "";
        this.days.appendChild(table);
        return (table);
    }
    addDayTriggers(cell) {
        cell.addEventListener("click", (event) => { this.pick(event); });
    }
    addFieldTriggers(change) {
        change.addEventListener("change", () => { this.draw(); });
        change.addEventListener("keydown", (event) => { this.navigate(event); });
    }
    styles() {
        this.cal.innerHTML =
            `
        <style>
            .datepicker-month
            {
                font-size: 15px;
                margin-top: 16px;
                margin-left: 16px;
                width: fit-content;
            }

            .datepicker-year
            {
                font-size: 15px;
                margin-top: 16px;
                margin-left: 32px;
                width: fit-content;
            }

            .datepicker-table
            {
                width: 100%;
                margin-top: 14px;
                border-collapse: separate;
            }

            .datepicker-head
            {
                font-weight: bold;
                text-align: center;
                color: ` + this.app.config.colors.text + `;
            }

            .datepicker-day
            {
                color: ` + this.app.config.colors.buttontext + `;
                padding: 5px;
                width: 14.28%;
                text-align: center;
                background: ` + this.app.config.colors.topbar + `;
            }

            .datepicker-blank
            {
                background: #ddd;
            }

            .datepicker-current
            {
                font-size: 16px;
                font-weight: bold;
            }

            .datepicker-day:hover
            {
                cursor: pointer;
                font-weight: bold;
                font-style: italic;
            }
        </style>
        `;
    }
}
DatePicker.decorators = [
    { type: Component, args: [{
                template: `
        <div #calendar></div>
    `
            },] }
];
DatePicker.ctorParameters = () => [
    { type: Context }
];
DatePicker.propDecorators = {
    calelem: [{ type: ViewChild, args: ["calendar", { read: ElementRef },] }]
};

class MessageBox {
    constructor(ctx) {
        this.top = "20%";
        this.left = "25%";
        this.width$ = "100px";
        this.height$ = "100px";
        this.title$ = "alert";
        this.message = "the message";
        this.msg = null;
        this.btn = null;
        this.app = ctx.app["_impl_"];
    }
    static show(app, message, title, width, height) {
        let pinst = new PopupInstance();
        pinst.display(app, MessageBox);
        let mbox = pinst.popup();
        mbox.title = title;
        mbox.message = message;
        if (width != null)
            mbox.width = width;
        if (height != null)
            mbox.height = height;
    }
    get bcolor() {
        return (this.app.config.colors.topbar);
    }
    get tcolor() {
        return (this.app.config.colors.buttontext);
    }
    set width(width) {
        this.width$ = width;
    }
    get width() {
        return (this.width$);
    }
    set height(height) {
        this.height$ = height;
    }
    get height() {
        return (this.height$);
    }
    set title(title) {
        this.title$ = title;
        this.win.title = this.title;
    }
    get title() {
        return (this.title$);
    }
    setWin(win) {
        this.win = win;
    }
    close(_cancel) {
        var _a;
        this.btn.removeEventListener("click", () => { this.close(false); });
        this.btn.removeEventListener("keydown", () => { this.close(false); });
        this.win.closeWindow();
        (_a = this.app.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.focus();
    }
    ngAfterViewInit() {
        var _a, _b;
        this.msg = (_a = this.msgelem) === null || _a === void 0 ? void 0 : _a.nativeElement;
        this.btn = (_b = this.acceptelem) === null || _b === void 0 ? void 0 : _b.nativeElement;
        setTimeout(() => { this.addTriggers(); }, 1);
        this.msg.innerHTML = this.message;
        this.keepFocus(0);
    }
    addTriggers() {
        this.btn.addEventListener("click", () => { this.close(false); });
        this.btn.addEventListener("keydown", () => { this.close(false); });
    }
    keepFocus(delay) {
        this.btn.focus();
        setTimeout(() => { this.keepFocus(delay + 1); }, delay);
    }
}
MessageBox.decorators = [
    { type: Component, args: [{
                selector: '',
                template: `
        <div class="messagebox">
            <div #msg class="messagebox-msg"></div>
            <div class="messagebox-buttom">
                <button #accept class="messagebox-btn" style="color: {{tcolor}}; background-color: {{bcolor}};">Ok</button>
            </div>
        </div>
        `,
                styles: [`
        .messagebox
        {
            top: 0px;
            left: 1px;
            right: 1px;
            bottom: 0px;
            display: block;
            position: absolute;
        }

        .messagebox-msg
        {
            height: 80px;
            display: flex;
            text-align: center;
            word-wrap: break-all;
            justify-content: center;
        }

        .messagebox-buttom
        {
            right: 1px;
            bottom: 4px;
            witdh: 35px;
            height: 35px;
            display: block;
            position: absolute;
        }

        .messagebox-btn
        {
            border: none;
            padding: 10px;
            outline: none;
            font-size: 15px;
            cursor: pointer;
            text-align: center;
            border-radius: 100%;
            display: inline-block;
            text-decoration: none;
        }
    `]
            },] }
];
MessageBox.ctorParameters = () => [
    { type: Context }
];
MessageBox.propDecorators = {
    msgelem: [{ type: ViewChild, args: ["msg", { read: ElementRef },] }],
    acceptelem: [{ type: ViewChild, args: ["accept", { read: ElementRef },] }]
};

class Condition {
    constructor(column, value, datatype) {
        this.level$ = 0;
        this.type$ = "and";
        this.prev$ = null;
        this.next$ = null;
        this.bindvalues$ = [];
        this.error$ = null;
        this.column$ = column;
        this.datatype$ = datatype;
        this.placeholder$ = column + Condition.ubid();
        if (this.column$ == null) {
            this.error$ = "cannot construct condition on unspecified column. Value = " + value;
            return;
        }
        if (value != null) {
            let type = value.constructor.name.toLowerCase();
            if (type == "date") {
                this.datatype$ = Column.date;
                this.value$ = value.getTime();
                this.datebtwn();
                this.bindvalues$.push({ name: this.placeholder$[0], value: this.value$[0], type: this.datatype$ });
                this.bindvalues$.push({ name: this.placeholder$[1], value: this.value$[1], type: this.datatype$ });
                return;
            }
            if (type == "number") {
                this.value$ = value;
                this.operator$ = "=";
                this.datatype$ = Column.decimal;
                this.bindvalues$.push({ name: this.placeholder$, value: this.value$, type: this.datatype$ });
                return;
            }
        }
        if (value != null && (value + "").trim().length > 0 && this.datatype$ == null) {
            value = (value + "").trim();
            let numeric = !isNaN(+value);
            if (numeric)
                this.datatype$ = Column.decimal;
        }
        if (value == null) {
            this.operator$ = "is null";
            return;
        }
        if (this.datatype$ == null)
            this.datatype$ = Column.varchar;
        this.operator$ = "";
        let quoted = false;
        if (value.startsWith("<"))
            this.operator$ = "<";
        else if (value.startsWith(">"))
            this.operator$ = ">";
        if (this.operator$.length == 1) {
            value = value.substring(1).trim();
            if (value.startsWith("="))
                this.operator$ += "=";
        }
        if (this.operator$.length == 2)
            value = value.substring(1).trim();
        if (value.startsWith('"') && value.endsWith('"')) {
            quoted = true;
            value = value.substring(1, value.length - 1);
        }
        if (value.startsWith("'") && value.endsWith("'")) {
            quoted = true;
            value = value.substring(1, value.length - 1);
        }
        if (!quoted) {
            let like = false;
            if (value.indexOf("%") >= 0)
                like = true;
            if (value.indexOf("_") >= 0)
                like = true;
            if (like)
                this.operator$ = "like";
        }
        this.value$ = value.trim();
        if (this.operator$.length == 0)
            this.operator$ = "=";
        if (this.datatype$ == Column.decimal && isNaN(+this.value$)) {
            this.error$ = "Unable to parse " + this.value$ + " as number";
            return;
        }
        if (this.datatype$ == Column.integer && isNaN(+this.value$)) {
            this.error$ = "Unable to parse " + this.value$ + " as number";
            return;
        }
        if (this.datatype$ == Column.date) {
            let date = dates.parse(this.value$);
            if (date == null) {
                this.error$ = "Unable to parse '" + this.value$ + "' as date";
                return;
            }
            this.value$ = date.getTime();
            if (this.operator$ == "=")
                this.datebtwn();
        }
        if (this.operator$ != "between") {
            this.bindvalues$.push({ name: this.placeholder$, value: this.value$, type: this.datatype$ });
        }
        else {
            this.bindvalues$.push({ name: this.placeholder$[0], value: this.value$[0], type: this.datatype$ });
            this.bindvalues$.push({ name: this.placeholder$[1], value: this.value$[1], type: this.datatype$ });
        }
    }
    static ubid() {
        if (++Condition.id > 9999)
            Condition.id = 1;
        let ubid = "" + Condition.id;
        while (ubid.length < 4)
            ubid = "0" + ubid;
        return ("_" + ubid);
    }
    static where(column, value, datatype) {
        let condition = new Condition(column, value, datatype);
        condition.type$ = "where";
        return (condition);
    }
    datebtwn() {
        this.operator$ = "between";
        let sdate = this.value$;
        // add 24 hours - minus 1 sec
        let edate = sdate + 60 * 60 * 24 * 1000 - 1000;
        this.value$ = [sdate, edate];
        this.placeholder$ = [this.placeholder$ + "_0", this.placeholder$ + "_1"];
    }
    get column() {
        return (this.column$);
    }
    get placeholder() {
        return (this.placeholder$);
    }
    getValue() {
        if (this.bindvalues$.length == 0)
            return (null);
        if (this.bindvalues$.length == 1)
            return (this.bindvalues$[0].value);
        if (this.bindvalues$.length > 1) {
            let vals = [];
            this.bindvalues$.forEach((bv) => { vals.push(bv.value); });
            return (vals);
        }
    }
    setCondition(condition) {
        this.error$ = null;
        this.condition$ = condition;
    }
    error() {
        return (this.error$);
    }
    or() {
        this.type$ = "or";
        return (this);
    }
    and() {
        this.type$ = "and";
        return (this);
    }
    where() {
        this.type$ = "where";
        return (this);
    }
    next(next) {
        if (next == null)
            return (this.next$);
        if (this.next$ != null)
            this.next$.prev$ = next;
        this.next$ = next;
        next.prev$ = this;
        return (next);
    }
    prev(prev) {
        if (prev == null)
            return (this.prev$);
        if (this.prev$ != null)
            this.prev$.next$ = prev;
        this.prev$ = prev;
        prev.next$ = this;
        return (prev);
    }
    first() {
        let pc = this;
        while (pc.prev$ != null)
            pc = pc.prev$;
        return (pc);
    }
    last() {
        let nc = this;
        while (nc.next$ != null)
            nc = nc.next$;
        return (nc);
    }
    pop() {
        this.level$ = -1;
        return (this);
    }
    push() {
        this.level$ = +1;
        return (this);
    }
    errors() {
        let errors = [];
        let cd = this.first();
        while (cd != null) {
            if (cd.error() != null)
                errors.push(cd.error());
            cd = cd.next$;
        }
        return (errors);
    }
    getAllBindvalues() {
        let bindvalues = [];
        let cd = this.first();
        while (cd != null) {
            cd.bindvalues$.forEach((bindvalue) => { bindvalues.push(bindvalue); });
            cd = cd.next$;
        }
        return (bindvalues);
    }
    split() {
        let conditions = [];
        let cd = this.first();
        while (cd != null) {
            conditions.push(cd);
            cd = cd.next$;
        }
        return (conditions);
    }
    toString() {
        let nc = this;
        while (nc.prev$ != null)
            nc = nc.prev$;
        if (nc.next$ == null)
            return (nc.type$ + " " + this.clause(nc));
        let str = (nc.level$ == 0) ? "where " : "where (";
        str += this.clause(nc);
        if (nc.next$ != null)
            str += " " + nc.type$ + " ";
        while (nc.next$ != null) {
            nc = nc.next$;
            if (+nc.level$ > 0)
                str += "(";
            str += this.clause(nc);
            if (+nc.level$ < 0)
                str += ")";
            if (nc.next$ != null)
                str += " " + nc.type$ + " ";
        }
        return (str);
    }
    clause(cond) {
        if (cond.condition$ != null)
            return (cond.condition$);
        if (cond.operator$.startsWith("is"))
            return (cond.column$ + " " + cond.operator$);
        else if (cond.operator$ == "between")
            return (cond.column$ + " between :" + cond.placeholder$[0] + " and :" + cond.placeholder$[1]);
        else
            return (cond.column$ + " " + cond.operator$ + " :" + cond.placeholder$);
    }
}
Condition.id = 1;

var SQLType;
(function (SQLType) {
    SQLType[SQLType["call"] = 0] = "call";
    SQLType[SQLType["lock"] = 1] = "lock";
    SQLType[SQLType["select"] = 2] = "select";
    SQLType[SQLType["insert"] = 3] = "insert";
    SQLType[SQLType["update"] = 4] = "update";
    SQLType[SQLType["delete"] = 5] = "delete";
})(SQLType || (SQLType = {}));
class Statement {
    constructor(sql) {
        this.sql$ = null;
        this.rows$ = null;
        this.subquery$ = null;
        this.table$ = null;
        this.order$ = null;
        this.limit$ = null;
        this.type$ = null;
        this.cursor$ = null;
        this.columns$ = [];
        this.errors = null;
        this.override = false;
        this.constraint$ = null;
        this.updates$ = [];
        this.condition$ = null;
        this.bindvalues = [];
        if (sql != null) {
            if (sql.constructor.name == "String")
                this.sql$ = "" + sql;
            else
                this.type$ = sql;
        }
        this.findtype();
    }
    findtype() {
        if (this.sql$ != null) {
            this.type$ = SQLType.call;
            let test = this.sql$.trim().substring(0, 7).trim().toLowerCase();
            if (test == "select")
                this.type$ = SQLType.select;
            if (test == "insert")
                this.type$ = SQLType.insert;
            if (test == "update")
                this.type$ = SQLType.update;
            if (test == "delete")
                this.type$ = SQLType.delete;
        }
    }
    set type(type) {
        this.type$ = type;
    }
    get type() {
        return (this.type$);
    }
    get sql() {
        return (this.build().sql);
    }
    set sql(sql) {
        this.sql$ = sql;
        this.findtype();
        this.override = true;
    }
    rows(rows) {
        this.rows$ = rows;
        return (this);
    }
    isFunction() {
        return (this.type == SQLType.call);
    }
    isSelect() {
        return (this.type == SQLType.select);
    }
    isInsert() {
        return (this.type == SQLType.insert);
    }
    isUpdate() {
        return (this.type == SQLType.update);
    }
    isDelete() {
        return (this.type == SQLType.delete);
    }
    set table(table) {
        this.table$ = table;
    }
    set limit(limit) {
        this.limit$ = limit;
    }
    set constraint(where) {
        this.constraint$ = where;
    }
    set order(order) {
        this.order$ = order;
    }
    set cursor(cursor) {
        this.cursor$ = cursor;
    }
    get cursor() {
        return (this.cursor$);
    }
    update(name, value, datatype) {
        if (value != null && datatype == null) {
            let type = value.constructor.name.toLowerCase();
            if (type == "date") {
                datatype = Column.date;
                value = value.getTime();
            }
            if (type == "number")
                datatype = Column.decimal;
        }
        if (value != null && (value + "").trim().length > 0 && datatype == null) {
            value = (value + "").trim();
            let numeric = !isNaN(+value);
            if (numeric)
                datatype = Column.decimal;
        }
        if (datatype == null)
            datatype = Column.varchar;
        this.updates$.push({ name: name, value: value, type: datatype });
    }
    set columns(columns) {
        this.columns$ = [];
        if (columns.constructor.name == "String") {
            this.columns$.push("" + columns);
        }
        else {
            columns.forEach((column) => {
                this.columns$.push("" + column);
            });
        }
    }
    setCondition(condition) {
        if (condition.constructor.name == "Array") {
            let arr = condition;
            this.condition$ = arr[0];
            for (let i = 1; i < arr.length; i++)
                this.condition$ = this.condition$.and().next(arr[i]);
            this.condition$ = this.condition$.first();
        }
        else {
            this.condition$ = condition;
        }
    }
    pop() {
        if (this.condition$ != null)
            this.condition$.pop();
        return (this);
    }
    push() {
        if (this.condition$ != null)
            this.condition$.push();
        return (this);
    }
    where(column, value, datatype) {
        if (this.condition$ == null) {
            this.condition$ = new Condition(column, value, datatype);
            this.condition$.where();
        }
        else {
            let cd = new Condition(column, value, datatype);
            this.condition$ = this.condition$.where().next(cd);
        }
        return (this);
    }
    whand(column, value, datatype) {
        if (this.condition$ != null)
            return (this.and(column, value, datatype));
        else
            return (this.where(column, value, datatype));
    }
    and(column, value, datatype) {
        if (this.condition$ == null) {
            this.condition$ = new Condition(column, value, datatype);
        }
        else {
            let cd = new Condition(column, value, datatype);
            this.condition$ = this.condition$.and().next(cd);
        }
        return (this);
    }
    or(column, value, datatype) {
        if (this.condition$ == null) {
            this.condition$ = new Condition(column, value, datatype);
        }
        else {
            let cd = new Condition(column, value, datatype);
            this.condition$ = this.condition$.or().next(cd);
        }
        return (this);
    }
    returnvalue(column, datatype) {
        this.bindvalues.unshift({ name: column, value: null, type: datatype });
        return (this);
    }
    bind(column, value, datatype) {
        if (value != null && datatype == null) {
            let type = value.constructor.name.toLowerCase();
            if (type == "date") {
                datatype = Column.date;
                value = value.getTime();
            }
            if (type == "number")
                datatype = Column.decimal;
        }
        if (value != null && (value + "").trim().length > 0 && datatype == null) {
            value = (value + "").trim();
            let numeric = !isNaN(+value);
            if (numeric)
                datatype = Column.decimal;
        }
        if (datatype == null)
            datatype = Column.varchar;
        this.bindvalues.push({ name: column, value: value, type: datatype });
        return (this);
    }
    get subquery() {
        return (this.subquery$);
    }
    set subquery(subquery) {
        this.subquery$ = subquery;
    }
    validate() {
        if (this.errors != null)
            return (this.errors);
        this.errors = [];
        if (this.condition$ != null)
            this.errors = this.condition$.errors();
        return (this.errors);
    }
    getCondition() {
        return (this.condition$);
    }
    build() {
        switch (this.type) {
            case SQLType.call: return (this.buildcall());
            case SQLType.lock: return (this.buildselect());
            case SQLType.select: return (this.buildselect());
            case SQLType.insert: return (this.buildinsert());
            case SQLType.update: return (this.buildupdate());
            case SQLType.delete: return (this.builddelete());
            default: console.log("don't know how to build " + SQLType[this.type]);
        }
    }
    buildcall() {
        let bindvals = [];
        this.bindvalues.forEach((bindv) => {
            bindvals.push({
                name: bindv.name,
                type: Column[bindv.type].toLowerCase(),
                value: bindv.value
            });
        });
        return ({ sql: this.sql$, bindvalues: bindvals });
    }
    buildinsert() {
        let bindvals = [];
        this.bindvalues.forEach((bindv) => {
            bindvals.push({
                name: bindv.name,
                type: Column[bindv.type].toLowerCase(),
                value: bindv.value
            });
        });
        this.sql$ = "insert into " + this.table$ + " (";
        for (let i = 0; i < bindvals.length; i++) {
            this.sql$ += bindvals[i].name;
            if (i < bindvals.length - 1)
                this.sql$ += ",";
        }
        this.sql$ += ") values (";
        for (let i = 0; i < bindvals.length; i++) {
            this.sql$ += ":" + bindvals[i].name;
            if (i < bindvals.length - 1)
                this.sql$ += ",";
        }
        this.sql$ += ")";
        return ({ sql: this.sql$, bindvalues: bindvals });
    }
    buildupdate() {
        let updates = [];
        let bindvals = [];
        for (let i = 0; i < this.updates$.length; i++) {
            updates.push({
                name: this.updates$[i].name,
                type: Column[this.updates$[i].type].toLowerCase(),
                value: this.updates$[i].value
            });
        }
        // Bindvalues for the update
        updates.forEach((bindv) => { bindvals.push(bindv); });
        let bindvalues = this.bindvalues;
        if (this.condition$ != null)
            this.condition$.getAllBindvalues().forEach((bind) => { bindvalues.push(bind); });
        // Bindvalues for the whereclause
        this.bindvalues.forEach((bindv) => {
            bindvals.push({
                name: bindv.name,
                type: Column[bindv.type].toLowerCase(),
                value: bindv.value
            });
        });
        this.sql$ = "update " + this.table$ + " set ";
        for (let i = 0; i < updates.length; i++) {
            this.sql$ += updates[i].name + " = :" + updates[i].name;
            if (i < updates.length - 1)
                this.sql$ += ", ";
        }
        if (this.constraint$ != null)
            this.sql$ += " " + this.constraint$;
        if (this.condition$ != null)
            this.sql$ += " " + this.condition$.toString();
        return ({ sql: this.sql$, bindvalues: bindvals });
    }
    builddelete() {
        let sql = this.sql$;
        if (sql == null)
            sql = "delete from " + this.table$;
        if (this.constraint$ != null)
            sql += " " + this.constraint$;
        let bindvalues = this.bindvalues;
        if (this.condition$ != null) {
            sql += " " + this.condition$.toString();
            this.condition$.getAllBindvalues().forEach((bind) => { bindvalues.push(bind); });
        }
        let bindvals = [];
        bindvalues.forEach((bindv) => {
            bindvals.push({
                name: bindv.name,
                type: Column[bindv.type].toLowerCase(),
                value: bindv.value
            });
        });
        return ({ sql: sql, bindvalues: bindvals });
    }
    buildselect() {
        let sql = this.sql$;
        if (sql == null) {
            sql = "select ";
            if (this.columns$ != null) {
                for (let i = 0; i < this.columns$.length - 1; i++)
                    sql += this.columns$[i] + ", ";
                sql += this.columns$[this.columns$.length - 1];
            }
            if (this.table$ != null)
                sql += " from " + this.table$;
        }
        if (!this.override) {
            let whand = " where ";
            if (this.condition$ != null) {
                sql += " " + this.condition$.toString();
                whand = " and ";
            }
            if (this.constraint$ != null) {
                sql += whand + this.constraint$;
                whand = " and ";
            }
            if (this.subquery$ != null) {
                sql += whand + this.subquery$.sql;
                whand = " and ";
            }
            // Don't order by if lock
            if (this.type$ == SQLType.select && this.order$ != null)
                sql += " order by " + this.order$;
            if (this.limit$ != null)
                sql += " " + this.limit$;
        }
        let bindvalues = this.bindvalues;
        if (this.condition$ != null)
            this.condition$.getAllBindvalues().forEach((bind) => { bindvalues.push(bind); });
        let bindvals = [];
        bindvalues.forEach((bindv) => {
            bindvals.push({
                name: bindv.name,
                type: Column[bindv.type].toLowerCase(),
                value: bindv.value
            });
        });
        if (this.subquery$ != null) {
            this.subquery$.bindvalues.forEach((bindv) => { bindvals.push(bindv); });
        }
        let sqlstmt = { sql: sql, bindvalues: bindvals };
        if (this.rows$ != null)
            sqlstmt["rows"] = this.rows$;
        return (sqlstmt);
    }
}

class Table {
    constructor(conn, table, key, columns, fielddef, rows) {
        this.keys = [];
        this.dates = [];
        this.index = new Map();
        this.key = key;
        this.conn = conn;
        this.table = table;
        this.fetch$ = rows;
        this.criterias = [];
        this.columns$ = columns;
        this.fielddef = fielddef;
        this.cursor = table.name + Date.now();
        if (this.key == null) {
            this.key = new Key("primary");
            this.columns$.forEach((col) => { this.key.addColumn(col.name); });
        }
        if (this.table.where != null) {
            this.table.where = this.table.where.trim();
            if (this.table.where.startsWith("where "))
                this.table.where = this.table.where.substring(6);
            if (this.table.where.startsWith("and "))
                this.table.where = this.table.where.substring(4);
            if (this.table.where.length == 0)
                this.table.where = null;
        }
        this.fetch$ *= 4;
        if (this.fetch$ < 10)
            this.fetch$ = 10;
        this.cnames = [];
        this.columns$.forEach((column) => {
            this.cnames.push(column.name);
            this.index.set(column.name, column);
            let date = false;
            if (column.type == Column.date)
                date = true;
            this.dates.push(date);
        });
    }
    get name() {
        return (this.table.name);
    }
    get tabdef() {
        return (this.table);
    }
    get columns() {
        return (this.cnames);
    }
    mandatory(column) {
        let def = this.index.get(column);
        if (def == null || def.mandatory == null)
            return (false);
        return (def.mandatory);
    }
    databasecolumn(column) {
        return (this.index.has(column.toLowerCase()));
    }
    set fielddata(fielddata) {
        this.fielddata$ = fielddata;
    }
    get fielddata() {
        return (this.fielddata$);
    }
    get searchfilter() {
        return (this.criterias);
    }
    set searchfilter(filter) {
        this.criterias = filter;
    }
    lock(record, data) {
        return __awaiter(this, void 0, void 0, function* () {
            let cols = [];
            for (let i = 0; i < this.columns.length; i++)
                cols.push({ name: this.columns[i], value: data[i] });
            let where = true;
            let stmt = new Statement(SQLType.lock);
            stmt.columns = this.columns;
            stmt.table = this.table.name;
            for (let i = 0; i < this.keys[record].length; i++) {
                let type = this.index.get(this.columns[i]).type;
                if (!where)
                    stmt.and(this.columns[i], this.keys[record][i], type);
                else
                    stmt.where(this.columns[i], this.keys[record][i], type);
                where = false;
            }
            let lock = stmt.build();
            let response = yield this.conn.invoke("lock", lock);
            if (response["status"] == "failed") {
                console.log(JSON.stringify(response));
                return ({ status: "failed", message: "Row is locked by another user. Try later" });
            }
            let rows = response["rows"];
            if (rows.length == 0) {
                console.log("Row[" + record + "] has been deleted by another user. Requery to see changes");
                return ({ status: "failed", message: "Row[" + record + "] has been deleted by another user. Requery to see changes" });
            }
            let row = rows[0];
            for (let i = 0; i < this.columns.length; i++) {
                let cval = cols[i].value;
                if (cval != null && this.dates[i])
                    cval = cval.getTime();
                if (row[this.columns[i]] != cval) {
                    let problem = cols[i].name + "[" + record + "], db: " + row[this.columns[i]] + " != " + cval;
                    console.log("Row has been changed by another user. Requery to see changes");
                    return ({ status: "failed", message: "Row has been changed by another user. Requery to see changes" });
                }
            }
            return ({ status: "ok" });
        });
    }
    insert(record, data) {
        return __awaiter(this, void 0, void 0, function* () {
            let cols = [];
            for (let i = 0; i < this.columns.length; i++)
                cols.push({ name: this.columns[i], value: data[i] });
            let stmt = new Statement(SQLType.insert);
            stmt.columns = this.columns;
            stmt.table = this.table.name;
            let keyval = [];
            for (let i = 0; i < this.columns.length; i++) {
                let cval = cols[i].value;
                let type = this.index.get(this.columns[i]).type;
                if (cval != null && this.dates[i])
                    cval = cval.getTime();
                if (i < this.key.columns().length)
                    keyval.push(cval);
                stmt.bind(cols[i].name, cval, type);
            }
            let insert = stmt.build();
            this.keys.splice(+record, 0, keyval);
            let response = yield this.conn.invoke("insert", insert);
            return (response);
        });
    }
    update(record, data) {
        return __awaiter(this, void 0, void 0, function* () {
            let keyupd = [];
            let keyval = this.keys[+record];
            let stmt = new Statement(SQLType.update);
            for (let i = 0; i < data.length; i++) {
                if (i < this.key.columns().length)
                    keyupd.push(keyval[i]);
                if (data[i].value.updated) {
                    let val = data[i].value.newvalue;
                    let type = this.index.get(data[i].name).type;
                    if (val != null && this.dates[i])
                        val = val.getTime();
                    if (i < this.key.columns().length)
                        keyupd[i] = val;
                    stmt.update(data[i].name, val, type);
                }
            }
            let where = true;
            if (this.table.where != null && this.table.where.trim.length > 0) {
                where = false;
                stmt.constraint = this.table.where;
            }
            for (let i = 0; i < keyval.length; i++) {
                let type = this.index.get(this.columns[i]).type;
                if (!where)
                    stmt.and(this.columns[i], keyval[i], type);
                else
                    stmt.where(this.columns[i], keyval[i], type);
                where = false;
            }
            stmt.table = this.table.name;
            let update = stmt.build();
            let response = yield this.conn.invoke("update", update);
            if (response["status"] != "failed")
                this.keys[+record] = keyupd;
            return (response);
        });
    }
    delete(record) {
        return __awaiter(this, void 0, void 0, function* () {
            let keyval = this.keys[+record];
            let stmt = new Statement(SQLType.delete);
            let where = true;
            if (this.table.where != null && this.table.where.trim.length > 0) {
                where = false;
                stmt.constraint = this.table.where;
            }
            for (let i = 0; i < keyval.length; i++) {
                let type = this.index.get(this.columns[i]).type;
                if (!where)
                    stmt.and(this.columns[i], keyval[i], type);
                else
                    stmt.where(this.columns[i], keyval[i], type);
                where = false;
            }
            stmt.table = this.table.name;
            let delrow = stmt.build();
            let response = yield this.conn.invoke("delete", delrow);
            if (response["status"] == "failed")
                return (response);
            let keys = this.keys.slice(0, record);
            keys = keys.concat(this.keys.slice(+record + 1, this.keys.length));
            this.keys = keys;
            return (response);
        });
    }
    parseQuery(keys, subquery, fields) {
        let stmt = new Statement(SQLType.select);
        stmt.cursor = this.cursor;
        stmt.columns = this.cnames;
        stmt.table = this.table.name;
        stmt.order = this.table.order;
        let where = true;
        if (this.table.limit != null)
            stmt.limit = this.table.limit;
        if (this.table.where != null) {
            where = false;
            stmt.constraint = this.table.where;
        }
        if (fields.length > 0) {
            this.criterias = [];
            fields.forEach((field) => {
                if (field.value != null && ("" + field.value).trim() != "")
                    this.criterias.push({ name: field.name, value: field.value });
            });
        }
        keys.forEach((key) => {
            key.values.forEach((part) => {
                let col = part.name;
                // Check if key column is mapped to diff. name
                let def = this.fielddef.get(col);
                if (def != null)
                    col = def.column;
                let type = this.index.get(col).type;
                if (!where)
                    stmt.and(col, part.value, type);
                else
                    stmt.where(col, part.value, type);
                where = false;
            });
        });
        this.criterias.forEach((field) => {
            let def = this.fielddef.get(field.name);
            if (def.column != null) {
                let type = this.index.get(def.column).type;
                if (!where)
                    stmt.and(def.column, field.value, type);
                else
                    stmt.where(def.column, field.value, type);
                where = false;
            }
        });
        if (subquery != null)
            stmt.subquery = subquery;
        return (stmt);
    }
    executequery(stmt) {
        return __awaiter(this, void 0, void 0, function* () {
            this.keys = [];
            this.eof = false;
            this.fielddata.clear();
            this.select = stmt.build();
            this.select.rows = this.fetch$;
            this.select.cursor = stmt.cursor;
            let response = yield this.conn.invoke("select", this.select);
            if (response["status"] == "failed")
                return (response);
            this.addRows(response["rows"]);
            return (response);
        });
    }
    fetch(stmt) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.eof)
                return ({ status: "ok" });
            let fetch = { cursor: stmt.cursor, rows: this.fetch$ };
            let response = yield this.conn.invoke("fetch", fetch);
            if (response["status"] == "failed")
                return (response);
            this.addRows(response["rows"]);
            return (response);
        });
    }
    addRows(rows) {
        let klen = this.key.values.length;
        if (rows.length < this.fetch$)
            this.eof = true;
        rows.forEach((row) => {
            // Table is not defined
            if (this.cnames.length == 0) {
                let keys = Object.keys(row);
                let flds = this.fielddata.fields;
                for (let i = 0; i < keys.length; i++)
                    this.cnames.push(keys[i]);
                for (let i = 0; i < keys.length - flds.length; i++)
                    flds.unshift(keys[i]);
                this.fielddata.fields = flds;
            }
            let col = 0;
            let keyval = [];
            let drow = this.fielddata.newrow();
            Object.keys(row).forEach((key) => {
                let val = row[key];
                if (this.dates[col] && ("" + val).length > 0)
                    val = new Date(+val);
                drow.setValue(col++, val);
                if (keyval.length < klen)
                    keyval.push(val);
            });
            this.keys.push(keyval);
            this.fielddata.add(drow);
        });
    }
}

class FieldData {
    constructor(block, table, fields, fielddef) {
        this.data = [];
        this.index = new Map();
        this.block = block;
        this.table$ = table;
        this.fields$ = fields;
        this.fielddef = fielddef;
        if (table != null)
            this.table$.fielddata = this;
        if (fields != null) {
            for (let i = 0; i < fields.length; i++)
                this.index.set(fields[i].toLowerCase(), i);
        }
    }
    get table() {
        return (this.table$);
    }
    get tabdef() {
        var _a;
        return ((_a = this.table$) === null || _a === void 0 ? void 0 : _a.tabdef);
    }
    get database() {
        return (this.table != null);
    }
    databasecolumn(column) {
        if (this.table == null)
            return (false);
        return (this.table.databasecolumn(column));
    }
    get fields() {
        return (this.fields$);
    }
    set fields(fields) {
        this.index.clear();
        this.fields$ = fields;
        for (let i = 0; i < fields.length; i++)
            this.index.set(fields[i].toLowerCase(), i);
    }
    get columns() {
        if (this.table == null)
            return (null);
        else
            return (this.table.columns);
    }
    get fetched() {
        return (this.data.length);
    }
    removeLocks() {
        this.data.forEach((row) => { row.locked = false; });
    }
    lock(record) {
        return __awaiter(this, void 0, void 0, function* () {
            if (record < 0 || record >= this.data.length)
                return ({ status: "failed", message: "row " + record + " does not exist" });
            if (this.data[record].locked)
                return ({ status: "failed", message: "row " + record + " already locked" });
            if (this.table == null)
                return ({ status: "ok" });
            let response = { status: "ok" };
            if (this.table != null) {
                response = yield this.table.lock(record, this.data[+record].values);
                if (response["status"] == "failed")
                    return (response);
            }
            this.data[record].locked = true;
            return (response);
        });
    }
    locked(record) {
        if (record < 0 || record >= this.data.length)
            return (false);
        if (this.data[+record].state == RecordState.insert)
            return (true);
        return (this.data[+record].locked);
    }
    mandatory(column) {
        var _a;
        let md = false;
        if (this.table != null)
            md = this.table.mandatory(column);
        if (!md) {
            md = (_a = this.fielddef.get(column)) === null || _a === void 0 ? void 0 : _a.mandatory;
            if (md == null)
                md = false;
        }
        return (md);
    }
    getNonValidated(record) {
        if (record < 0 || record >= this.data.length)
            return ([]);
        let row = this.data[record];
        let cols = [];
        for (let i = 0; i < row.fields.length; i++) {
            if (this.mandatory(this.fields[i]) && row.fields[i].value$ == null) {
                cols.push(this.columns[i]);
            }
            else if (!row.fields[i].validated) {
                cols.push(this.columns[i]);
            }
        }
        return (cols);
    }
    validated(record, fields) {
        if (record < 0 || record >= this.data.length)
            return (true);
        let row = this.data[record];
        if (fields) {
            for (let i = 0; i < row.fields.length; i++) {
                if (this.mandatory(this.fields[i]) && row.fields[i].value$ == null)
                    return (false);
                if (!row.fields[i].validated)
                    return (false);
            }
            return (true);
        }
        return (row.validated);
    }
    newrow() {
        let row = new Row(0, this);
        return (row);
    }
    add(row) {
        this.data.push(row);
    }
    column(fname) {
        return (this.index.get(fname.toLowerCase()));
    }
    clear() {
        this.data = [];
    }
    getValue(record, column) {
        if (+record < 0 || +record >= +this.data.length) {
            console.log("get " + column + "[" + record + "] record does not exist");
            return (null);
        }
        let colno = this.index.get(column.toLowerCase());
        if (colno == null) {
            console.log("get " + column + "[" + record + "] column does not exist");
            return (null);
        }
        let rec = this.data[+record];
        return (rec.fields[+colno].value$);
    }
    getValidated(record, column) {
        if (record < 0 || record >= this.data.length) {
            console.log("set " + column + "[" + record + "] row does not exist");
            return (true);
        }
        let rec = this.data[+record];
        if (column == null)
            return (rec.validated);
        let colno = this.index.get(column.toLowerCase());
        if (colno == null) {
            console.log("set " + column + "[" + record + "] column does not exist");
            return;
        }
        return (rec.fields[+colno].validated);
    }
    setValidated(record, column) {
        return __awaiter(this, void 0, void 0, function* () {
            if (record < 0 || record >= this.data.length)
                return ({ status: "failed", message: "set " + column + "[" + record + "] validated failed, row does not exist" });
            let rec = this.data[+record];
            if (column == null) {
                if (rec.validated)
                    return ({ status: "failed", message: "Record already validated" });
                if (rec.state == RecordState.insert) {
                    if (this.table != null) {
                        let scn = rec.scn;
                        let response = yield this.table.insert(record, this.data[+record].values);
                        if (response["status"] == "failed")
                            return (response);
                        rec.dbn = scn;
                    }
                }
                else if (this.table != null) {
                    let scn = rec.scn;
                    let columns = [];
                    for (let i = 0; i < this.columns.length; i++) {
                        let status = { updated: false };
                        if (+rec.fields[i].scn > +rec.dbn) {
                            status.updated = true;
                            status.newvalue = rec.fields[i].value$;
                        }
                        columns.push({ name: this.columns[i], value: status });
                    }
                    let response = yield this.table.update(record, columns);
                    if (response["status"] == "failed")
                        return (response);
                    rec.dbn = scn;
                }
                rec.validated = true;
                if (rec.state == RecordState.insert)
                    rec.state = RecordState.update;
                return ({ status: "ok" });
            }
            let colno = this.index.get(column.toLowerCase());
            if (colno == null)
                return ({ status: "failed", message: "set " + column + "[" + record + "] validated failed, column does not exist" });
            if (this.table != null && +colno < this.table.columns.length)
                rec.fields[+colno].validated = true;
            return ({ status: "ok" });
        });
    }
    setValue(record, column, value) {
        if (record < 0 || record >= this.data.length) {
            console.log("set " + column + "[" + record + "] row does not exist");
            return (false);
        }
        let colno = this.index.get(column.toLowerCase());
        if (colno == null) {
            console.log("set " + column + "[" + record + "] column does not exist");
            return (false);
        }
        let rec = this.data[+record];
        if (rec.fields[+colno].value$ == value)
            return (false);
        let scn = +rec.scn + 1;
        if (this.table != null && +colno < this.table.columns.length) {
            rec.validated = false;
            rec.fields[+colno].validated = false;
        }
        rec.scn = scn;
        rec.fields[+colno].setValue(scn, value);
        return (true);
    }
    state(record, state) {
        if (record >= this.data.length)
            return (RecordState.na);
        if (state != null)
            this.data[record].state = state;
        return (this.data[record].state);
    }
    get searchfilter() {
        if (this.table == null)
            return (null);
        return (this.table.searchfilter);
    }
    set searchfilter(filter) {
        if (this.table != null)
            this.table.searchfilter = filter;
    }
    parseQuery(keys, subquery, fields) {
        if (this.table == null)
            return (null);
        return (this.table.parseQuery(keys, subquery, fields));
    }
    executequery(stmt) {
        return __awaiter(this, void 0, void 0, function* () {
            this.query = stmt;
            if (this.table == null)
                return ({ status: "ok" });
            let response = yield this.table.executequery(stmt);
            if (response["status"] != "failed") {
                let rows = response["rows"];
                for (let i = 0; i < rows.length; i++) {
                    let event = new SQLTriggerEvent(this.block.alias, i, null);
                    this.block.invokeTriggers(Trigger.PostQuery, event);
                }
            }
            return (response);
        });
    }
    insert(record) {
        let data = [];
        if (record > this.data.length)
            record = this.data.length;
        data = this.data.slice(0, record);
        data[+record] = new Row(0, this);
        data[+record].locked = true;
        data[+record].state = RecordState.insert;
        data = data.concat(this.data.slice(record, this.data.length));
        this.data = data;
        return (true);
    }
    delete(record) {
        return __awaiter(this, void 0, void 0, function* () {
            let data = [];
            let response = { status: "ok" };
            if (record < 0 || record >= this.data.length)
                return (response);
            if (this.data[+record].state == RecordState.insert) {
                data = this.data.slice(0, record);
                data = data.concat(this.data.slice(+record + 1, this.data.length));
                this.data = data;
                return (response);
            }
            if (this.table != null) {
                response = yield this.table.delete(record);
                if (response["status"] == "failed")
                    return (response);
            }
            data = this.data.slice(0, record);
            data = data.concat(this.data.slice(+record + 1, this.data.length));
            this.data = data;
            return (response);
        });
    }
    get rows() {
        return (this.data.length);
    }
    fetch(offset, rows) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data.length <= +offset + rows && this.query != null) {
                let response = yield this.table.fetch(this.query);
                if (response["status"] == "failed") {
                    this.block.alert(JSON.stringify(response), "Database");
                    return (0);
                }
                else {
                    let rows = response["rows"];
                    if (rows != null) {
                        for (let i = 1; i <= rows.length; i++) {
                            let event = new SQLTriggerEvent(this.block.alias, +i + +offset, null);
                            this.block.invokeTriggers(Trigger.PostQuery, event);
                        }
                    }
                }
            }
            let avail = this.data.length - offset - 1;
            if (avail < 0)
                avail = 0;
            return (avail);
        });
    }
    get(start, rows) {
        let values = [];
        if (start < 0)
            start = 0;
        let end = +start + rows;
        if (end > this.data.length)
            end = this.data.length;
        for (let i = start; i < end; i++)
            values.push(this.data[i].values);
        return (values);
    }
}
class Row {
    constructor(scn, table, values) {
        this.scn = 0;
        this.dbn = 0;
        this.fields = [];
        this.locked = false;
        this.validated = true;
        this.state = RecordState.na;
        this.scn = scn;
        for (let i = 0; i < table.fields.length; i++)
            this.fields.push(new Column$1(scn));
        let i = 0;
        if (values != null)
            this.fields.forEach((column) => { column.setValue(scn, values[i++]); });
    }
    setValue(col, value) {
        // Used by table
        this.fields[col].value$ = value;
    }
    get values() {
        let values = [];
        this.fields.forEach((col) => {
            values.push(col.value$);
        });
        return (values);
    }
    print() {
        let i = 0;
        let values = "";
        this.fields.forEach((col) => {
            let val = col.value$;
            if (val == null)
                val = "";
            values += i + " " + col.value$ + ", ";
            i++;
        });
        values = values.substring(0, values.length - 2);
        console.log(values);
    }
}
class Column$1 {
    constructor(scn, value) {
        this.scn = 0;
        this.validated = true;
        this.scn = scn;
        this.value$ = value;
        if (value == undefined)
            this.value$ = null;
    }
    setValue(scn, value) {
        this.scn = scn;
        this.value$ = value;
        if (value == undefined)
            this.value$ = null;
    }
}

class ListOfValuesImpl {
    constructor(ctx) {
        this.last = "";
        this.minlen = 0;
        this.prefix = "";
        this.postfix = "";
        this.wait = false;
        this.rows = 10;
        this.size = 20;
        this.top = null;
        this.left = null;
        this.width = null;
        this.height = null;
        this.title = null;
        this.app = ctx.app["_impl_"];
    }
    static show(app, impl, lov) {
        let pinst = new PopupInstance();
        pinst.display(app, ListOfValuesImpl);
        let lovwin = pinst.popup();
        lovwin.setDefinition(lov);
        lovwin.setBlockImpl(impl);
    }
    setDefinition(lov) {
        this.lov = lov;
        this.title = lov.title;
        this.width = lov.width;
        this.height = lov.height;
        this.rows = lov.rows ? lov.rows : 12;
        this.fetch = lov.rows ? lov.rows : 12;
        if (this.size == null)
            this.size = 25;
        let width = this.size * 12;
        let height = this.rows * 28 + 16;
        if (this.width == null)
            this.width = width + "px";
        if (this.height == null)
            this.height = height + "px";
        this.win.title = this.title;
        this.win.width = this.width;
        this.win.height = this.height;
        if (this.lov.minlen != null)
            this.minlen = this.lov.minlen;
        if (this.lov.prefix != null)
            this.prefix = this.lov.prefix;
        if (this.lov.postfix != null)
            this.postfix = this.lov.postfix;
    }
    setBlockImpl(impl) {
        this.iblock = impl[0];
        this.sblock = impl[1];
        this.rblock = impl[2];
    }
    close(_cancel) {
        var _a;
        this.app.enable();
        this.win.closeWindow();
        (_a = this.app.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.focus();
    }
    setWin(win) {
        this.win = win;
    }
    ngOnInit() {
        this.app.disable();
        this.app.setContainer();
    }
    ngAfterViewInit() {
        let container = this.app.getContainer();
        container.finish();
        this.sblock.setFields(container.getBlock("search").fields);
        this.rblock.setFields(container.getBlock("result").fields);
        this.rblock.usage = { query: true };
        container.getBlock("search").records.forEach((rec) => {
            this.sblock.addRecord(new Record(rec.row, rec.fields, rec.index));
            this.filter = this.sblock.getField(rec.row, "filter");
            let filtdef = { name: "filter", type: FieldType.text };
            if (this.lov.case != null)
                filtdef.case = this.lov.case;
            this.filter.setDefinition(filtdef, true);
            this.filter.enable(false);
        });
        let fielddef = new Map();
        let descdef = { name: "description", type: FieldType.text, fieldoptions: { update: false } };
        fielddef.set("description", descdef);
        container.getBlock("result").records.forEach((rec) => {
            this.rblock.addRecord(new Record(rec.row, rec.fields, rec.index));
            this.description = this.rblock.getField(rec.row, "description");
            this.description.setDefinition(descdef, true);
            this.description.enable(true);
        });
        let conn = this.app.appstate.connection;
        let table = new Table(conn, { name: "none" }, null, [], null, this.fetch);
        this.rblock.setApplication(this.app);
        this.rblock.data = new FieldData(this.rblock, table, ["description"], fielddef);
        this.app.dropContainer();
        let keys = [
            keymap.enter,
            keymap.escape,
            keymap.nextrecord,
            keymap.prevrecord,
            keymap.nextfield,
            keymap.prevfield
        ];
        this.sblock.addKeyTrigger(this, this.onkey, keys);
        this.rblock.addKeyTrigger(this, this.onkey, keys);
        this.sblock.addTrigger(this, this.search, Trigger.Typing);
        this.rblock.addTrigger(this, this.prequery, Trigger.PreQuery);
        this.rblock.addTrigger(this, this.onMouse, Trigger.MouseDoubleClick);
        this.rblock.navigable = false;
        this.filter.focus();
        if (this.lov.autoquery) {
            this.last = " ";
            this.search(null);
        }
    }
    search(_event) {
        return __awaiter(this, void 0, void 0, function* () {
            this.execute();
            return (true);
        });
    }
    execute() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.wait) {
                setTimeout(() => { this.execute(); }, 200);
                return;
            }
            if (this.filter.value == this.last)
                return;
            this.wait = true;
            this.last = this.filter.value;
            if (this.last == null)
                this.last = "";
            if (this.last.length < this.minlen)
                this.rblock.clear();
            else
                yield this.rblock.keyexeqry();
            this.wait = false;
        });
    }
    prequery(event) {
        return __awaiter(this, void 0, void 0, function* () {
            let stmt = new Statement(this.lov.sql);
            stmt.cursor = event.stmt.cursor;
            if (this.lov.bindvalues != null)
                this.lov.bindvalues.forEach((bv) => { stmt.bind(bv.name, bv.value, bv.type); });
            if (this.filter.value == null)
                this.filter.value = "";
            stmt.bind("filter", this.prefix + this.filter.value + this.postfix);
            event.stmt = stmt;
            return (true);
        });
    }
    onMouse(event) {
        return __awaiter(this, void 0, void 0, function* () {
            this.picked(event.record);
            return (true);
        });
    }
    onkey(event) {
        return __awaiter(this, void 0, void 0, function* () {
            if (event.type == Trigger.Key && event.field == "filter") {
                if (event.key == keymap.prevfield)
                    event.event.preventDefault();
                if (event.key == keymap.nextfield || event.key == keymap.nextrecord) {
                    this.rblock.navigable = true;
                    this.rblock.focus(0);
                }
            }
            if (event.type == Trigger.Key && event.field == "description") {
                if (event.key == keymap.nextfield || event.key == keymap.prevfield) {
                    this.sblock.focus();
                    event.event.preventDefault();
                    this.rblock.navigable = false;
                }
            }
            if (event.type == Trigger.Key && event.key == keymap.escape)
                this.close(false);
            if (event.type == Trigger.Key && event.key == keymap.enter) {
                let record = -1;
                if (event.field == "filter" && this.rblock.fetched == 1)
                    record = 0;
                if (event.field == "description")
                    record = event.record;
                if (record >= 0)
                    this.picked(record);
            }
            return (true);
        });
    }
    picked(record) {
        this.lov.fieldmap.forEach((col, fld) => {
            let val = this.rblock.getValue(record, fld);
            this.iblock.setValue(this.iblock.record, col, val);
        });
        this.close(false);
    }
}
ListOfValuesImpl.decorators = [
    { type: Component, args: [{
                template: `
        <div class="lov">
        <table>
            <tr>
                <td class="lov-center"><field class="lov-search" size="15" name="filter" block="search"></field></td>
            </tr>

            <tr class="lov-spacer"></tr>

            <tr *ngFor="let item of [].constructor(rows); let row = index">
                <td><field class="lov-result" size="{{size}}" name="description" row="{{row}}" block="result"></field></td>
            </tr>

            <tr class="lov-spacer"></tr>
        </table>
        </div>
    `,
                styles: [`
            .lov-spacer
            {
                height: 8px;
            }

            .lov-center
            {
                border: none;
                display: flex;
                justify-content: center;
            }
        `]
            },] }
];
ListOfValuesImpl.ctorParameters = () => [
    { type: Context }
];

class BlockImpl {
    constructor(block) {
        this.block = block;
        this.row$ = 0;
        this.offset = 0;
        this.form$ = null;
        this.ready$ = false;
        this.records$ = [];
        this.querying$ = false;
        this.disabled$ = false;
        this.navigable$ = true;
        this.lastqry = [];
        this.fields$ = [];
        this.triggers = new Triggers();
        this.state = FormState.normal;
        this.fieldidx$ = new Map();
        this.dbusage$ =
            {
                query: false,
                update: true,
                insert: false,
                delete: false
            };
        if (block != null) {
            this.name$ = block.constructor.name;
            if (this.name$ == "Block")
                this.name$ = "anonymous";
        }
    }
    get name() {
        return (this.name$);
    }
    set alias(alias) {
        this.alias$ = alias;
    }
    get alias() {
        return (this.alias$);
    }
    get table() {
        var _a;
        return ((_a = this.data) === null || _a === void 0 ? void 0 : _a.tabdef);
    }
    set row(row) {
        this.row$ = row;
    }
    get row() {
        return (this.row$);
    }
    exists(record) {
        if (+record < +this.data.rows)
            return (true);
        return (false);
    }
    displayed(record) {
        if (+record < +this.offset)
            return (false);
        if (+record > +this.sum(this.offset, this.rows))
            return (false);
        let row = +record - +this.offset;
        let state = this.records[+row].state;
        if (state == RecordState.na || state == RecordState.qmode)
            return (false);
        return (true);
    }
    get rows() {
        return (this.records$.length);
    }
    database() {
        var _a;
        return ((_a = this.data) === null || _a === void 0 ? void 0 : _a.database);
    }
    get datarows() {
        if (this.data == null)
            return (0);
        return (this.data.rows);
    }
    get columns() {
        if (this.data == null)
            return (null);
        else
            return (this.data.columns);
    }
    get ready() {
        return (this.ready$);
    }
    set ready(ready) {
        this.ready$ = ready;
        let rec = this.getRecord(0);
        if (rec != null) {
            rec.enable(true);
            rec.current = true;
        }
    }
    get navigable() {
        return (this.navigable$);
    }
    set navigable(navigable) {
        this.navigable$ = navigable;
    }
    get record() {
        return (this.sum(this.row, this.offset));
    }
    get fetched() {
        if (this.data == null)
            return (0);
        return (this.data.fetched);
    }
    get field() {
        return (this.field$);
    }
    get fields() {
        if (this.data == null)
            return (null);
        else
            return (this.data.fields);
    }
    get clazz() {
        if (this.block == null)
            return (null);
        return (this.block.constructor.name.toLowerCase());
    }
    get data() {
        return (this.data$);
    }
    set data(data) {
        this.data$ = data;
    }
    set form(form) {
        this.form$ = form;
    }
    get form() {
        return (this.form$);
    }
    setFieldDefinition(def) {
        let inst = this.fieldidx$.get(def.name);
        if (inst != null) {
            let fields = inst.parent.fields;
            let cfields = inst.parent.cfields;
            fields.forEach((fld) => { if (fld.id == inst.id)
                fld.definition = def; });
            cfields.forEach((fld) => { if (fld.id == inst.id)
                fld.definition = def; });
            return (true);
        }
        return (false);
    }
    setPossibleValues(field, values, enforce) {
        let inst = this.fieldidx$.get(field);
        if (inst != null) {
            let fields = inst.parent.fields;
            let cfields = inst.parent.cfields;
            fields.forEach((fld) => { if (fld.id == inst.id)
                fld.setPossibleValues(values, enforce); });
            cfields.forEach((fld) => { if (fld.id == inst.id)
                fld.setPossibleValues(values, enforce); });
            return (true);
        }
        return (false);
    }
    setFields(fields) {
        this.fields$ = fields;
        fields.forEach((inst) => {
            let name = inst.name;
            if (inst.id != null && inst.id.length > 0)
                name += "." + inst.id;
            this.fieldidx$.set(name, inst);
        });
    }
    setMasterDetail(md) {
        this.masterdetail = md;
    }
    setListOfValues(lovs) {
        this.lovs = lovs;
    }
    setIdListOfValues(lovs) {
        this.idlovs = lovs;
    }
    addListOfValues(form, func, field, id) {
        let utils = new Utils();
        let lovdef = null;
        let params = utils.getParams(func);
        if (!form)
            lovdef = { inst: this.block, func: func.name, params: params };
        else
            lovdef = { inst: this.form.form, func: func.name, params: params };
        if (id == null)
            this.lovs.set(field.toLowerCase(), lovdef);
        else
            this.idlovs.set(field.toLowerCase(), lovdef);
    }
    removeListOfValues(field, id) {
        if (id == null)
            this.lovs.delete(field.toLowerCase());
        else
            this.idlovs.delete(field.toLowerCase() + "." + id.toLowerCase());
    }
    get querymode() {
        return (this.state == FormState.entqry);
    }
    focus(row) {
        var _a;
        if (!this.navigable)
            return;
        if (row != null && row >= 0 && row < this.rows) {
            if ((_a = this.records[+row]) === null || _a === void 0 ? void 0 : _a.enabled) {
                this.row = row;
                this.records[+row].current = true;
            }
        }
        let rec = this.records[+this.row];
        if (this.field != null) {
            let field = rec.getField(this.field.name);
            let inst = rec.getFieldByGuid(this.field.name, this.field.guid);
            if (inst === null || inst === void 0 ? void 0 : inst.focus())
                return;
            if (field === null || field === void 0 ? void 0 : field.focus())
                return;
        }
        for (let i = 0; i < this.fields$.length; i++) {
            if (this.fields$[i].row == this.row)
                if (this.fields$[i].focus())
                    return;
        }
        rec === null || rec === void 0 ? void 0 : rec.focus();
    }
    getValue(record, column) {
        if (this.state == FormState.entqry) {
            let field = this.records[0].getField(column);
            return (field === null || field === void 0 ? void 0 : field.value);
        }
        if (this.data == null)
            return (null);
        return (this.data.getValue(+record, column));
    }
    setValue(record, column, value) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data == null)
                return (false);
            if (this.state == FormState.entqry) {
                let field = this.records[0].getField(column);
                if (field != null)
                    field.value = value;
                return (true);
            }
            let previous = this.data.getValue(+record, column);
            if (!(yield this.lockrecord(record, column)))
                return (false);
            if (!this.data.setValue(+record, column, value))
                return (false);
            this.data.setValidated(record, column);
            let trgevent = new FieldTriggerEvent(this.alias, column, null, +record, value, previous);
            this.invokeFieldTriggers(Trigger.PostChange, column, trgevent);
            if (+record >= +this.offset && +record < this.sum(this.offset, this.rows)) {
                let field = this.records[record - this.offset].getField(column);
                if (field != null)
                    field.value = value;
            }
            if (record == this.record && this.masterdetail != null && value != previous)
                this.masterdetail.sync(this, column);
        });
    }
    get records() {
        return (this.records$);
    }
    getRecord(row) {
        if (+row < +this.records$.length)
            return (this.records$[+row]);
        return (null);
    }
    getField(row, name) {
        var _a;
        return ((_a = this.records[+row]) === null || _a === void 0 ? void 0 : _a.getField(name));
    }
    addRecord(record) {
        this.records.push(record);
        record.fields.forEach((inst) => { inst.block = this; });
        if (this.records.length == 1) {
            record.current = true;
            this.field$ = record.fields[0].getFirstInstance();
        }
    }
    set usage(usage) {
        this.dbusage$ = usage;
    }
    get usage() {
        return (this.dbusage$);
    }
    setApplication(app) {
        this.app = app;
    }
    sendkey(event, key) {
        return __awaiter(this, void 0, void 0, function* () {
            if (event == null)
                event = new KeyTriggerEvent(Origin.Block, this.alias, null, key, null);
            return (yield this.onEvent(event, this.field, "key", key));
        });
    }
    get searchfilter() {
        if (this.data == null)
            return (null);
        return (this.data.searchfilter);
    }
    set searchfilter(filter) {
        if (this.data != null)
            this.data.searchfilter = filter;
    }
    removeLocks() {
        if (this.data != null)
            this.data.removeLocks();
    }
    execute(stmt, firstrow, firstcolumn) {
        return __awaiter(this, void 0, void 0, function* () {
            if (stmt == null)
                return (null);
            let errors = stmt.validate();
            if (errors.length > 0) {
                let msg = "<table>";
                errors.forEach((err) => { msg += "<tr><td>" + err + "</td></tr>"; });
                msg += "</table>";
                this.alert(msg, "Execute");
                return (null);
            }
            let response = yield this.app.appstate.connection.invokestmt(stmt);
            if (response["status"] == "failed")
                this.alert(JSON.stringify(response), "Execute SQL Failed");
            let rows = response["rows"];
            if (rows == null) {
                if (firstcolumn)
                    return (null);
                return ([]);
            }
            if (!firstrow)
                return (rows);
            let row = [];
            if (rows.length > 0)
                row = rows[0];
            if (!firstcolumn)
                return (row);
            let columns = Object.keys(row);
            if (columns.length == 0)
                return (null);
            return (row[columns[0]]);
        });
    }
    showDatePicker(field, row) {
        if (row == null || row == -1)
            row = this.row;
        let record = this.sum(this.offset, row);
        if (record >= this.records.length)
            return;
        if (this.records[record].state == RecordState.na)
            return;
        if (this.records[record].state == RecordState.update && !this.usage.update)
            return;
        let fld = this.records[+record].getField(field);
        let value = new Date();
        if (fld != null)
            value = fld.value;
        DatePicker.show(this.app, this, record, field, value);
    }
    showListOfValues(field, id, row) {
        var _a;
        if (field == null)
            return;
        if (row == null || row == -1)
            row = this.row;
        if (!this.app.connected)
            return;
        if (!this.records[+row].enabled)
            return;
        if (this.records[+row].state == RecordState.na)
            return;
        let ldef = null;
        field = field.trim().toLowerCase();
        if (this.idlovs != null && id != null && id.trim().length > 0) {
            id = id.trim().toLowerCase();
            ldef = this.idlovs.get(field + "." + id);
        }
        else if (this.lovs != null) {
            ldef = this.lovs.get(field);
        }
        if (ldef != null) {
            let lov = null;
            let record = this.sum(row, this.offset);
            if (ldef.params.length == 0)
                lov = ldef.inst[ldef.func]();
            else
                lov = ldef.inst[ldef.func](record);
            let blocks = [this, new BlockImpl(), new BlockImpl()];
            if (!lov.force && ((_a = this.records[+row].getField(field)) === null || _a === void 0 ? void 0 : _a.readonly))
                return;
            ListOfValuesImpl.show(this.app, blocks, lov);
        }
    }
    keyinsert(after) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data == null)
                return (false);
            if (!this.usage.insert)
                return (false);
            if (this.data.database && !this.app.connected)
                return (false);
            return (yield this.insert(after));
        });
    }
    keydelete() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data == null)
                return (false);
            if (this.row >= this.data.rows)
                return (true);
            if (this.state == FormState.entqry)
                return (true);
            let rec = this.records[+this.row];
            if (rec.state == RecordState.na)
                return (true);
            if (this.data.database && !this.app.connected)
                return (false);
            if (!this.usage.delete && rec.state != RecordState.insert)
                return (false);
            return (yield this.delete());
        });
    }
    keyentqry(force) {
        return __awaiter(this, void 0, void 0, function* () {
            if (force == null)
                force = false;
            if (!force) {
                if (this.data == null)
                    return (false);
                if (!this.usage.query)
                    return (false);
                if (this.data.database && !this.app.connected)
                    return (false);
            }
            let event = new KeyTriggerEvent(Origin.Block, this.alias, null, keymap.enterquery, null);
            this.invokeTriggers(Trigger.Key, event, keymap.enterquery);
            if (!(yield this.enterqry()))
                return (false);
            if (this.masterdetail != null)
                this.masterdetail.enterquery(this);
            this.focus(0);
            return (true);
        });
    }
    keyexeqry(force) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.masterdetail != null) {
                if (this.masterdetail.master != null && this.masterdetail.master != this)
                    return (this.masterdetail.master.keyexeqry(force));
                if (this.state != FormState.entqry)
                    this.masterdetail.clearfilters(this);
            }
            if (force == null)
                force = false;
            if (!force) {
                if (this.data == null || !this.usage.query) {
                    if (this.masterdetail != null)
                        this.masterdetail.master = null;
                    return (false);
                }
                if (this.data.database && !this.app.connected) {
                    if (this.masterdetail != null)
                        this.masterdetail.master = null;
                    return (false);
                }
            }
            let subquery = null;
            if (this.masterdetail != null) {
                subquery = yield this.masterdetail.getDetailQuery();
                this.masterdetail.querydetails(this, true, false);
            }
            let status = yield this.executeqry(subquery);
            this.focus(0);
            return (status);
        });
    }
    cancelqry() {
        this.records[0].current = true;
        this.records[0].clear();
        this.records[0].disable();
        this.state = FormState.normal;
        this.records[0].state = RecordState.na;
        this.records[0].enable(true);
    }
    enterqry() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data.database && !this.app.connected)
                return (false);
            if (!(yield this.validate()))
                return (false);
            yield this.clear();
            this.row = 0;
            this.searchfilter = [];
            this.state = FormState.entqry;
            this.records[0].state = RecordState.qmode;
            this.records[0].enable(false);
            return (true);
        });
    }
    get querying() {
        return (this.querying$);
    }
    // Public because of master-detail. Dont call direct
    executeqry(subquery) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data.database && !this.app.connected)
                return (false);
            if (!(yield this.validate()))
                return (false);
            let keys = [];
            let fields = [];
            if (this.querying$) {
                if (this.masterdetail != null)
                    this.masterdetail.done(this, false);
                return (false);
            }
            this.querying$ = true;
            if (this.state == FormState.entqry) {
                fields = this.records[0].fields;
                this.records[0].disable();
            }
            if (this.masterdetail != null)
                keys = this.masterdetail.getKeys(this);
            let stmt = this.data.parseQuery(keys, subquery, fields);
            this.lastqry = this.searchfilter;
            yield this.clear();
            let errors = stmt.validate();
            if (errors.length > 0) {
                let msg = "<table>";
                errors.forEach((err) => { msg += "<tr><td>" + err + "</td></tr>"; });
                msg += "</table>";
                this.alert(msg, "Query Condition");
                this.querying$ = false;
                if (this.masterdetail != null)
                    this.masterdetail.done(this, false);
                return (false);
            }
            let event = new SQLTriggerEvent(this.alias, 0, stmt);
            if (!(yield this.invokeTriggers(Trigger.PreQuery, event))) {
                this.querying$ = false;
                if (this.masterdetail != null)
                    this.masterdetail.done(this, false);
                return (false);
            }
            this.state = FormState.exeqry;
            stmt = event.stmt; // could be replaced by trigger
            let response = yield this.data.executequery(stmt);
            if (response["status"] == "failed") {
                this.alert(JSON.stringify(response), "Database Query");
                this.querying$ = false;
                if (this.masterdetail != null)
                    this.masterdetail.done(this, false);
                this.state = FormState.normal;
                return (false);
            }
            if (this.masterdetail != null)
                this.masterdetail.querydetails(this, false, true);
            this.row = 0;
            yield this.display(0);
            this.querying$ = false;
            this.state = FormState.normal;
            this.records[0].current = true;
            if (this.masterdetail != null)
                this.masterdetail.done(this, true);
            return (true);
        });
    }
    createControlRecord() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.data.database) {
                if (!this.data.insert(this.sum(this.row, this.offset, 1)))
                    return (-1);
                this.records[+this.row].state = RecordState.update;
                this.records[+this.row].enable(false);
                return (this.record);
            }
            return (-1);
        });
    }
    insert(after) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data.database && !this.app.connected)
                return (false);
            if (!(yield this.validate()))
                return (false);
            let off = after ? 1 : 0;
            if (!this.data.insert(this.sum(this.row, this.offset, off)))
                return (false);
            if (this.masterdetail != null)
                this.masterdetail.cleardetails(this);
            // Is first row
            if (this.data.rows == 1) {
                yield this.display(this.offset);
                if (this.form == null)
                    this.disableall();
                else
                    this.form.disableall();
                this.records[0].enable(false);
                this.focus(0);
                return (true);
            }
            let scroll = 0;
            let row = this.row;
            if (after && this.row == this.rows - 1)
                scroll = 1;
            if (!after && this.row == 0)
                scroll = -1;
            let move = 0;
            if (scroll == 0)
                move = after ? 1 : 0;
            yield this.display(this.sum(this.offset, scroll));
            row = this.sum(row, move);
            let rec = this.records[+row];
            rec.current = true;
            if (this.form == null)
                this.disableall();
            else
                this.form.disableall();
            this.records[+row].enable(false);
            this.focus(row);
            return (true);
        });
    }
    delete() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data == null)
                return (false);
            if (this.data.database && !this.app.connected)
                return (false);
            let record = this.sum(this.row, this.offset);
            // Lock the record
            if (!this.data.locked(record)) {
                let response = yield this.data.lock(record);
                if (response["status"] == "failed") {
                    this.alert(response["message"], "Lock Failure");
                    return (false);
                }
            }
            let response = yield this.data.delete(this.sum(this.row, this.offset));
            if (response["status"] == "failed") {
                this.alert(JSON.stringify(response), "Delete Failed");
                return (false);
            }
            if (this.masterdetail != null)
                this.masterdetail.cleardetails(this);
            // current view is not full
            if (+this.data.rows - this.offset < this.rows) {
                this.offset--;
                if (this.offset < 0)
                    this.offset = 0;
            }
            let row = this.row;
            yield this.display(this.offset);
            // no records at current position
            if (this.sum(row, this.offset) >= this.data.rows)
                row = this.data.rows - this.offset - 1;
            if (row < 0)
                this.row = 0;
            this.focus(row);
            if (this.masterdetail != null)
                this.masterdetail.querydetails(this, true, true);
        });
    }
    lockrecord(record, field) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data == null)
                return (true);
            if (this.state != FormState.normal)
                return (true);
            if (!this.data.databasecolumn(field))
                return (true);
            if (this.data.locked(record))
                return (true);
            let trgevent = new TriggerEvent(this.alias, record, null);
            if (!(yield this.invokeTriggers(Trigger.Lock, trgevent)))
                return (false);
            let response = yield this.data.lock(record);
            if (response["status"] == "failed") {
                let row = +record - +this.offset;
                this.alert(response["message"], "Lock Failure");
                let value = this.getValue(record, field);
                let ffield = this.records[+row].getField(field);
                if (ffield != null)
                    ffield.value = value;
                return (false);
            }
            return (true);
        });
    }
    validate() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!(yield this.validatefield(this.field)))
                return (false);
            return (yield this.validaterecord());
        });
    }
    validatefield(field) {
        return __awaiter(this, void 0, void 0, function* () {
            if (field == null)
                return (true);
            if (this.data == null)
                return (true);
            if (this.row >= this.data.rows)
                return (true);
            if (this.state != FormState.normal)
                return (true);
            if (this.records[+this.row].state == RecordState.na)
                return (true);
            let previous = this.data.getValue(this.sum(field.row, this.offset), field.name);
            // Nothing has changed
            if (field.value == previous)
                return (this.data.getValidated(this.sum(field.row, this.offset), field.name));
            if (!(yield this.lockrecord(this.sum(field.row, this.offset), field.name)))
                return (true);
            if (!field.validate()) {
                field.valid = false;
                this.data.setValue(this.sum(field.row, this.offset), field.name, field.value);
                return (false);
            }
            this.data.setValue(+field.row + this.offset, field.name, field.value);
            let trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, previous, null);
            if (!(yield this.invokeFieldTriggers(Trigger.WhenValidateField, field.name, trgevent))) {
                field.valid = false;
                return (false);
            }
            field.parent.valid = true;
            this.data.setValidated(this.sum(field.row, this.offset), field.name);
            if (field.value != previous) {
                if (this.sum(field.row, this.offset) == this.record && this.masterdetail != null)
                    this.masterdetail.sync(this, field.name);
                if (!(yield this.invokeFieldTriggers(Trigger.PostChange, field.name, trgevent)))
                    return (false);
                if (this.records[+this.row].state == RecordState.insert) {
                    if (this.data.validated(this.record, true))
                        this.validaterecord();
                }
            }
            return (true);
        });
    }
    validaterecord() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data == null)
                return (true);
            if (this.row >= this.data.rows)
                return (true);
            if (this.state == FormState.entqry)
                return (true);
            let rec = this.records[+this.row];
            if (rec.state == RecordState.na)
                return (true);
            // Check fields is validated
            if (!this.data.validated(this.record, true)) {
                let cols = this.data.getNonValidated(this.record);
                this.alert("The following columns are not valid:<br><br>" + cols, "Validate Record");
                cols.forEach((col) => { this.records[+this.record].getField(col).valid = false; });
                return (false);
            }
            // Check record is validated
            if (this.data.validated(this.record, false))
                return (true);
            let trgevent = new TriggerEvent(this.alias, this.record, null);
            if (!(yield this.invokeTriggers(Trigger.WhenValidateRecord, trgevent)))
                return (false);
            let insert = (rec.state == RecordState.insert);
            let response = yield this.data.setValidated(this.record);
            if (response["status"] == "failed") {
                let title = insert ? "Insert" : "Update";
                this.alert(JSON.stringify(response), title + " Failed");
                return (false);
            }
            if (insert) {
                if (this.form == null)
                    this.enableall();
                else
                    this.form.enableall();
            }
            return (true);
        });
    }
    clearblock() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.clear();
            this.focus(0);
            this.searchfilter = [];
            if (this.data)
                this.data.clear();
        });
    }
    clear() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.rows == null)
                return;
            this.field$ = this.fields$[0];
            for (let r = 0; r < this.rows; r++) {
                this.records[+r].clear();
                this.records[+r].disable();
                this.records[+r].state = RecordState.na;
            }
            this.records[0].current = true;
            this.records[0].state = RecordState.na;
            if (!this.disabled$)
                this.records[0].enable(true);
        });
    }
    disableall() {
        return __awaiter(this, void 0, void 0, function* () {
            this.disabled$ = true;
            for (let r = 0; r < this.rows; r++)
                this.records[+r].disable();
        });
    }
    enableall() {
        return __awaiter(this, void 0, void 0, function* () {
            this.disabled$ = false;
            for (let r = 0; r < this.rows; r++) {
                if (this.records[+r].state != RecordState.na)
                    this.records[+r].enable(false);
            }
        });
    }
    display(start) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.clear();
            this.offset = start;
            if (this.data == null)
                return;
            if (this.sum(this.offset, this.rows) > +this.data.rows)
                this.offset = this.data.rows - this.rows;
            if (this.offset < 0)
                this.offset = 0;
            let columns = this.data.fields;
            let rows = this.data.get(this.offset, this.rows);
            for (let r = 0; r < rows.length; r++) {
                let rec = this.getRecord(r);
                let state = this.data.state(this.sum(this.offset, r));
                for (let c = 0; c < rows[r].length; c++) {
                    let field = rec.getField(columns[c]);
                    if (field != null)
                        field.value = rows[r][c];
                }
                if (state == RecordState.na) {
                    let execs = [];
                    for (let c = 0; c < rows[r].length; c++) {
                        let field = rec.getField(columns[c]);
                        let value = rows[r][c];
                        let fname = columns[c];
                        if (field != null)
                            fname = field.name;
                        let trgevent = new FieldTriggerEvent(this.alias, fname, null, this.sum(r, this.offset), value, value);
                        execs.push(this.invokeFieldTriggers(Trigger.PostChange, fname, trgevent));
                    }
                    execs.push(this.invokeTriggers(Trigger.PostChange, new TriggerEvent(this.alias, this.sum(r, this.offset))));
                    state = this.data.state(this.sum(this.offset, r), RecordState.update);
                    for (let i = 0; i < execs.length; i++)
                        yield execs[i];
                }
                rec.state = state;
                if (!this.disabled$)
                    rec.enable(false);
            }
        });
    }
    addTrigger(instance, func, types) {
        this.triggers.addTrigger(instance, func, types);
    }
    addKeyTrigger(instance, func, keys) {
        this.triggers.addTrigger(instance, func, Trigger.Key, null, keys);
    }
    addFieldTrigger(instance, func, types, fields, keys) {
        this.triggers.addTrigger(instance, func, types, fields, keys);
    }
    onEvent(event, field, type, key) {
        var _a, _b, _c, _d, _e, _f, _g;
        return __awaiter(this, void 0, void 0, function* () {
            let trgevent = null;
            if (event == null)
                event = { type: type };
            if (this.records.length == 0)
                return (true);
            if (type == "focus") {
                this.field$ = field;
                if (this.form != null)
                    this.form.block = this;
                if (this.state == FormState.entqry)
                    return (true);
                if (this.row != field.row) {
                    if (!(yield this.validate())) {
                        this.records[+this.row].current = true;
                        this.field.focus();
                        return (false);
                    }
                    let state = this.records[field.row].state;
                    if (this.masterdetail != null && state != RecordState.na)
                        this.masterdetail.querydetails(this, true, true);
                }
                this.row = field.row;
                this.records$[+field.row].current = true;
                trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, field.value, event);
                return (yield this.invokeFieldTriggers(Trigger.PreField, field.name, trgevent));
            }
            if (type == "blur") {
                if (this.state == FormState.entqry)
                    return (true);
                trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, field.value, event);
                return (yield this.invokeFieldTriggers(Trigger.PostField, field.name, trgevent));
            }
            if (type == "fchange") {
                if (this.state == FormState.entqry || this.data == null)
                    return (true);
                return (yield this.lockrecord(this.sum(field.row, this.offset), field.name));
            }
            if (type == "cchange") {
                if (this.state == FormState.entqry)
                    return (true);
                let previous = this.getValue(this.sum(field.row, this.offset), field.name);
                trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, previous, event);
                return (this.invokeFieldTriggers(Trigger.Typing, field.name, trgevent));
            }
            if (type == "change") {
                // Current row field firing after move
                if (field.row != this.row)
                    return (true);
                // This will fire appropiate triggers
                if (!(yield this.validatefield(field))) {
                    this.field.focus();
                    return (false);
                }
                return (true);
            }
            // Enter
            if (type == "key" && key == keymap.enter) {
                if (this.state == FormState.entqry)
                    key = keymap.executequery;
                if (((_a = this.records[+this.row]) === null || _a === void 0 ? void 0 : _a.state) == RecordState.insert) {
                    if (!(yield this.validaterecord()))
                        return (false);
                }
                if (((_b = this.records[+this.row]) === null || _b === void 0 ? void 0 : _b.state) == RecordState.update) {
                    if (!(yield this.validaterecord()))
                        return (false);
                }
            }
            // Cancel
            if (type == "key" && key == keymap.escape) {
                if (this.state == FormState.entqry) {
                    this.cancelqry();
                    this.focus();
                }
                if (((_c = this.records[+this.row]) === null || _c === void 0 ? void 0 : _c.state) == RecordState.insert) {
                    this.enableall();
                    key = keymap.delete;
                }
            }
            // ListOfValues / Datepicker
            if (type == "key" && key == keymap.listval) {
                if (event != null && event["preventDefault"] != null)
                    event.preventDefault();
                let type = field.definition.type;
                if (type == FieldType.date || type == FieldType.datetime) {
                    if (!field.readonly)
                        DatePicker.show(this.app, this, this.record, field.name, field.value);
                    return (true);
                }
                this.showListOfValues(field.name, field.id, this.row);
                return (true);
            }
            // Enter query
            if (type == "key" && key == keymap.enterquery) {
                if (this.state == FormState.entqry) {
                    for (let i = 0; i < this.lastqry.length; i++) {
                        let nvp = this.lastqry[i];
                        yield this.setValue(0, nvp.name, nvp.value);
                    }
                    return (true);
                }
                if (!(yield this.validate()))
                    return (false);
                if (!(yield this.keyentqry())) {
                    field.focus();
                    return (false);
                }
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                return (yield this.invokeTriggers(Trigger.Key, trgevent, key));
            }
            // Execute query
            if (type == "key" && key == keymap.executequery) {
                if (!(yield this.validate()))
                    return (false);
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                if (!(yield this.invokeTriggers(Trigger.Key, trgevent, key)))
                    return (true);
                return (yield this.keyexeqry());
            }
            // Delete
            if (type == "key" && key == keymap.delete) {
                if (event != null && event["preventDefault"] != null)
                    event.preventDefault();
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                if (((_d = this.records[+this.row]) === null || _d === void 0 ? void 0 : _d.state) == RecordState.update) {
                    if (!(yield this.invokeTriggers(Trigger.Key, trgevent, key)))
                        return (false);
                }
                return (yield this.keydelete());
            }
            // Insert after
            if (type == "key" && key == keymap.insertafter) {
                if (!(yield this.validate()))
                    return (false);
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                if (!(yield this.invokeTriggers(Trigger.Key, trgevent, key)))
                    return (true);
                if (!(yield this.keyinsert(true))) {
                    field.focus();
                    return (false);
                }
                return (true);
            }
            // Insert before
            if (type == "key" && key == keymap.insertbefore) {
                if (!(yield this.validate()))
                    return (false);
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                if (!(yield this.invokeTriggers(Trigger.Key, trgevent, key)))
                    return (true);
                if (!(yield this.keyinsert(false))) {
                    field.focus();
                    return (false);
                }
                return (true);
            }
            // Next/Previous field
            if (type == "key" && (key == keymap.nextfield || key == keymap.prevfield)) {
                if (this.state != FormState.entqry && ((_e = this.records[+this.row]) === null || _e === void 0 ? void 0 : _e.state) != RecordState.na) {
                    let previous = this.data.getValue(this.sum(field.row, this.offset), field.name);
                    if (field.dirty) {
                        // ctrl-z doesn't refresh
                        if (field.value == previous)
                            field.parent.copy(field);
                    }
                    trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, previous, event);
                    if (key == keymap.prevfield) {
                        if (!(yield this.invokeFieldTriggers(Trigger.KeyPrevField, field.name, trgevent, key)))
                            return (false);
                    }
                    if (key == keymap.nextfield) {
                        if (!(yield this.invokeFieldTriggers(Trigger.KeyNextField, field.name, trgevent, key)))
                            return (false);
                    }
                }
            }
            // Next record
            if (type == "key" && key == keymap.nextrecord) {
                if (!(yield this.validate()))
                    return (false);
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                if (!(yield this.invokeTriggers(Trigger.Key, trgevent, key)))
                    return (true);
                let row = this.sum(field.row, 1);
                if (this.data == null)
                    return (false);
                if (+row >= +this.rows) {
                    row = +this.rows - 1;
                    if (this.data == null)
                        return (false);
                    let offset = this.sum(field.row, this.offset);
                    let fetched = yield this.data.fetch(offset, 1);
                    if (fetched == 0)
                        return (false);
                    yield this.display(this.sum(this.offset, 1));
                }
                if ((_f = this.records[+row]) === null || _f === void 0 ? void 0 : _f.enabled) {
                    this.focus(row);
                    if (this.masterdetail != null)
                        this.masterdetail.querydetails(this, true, true);
                }
                return (true);
            }
            // Previous record
            if (type == "key" && key == keymap.prevrecord) {
                if (this.record == 0)
                    return (true);
                if (!(yield this.validate()))
                    return (false);
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                if (!(yield this.invokeTriggers(Trigger.Key, trgevent, key)))
                    return (true);
                let row = +field.row - 1;
                if (this.data == null)
                    return (false);
                if (+row < 0) {
                    row = 0;
                    yield this.display(this.offset - 1);
                }
                this.focus(row);
                if (this.masterdetail != null)
                    this.masterdetail.querydetails(this, true, true);
                return (true);
            }
            // Page down
            if (type == "key" && key == keymap.pagedown) {
                if (!(yield this.validate()))
                    return (false);
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                if (!(yield this.invokeTriggers(Trigger.Key, trgevent, key)))
                    return (true);
                let offset = this.sum(this.offset, field.row);
                let fetched = yield this.data.fetch(offset, this.rows);
                if (fetched == 0)
                    return (false);
                yield this.display(this.sum(this.offset, this.rows));
                this.focus();
                if (this.masterdetail != null)
                    this.masterdetail.querydetails(this, true, true);
                return (true);
            }
            // Page up
            if (type == "key" && key == keymap.pageup) {
                if (this.record == 0)
                    return (true);
                if (!(yield this.validate()))
                    return (false);
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                if (!(yield this.invokeTriggers(Trigger.Key, trgevent, key)))
                    return (true);
                yield this.display(+this.offset - this.rows);
                this.focus();
                if (this.masterdetail != null)
                    this.masterdetail.querydetails(this, true, true);
                return (true);
            }
            // Next/Prev block
            if (type == "key" && (key == keymap.prevblock || key == keymap.nextblock)) {
                if (this.state != FormState.entqry && ((_g = this.records[+this.row]) === null || _g === void 0 ? void 0 : _g.state) != RecordState.na) {
                    if (!(yield this.validate()))
                        return (false);
                    trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, null, event);
                    if (key == keymap.prevblock) {
                        if (!(yield this.invokeFieldTriggers(Trigger.KeyPrevBlock, field.name, trgevent, key)))
                            return (false);
                    }
                    if (key == keymap.nextblock) {
                        if (!(yield this.invokeFieldTriggers(Trigger.KeyNextBlock, field.name, trgevent, key)))
                            return (false);
                    }
                }
            }
            if (type == "key" && key == keymap.clearblock) {
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, null, keymap.clearblock, null);
                if (!(yield this.invokeTriggers(Trigger.Key, event, keymap.clearblock)))
                    return (false);
                this.clearblock();
            }
            if (type == "key" && key == keymap.clearform && this.form != null)
                yield this.form.onEvent(event, field, type, key);
            if (type == "key" && key == keymap.prevfield && this.form != null)
                yield this.form.onEvent(event, field, type, key);
            if (type == "key" && key == keymap.nextfield && this.form != null)
                yield this.form.onEvent(event, field, type, key);
            if (type == "key" && key == keymap.prevblock && this.form != null)
                yield this.form.onEvent(event, field, type, key);
            if (type == "key" && key == keymap.nextblock && this.form != null)
                yield this.form.onEvent(event, field, type, key);
            if (type == "key") {
                if (event != null && event["preventDefault"] != null)
                    event.preventDefault();
                trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                return (yield this.invokeTriggers(Trigger.Key, trgevent, key));
            }
            if (type == "click") {
                trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, field.value, event);
                return (yield this.invokeFieldTriggers(Trigger.MouseClick, field.name, trgevent, key));
            }
            if (type == "dblclick") {
                trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, field.value, event);
                return (yield this.invokeFieldTriggers(Trigger.MouseDoubleClick, field.name, trgevent, key));
            }
            return (true);
        });
    }
    invokeTriggers(type, event, key) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.form != null)
                if (!(yield this.form.invokeTriggers(type, event, key)))
                    return (false);
            return (yield this.triggers.invokeTriggers(type, event, key));
        });
    }
    invokeFieldTriggers(type, field, event, key) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.form != null)
                if (!(yield this.form.invokeFieldTriggers(type, field, event, key)))
                    return (false);
            return (yield this.triggers.invokeFieldTriggers(type, field, event, key));
        });
    }
    sleep(ms) {
        return (new Promise(resolve => setTimeout(resolve, ms)));
    }
    alert(msg, title, width, height) {
        if (title == null)
            title = this.alias;
        MessageBox.show(this.app, msg, title, width, height);
    }
    sum(n1, n2, n3) {
        let s = +n1 + +n2;
        if (n3 != null)
            s = +s + +n3;
        return (s);
    }
}

class Block {
    // dont rename impl as it is read behind the scenes
    constructor() {
        this._impl_ = new BlockImpl(this);
    }
    get form() {
        return (this._impl_.form.form);
    }
    get table() {
        return (this._impl_.table);
    }
    get connected() {
        return (this.form.connected);
    }
    getValue(record, field) {
        return (this._impl_.getValue(record, field));
    }
    setValue(record, field, value) {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this._impl_.setValue(record, field, value));
        });
    }
    get querymode() {
        return (this._impl_.querymode);
    }
    empty() {
        return (this._impl_.getRecord(0).state == RecordState.na);
    }
    cancel() {
        this._impl_.sendkey(null, keymap.escape);
    }
    goField(field, row) {
        if (row == null)
            row = this._impl_.row;
        this._impl_.getField(row, field).focus();
    }
    get ready() {
        return (this._impl_.ready);
    }
    get searchfilter() {
        return (this._impl_.searchfilter);
    }
    set searchfilter(filter) {
        this._impl_.searchfilter = filter;
    }
    sendKey(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this._impl_.sendkey(null, key));
        });
    }
    enterquery(override) {
        return __awaiter(this, void 0, void 0, function* () {
            return (this._impl_.keyentqry(override));
        });
    }
    executequery(override) {
        return __awaiter(this, void 0, void 0, function* () {
            return (this._impl_.keyexeqry(override));
        });
    }
    nextrecord() {
        this._impl_.sendkey(null, keymap.nextrecord);
    }
    prevrecord() {
        this._impl_.sendkey(null, keymap.prevrecord);
    }
    nextblock() {
        this._impl_.sendkey(null, keymap.nextblock);
    }
    prevblock() {
        this._impl_.sendkey(null, keymap.prevblock);
    }
    pageup() {
        this._impl_.sendkey(null, keymap.pageup);
    }
    pagedown() {
        this._impl_.sendkey(null, keymap.pagedown);
    }
    get row() {
        return (this._impl_.row);
    }
    get record() {
        return (this._impl_.record);
    }
    createControlRecord() {
        return __awaiter(this, void 0, void 0, function* () {
            return (this._impl_.createControlRecord());
        });
    }
    delete(override) {
        return __awaiter(this, void 0, void 0, function* () {
            if (override)
                return (this._impl_.delete());
            else
                return (this._impl_.sendkey(null, keymap.delete));
        });
    }
    setFieldDefinition(def) {
        return (this._impl_.setFieldDefinition(def));
    }
    setPossibleValues(field, values, enforce) {
        return (this._impl_.setPossibleValues(field, values, enforce));
    }
    showDatePicker(field, row) {
        this._impl_.showDatePicker(field, row);
    }
    showListOfValues(field, id, row) {
        this._impl_.showListOfValues(field, id, row);
    }
    insert(above, override) {
        return __awaiter(this, void 0, void 0, function* () {
            if (above == null)
                above = false;
            if (override)
                return (this._impl_.insert(!above));
            else {
                if (!above)
                    return (this._impl_.sendkey(null, keymap.insertafter));
                else
                    return (this._impl_.sendkey(null, keymap.insertbefore));
            }
        });
    }
    execute(stmt, firstrow, firstcolumn) {
        return __awaiter(this, void 0, void 0, function* () {
            return (this._impl_.execute(stmt, firstrow, firstcolumn));
        });
    }
    addListOfValues(func, field, id) {
        this._impl_.addListOfValues(false, func, field, id);
    }
    addTrigger(listener, types) {
        this._impl_.addTrigger(this, listener, types);
    }
    addKeyTrigger(listener, keys) {
        this._impl_.addKeyTrigger(this, listener, keys);
    }
    addFieldTrigger(listener, types, fields) {
        this._impl_.addFieldTrigger(this, listener, types, fields);
    }
    alert(message, title, width, height) {
        this._impl_.alert(message, title, width, height);
    }
}

class MasterDetailQuery {
    constructor(md, links, block, col) {
        this.md = md;
        this.links = links;
        this.finished = 0;
        this.detailblks = new Map();
        this.masterblks = new Map();
        this.root$ = block;
        this.findblocks(block.alias, col);
    }
    get root() {
        return (this.root$);
    }
    findblocks(block, col) {
        let dep = this.links.get(block);
        if (this.details(dep)) {
            this.masterblks.set(block, false);
            dep.details.forEach((det) => {
                if (col == null || det.mkey.partof(col)) {
                    this.findblocks(det.block.alias, null);
                    this.detailblks.set(det.block.alias, 0);
                }
            });
        }
    }
    waitfor(block) {
        this.detailblks.set(block.alias, 1);
    }
    ready(block) {
        this.masterblks.set(block.alias, true);
        let dep = this.links.get(block.alias);
        if (this.detailblks.size == 0) {
            this.md.finished();
            return;
        }
        if (this.details(dep))
            this.execute(dep);
        else
            this.state(block, 2);
    }
    done(block) {
        this.finished++;
        this.state(block, 3);
        if (this.finished == this.detailblks.size)
            this.md.finished();
    }
    failed(block) {
        this.remove(block);
        if (this.finished == this.detailblks.size)
            this.md.finished();
    }
    remove(block) {
        if (this.detailblks.get(block.alias) < 2) {
            this.detailblks.delete(block.alias);
            let dep = this.links.get(block.alias);
            if (dep != null && dep.details != null) {
                dep.details.forEach((det) => { this.remove(det.block); });
            }
        }
        else {
            this.finished++;
            this.state(block, 3);
        }
    }
    status(state) {
        console.log(state + " finished: " + this.finished + " " + this.detailblks.size);
        this.detailblks.forEach((state, blk) => { console.log(blk + " " + state); });
    }
    execute(dep) {
        return __awaiter(this, void 0, void 0, function* () {
            if (dep.details != null) {
                for (let i = 0; i < dep.details.length; i++) {
                    if (this.isready(dep.details[i].block)) {
                        dep.details[i].block.executeqry();
                        this.state(dep.details[i].block, 1);
                    }
                }
            }
        });
    }
    isready(block) {
        let ready = true;
        let dep = this.links.get(block.alias);
        if (dep.masters != null) {
            dep.masters.forEach((master) => {
                let alias = master.block.alias;
                let ok = this.masterblks.get(alias);
                if (ok == null || !ok)
                    ready = false;
            });
        }
        return (ready);
    }
    state(block, state) {
        this.detailblks.set(block.alias, state);
    }
    details(dep) {
        return (dep != null && dep.details != null);
    }
}

class MasterDetail {
    constructor(form) {
        this.form = null;
        this.master$ = null;
        this.waiting = null;
        this.query = null;
        this.blocks = new Map();
        this.links = new Map();
        this.defined = new Map();
        this.form = form;
    }
    get master() {
        return (this.master$);
    }
    set master(block) {
        this.master$ = block;
    }
    getRoot(block) {
        if (block == null)
            block = Array.from(this.blocks)[0]["1"];
        let dep = this.links.get(block.alias);
        while (dep != null && dep.masters != null && dep.masters.length > 0) {
            block = dep.masters[0].block;
            dep = this.links.get(block.alias);
        }
        return (block);
    }
    cleardetails(block) {
        let dep = this.links.get(block.alias);
        if (dep != null && dep.details != null)
            dep.details.forEach((det) => this.clear(det.block));
    }
    clear(block) {
        block.clear();
        let dep = this.links.get(block.alias);
        if (dep != null && dep.details != null)
            dep.details.forEach((det) => this.clear(det.block));
    }
    sync(block, col) {
        let dep = this.links.get(block.alias);
        if (dep != null) {
            if (!dep.keycols.has(col))
                return;
            this.master = block;
            this.query = new MasterDetailQuery(this, this.links, block, col);
            this.query.ready(block);
        }
    }
    enterquery(block) {
        this.master$ = block;
        this.enterdetailquery(block);
    }
    enterdetailquery(block) {
        let dep = this.links.get(block.alias);
        if (dep != null && dep.details != null) {
            dep.details.forEach((det) => {
                if (det.block.usage.query)
                    det.block.enterqry();
                this.enterdetailquery(det.block);
            });
        }
    }
    clearfilters(block) {
        block.searchfilter = [];
        let dep = this.links.get(block.alias);
        if (dep != null && dep.details != null) {
            dep.details.forEach((det) => {
                det.block.searchfilter = [];
                this.clearfilters(det.block);
            });
        }
    }
    // Build subquery from details
    getDetailQuery() {
        return __awaiter(this, void 0, void 0, function* () {
            let block = this.master$;
            this.master$ = null;
            if (block == null)
                return (null);
            let dep = this.links.get(block.alias);
            let sub = {
                lev: 0,
                sql: null,
                subs: [],
                mcols: [],
                dcols: [],
                bindvalues: [],
                mtab: null
            };
            if (dep != null && dep.details != null) {
                for (let i = 0; i < dep.details.length; i++)
                    yield this.subquery(sub, dep.details[i]);
            }
            let subq = null;
            this.buildsubquery(sub);
            if (sub.sql.length > 0) {
                let bindvals = [];
                sub.bindvalues.forEach((bindv) => {
                    bindvals.push({
                        name: bindv.name,
                        type: Column[bindv.type].toLowerCase(),
                        value: bindv.value
                    });
                });
                subq = { sql: sub.sql, bindvalues: bindvals };
            }
            return (subq);
        });
    }
    subquery(parent, detail) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            let mkey = detail.mkey;
            let dkey = detail.dkey;
            let block = detail.block;
            if (block.querymode) {
                let sub = {
                    sql: null,
                    subs: [],
                    bindvalues: [],
                    lev: +parent.lev + 1,
                    mcols: mkey.columns(),
                    dcols: dkey.columns(),
                    mtab: (_b = (_a = block.data) === null || _a === void 0 ? void 0 : _a.table) === null || _b === void 0 ? void 0 : _b.name
                };
                parent.subs.push(sub);
                let fields = block.records[0].fields;
                let stmt = block.data.parseQuery([], null, fields);
                let event = new SQLTriggerEvent(block.alias, 0, stmt);
                if (!(yield block.invokeTriggers(Trigger.PreQuery, event)))
                    return;
                block.cancelqry();
                if (block.searchfilter.length > 0) {
                    stmt.order = null;
                    stmt.columns = dkey.columns();
                    sub.sql = stmt.build().sql;
                    sub.bindvalues = stmt.getCondition().getAllBindvalues();
                }
                let dep = this.links.get(block.alias);
                if (dep != null && dep.details != null) {
                    for (let i = 0; i < dep.details.length; i++)
                        yield this.subquery(sub, dep.details[i]);
                }
            }
        });
    }
    buildsubquery(sub) {
        let children = false;
        for (let i = 0; i < sub.subs.length; i++) {
            this.buildsubquery(sub.subs[i]);
            if (sub.subs[i].sql != null && sub.subs[i].sql.length > 0)
                children = true;
        }
        let sql = "";
        let and = false;
        let where = false;
        if (sub.sql != null) {
            and = true;
        }
        else if (children && sub.mtab != null) {
            where = true;
            sub.sql = "select " + sub.dcols + " from " + sub.mtab;
        }
        if (children) {
            for (let i = 0; i < sub.subs.length; i++) {
                if (sub.subs[i].sql != null && sub.subs[i].sql.length > 0) {
                    if (and)
                        sql += " and ";
                    if (where)
                        sql += " where ";
                    sql += "(" + sub.subs[i].mcols + ") in (";
                    sql += sub.subs[i].sql;
                    sql += ")";
                    sub.subs[i].bindvalues.forEach((bind) => { sub.bindvalues.push(bind); });
                    and = true;
                    where = false;
                }
            }
        }
        if (sub.sql == null)
            sub.sql = sql;
        else
            sub.sql += sql;
    }
    querydetails(block, init, ready) {
        if (init == null)
            init = false;
        if (init) {
            if (this.query != null) {
                this.waiting = block;
                return;
            }
            this.master = block;
            this.query = new MasterDetailQuery(this, this.links, block);
        }
        if (ready)
            this.query.ready(block);
        else
            this.query.waitfor(block);
    }
    done(block, success) {
        if (success)
            this.query.done(block);
        else
            this.query.failed(block);
    }
    finished() {
        let block = null;
        if (this.waiting != null) {
            block = this.waiting;
            this.waiting = null;
            this.query = new MasterDetailQuery(this, this.links, block);
            this.query.ready(block);
        }
        else {
            this.query = null;
            this.master = null;
        }
    }
    getKeys(block) {
        let keys = [];
        let dep = this.links.get(block.alias);
        if (dep != null && dep.masters != null) {
            dep.masters.forEach((master) => {
                let c = 0;
                let record = master.block.record;
                master.mkey.columns().forEach((col) => {
                    let val = null;
                    if (record < master.block.datarows)
                        val = master.block.getValue(record, col);
                    master.dkey.set(c++, val);
                });
                keys.push(master.dkey);
            });
        }
        return (keys);
    }
    addBlock(block) {
        this.blocks.set(block.alias, block);
    }
    addKeys(block, keys) {
        this.defined.set(block.alias, keys);
    }
    addJoins(joins) {
        if (joins == null)
            return;
        joins.forEach((join) => {
            let skip = false;
            let master = this.blocks.get(join.master.alias);
            let detail = this.blocks.get(join.detail.alias);
            if (master == null) {
                skip = true;
                console.log("Master block " + join.master.alias + " in join on form " + this.form.name + " does not exist");
            }
            if (detail == null) {
                skip = true;
                console.log("Detail block " + join.detail.alias + " in join on form " + this.form.name + " does not exist");
            }
            if (!skip) {
                let keys = null;
                keys = this.defined.get(join.master.alias);
                let mkey = keys === null || keys === void 0 ? void 0 : keys.get(join.master.key);
                keys = this.defined.get(join.detail.alias);
                let dkey = keys === null || keys === void 0 ? void 0 : keys.get(join.detail.key);
                if (mkey == null) {
                    skip = true;
                    console.log("Join on form " + this.form.name + ". Cannot find key " + join.master.key + " on block " + join.master.alias);
                }
                if (dkey == null) {
                    skip = true;
                    console.log("Join on form " + this.form.name + ". Cannot find key " + join.detail.key + " on block " + join.detail.alias);
                }
                if (!skip) {
                    let mdep = this.links.get(master.alias);
                    if (mdep == null) {
                        mdep = { keycols: new Set() };
                        this.links.set(master.alias, mdep);
                    }
                    if (mdep.details == null)
                        mdep.details = [];
                    dkey.columns().forEach((col) => { mdep.keycols.add(col); });
                    mdep.details.push({ block: detail, mkey: mkey, dkey: dkey });
                    let ddep = this.links.get(detail.alias);
                    if (ddep == null) {
                        ddep = { keycols: new Set() };
                        this.links.set(detail.alias, ddep);
                    }
                    if (ddep.masters == null)
                        ddep.masters = [];
                    ddep.masters.push({ block: master, mkey: mkey, dkey: dkey });
                }
            }
        });
    }
}

class FormImpl {
    constructor(form$) {
        this.form$ = form$;
        this.blocks = [];
        this.cancelled = false;
        this.initiated$ = false;
        this.fields$ = [];
        this.triggers = new Triggers();
        this.parameters = new Map();
        this.stack = new Map();
        this.blkindex = new Map();
        this.creationerror = false;
        this.guid$ = FormImpl.id++;
        let utils = new Utils();
        this.name$ = utils.getName(form$);
    }
    get guid() {
        return (this.guid$);
    }
    get form() {
        return (this.form$);
    }
    get name() {
        return (this.name$);
    }
    set path(path) {
        this.path$ = path;
    }
    get path() {
        return (this.path$);
    }
    set title(title) {
        this.title$ = title;
    }
    get title() {
        return (this.title$);
    }
    get block() {
        return (this.block$);
    }
    enterquery(force) {
        var _a;
        (_a = this.depencies.getRoot()) === null || _a === void 0 ? void 0 : _a.keyentqry(force);
    }
    executequery(force) {
        var _a;
        (_a = this.depencies.getRoot()) === null || _a === void 0 ? void 0 : _a.keyexeqry(force);
    }
    get popup() {
        return (this.win != null);
    }
    getCurrentRow(block) {
        let blk = this.getBlock(block);
        if (blk == null)
            return (0);
        return (blk.row);
    }
    getCurrentRecord(block) {
        let blk = this.getBlock(block);
        if (blk == null)
            return (0);
        return (blk.record);
    }
    getBlock(bname) {
        return (this.blkindex.get(bname.toLowerCase()));
    }
    clear() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            for (let i = 0; i < this.blocks.length; i++) {
                let event = new KeyTriggerEvent(Origin.Form, this.blocks[i].alias, null, keymap.clearblock, null);
                yield this.blocks[i].sendkey(event, keymap.clearblock);
            }
            if (this.blocks.length > 0)
                this.block = this.blocks[0];
            (_a = this.block) === null || _a === void 0 ? void 0 : _a.focus();
            return (true);
        });
    }
    enableall() {
        this.blocks.forEach((block) => { block.enableall(); });
    }
    disableall() {
        this.blocks.forEach((block) => { block.disableall(); });
    }
    focus() {
        var _a;
        (_a = this.block) === null || _a === void 0 ? void 0 : _a.focus();
    }
    set block(block) {
        var _a;
        if (this.block != null && this.block != block)
            if (!((_a = this.block) === null || _a === void 0 ? void 0 : _a.validate()))
                return;
        this.block$ = block;
    }
    getChain() {
        if (this.next == null)
            return (this);
        return (this.next.getChain());
    }
    initiated() {
        return (this.initiated$);
    }
    setMenu(menu) {
        if (this.app == null) {
            this.menu$ = menu;
            return;
        }
        this.app.deletemenu(this.menu$);
        this.ddmenu = this.app.createmenu(menu);
        this.app.showMenu(this.ddmenu);
        this.menu$ = menu;
    }
    getMenu() {
        return (this.menu$);
    }
    getApplication() {
        return (this.app);
    }
    setRoot(root) {
        this.root = root;
    }
    setParent(parent) {
        this.parent = parent;
    }
    setApplication(app) {
        this.app = app;
        if (this.menu$ == null)
            this.menu$ = new DefaultMenu();
        this.conn = app.appstate.connection;
        this.ddmenu = app.createmenu(this.menu$);
    }
    getInstanceID() {
        return (this.inst);
    }
    setInstanceID(inst) {
        this.inst = inst;
    }
    setModalWindow(win) {
        this.win = win;
    }
    getModalWindow() {
        return (this.win);
    }
    setCallback(func) {
        this.callbackfunc = func;
    }
    setParameters(params) {
        if (params != null)
            this.parameters = params;
        else
            this.parameters = new Map();
    }
    getParameters() {
        return (this.parameters);
    }
    getDropDownMenu() {
        return (this.ddmenu);
    }
    onCommit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.blocks.forEach((blk) => { blk.removeLocks(); });
        });
    }
    execute(stmt, firstrow, firstcolumn) {
        return __awaiter(this, void 0, void 0, function* () {
            let response = yield this.app.appstate.connection.invokestmt(stmt);
            if (response["status"] == "failed")
                this.alert(JSON.stringify(response), "Execute SQL Failed");
            let rows = response["rows"];
            if (rows == null) {
                if (firstcolumn)
                    return (null);
                return ([]);
            }
            if (!firstrow)
                return (rows);
            let row = [];
            if (rows.length > 0)
                row = rows[0];
            if (!firstcolumn)
                return (row);
            let columns = Object.keys(row);
            if (columns.length == 0)
                return (null);
            return (row[columns[0]]);
        });
    }
    newForm(container) {
        let utils = new Utils();
        this.depencies = new MasterDetail(this);
        // Add all form key triggers
        let fktriggers = TriggerDefinitions.getFormKeyTriggers(this.name);
        fktriggers.forEach((def) => { this.triggers.addTrigger(this.form, def.func, def.trigger, def.field, def.key); });
        // Create blocks
        let blockdef = BlockDefinitions.getBlocks(this.name);
        blockdef.forEach((bdef) => { this.createBlock(bdef); });
        if (this.creationerror)
            return;
        // DatabaseUsage for this form
        let fusage = DatabaseDefinitions.getFormUsage(this.name);
        // Merge form, block and block usage. Form usage overides
        blockdef.forEach((bdef) => { this.setBlockUsage(fusage, bdef); });
        container.finish();
        // Get all fields per block
        let bfields = new Map();
        container.getBlocks().forEach((cb) => {
            let block = this.blkindex.get(cb.name);
            if (block == null) {
                let dblk = new Block();
                block = dblk["_impl_"];
                this.blocks.push(block);
                this.blkindex.set(cb.name, block);
                block.form = this;
                block.alias = cb.name;
                block.setApplication(this.app);
                console.log("Block " + cb.name + " auto-created");
            }
            bfields.set(block.alias, cb.fields);
            cb.records.forEach((rec) => { block.addRecord(new Record(rec.row, rec.fields, rec.index)); });
        });
        this.blkindex.forEach((block) => {
            this.depencies.addBlock(block);
            block.setMasterDetail(this.depencies);
            // Finish setup for each block
            let keydefs = BlockDefinitions.getKeys(block.clazz);
            let tabdef = utils.clone(TableDefinitions.get(block.clazz));
            // Column definitions
            let colindex = ColumnDefinitions.getIndex(block.clazz);
            // Columns mapped to fields. Form definitions overrides
            let colfields = FieldDefinitions.getColumnIndex(block.clazz);
            let colffields = FieldDefinitions.getFormColumnIndex(this.name, block.alias);
            colffields.forEach((def, fld) => { colfields.set(fld, def); });
            // Create keys and decide on primary
            let pkey = null;
            let keys = new Map();
            keydefs.forEach((kdef) => {
                let key = keys.get(kdef.name);
                if (key == null) {
                    key = new Key(kdef.name);
                    keys.set(kdef.name, key);
                    kdef.columns.forEach((col) => {
                        let fdef = colfields.get(col);
                        if (fdef != null)
                            col = fdef.name;
                        key.addColumn(col);
                    });
                    if (kdef.unique && pkey == null)
                        pkey = key;
                    if (kdef.name.startsWith("primary"))
                        pkey = key;
                }
                else {
                    console.log("key " + kdef.name + " is defined twice");
                }
            });
            this.depencies.addKeys(block, keys);
            let fields = [];
            let sorted = [];
            // List of data-fields. First pkey
            if (pkey != null) {
                pkey.columns().forEach((part) => {
                    let fname = part;
                    let fdef = colfields.get(part);
                    if (fdef != null)
                        fname = fdef.name;
                    sorted.push(colindex.get(part));
                    fields.push(fname);
                });
            }
            // Then other columns. First gather all definitions
            let columns = ColumnDefinitions.get(block.clazz);
            let fieldidx = FieldDefinitions.getFieldIndex(block.clazz);
            let ffieldidx = FieldDefinitions.getFormFieldIndex(this.name, block.alias);
            // Override by form
            ffieldidx.forEach((def, fld) => { fieldidx.set(fld, def); });
            columns.forEach((column) => {
                let nonkey = true;
                if (pkey != null && pkey.partof(column.name))
                    nonkey = false;
                if (nonkey) {
                    sorted.push(column);
                    let fname = null;
                    let field = colfields.get(column.name);
                    if (field != null)
                        fname = field.name;
                    else {
                        field = fieldidx.get(column.name);
                        if (field == null)
                            fname = column.name;
                        else {
                            fname = field.name;
                            field.column = column.name;
                        }
                    }
                    fields.push(fname);
                }
            });
            columns = sorted;
            // Then other defined fields (block or form)
            fieldidx.forEach((field) => { if (!fields.includes(field.name, 0))
                fields.push(field.name); });
            // Field overrides.
            let overideidx = FieldDefinitions.getFieldIndex(block.clazz);
            // Set field properties and add undefined fields
            let bfieldlist = bfields.get(block.alias);
            if (bfieldlist != null)
                bfieldlist.forEach((inst) => {
                    let fdef = utils.clone(fieldidx.get(inst.name));
                    if (fdef == null) {
                        // Auto create field definition
                        fdef = { name: inst.name };
                        fieldidx.set(inst.name, fdef);
                        if (!fields.includes(inst.name, 0))
                            fields.push(inst.name);
                    }
                    if (fdef.column == null) {
                        // Map to column, unless column is mapped otherwise
                        let cdef = colindex.get(fdef.name);
                        if (cdef != null && colfields.get(fdef.name) == null)
                            fdef.column = fdef.name;
                    }
                    // Save default definition
                    fieldidx.set(inst.name, fdef);
                    // Override def
                    if (inst.id.length > 0) {
                        let id = inst.name + "." + inst.id;
                        let iddef = utils.clone(FieldDefinitions.getFormFieldOverride(this.name, block.alias, id));
                        if (iddef == null)
                            iddef = utils.clone(FieldDefinitions.getFieldOverride(block.clazz, id));
                        if (iddef != null) {
                            overideidx.set(id, iddef);
                            iddef.column = fdef.column;
                            fdef = iddef;
                        }
                    }
                    let cdef = colindex.get(fdef.column);
                    if (fdef.column != null && !fdef.hasOwnProperty("case"))
                        fdef.case = cdef.case;
                    if (fdef.column != null && !fdef.hasOwnProperty("default"))
                        fdef.default = cdef.default;
                    if (fdef.column != null && !fdef.hasOwnProperty("mandatory"))
                        fdef.mandatory = cdef.mandatory;
                    if (fdef.type == null)
                        fdef.type = FieldImplementation.guess(cdef === null || cdef === void 0 ? void 0 : cdef.type);
                    if (fdef.fieldoptions == null)
                        fdef.fieldoptions = {};
                    if (!block.usage.update)
                        fdef.fieldoptions.update = false;
                    inst.definition = fdef;
                    if (inst.parent.definition == null)
                        inst.parent.setDefinition(fdef, false);
                });
            let def = new Map();
            let ovf = new Map();
            let lovs = new Map();
            let idlovs = new Map();
            def = LOVDefinitions.getblock(block.name);
            def.forEach((lov, fld) => { lovs.set(fld, lov); });
            def = LOVDefinitions.getblockid(block.name);
            def.forEach((lov, fld) => { lovs.set(fld, lov); });
            ovf = LOVDefinitions.getform(this.name, block.alias);
            ovf.forEach((lov, fld) => { lovs.set(fld, lov); });
            ovf = LOVDefinitions.getidform(this.name, block.alias);
            ovf.forEach((lov, fld) => { idlovs.set(fld, lov); });
            block.setListOfValues(lovs);
            block.setIdListOfValues(idlovs);
            // Form triggers
            let ftriggers = TriggerDefinitions.getFormFieldTriggers(this.name, null);
            // Field triggers for block
            let bftriggers = TriggerDefinitions.getFieldTriggers(block.name);
            let fftriggers = TriggerDefinitions.getFormFieldTriggers(this.name, block.alias);
            // Form overrides
            ftriggers.forEach((def, trg) => { bftriggers.set(trg, def); });
            fftriggers.forEach((def, trg) => { bftriggers.set(trg, def); });
            bftriggers.forEach((def) => {
                if (!def.blktrg && def.block == block.alias) {
                    // Blocktrigger defined on form
                    block["triggers"].addTrigger(this.form, def.func, def.trigger, def.field);
                }
                else {
                    if (!def.blktrg)
                        this.triggers.addTrigger(this.form, def.func, def.trigger, def.field);
                    else
                        block["triggers"].addTrigger(block.block, def.func, def.trigger, def.field);
                }
            });
            // Key triggers for block
            let bktriggers = TriggerDefinitions.getKeyTriggers(block.name);
            // delete block-triggers if defined on form
            fktriggers.forEach((_def, trg) => { bktriggers.delete(trg); });
            bktriggers.forEach((def) => { block["triggers"].addTrigger(block.block, def.func, def.trigger, def.field, def.key); });
            // Create data-backing table
            let table = null;
            let rows = block.records.length;
            if (tabdef != null)
                table = new Table(this.conn, tabdef, pkey, columns, fieldidx, rows);
            block.data = new FieldData(block, table, fields, fieldidx);
            // Start form
            block.ready = true;
        });
        // Get all fields on form
        this.fields$ = container.fields;
        if (this.blocks.length > 0)
            this.block$ = this.blocks[0];
        this.groupfields();
        this.blocks.forEach((block) => {
            if (block.records.length > 0)
                block.records[0].enable(true);
        });
        this.depencies.addJoins(JOINDefinitions.get(this.name));
        this.app.newForm(this);
        this.initiated$ = true;
        if (this.fields$.length > 0)
            this.fields$[0].focus();
    }
    showform(form, destroy, parameters) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.validate())
                return;
            if (this.win == null) {
                yield this.app.showform(form, destroy, parameters);
            }
            else {
                yield this.replaceform(form, destroy, parameters);
            }
        });
    }
    replaceform(form, destroy, parameters) {
        return __awaiter(this, void 0, void 0, function* () {
            let utils = new Utils();
            let name = utils.getName(form);
            let id = this.parent.stack.get(name);
            this.onHide();
            // newform
            if (destroy)
                this.app.closeform(this, destroy);
            // create
            if (id == null) {
                id = this.app.getNewInstance(form);
                this.parent.stack.set(id.name, id);
            }
            this.parent.next = id.impl;
            id.impl.setParent(this.parent);
            let inst = this.app.getInstance(id);
            yield this.app.preform(id.impl, parameters, inst, false);
            if (this.win != null) {
                this.win.newForm(inst);
                id.impl.setRoot(this.root);
            }
            else {
                id.impl.setRoot(this);
                this.app.showinstance(inst);
            }
        });
    }
    callform(form, destroy, parameters) {
        return __awaiter(this, void 0, void 0, function* () {
            let utils = new Utils();
            let name = utils.getName(form);
            let id = this.stack.get(name);
            this.onHide();
            // newform
            if (id != null && destroy) {
                this.app.closeform(id.impl, destroy);
                id = null;
            }
            // create
            if (id == null) {
                id = this.app.getNewInstance(form);
                if (id == null)
                    return (null);
                this.stack.set(name, id);
            }
            this.next = id.impl;
            id.impl.setParent(this);
            let inst = this.app.getInstance(id);
            yield this.app.preform(id.impl, parameters, inst, false);
            if (this.win != null) {
                this.win.newForm(inst);
                id.impl.setRoot(this.root);
            }
            else {
                id.impl.setRoot(this);
                this.app.showinstance(inst);
            }
            return (id.impl);
        });
    }
    wasCancelled() {
        return (this.cancelled);
    }
    cancel() {
        this.cancelled = true;
        this.close(true);
    }
    onClose(impl, cancelled) {
        this.next = null;
        try {
            if (this.callbackfunc != null)
                this.form[this.callbackfunc.name](impl.form, cancelled);
        }
        catch (error) {
            console.log(error);
        }
        if (cancelled && this.parent != null)
            this.parent.onClose(this, cancelled);
    }
    close(destroy) {
        return __awaiter(this, void 0, void 0, function* () {
            let win = (this.win != null);
            let menu = (this.root == null);
            let root = (this.parent == null);
            if (!this.cancelled && !destroy && !(yield this.validate()))
                return;
            this.next = null;
            if (this.parent != null)
                this.parent.onClose(this, this.cancelled);
            if (this.cancelled) {
                this.cancelled = false;
                if (menu) {
                    //chain, started from "menu", was cancelled
                    this.app.closeform(this, true);
                }
                else {
                    //chain, started from form, was cancelled
                    this.parent.stack.delete(this.name);
                    this.app.closeInstance(this.inst, true);
                    this.app.showTitle(this.root.title);
                }
                if (!menu)
                    this.root.onShow();
                return;
            }
            if (!win) {
                //Normal behaivior
                this.app.closeform(this, destroy);
                if (!root)
                    this.parent.onShow();
                return;
            }
            if (win && root) {
                //Root window
                this.app.closeform(this, destroy);
                if (!root)
                    this.parent.onShow();
                this.win.closeWindow();
                return;
            }
            //child closed
            this.app.closeInstance(this.inst, destroy);
            if (destroy)
                this.parent.stack.delete(this.name);
            let pinst = this.parent.getInstanceID();
            this.app.showTitle(this.parent.title);
            if (pinst != null) {
                //Parent is modal
                let inst = this.app.getInstance(pinst);
                this.win.newForm(inst);
            }
            else
                this.win.closeWindow();
            this.parent.onShow();
        });
    }
    getCallStack() {
        let stack = [];
        this.stack.forEach((id) => {
            stack.push(id.impl.form);
        });
        return (stack);
    }
    clearStack() {
        this.stack.forEach((id) => {
            id.impl.clearStack();
            if (id.ref != null)
                this.app.closeInstance(id, true);
        });
        this.stack.clear();
    }
    createBlock(blockdef) {
        let impl = this.blkindex.get(blockdef.alias);
        if (impl != null) {
            console.log("Block alias " + blockdef.alias + " defined twice");
            return;
        }
        let block = null;
        if (blockdef.prop != null) {
            block = this.form[blockdef.prop];
            if (block == null && blockdef.component != null) {
                block = new blockdef.component();
                this.form[blockdef.prop] = block;
            }
        }
        else {
            if (blockdef.component != null)
                block = new blockdef.component();
        }
        if (block != null)
            impl = block["_impl_"];
        if (impl == null) {
            this.creationerror = true;
            console.log(this.name + " cannot create instance of " + blockdef.alias + " bailing out");
            return;
        }
        let cname = block.constructor.name;
        if (!(impl instanceof BlockImpl)) {
            this.creationerror = true;
            console.log("component: " + cname + " is not an instance of block bailing out");
            return;
        }
        let alias = blockdef.alias;
        if (alias == null) {
            alias = block.constructor.name;
            alias = BlockDefinitions.getDefaultAlias(alias);
        }
        alias = alias.toLowerCase();
        impl.alias = alias;
        blockdef.alias = alias;
        this.blocks.push(impl);
        this.blkindex.set(alias, impl);
        impl.form = this;
        impl.setApplication(this.app);
    }
    setBlockUsage(fusage, blockdef) {
        let block = this.blkindex.get(blockdef.alias);
        let usage = {};
        let pusage = blockdef.databaseopts;
        let dusage = DatabaseDefinitions.getBlockDefault(block.clazz);
        if (dusage == null)
            dusage = {};
        if (pusage == null)
            pusage = {};
        if (fusage == null)
            fusage = {};
        usage = DBUsage.merge(pusage, dusage);
        usage = DBUsage.override(fusage, usage);
        usage = DBUsage.complete(usage);
        block.usage = usage;
    }
    // Sort fields by group and set tabindex
    groupfields(groups) {
        let seq = 1;
        if (groups == null)
            groups = [];
        let index = new Map();
        this.fields$.forEach((field) => {
            let group = index.get(field.group);
            if (group == null) {
                group = [];
                index.set(field.group, group);
                let exists = false;
                for (let i = 0; i < groups.length; i++) {
                    if (groups[i] == field.group) {
                        exists = true;
                        break;
                    }
                }
                if (!exists)
                    groups.push(field.group);
            }
            group.push(field);
        });
        groups.forEach((name) => {
            let group = index.get(name);
            if (group != null) {
                group.forEach((field) => { field.seq = seq++; });
            }
        });
        this.fields$ = this.fields$.sort((a, b) => { return (a.seq - b.seq); });
        let blocks = new Map();
        this.fields$.forEach((field) => {
            let fields = blocks.get(field.block);
            if (fields == null) {
                fields = [];
                blocks.set(field.block, fields);
            }
            fields.push(field);
        });
        blocks.forEach((fields, bname) => { this.blkindex.get(bname).setFields(fields); });
    }
    validate() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.block == null)
                return (true);
            else
                return (yield this.block.validate());
        });
    }
    onShow() {
    }
    onHide() {
    }
    sendkey(event, key) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            if (key == keymap.close) {
                yield this.close(false);
                return (true);
            }
            if (event == null)
                event = new KeyTriggerEvent(Origin.Form, null, null, keymap.clearblock, null);
            return (yield ((_a = this.block) === null || _a === void 0 ? void 0 : _a.sendkey(event, key)));
        });
    }
    addTrigger(instance, func, types) {
        this.triggers.addTrigger(instance, func, types);
    }
    addKeyTrigger(instance, func, keys) {
        this.triggers.addTrigger(instance, func, Trigger.Key, null, keys);
    }
    addFieldTrigger(instance, func, types, fields, keys) {
        this.triggers.addTrigger(instance, func, types, fields, keys);
    }
    onEvent(event, field, type, key) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.app == null)
                return;
            if (type == "focus")
                this.block = this.blkindex.get(field.block);
            if (type == "key" && key == keymap.prevfield) {
                if (event["preventDefault"] != null)
                    event.preventDefault();
                let row = field.row;
                let seq = field.seq - 1;
                let block = field.block;
                for (let i = 0; i < this.fields$.length; i++) {
                    if (--seq < 0)
                        seq = this.fields$.length - 1;
                    if (this.fields$[seq].row == row && this.fields$[seq].block == block) {
                        if (this.fields$[seq].enabled) {
                            this.fields$[seq].focus();
                            break;
                        }
                    }
                }
            }
            if (type == "key" && key == keymap.nextfield) {
                if (event["preventDefault"] != null)
                    event.preventDefault();
                let row = field.row;
                let seq = field.seq - 1;
                let block = field.block;
                for (let i = 0; i < this.fields$.length; i++) {
                    if (++seq >= this.fields$.length)
                        seq = 0;
                    if (this.fields$[seq].row == row && this.fields$[seq].block == block) {
                        if (this.fields$[seq].enabled) {
                            this.fields$[seq].focus();
                            break;
                        }
                    }
                }
            }
            if (type == "key" && key == keymap.prevblock) {
                if (event["preventDefault"] != null)
                    event.preventDefault();
                let seq = field.seq - 1;
                let block = field.block;
                let row = 0;
                let next = "";
                for (let i = 0; i < this.fields$.length; i++) {
                    if (--seq < 0)
                        seq = this.fields$.length - 1;
                    if (this.fields$[seq].block != block) {
                        let blk = this.fields$[seq].block;
                        if (blk != next) {
                            let nb = this.blkindex.get(blk);
                            let nf = nb.field;
                            if (nf.enabled) {
                                nf.focus();
                                break;
                            }
                            next = blk;
                            row = nb.row;
                        }
                        if (this.fields$[seq].row == row && this.fields$[seq].enabled) {
                            this.fields$[seq].focus();
                            break;
                        }
                    }
                }
            }
            if (type == "key" && key == keymap.nextblock) {
                if (event["preventDefault"] != null)
                    event.preventDefault();
                let seq = field.seq - 1;
                let block = field.block;
                let row = 0;
                let next = "";
                for (let i = 0; i < this.fields$.length; i++) {
                    if (++seq >= this.fields$.length)
                        seq = 0;
                    if (this.fields$[seq].block != block) {
                        let blk = this.fields$[seq].block;
                        if (blk != next) {
                            let nb = this.blkindex.get(blk);
                            let nf = nb.field;
                            if (nf.enabled) {
                                nf.focus();
                                break;
                            }
                            next = blk;
                            row = nb.row;
                        }
                        if (this.fields$[seq].row == row && this.fields$[seq].enabled) {
                            this.fields$[seq].focus();
                            break;
                        }
                    }
                }
            }
            if (type == "key" && key == keymap.clearform) {
                let event = new KeyTriggerEvent(Origin.Form, null, null, keymap.clearform, null);
                if (!(yield this.invokeTriggers(Trigger.Key, event, keymap.clearform)))
                    return (false);
                this.clear();
            }
        });
    }
    invokeTriggers(type, event, key) {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this.triggers.invokeTriggers(type, event, key));
        });
    }
    invokeFieldTriggers(type, field, event, key) {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this.triggers.invokeFieldTriggers(type, field, event, key));
        });
    }
    alert(msg, title, width, height) {
        MessageBox.show(this.app, msg, title, width, height);
    }
}
FormImpl.id = 0;

class Form {
    // dont rename impl as it is read behind the scenes
    constructor() {
        this._impl_ = new FormImpl(this);
    }
    get name() {
        return (this.constructor.name);
    }
    set title(title) {
        this._impl_.title = title;
    }
    get title() {
        return (this._impl_.title);
    }
    set menu(menu) {
        this._impl_.setMenu(menu);
    }
    get menu() {
        return (this._impl_.getMenu());
    }
    focus() {
        this._impl_.focus();
    }
    get block() {
        var _a;
        return ((_a = this._impl_.block) === null || _a === void 0 ? void 0 : _a.block);
    }
    get connected() {
        return (this._impl_.getApplication().connected);
    }
    groupfields(groups) {
        this._impl_.groupfields(groups);
    }
    get popup() {
        return (this._impl_.popup);
    }
    get colors() {
        return (this._impl_.getApplication().config.colors);
    }
    getBlockFilter(block) {
        let blk = this.getBlock(block);
        if (blk != null && blk.searchfilter.length > 0)
            return (this.colors.rowindicator);
        return ("");
    }
    showRowIndicator(block, row) {
        if (row == this.getCurrentRow(block))
            return (true);
        return (false);
    }
    getRowIndicator(block, row) {
        if (row == this.getCurrentRow(block))
            return (this.colors.rowindicator);
        return ("");
    }
    getCurrentRow(block) {
        return (this._impl_.getCurrentRow(block));
    }
    getCurrentRecord(block) {
        return (this._impl_.getCurrentRecord(block));
    }
    getBlock(block) {
        let impl = this._impl_.getBlock(block);
        if (impl != null)
            return (impl.block);
        return (null);
    }
    addListOfValues(block, func, field, id) {
        let impl = this._impl_.getBlock(block);
        if (impl != null)
            impl.addListOfValues(true, func, field, id);
    }
    newform(form, parameters) {
        this._impl_.showform(form, true, parameters);
    }
    showform(form, parameters) {
        this._impl_.showform(form, false, parameters);
    }
    callform(form, parameters) {
        return __awaiter(this, void 0, void 0, function* () {
            let impl = yield this._impl_.callform(form, false, parameters);
            if (impl != null)
                return (impl.form);
            return (null);
        });
    }
    getCallStack() {
        return (this._impl_.getCallStack());
    }
    clearCallStack() {
        this._impl_.clearStack();
    }
    getTable(block) {
        var _a;
        return ((_a = this.getBlock(block)) === null || _a === void 0 ? void 0 : _a.table);
    }
    get parameters() {
        return (this._impl_.getParameters());
    }
    getValue(block, record, field) {
        let blk = this.getBlock(block);
        if (blk != null)
            return (blk.getValue(record, field));
        return (null);
    }
    setValue(block, record, field, value) {
        return __awaiter(this, void 0, void 0, function* () {
            let blk = this.getBlock(block);
            if (blk != null)
                return (yield blk.setValue(record, field, value));
            return (false);
        });
    }
    cancelled() {
        return (this._impl_.wasCancelled());
    }
    clear() {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this._impl_.clear());
        });
    }
    cancel() {
        this._impl_.cancel();
    }
    close(dismiss) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this._impl_.close(dismiss);
        });
    }
    sendKey(key) {
        return __awaiter(this, void 0, void 0, function* () {
            return (yield this._impl_.sendkey(null, key));
        });
    }
    setCallback(func) {
        this._impl_.setCallback(func);
    }
    addTrigger(func, types) {
        this._impl_.addTrigger(this, func, types);
    }
    addKeyTrigger(func, keys) {
        this._impl_.addKeyTrigger(this, func, keys);
    }
    enterquery(force) {
        this._impl_.enterquery(force);
    }
    executequery(force) {
        this._impl_.executequery(force);
    }
    prevBlock() {
        this._impl_.block.sendkey(null, keymap.prevblock);
    }
    nextBlock() {
        this._impl_.block.sendkey(null, keymap.nextblock);
    }
    execute(stmt, firstrow, firstcolumn) {
        return __awaiter(this, void 0, void 0, function* () {
            return (this._impl_.execute(stmt, firstrow, firstcolumn));
        });
    }
    addFieldTrigger(listener, types, fields) {
        this._impl_.addFieldTrigger(this, listener, types, fields);
    }
    ngOnInit() {
        this._impl_.getApplication().setContainer();
    }
    ngAfterViewInit() {
        let container = this._impl_.getApplication().getContainer();
        this._impl_.getApplication().dropContainer();
        this._impl_.newForm(container);
    }
    alert(message, title, width, height) {
        if (title == null)
            title = this.name;
        this._impl_.alert(message, title, width, height);
    }
}
Form.decorators = [
    { type: Component, args: [{ template: '' },] }
];
Form.ctorParameters = () => [];

var Case;
(function (Case) {
    Case[Case["upper"] = 0] = "upper";
    Case[Case["lower"] = 1] = "lower";
    Case[Case["mixed"] = 2] = "mixed";
})(Case || (Case = {}));

class FieldInstance {
    constructor(ctx) {
        this.fgroup$ = null;
        this.valid$ = true;
        this.lvalid = true;
        this.enforce = false;
        this.enabled$ = false;
        this.readonly$ = false;
        this.mandatory$ = false;
        this.firstchange = true;
        this.values = null;
        this.container = null;
        this.state$ = RecordState.na;
        this.options$ = { query: true, insert: true, update: true, navigable: true };
        this.id$ = "";
        this.row$ = -1;
        this.name$ = "";
        this.block$ = "";
        this.group$ = "";
        this.class$ = "";
        this.style$ = "";
        this.size$ = null;
        this.value$ = null;
        this.app = ctx.app["_impl_"];
    }
    get id() {
        return (this.id$);
    }
    get row() {
        return (this.row$);
    }
    set row(row) {
        this.row$ = row;
    }
    set seq(seq) {
        if (this.clazz != null)
            this.clazz.tabindex = seq;
    }
    get seq() {
        if (this.clazz == null)
            return (0);
        else
            return (this.clazz.tabindex);
    }
    get name() {
        return (this.name$);
    }
    get fname() {
        let name = this.block$ + "." + this.name;
        if (this.id.length > 0)
            name += "." + this.id;
        name += "[" + this.row + "](" + this.guid + ")";
        return (name);
    }
    set guid(guid) {
        this.guid$ = guid;
    }
    get guid() {
        return (this.guid$);
    }
    get block() {
        return (this.block$);
    }
    get group() {
        return (this.group$);
    }
    get value() {
        if (this.clazz == null)
            return (null);
        let value = this.clazz.value;
        if (("" + value).trim().length == 0)
            value = null;
        return (value);
    }
    get parent() {
        return (this.fgroup$);
    }
    set parent(field) {
        this.fgroup$ = field;
    }
    get fieldoptions() {
        return (this.options$);
    }
    get enabled() {
        return (this.enabled$);
    }
    get state() {
        return (this.state$);
    }
    set state(state) {
        this.state$ = state;
    }
    set readonly(flag) {
        this.readonly$ = flag;
    }
    get readonly() {
        return (this.readonly$);
    }
    get mandatory() {
        return (this.mandatory$);
    }
    setPossibleValues(values, enforce) {
        this.enforce = enforce;
        let type = this.clazz.constructor.name;
        if (type == "DropDown")
            this.setDropDownValues(values);
        if (type == "TextField")
            this.setTextFieldValues(values);
    }
    setTextFieldValues(values) {
        let name = this.block + "." + this.name;
        if (this.id.length > 0)
            name += "." + this.id;
        let list = document.getElementById(name);
        if (list == null) {
            let kvpair = true;
            if (values instanceof Map)
                this.values = new Map(values);
            else {
                kvpair = false;
                this.values = new Map();
                values.forEach((val) => this.values.set(val, val));
            }
            list = document.createElement("datalist");
            list.setAttribute("id", name);
            this.values.forEach((val, key) => {
                let option = document.createElement("option");
                option.text = val;
                if (kvpair)
                    option.value = key;
                list.append(option);
            });
            this.clazz.element.appendChild(list);
        }
        this.clazz.element.setAttribute("list", name);
    }
    setDropDownValues(xvalues) {
        if (xvalues instanceof Map)
            this.values = new Map(xvalues);
        else {
            this.values = new Map();
            xvalues.forEach((val) => this.values.set(val, val));
        }
        this.values.forEach((val, key) => {
            let option = document.createElement("option");
            option.text = val;
            option.value = key;
            this.clazz.element.appendChild(option);
        });
    }
    set mandatory(flag) {
        this.mandatory$ = flag;
        if (flag)
            this.addClass("mandatory");
        else
            this.removeClass("mandatory");
    }
    focus() {
        if (!this.enabled)
            return (false);
        setTimeout(() => { this.clazz.focus(); }, 0);
        return (true);
    }
    blur() {
        setTimeout(() => { this.clazz.element.blur(); }, 0);
    }
    addClass(clazz) {
        if (this.clazz != null)
            this.clazz.element.classList.add(clazz);
    }
    removeClass(clazz) {
        if (this.clazz != null)
            this.clazz.element.classList.remove(clazz);
    }
    get current() {
        return (this.guid.startsWith("c"));
    }
    set value(value) {
        if (value == null)
            value = "";
        if (this.clazz != null)
            this.clazz.value = value;
    }
    get valid() {
        return (this.valid$);
    }
    get dirty() {
        return (!this.firstchange);
    }
    validate() {
        if (this.state == RecordState.qmode || this.state == RecordState.na)
            return (true);
        if (!this.clazz.validate())
            return (false);
        if (this.mandatory && (this.value == null || ("" + this.value).length == 0))
            return (false);
        if (this.enforce && this.values != null && this.value != null)
            if (!this.values.has(this.value))
                return (false);
        return (true);
    }
    set valid(flag) {
        if (flag == this.valid$)
            return;
        if (flag) {
            this.valid$ = flag;
            this.removeClass("invalid");
        }
        else {
            if (this.enabled && !this.readonly) {
                this.valid$ = flag;
                this.addClass("invalid");
            }
        }
    }
    enable() {
        this.setInputState();
    }
    disable() {
        this.valid = true;
        this.enabled$ = false;
        this.readonly$ = true;
        this.state = RecordState.na;
        if (this.clazz != null) {
            this.clazz.enable = false;
            this.clazz.readonly = true;
        }
    }
    setInputState() {
        this.enabled$ = false;
        if (!this.options$.navigable) {
            if (this.clazz != null)
                this.clazz.enable = false;
            return;
        }
        if (this.state$ == RecordState.na)
            this.enabled$ = true;
        else if (this.state$ == RecordState.insert && this.options$.insert)
            this.enabled$ = true;
        else if (this.state$ == RecordState.update && this.options$.update)
            this.enabled$ = true;
        else if (this.state$ == RecordState.qmode && this.options$.query)
            this.enabled$ = true;
        if (this.clazz != null) {
            if (!this.enabled$ && this.state$ == RecordState.update) {
                this.enabled$ = true;
                this.readonly$ = true;
            }
            this.clazz.enable = this.enabled$;
            this.clazz.readonly = this.readonly$;
        }
    }
    get definition() {
        return (this.def);
    }
    set definition(def) {
        let override = false;
        if (this.def != null) {
            override = true;
            if (def.hasOwnProperty("case"))
                this.def.case = def.case;
            if (def.hasOwnProperty("mandatory"))
                this.def.mandatory = def.mandatory;
            if (def.hasOwnProperty("type"))
                this.def.type = def.type;
            if (def.hasOwnProperty("fieldoptions")) {
                if (def.hasOwnProperty("query"))
                    this.def.fieldoptions.query = def.fieldoptions.query;
                if (def.hasOwnProperty("insert"))
                    this.def.fieldoptions.insert = def.fieldoptions.insert;
                if (def.hasOwnProperty("update"))
                    this.def.fieldoptions.update = def.fieldoptions.update;
                if (def.hasOwnProperty("navigable"))
                    this.def.fieldoptions.navigable = def.fieldoptions.navigable;
            }
        }
        this.def = def;
        this.setType(def.type);
        if (!this.def.hasOwnProperty("case"))
            this.def.case = Case.mixed;
        if (this.def.hasOwnProperty("mandatory"))
            this.mandatory = this.def.mandatory;
        if (this.def.fieldoptions != null) {
            this.options$ = this.def.fieldoptions;
            if (!this.options$.hasOwnProperty("query"))
                this.options$.query = true;
            if (!this.options$.hasOwnProperty("insert"))
                this.options$.insert = true;
            if (!this.options$.hasOwnProperty("update"))
                this.options$.update = true;
            if (!this.options$.hasOwnProperty("navigable"))
                this.options$.navigable = true;
        }
        if (override)
            this.setInputState();
    }
    setType(type) {
        let seq = this.seq;
        this.container.innerHTML = null;
        let cname = FieldImplementation.getClass(FieldType[type]);
        if (cname != null) {
            this.clazz = new cname();
            this.container.innerHTML = this.clazz.html;
            this.clazz.element = this.container.children[0];
            if (this.size$ != null)
                this.clazz.size = this.size$;
            if (this.value$ != null)
                this.clazz.value = this.value$;
            if (this.class$ != "")
                this.clazz.element.classList.add(this.class$);
            if (this.style$ != "")
                this.clazz.element.style.cssText = this.style$;
            this.seq = seq;
            this.disable();
            this.addTriggers();
            // Ugly, but need to set name
            this.clazz.element.name = this.name;
        }
    }
    onEvent(event) {
        return __awaiter(this, void 0, void 0, function* () {
            let keypress = false;
            if (this.fgroup$ == null)
                return;
            if (event.type == "focus") {
                this.firstchange = true;
                this.lvalue = this.value;
                this.lvalid = this.valid$;
                this.fgroup$["onEvent"](event, this, "focus");
            }
            if (event.type == "blur") {
                if (this.dirty && this.value == this.lvalue && !this.lvalid)
                    this.valid = false;
                this.fgroup$["onEvent"](event, this, "blur");
            }
            if (event.type == "click" || event.type == "dblclick")
                this.fgroup$["onEvent"](event, this, event.type);
            if (event.type == "change") {
                if (this.enabled && !this.readonly)
                    if (!this.valid)
                        this.fgroup$.valid = false;
                this.valid = this.validate();
                if (this.clazz instanceof CheckBox)
                    this.value = this.value$;
                if (this.clazz instanceof RadioButton)
                    this.value = this.value$;
                this.fgroup$["onEvent"](event, this, "change");
            }
            if (event.type == "keydown" && event.keyCode == 8)
                keypress = true;
            if (event.type == "keydown" && !keypress) {
                if (+event.keyCode >= 16 && +event.keyCode <= 20)
                    return;
                let keydef = {
                    code: event.keyCode,
                    alt: event.altKey,
                    ctrl: event.ctrlKey,
                    meta: event.metaKey,
                    shift: event.shiftKey
                };
                let map = KeyMapper.map(keydef);
                let key = KeyMapper.keymap(map);
                if (key == keymap.undo || key == keymap.paste) {
                    setTimeout(() => { this.blur(); }, 1);
                    setTimeout(() => { this.focus(); }, 1);
                    return;
                }
                if (key != null) {
                    // handled by application
                    if (key == keymap.close ||
                        key == keymap.listval ||
                        key == keymap.connect ||
                        key == keymap.disconnect ||
                        key == keymap.commit ||
                        key == keymap.rollback ||
                        key == keymap.delete ||
                        key == keymap.clearform ||
                        key == keymap.insertafter ||
                        key == keymap.insertbefore ||
                        key == keymap.enterquery ||
                        key == keymap.executequery) {
                        this.fgroup$.copy(this);
                        return;
                    }
                    this.fgroup$["onEvent"](event, this, "key", key);
                }
            }
            if (event.type == "keypress" || keypress) {
                if (this.readonly)
                    return;
                if (this.firstchange && (event.key.length == 1 || event.keyCode == KeyCodes.backspace)) {
                    this.firstchange = false;
                    if (!this.valid)
                        this.fgroup$.valid = true;
                    this.fgroup$["onEvent"](event, this, "fchange");
                }
                let value = this.value;
                setTimeout(() => { this.continious(event, value); }, 0);
            }
        });
    }
    continious(event, value) {
        if (this.value == value)
            return;
        if (this.def.type == FieldType.integer) {
            if (!this.valnumber(value))
                return;
        }
        if (this.def.type == FieldType.decimal) {
            if (!this.valdecimal(value))
                return;
        }
        if (this.value != null && this.def.case == Case.lower)
            this.value = ("" + this.value).toLowerCase();
        if (this.value != null && this.def.case == Case.upper)
            this.value = ("" + this.value).toUpperCase();
        this.fgroup$.onEvent(event, this, "cchange");
    }
    valnumber(value) {
        if (this.state == RecordState.qmode)
            return (true);
        let nvalue = this.value;
        if (nvalue == null || nvalue.trim().length == 0)
            return (true);
        let numeric = !isNaN(+nvalue);
        if (!numeric || nvalue.indexOf(".") >= 0) {
            this.value = value;
            return (false);
        }
        return (true);
    }
    valdecimal(value) {
        if (this.state == RecordState.qmode)
            return (true);
        let nvalue = this.value;
        if (nvalue == null || nvalue.trim().length == 0)
            return (true);
        let numeric = !isNaN(+nvalue);
        if (!numeric) {
            this.value = value;
            return (false);
        }
        return (true);
    }
    ngAfterViewInit() {
        var _a;
        this.container = (_a = this.containerelem) === null || _a === void 0 ? void 0 : _a.nativeElement;
        this.id$ = this.id$.toLowerCase();
        this.name$ = this.name$.toLowerCase();
        this.block$ = this.block$.toLowerCase();
        this.app.getContainer().register(this);
    }
    addTriggers() {
        let impl = this.container.firstChild;
        if (impl == null)
            return;
        impl.addEventListener("blur", (event) => { this.onEvent(event); });
        impl.addEventListener("focus", (event) => { this.onEvent(event); });
        impl.addEventListener("change", (event) => { this.onEvent(event); });
        impl.addEventListener("click", (event) => { this.onEvent(event); });
        impl.addEventListener("keydown", (event) => { this.onEvent(event); });
        impl.addEventListener("keypress", (event) => { this.onEvent(event); });
        impl.addEventListener("dblclick", (event) => { this.onEvent(event); });
    }
}
FieldInstance.decorators = [
    { type: Component, args: [{
                selector: 'field',
                template: '<span #container></span>'
            },] }
];
FieldInstance.ctorParameters = () => [
    { type: Context }
];
FieldInstance.propDecorators = {
    id$: [{ type: Input, args: ["id",] }],
    row$: [{ type: Input, args: ["row",] }],
    name$: [{ type: Input, args: ["name",] }],
    block$: [{ type: Input, args: ["block",] }],
    group$: [{ type: Input, args: ["group",] }],
    class$: [{ type: Input, args: ["class",] }],
    style$: [{ type: Input, args: ["style",] }],
    size$: [{ type: Input, args: ["size",] }],
    value$: [{ type: Input, args: ["value",] }],
    containerelem: [{ type: ViewChild, args: ["container", { read: ElementRef },] }]
};

class DateUtils {
    parse(datestr, format) {
        return (dates.parse(datestr, format));
    }
    format(date, format) {
        return (dates.format(date, format));
    }
}

class FormList {
    constructor(ctx) {
        this.page = "";
        this.ready = false;
        this.name = "/";
        this.conf = ctx.conf;
        this.app = ctx.app["_impl_"];
        this.root = new Folder(this.name);
        this.conf.notify(this, "setColors");
        this.app.setFormList(this);
        this.formsdef = this.app.getFormsList();
        this.parse();
        this.page += "<style>\n";
        this.page += this.styles() + "\n";
        this.page += "</style>\n";
        this.page += "<div class='formlist'>\n";
        this.page += this.print("/", this.root, 0, [true]);
        this.page += "</div>\n";
    }
    open(folder) {
        if (!this.ready) {
            setTimeout(() => { this.open(folder); }, 10);
            return;
        }
        folder = folder.trim();
        let parts = folder.split("/");
        let current = this.root;
        for (let i = 0; i < parts.length; i++) {
            current = current.findFolder([parts[i]]);
            if (current == null)
                return;
            if (!current.content.classList.contains("formlist-active")) {
                current.img.src = "/assets/images/open.jpg";
                current.content.classList.toggle("formlist-active");
            }
        }
    }
    print(path, root, level, last) {
        let html = "";
        html += this.folder(path, root, level, last);
        html += "<div class='formlist-folder-content' id='" + path + "-content'>";
        level++;
        last.push(false);
        if (path == "/")
            path = "";
        let subs = root.folders.length;
        let forms = root.forms.length;
        for (let i = 0; i < subs; i++) {
            let folder = root.folders[i];
            if (i == subs - 1 && forms == 0)
                last[level] = true;
            html += this.print(path + "/" + folder.name, folder, level, last);
        }
        last[level] = false;
        html += this.forms(root, level, last);
        last.pop();
        html += "</div>";
        return (html);
    }
    parse() {
        for (let i = 0; i < this.formsdef.length; i++) {
            let path = this.formsdef[i].path;
            if (!this.formsdef[i].navigable)
                continue;
            let form = path;
            let folder = "/";
            let pos = path.lastIndexOf("/");
            if (pos >= 0) {
                form = path.substring(pos + 1);
                folder = path.substring(0, pos);
            }
            let current = this.root;
            let parts = folder.split("/");
            for (let p = 1; p < parts.length; p++) {
                if (parts[p] == "")
                    parts[p] = "/";
                current = current.getFolder(parts[p].trim());
            }
            current.addForm(form, this.formsdef[i]);
        }
    }
    ngAfterViewInit() {
        var _a;
        this.html = (_a = this.elem) === null || _a === void 0 ? void 0 : _a.nativeElement;
        this.html.innerHTML = this.page;
        let folders = this.html.getElementsByClassName("formlist-folder");
        for (let i = 0; i < folders.length; i++) {
            let container = folders.item(i);
            let content = document.getElementById(container.id + "-content");
            let lnk = container.querySelector("[id='" + container.id + "-lnk']");
            let img = container.querySelector("[id='" + container.id + "-img']");
            let folder = this.root.findFolder(container.id.split("/"));
            folder.img = img;
            folder.lnk = lnk;
            folder.content = content;
            folder.img.addEventListener("click", (event) => this.toggle(event));
            folder.lnk.addEventListener("click", (event) => this.toggle(event));
        }
        let forms = this.html.getElementsByClassName("formlist-form");
        for (let i = 0; i < forms.length; i++) {
            let form = forms.item(i);
            let lnk = form.querySelector("[id='" + form.id + "-lnk']");
            lnk.addEventListener("click", (event) => this.show(event));
        }
        this.setColors();
        this.open("/");
        this.root.lnk.innerHTML = this.name;
        this.ready = true;
    }
    setColors() {
        let link = this.conf.colors.link;
        let tree = this.conf.colors.foldertree;
        let list = null;
        list = this.html.getElementsByClassName("formlist-txt");
        for (let i = 0; i < list.length; i++)
            list[i].style.color = tree;
        list = this.html.getElementsByClassName("formlist-link");
        for (let i = 0; i < list.length; i++)
            list[i].style.color = link;
        list = this.html.getElementsByClassName("formlist-off");
        for (let i = 0; i < list.length; i++)
            list[i].style.borderLeft = "1px solid " + tree;
        list = this.html.getElementsByClassName("formlist-vln");
        for (let i = 0; i < list.length; i++)
            list[i].style.borderLeft = "1px solid " + tree;
        list = this.html.getElementsByClassName("formlist-cnr");
        for (let i = 0; i < list.length; i++) {
            list[i].style.borderLeft = "1px solid " + tree;
            list[i].style.borderBottom = "1px solid " + tree;
        }
    }
    toggle(event) {
        let fname = event.target.id;
        fname = fname.substring(0, fname.length - 4);
        let folder = this.root.findFolder(fname.split("/"));
        folder.content.classList.toggle("formlist-active");
        if (folder.content.classList.contains("formlist-active")) {
            folder.img.src = "/assets/images/open.jpg";
        }
        else {
            folder.img.src = "/assets/images/closed.jpg";
        }
    }
    show(event) {
        let fname = event.target.id;
        fname = fname.substring(0, fname.length - 4);
        this.app.showform(fname, false);
    }
    folder(path, root, level, last) {
        let html = "";
        html += "<div id='" + path + "' class='formlist-folder'>\n";
        if (level > 0) {
            html += this.half();
            for (let i = 1; i < level; i++)
                html += this.indent(last[i]);
        }
        if (level > 0)
            html += this.pre(last[level]);
        html += "<img class='formlist-img' id='" + path + "-img' src='/assets/images/closed.jpg'>\n";
        html += "<span class='formlist-txt' id='" + path + "-lnk'>" + root.name + "</span>\n";
        html += "</div>\n";
        return (html);
    }
    forms(root, level, last) {
        let html = "";
        for (let i = 0; i < root.forms.length; i++) {
            if (i == root.forms.length - 1)
                last[level] = true;
            html += this.form(root.forms[i], level, last);
        }
        return (html);
    }
    form(form, level, last) {
        let html = "";
        html += "<div id='" + form.def.name + "' class='formlist-form'>\n";
        html += this.half();
        for (let i = 1; i < level; i++)
            html += this.indent(last[i]);
        if (level > 0)
            html += this.pre(last[last.length - 1]);
        html += "<span class='formlist-link' id='" + form.def.name + "-lnk'> " + form.name + "</span>\n";
        html += "</div>\n";
        return (html);
    }
    pre(last) {
        let html = "";
        html += "<span class='formlist-lct'>\n";
        html += " <span class='formlist-off'></span>\n";
        html += " <span class='formlist-cnr'></span>\n";
        if (last)
            html += "<span class='formlist-end'></span>\n";
        else
            html += "<span class='formlist-vln'></span>\n";
        html += "</span>\n";
        return (html);
    }
    indent(skip) {
        let html = "";
        if (skip) {
            html += "<span class='formlist-lct'>\n";
            html += "</span>\n";
            html += " <span class='formlist-ind'></span>\n";
        }
        else {
            html += "<span class='formlist-lct'>\n";
            html += " <span class='formlist-vln'></span>\n";
            html += " <span class='formlist-vln'></span>\n";
            html += " <span class='formlist-vln'></span>\n";
            html += "</span>\n";
            html += " <span class='formlist-ind'></span>\n";
        }
        return (html);
    }
    half() {
        let html = "";
        html += " <span class='formlist-ind'></span>\n";
        return (html);
    }
    styles() {
        let styles = `
		.formlist
		{
			width: 1px;
			position: relative;
		}

    	.formlist-folder
    	{
			margin: 0;
			padding: 0;
			width: 100%;
			height: 100%;
			font-size: 0;
			position: relative;
			border-collapse: collapse;
    	}

		.formlist-folder-content
		{
			display: none;
		}

		.formlist-lct
		{
			width: 16px;
			height: 24px;
			pointer-events:none;
			white-space: nowrap;
			display: inline-block;
			vertical-align: middle;
		}

		.formlist-txt
		{
			width: 16px;
			height: 21px;
			font-size: 15px;
			cursor: pointer;
			white-space: nowrap;
			display: inline-block;
			vertical-align: bottom;
		}

		.formlist-off
		{
			width: 16px;
			height: 4px;
			display: block;
			pointer-events:none;
		}

		.formlist-vln
		{
			width: 16px;
			height: 12px;
			display: block;
			pointer-events:none;
		}

		.formlist-cnr
		{
			width: 16px;
			height: 8px;
			display: block;
			pointer-events:none;
		}

		.formlist-end
		{
			width: 16px;
			height: 12px;
			display: block;
			pointer-events:none;
		}

		.formlist-ind
		{
			width: 12px;
			height: 24px;
			white-space: nowrap;
			pointer-events:none;
			display: inline-block;
			vertical-align: middle;
		}

		.formlist-img
		{
			width: 24px;
			height: 24px;
			cursor: pointer;
			vertical-align: middle;
		}

		.formlist-link
		{
			width: 16px;
			height: 22px;
			cursor: pointer;
			font-size: 15px;
			margin-left: 8px;
			font-style: italic;
			white-space: nowrap;
			display: inline-block;
			vertical-align: bottom;
		}

		.formlist-form
		{
			margin: 0;
			padding: 0;
			font-size: 0;
			display: block;
			border-collapse: collapse;
		}

		.formlist-active
		{
			display: block;
		}
		`;
        return (styles);
    }
}
FormList.decorators = [
    { type: Component, args: [{
                selector: 'formlist',
                template: `
		<div #html style="display: inline-block; white-space: nowrap;"></div>
	`
            },] }
];
FormList.ctorParameters = () => [
    { type: Context }
];
FormList.propDecorators = {
    name: [{ type: Input, args: ['root',] }],
    elem: [{ type: ViewChild, args: ["html", { read: ElementRef },] }]
};
class Folder {
    constructor(name) {
        this.forms = [];
        this.folders = [];
        this.name = name;
    }
    getFolder(next) {
        if (next == this.name)
            return (this);
        for (let i = 0; i < this.folders.length; i++)
            if (this.folders[i].name == next)
                return (this.folders[i]);
        let folder = new Folder(next);
        this.folders.push(folder);
        return (folder);
    }
    findFolder(path) {
        while (path[0] == "")
            path.shift();
        if (path.length == 0)
            return (this);
        let next = null;
        for (let i = 0; i < this.folders.length; i++) {
            if (this.folders[i].name == path[0]) {
                next = this.folders[i];
                break;
            }
        }
        if (next == null)
            return (null);
        path.shift();
        return (next.findFolder(path));
    }
    addForm(name, form) {
        this.forms.push({ name: name, def: form });
    }
    print() {
        console.log("");
        console.log("Folder: " + this.name);
        for (let i = 0; i < this.forms.length; i++)
            console.log("Form: " + this.forms[i].name);
        for (let i = 0; i < this.folders.length; i++)
            this.folders[i].print();
    }
}

class FormArea {
    constructor(ctx) {
        this.app = null;
        this.app = ctx.app;
    }
    getFormsArea() {
        return (this.formarea.nativeElement);
    }
    ngAfterViewInit() {
        let impl = this.app["_impl_"];
        impl.setFormArea(this);
    }
}
FormArea.decorators = [
    { type: Component, args: [{
                selector: 'formarea',
                template: '<div #formarea></div>'
            },] }
];
FormArea.ctorParameters = () => [
    { type: Context }
];
FormArea.propDecorators = {
    formarea: [{ type: ViewChild, args: ["formarea", { read: ElementRef },] }]
};

class MacKeyMap {
    constructor() {
        this.zoom = KeyMapper.map({ code: 90, ctrl: true });
        this.close = KeyMapper.map({ code: 87, ctrl: true });
        this.undo = KeyMapper.map({ code: 90, meta: true });
        this.paste = KeyMapper.map({ code: 86, meta: true });
        this.enter = KeyMapper.map({ code: KeyCodes.enter });
        this.escape = KeyMapper.map({ code: KeyCodes.escape });
        this.listval = KeyMapper.map({ code: 76, shift: true, ctrl: true });
        this.clearblock = KeyMapper.map({ code: KeyCodes.escape, ctrl: true });
        this.clearform = KeyMapper.map({ code: KeyCodes.escape, shift: true, ctrl: true });
        this.insertafter = KeyMapper.map({ code: 73, ctrl: true });
        this.insertbefore = KeyMapper.map({ code: 73, shift: true, ctrl: true });
        this.delete = KeyMapper.map({ code: 68, ctrl: true });
        this.dublicate = KeyMapper.map({ code: 86, ctrl: true });
        this.commit = KeyMapper.map({ code: KeyCodes.enter, ctrl: true });
        this.rollback = KeyMapper.map({ code: KeyCodes.f1, ctrl: true, shift: true });
        this.connect = KeyMapper.map({ code: 67, ctrl: true });
        this.disconnect = KeyMapper.map({ code: 67, shift: true, ctrl: true });
        this.nextfield = KeyMapper.map({ code: KeyCodes.tab });
        this.prevfield = KeyMapper.map({ code: KeyCodes.tab, shift: true });
        this.nextrecord = KeyMapper.map({ code: KeyCodes.down, shift: false });
        this.prevrecord = KeyMapper.map({ code: KeyCodes.up, shift: false });
        this.nextblock = KeyMapper.map({ code: KeyCodes.down, shift: true });
        this.prevblock = KeyMapper.map({ code: KeyCodes.up, shift: true });
        this.pageup = KeyMapper.map({ code: 80, ctrl: true, shift: true });
        this.pagedown = KeyMapper.map({ code: 80, ctrl: true, shift: false });
        this.enterquery = KeyMapper.map({ code: 81, ctrl: true });
        this.executequery = KeyMapper.map({ code: 81, shift: true, ctrl: true });
        this.map =
            `
            <table>
                <tr><td class="kmtd">   connect            </td><td>   ctrl-c             </td></tr>
                <tr><td class="kmtd">   disconnect         </td><td>   ctrl-shift-c       </td></tr>
                <tr><td class="kmtd">   close              </td><td>   ctrl-w             </td></tr>
                <tr><td class="kmtd">   zoom               </td><td>   ctrl-z             </td></tr>
                <tr><td class="kmtd">   datepicker         </td><td>   ctrl-shift-l       </td></tr>
                <tr><td class="kmtd">   list of values     </td><td>   ctrl-shift-l       </td></tr>
                <tr><td class="kmtd">   clear block        </td><td>   ctrl-escape        </td></tr>
                <tr><td class="kmtd">   clear form         </td><td>   ctrl-shift-escape  </td></tr>
                <tr><td class="kmtd">   insert after       </td><td>   ctrl-i             </td></tr>
                <tr><td class="kmtd">   insert before      </td><td>   ctrl-shift-i       </td></tr>
                <tr><td class="kmtd">   delete             </td><td>   ctrl-d             </td></tr>
                <tr><td class="kmtd">   commit             </td><td>   ctrl-enter         </td></tr>
                <tr><td class="kmtd">   rollback           </td><td>   ctrl-shift-escape  </td></tr>
                <tr><td class="kmtd">   next record        </td><td>   key-down           </td></tr>
                <tr><td class="kmtd">   previous record    </td><td>   key-up             </td></tr>
                <tr><td class="kmtd">   page down          </td><td>   ctrl-p             </td></tr>
                <tr><td class="kmtd">   page up            </td><td>   ctrl-shift-p       </td></tr>
                <tr><td class="kmtd">   next block         </td><td>   shift-key-down     </td></tr>
                <tr><td class="kmtd">   previous block     </td><td>   shift-key-up       </td></tr>
                <tr><td class="kmtd">   enter query        </td><td>   ctrl-q             </td></tr>
                <tr><td class="kmtd">   execute query      </td><td>   ctrl-shift-q       </td ></tr>
            </table>

            <style>
              .kmtd
              {
                  width: 150px;
                  display: block;
              }
            </style>
        `;
    }
    ;
}

class WinKeyMap {
    constructor() {
        this.zoom = KeyMapper.map({ code: 90, ctrl: true });
        this.close = KeyMapper.map({ code: 87, ctrl: true });
        this.undo = KeyMapper.map({ code: 90, meta: true });
        this.paste = KeyMapper.map({ code: 86, ctrl: true });
        this.enter = KeyMapper.map({ code: KeyCodes.enter });
        this.escape = KeyMapper.map({ code: KeyCodes.escape });
        this.listval = KeyMapper.map({ code: KeyCodes.f9 });
        this.clearblock = KeyMapper.map({ code: KeyCodes.f5, shift: true });
        this.clearform = KeyMapper.map({ code: KeyCodes.f7, shift: true });
        this.insertafter = KeyMapper.map({ code: KeyCodes.insert });
        this.insertbefore = KeyMapper.map({ code: KeyCodes.insert, shift: true });
        this.dublicate = KeyMapper.map({ code: 86, ctrl: true });
        this.delete = KeyMapper.map({ code: KeyCodes.delete, ctrl: true });
        this.commit = KeyMapper.map({ code: KeyCodes.f10, ctrl: false, shift: false });
        this.rollback = KeyMapper.map({ code: KeyCodes.f10, ctrl: false, shift: true });
        this.connect = KeyMapper.map({ code: 67, ctrl: true });
        this.disconnect = KeyMapper.map({ code: 67, shift: true, ctrl: true });
        this.nextfield = KeyMapper.map({ code: KeyCodes.tab });
        this.prevfield = KeyMapper.map({ code: KeyCodes.tab, shift: true });
        this.nextrecord = KeyMapper.map({ code: KeyCodes.down, shift: false });
        this.prevrecord = KeyMapper.map({ code: KeyCodes.up, shift: false });
        this.prevblock = KeyMapper.map({ code: KeyCodes.pageup, shift: true });
        this.nextblock = KeyMapper.map({ code: KeyCodes.pagedown, shift: true });
        this.pageup = KeyMapper.map({ code: KeyCodes.pageup });
        this.pagedown = KeyMapper.map({ code: KeyCodes.pagedown });
        this.enterquery = KeyMapper.map({ code: KeyCodes.f7 });
        this.executequery = KeyMapper.map({ code: KeyCodes.f8 });
        this.map =
            `
            <table>
                <tr><td class="kmtd">   connect            </td><td>   ctrl-c             </td></tr>
                <tr><td class="kmtd">   disconnect         </td><td>   ctrl-shift-c       </td></tr>
                <tr><td class="kmtd">   close              </td><td>   ctrl-w             </td></tr>
                <tr><td class="kmtd">   zoom               </td><td>   ctrl-z             </td></tr>
                <tr><td class="kmtd">   datepicker         </td><td>   F9                 </td></tr>
                <tr><td class="kmtd">   list of values     </td><td>   F9                 </td></tr>
                <tr><td class="kmtd">   clear block        </td><td>   shift-F5           </td></tr>
                <tr><td class="kmtd">   clear form         </td><td>   shift-F7           </td></tr>
                <tr><td class="kmtd">   insert after       </td><td>   insert             </td></tr>
                <tr><td class="kmtd">   insert before      </td><td>   shift-insert       </td></tr>
                <tr><td class="kmtd">   delete             </td><td>   delete             </td></tr>
                <tr><td class="kmtd">   commit             </td><td>   F10                </td></tr>
                <tr><td class="kmtd">   rollback           </td><td>   shift-F10          </td></tr>
                <tr><td class="kmtd">   next record        </td><td>   key-down           </td></tr>
                <tr><td class="kmtd">   previous record    </td><td>   key-up             </td></tr>
                <tr><td class="kmtd">   page down          </td><td>   pagedown           </td></tr>
                <tr><td class="kmtd">   page up            </td><td>   pageup             </td></tr>
                <tr><td class="kmtd">   next block         </td><td>   shift-pagedown     </td></tr>
                <tr><td class="kmtd">   previous block     </td><td>   shift-pageup       </td></tr>
                <tr><td class="kmtd">   enter query        </td><td>   F7                 </td></tr>
                <tr><td class="kmtd">   execute query      </td><td>   F8                 </td ></tr>
            </table>

            <style>
              .kmtd
              {
                  width: 150px;
                  display: block;
              }
            </style>
        `;
    }
    ;
}

class defaultTheme {
    constructor() {
        this.name = "default";
        this.link = "blue";
        this.text = "black";
        this.title = "white";
        this.topbar = "#303f9f";
        this.enabled = "white";
        this.disabled = "silver";
        this.menuoption = "white";
        this.buttontext = "white";
        this.foldertree = "#303f9f";
        this.rowindicator = "#303f9f";
    }
}
class Indigo extends defaultTheme {
    constructor() {
        super(...arguments);
        this.name = "indigo";
    }
}
class Grey extends defaultTheme {
    constructor() {
        super(...arguments);
        this.name = "grey";
        this.link = "grey";
        this.topbar = "grey";
        this.foldertree = "grey";
        this.rowindicator = "grey";
    }
}
class Pink extends defaultTheme {
    constructor() {
        super(...arguments);
        this.name = "pink";
        this.link = "#ff4081";
        this.topbar = "#ff4081";
        this.foldertree = "#ff4081";
        this.rowindicator = "#ff4081";
    }
}
class Yellow {
    constructor() {
        this.name = "yellow";
        this.link = "grey";
        this.text = "black";
        this.title = "black";
        this.topbar = "yellow";
        this.foldertree = "grey";
        this.enabled = "black";
        this.disabled = "silver";
        this.menuoption = "black";
        this.buttontext = "black";
        this.rowindicator = "yellow";
    }
}

class Config {
    constructor(client) {
        this.client = client;
        this.config = null;
        this.notifications = [];
        this.invoker = null;
        this.caltitle = "Calendar";
        this.keymaphelp = "Shortkeys";
        this.themes = new Map();
        this.lang = Intl.DateTimeFormat().resolvedOptions().locale;
        this.load();
        this.themes.set("pink", new Pink());
        this.themes.set("grey", new Grey());
        this.themes.set("indigo", new Indigo());
        this.themes.set("yellow", new Yellow());
        this.themes.set("default", new defaultTheme());
        let os = this.os();
        if (os == "Windows")
            this.keymap = new WinKeyMap();
        else
            this.keymap = new MacKeyMap();
        KeyMapper.index(this.keymap);
        this.colors = this.themes.get("default");
    }
    os() {
        let os = "unknown";
        if (navigator.appVersion.indexOf("Mac") != -1)
            os = "MacOS";
        if (navigator.appVersion.indexOf("X11") != -1)
            os = "UNIX";
        if (navigator.appVersion.indexOf("Linux") != -1)
            os = "Linux";
        if (navigator.appVersion.indexOf("Win") != -1)
            os = "Windows";
        return (os);
    }
    load() {
        return __awaiter(this, void 0, void 0, function* () {
            this.invoker = this.client.get("/assets/config/config.json").toPromise();
            this.invoker.then(data => { this.loaded(data); }, error => { this.config = {}; console.log("Loading config failed: " + error); });
        });
    }
    loaded(config) {
        this.config = config;
        this.datefmt$ = this.config["datefmt"];
        dates.setFormat(this.datefmt$);
        if (this.config["locale"] != null)
            this.lang = this.config["locale"];
        if (this.config["calendar"] != null)
            this.caltitle = this.config["calendar"];
        if (this.config["keymap"] != null)
            this.keymaphelp = this.config["keymap"];
    }
    ready() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.invoker != null) {
                yield this.invoker;
                this.invoker = null;
            }
            return (true);
        });
    }
    get locale() {
        return (this.lang);
    }
    get datefmt() {
        return (this.datefmt$);
    }
    set colors(theme) {
        this.colors$ = theme;
    }
    get colors() {
        return (this.colors$);
    }
    get others() {
        return (this.config);
    }
    notify(instance, func) {
        this.notifications.push({ instance: instance, func: func });
    }
    setTheme(theme) {
        let ttheme = null;
        if (typeof theme == 'object')
            ttheme = theme;
        else
            ttheme = this.themes.get(theme);
        if (ttheme != null) {
            this.colors = ttheme;
            this.notifications.forEach((notify) => { notify.instance[notify.func](); });
        }
    }
    get keymapping() {
        return (this.keymap);
    }
    get keymaptitle() {
        return (this.keymaphelp);
    }
    get calendarname() {
        return (this.caltitle);
    }
}
Config.ɵprov = ɵɵdefineInjectable({ factory: function Config_Factory() { return new Config(ɵɵinject(HttpClient)); }, token: Config, providedIn: "root" });
Config.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] }
];
Config.ctorParameters = () => [
    { type: HttpClient }
];

class KeyMapHelp {
    constructor(ctx) {
        this.width = "300px";
        this.height = "475px";
        this.title = "ShortKeys";
        this.html = null;
        this.win = null;
        this.map = null;
        this.okbtn = null;
        this.title = ctx.conf.keymaptitle;
        this.html = ctx.conf.keymapping.map;
    }
    static show(app) {
        let pinst = new PopupInstance();
        pinst.display(app, KeyMapHelp);
    }
    close(_cancel) {
        this.win.closeWindow();
    }
    setWin(win) {
        this.win = win;
    }
    ngAfterViewInit() {
        var _a, _b;
        this.map = (_a = this.mapelem) === null || _a === void 0 ? void 0 : _a.nativeElement;
        this.okbtn = (_b = this.okelem) === null || _b === void 0 ? void 0 : _b.nativeElement;
        this.okbtn.addEventListener("keydown", () => this.close(true));
        this.okbtn.addEventListener("keypress", () => this.close(true));
        this.map.innerHTML = this.html;
        this.okbtn.focus();
    }
}
KeyMapHelp.decorators = [
    { type: Component, args: [{
                template: `
        <div #keymap></div>
        <button style="width: 100%; height: 1px" #ok></button>
    `
            },] }
];
KeyMapHelp.ctorParameters = () => [
    { type: Context }
];
KeyMapHelp.propDecorators = {
    okelem: [{ type: ViewChild, args: ["ok", { read: ElementRef },] }],
    mapelem: [{ type: ViewChild, args: ["keymap", { read: ElementRef },] }]
};

class Builder {
    constructor(resolver, injector, app) {
        this.resolver = resolver;
        this.injector = injector;
        this.app = app;
    }
    createComponent(component) {
        let cref = this.resolver.resolveComponentFactory(component).create(this.injector);
        return (cref);
    }
    getAppRef() {
        return (this.app);
    }
}
Builder.ɵprov = ɵɵdefineInjectable({ factory: function Builder_Factory() { return new Builder(ɵɵinject(ComponentFactoryResolver), ɵɵinject(INJECTOR), ɵɵinject(ApplicationRef)); }, token: Builder, providedIn: "root" });
Builder.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] }
];
Builder.ctorParameters = () => [
    { type: ComponentFactoryResolver },
    { type: Injector },
    { type: ApplicationRef }
];

class LoginForm extends Block {
    constructor(ctx) {
        super();
        this.top = "20%";
        this.left = "25%";
        this.width = "300px";
        this.height = "150px";
        this.tmargin = "20px";
        this.title = "Login";
        this.app = ctx.app["_impl_"];
        this.addKeyTrigger(this.onEvent, [
            keymap.enter,
            keymap.escape,
            keymap.nextfield,
            keymap.prevfield
        ]);
    }
    setWin(win) {
        this.win = win;
    }
    close(cancel) {
        var _a;
        this.app.enable();
        this.win.closeWindow();
        if (!cancel)
            this.app.appstate.connection.connect(this.usr.value, this.pwd.value);
        (_a = this.app.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.focus();
    }
    onEvent(kevent) {
        return __awaiter(this, void 0, void 0, function* () {
            if (kevent.key == keymap.enter)
                this.close(false);
            if (kevent.key == keymap.escape)
                this.close(true);
            if (kevent.key == keymap.nextfield && kevent.field == "usr") {
                kevent.event.preventDefault();
                this.pwd.focus();
            }
            if (kevent.key == keymap.nextfield && kevent.field == "pwd") {
                kevent.event.preventDefault();
                this.usr.focus();
            }
            if (kevent.key == keymap.prevfield && kevent.field == "usr") {
                kevent.event.preventDefault();
                this.pwd.focus();
            }
            if (kevent.key == keymap.prevfield && kevent.field == "pwd") {
                kevent.event.preventDefault();
                this.usr.focus();
            }
            return (true);
        });
    }
    ngOnInit() {
        this.app.disable();
        this.app.setContainer();
    }
    ngAfterViewInit() {
        let container = this.app.getContainer();
        container.finish();
        container.getBlock("").records.forEach((rec) => { this["_impl_"].addRecord(new Record(0, rec.fields, rec.index)); });
        this.usr = this["_impl_"].getField(0, "usr");
        this.pwd = this["_impl_"].getField(0, "pwd");
        let usr = { name: "usr", mandatory: true, type: FieldType.text };
        let pwd = { name: "pwd", mandatory: true, type: FieldType.password };
        this.usr.setDefinition(usr, true);
        this.pwd.setDefinition(pwd, true);
        this.usr.enable(false);
        this.pwd.enable(false);
        let field = document.getElementsByName("usr")[1];
        let width = (1.75 * field.offsetWidth + 10) + "px";
        let height = (4 * field.offsetHeight + 20) + "px";
        this.win.resize(width, height);
        this.usr.focus();
        this.app.dropContainer();
    }
}
LoginForm.decorators = [
    { type: Component, args: [{
                selector: '',
                template: `
        <table style='margin-top: "20px"; margin-right: "10px"'>
          <tr>
            <td>Username</td><td>: <field name='usr'></field> </td>
          </tr>
          <tr>
            <td>Password</td><td>: <field name='pwd'></field> </td>
          </tr>
        </table>
    `
            },] }
];
LoginForm.ctorParameters = () => [
    { type: Context }
];

class Wait {
    constructor() {
        this.input = null;
        this.canvas = null;
    }
    static show(app) {
        if (Wait.displayed)
            return;
        Wait.ready = false;
        Wait.displayed = true;
        Wait.win = app.builder.createComponent(Wait);
        let element = Wait.win.hostView.rootNodes[0];
        app.builder.getAppRef().attachView(Wait.win.hostView);
        document.body.appendChild(element);
        Wait.ready = true;
    }
    static waiting() {
        return (Wait.displayed);
    }
    static close(app) {
        if (!Wait.displayed)
            return;
        if (!Wait.ready) {
            setTimeout(() => { Wait.close(app); }, 1);
            return;
        }
        Wait.displayed = false;
        let element = Wait.win.hostView.rootNodes[0];
        document.body.removeChild(element);
        app.builder.getAppRef().detachView(Wait.win.hostView);
        Wait.win.destroy();
        app.getCurrentForm().focus();
    }
    ngAfterViewInit() {
        var _a, _b;
        this.input = (_a = this.inputElement) === null || _a === void 0 ? void 0 : _a.nativeElement;
        this.canvas = (_b = this.canvasElement) === null || _b === void 0 ? void 0 : _b.nativeElement;
        let ctx = this.canvas.getContext("2d");
        setTimeout(() => { this.focus(); }, 10);
        setTimeout(() => { this.showrunning(ctx, 0); }, 250);
    }
    focus() {
        if (!Wait.displayed)
            return;
        this.input.focus();
        setTimeout(() => { this.focus(); }, 100);
    }
    showrunning(ctx, pick) {
        if (!Wait.displayed)
            return;
        ctx.lineWidth = 5;
        let pcolor = "black";
        let bcolor = "#DCDCDC";
        pick = pick % 3;
        let rad = 6;
        let off = 64;
        ctx.beginPath();
        ctx.strokeStyle = bcolor;
        if (pick == 0)
            ctx.strokeStyle = pcolor;
        ctx.arc(rad + off, 2 * rad, rad, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.closePath();
        ctx.beginPath();
        ctx.strokeStyle = bcolor;
        if (pick == 1)
            ctx.strokeStyle = pcolor;
        ctx.arc(6 * rad + off, 2 * rad, rad, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.closePath();
        ctx.beginPath();
        ctx.strokeStyle = bcolor;
        if (pick == 2)
            ctx.strokeStyle = pcolor;
        ctx.arc(11 * rad + off, 2 * rad, rad, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.closePath();
        setTimeout(() => { this.showrunning(ctx, pick + 1); }, 250);
    }
}
Wait.ready = false;
Wait.displayed = false;
Wait.win = null;
Wait.decorators = [
    { type: Component, args: [{
                selector: '',
                template: `
                <div class="wait-modal">
                    <canvas #canvas class="wait-canvas" id="canvas"></canvas>
                    <input #input class="wait-input">
                </div>
              `,
                styles: [`
        .wait-input
        {
            width: 0;
            height: 0;
            opacity: 0;
            filter:alpha(opacity=0);
        }

        .wait-canvas
        {
            top: 25%;
            left: 40%;
            width: 320px;
            height: 160px;
            position: fixed;
        }

        .wait-modal
        {
            top: 0;
            left: 0;
            z-index: 1;
            opacity: 1;
            width: 100%;
            height: 100%;
            display: block;
            overflow: auto;
            position: fixed;
            box-shadow: inset 0px 0px 400px 110px rgba(0, 0, 0, .2);
        }
        `]
            },] }
];
Wait.propDecorators = {
    inputElement: [{ type: ViewChild, args: ["input", { read: ElementRef },] }],
    canvasElement: [{ type: ViewChild, args: ["canvas", { read: ElementRef },] }]
};

class MenuInterface {
    constructor(menu) {
        this.menu$ = menu;
        this.app$ = this.menu$.getApplication()["_impl_"];
    }
    get app() {
        return (this.app$.getApplication());
    }
    isConnected() {
        return (this.app$.connected);
    }
    enable(menu) {
        this.menu$.enable(menu);
    }
    disable(menu) {
        this.menu$.disable(menu);
    }
}

class DropDownMenu {
    constructor(ctx) {
        this.ctx = ctx;
        this.options = new Map();
        this.menus = new Map();
        this.conf = ctx.conf;
        this.app$ = ctx.app["_impl_"]; // might not be initialized
        this.instance = "DropDownMenu-" + (DropDownMenu.instances++);
    }
    static setForm(inst, form) {
        if (inst.instance.getMenu() == null) {
            if (DropDownMenu.calls++ > 10)
                return;
            setTimeout(() => { DropDownMenu.setForm(inst, form); }, 10);
            return;
        }
        inst.instance.getMenu().getHandler().onFormChange(form);
    }
    getMenu() {
        return (this.menu);
    }
    getApplication() {
        return (this.app$.getApplication());
    }
    enable(menu) {
        if (menu == null) {
            this.menus.forEach((mopt) => {
                mopt.elem.classList.remove("ddmenu-disabled");
                mopt.options.forEach((opt) => { opt.elem.children[0].classList.remove("ddmenu-disabled"); });
            });
            return;
        }
        menu = menu.toLowerCase();
        let mopt = this.menus.get(menu);
        if (mopt != null) {
            mopt.elem.classList.remove("ddmenu-disabled");
            mopt.options.forEach((opt) => { opt.elem.children[0].classList.remove("ddmenu-disabled"); });
            return;
        }
        let option = menu;
        mopt = this.menus.get(menu.substring(0, menu.lastIndexOf("/")));
        if (mopt == null)
            return;
        let enabled = 0;
        mopt.options.forEach((opt) => {
            if (opt.elem.id == option)
                opt.elem.children[0].classList.remove("ddmenu-disabled");
            if (!opt.elem.children[0].classList.contains("ddmenu-disabled"))
                enabled++;
        });
        if (enabled > 0)
            mopt.elem.classList.remove("ddmenu-disabled");
    }
    disable(menu) {
        if (menu == null) {
            this.menus.forEach((mopt) => {
                mopt.elem.classList.add("ddmenu-disabled");
                mopt.options.forEach((opt) => { opt.elem.children[0].classList.add("ddmenu-disabled"); });
            });
            return;
        }
        menu = menu.toLowerCase();
        let mopt = this.menus.get(menu);
        if (mopt != null) {
            mopt.elem.classList.add("ddmenu-disabled");
            mopt.options.forEach((opt) => { opt.elem.children[0].classList.add("ddmenu-disabled"); });
            return;
        }
        let option = menu;
        mopt = this.menus.get(menu.substring(0, menu.lastIndexOf("/")));
        if (mopt == null)
            return;
        let enabled = 0;
        mopt.options.forEach((opt) => {
            if (opt.elem.id == option)
                opt.elem.children[0].classList.add("ddmenu-disabled");
            if (!opt.elem.children[0].classList.contains("ddmenu-disabled"))
                enabled++;
        });
        if (enabled == 0)
            mopt.elem.classList.add("ddmenu-disabled");
    }
    display(menu) {
        if (menu == null)
            return;
        if (this.html == null) {
            setTimeout(() => { this.display(menu); }, 10);
            return;
        }
        this.app$ = this.ctx.app["_impl_"];
        this.menu = menu;
        let intf = new MenuInterface(this);
        menu.getHandler()["__menu__"] = intf;
        this.menu = menu;
        this.html.innerHTML = this.menuhtml();
        let menus = this.html.getElementsByClassName("ddmenu-menu");
        let options = this.html.getElementsByClassName("ddmenu-option");
        for (let i = 0; i < menus.length; i++) {
            let mopt = new MenuOption(menus[i].children[0]);
            this.menus.set(mopt.elem.id, mopt);
            mopt.elem.classList.add("ddmenu-default");
            mopt.elem.classList.add("ddmenu-disabled");
            mopt.elem.addEventListener("click", (event) => { this.toggle(event); });
        }
        for (let i = 0; i < options.length; i++) {
            let id = options[i].id;
            let menu = id.substring(0, id.lastIndexOf("/"));
            let opt = this.options.get(id);
            options[i].children[0].classList.add("ddmenu-disabled");
            options[i].addEventListener("click", (event) => { this.action(event); });
            opt.elem = options[i];
            let mopt = this.menus.get(menu);
            mopt.options.push(opt);
        }
        menu.getHandler().onInit();
    }
    onEvent(event) {
        if (!event.target.matches('.ddmenu-entry')) {
            this.closeall();
            WindowListener.remove(this.instance, "click");
        }
    }
    action(event) {
        let handler = this.menu.getHandler();
        let link = null;
        let text = event.target;
        if (text.classList.contains("ddmenu-linktext")) {
            link = text.parentElement;
        }
        else {
            link = text;
            text = text.children[0];
        }
        if (text.classList.contains("ddmenu-disabled"))
            return;
        let opt = this.options.get(link.id);
        if (opt.option.action != null)
            handler[opt.option.action]();
    }
    toggle(event) {
        let menu = event.target;
        let container = menu.parentNode.children[1];
        if (menu.classList.contains("ddmenu-disabled"))
            return;
        container.classList.toggle("ddmenu-show");
        if (container.classList.contains("ddmenu-show")) {
            this.closeall(container);
            WindowListener.add(this.instance, this, "click");
        }
        else {
            container.classList.remove("ddmenu-show");
        }
    }
    closeall(except) {
        let open = this.html.getElementsByClassName("ddmenu-show");
        for (let i = 0; i < open.length; i++) {
            if (except == null || open[i].id != except.id)
                open[i].classList.remove("ddmenu-show");
        }
    }
    menuhtml() {
        let html = "";
        html += "<style>\n";
        html += this.styles() + "\n";
        html += "</style>\n";
        html += "<span class='ddmenu-bar'>\n";
        html += this.entries("", "", this.menu.getEntries());
        html += "</span>\n";
        return (html);
    }
    entries(indent, path, entries) {
        let html = "";
        for (let i = 0; i < entries.length; i++) {
            let id = path + "/" + entries[i].name.toLowerCase();
            html += indent + "<div class='ddmenu-menu'>\n";
            html += indent + "  <button class='ddmenu-entry' id='" + id + "'>\n";
            html += indent + entries[i].name;
            html += indent + "  </button>\n";
            html += indent + "  <div class='ddmenu-content' id='" + id + "-content'>\n";
            if (entries[i].options != null) {
                for (let f = 0; f < entries[i].options.length; f++) {
                    let entry = entries[i].options[f];
                    let oid = id + "/" + entry.name.toLowerCase();
                    this.options.set(oid, new Option(entries[i].options[f]));
                    html += indent + "    <a class='ddmenu-option' id='" + oid + "'>\n";
                    html += indent + "      <span class='ddmenu-linktext'>" + entry.name + "</span>\n";
                    html += indent + "    </a>\n";
                }
            }
            html += indent + "  </div>\n";
            html += indent + "</div>\n";
        }
        return (html);
    }
    styles() {
        let style = `
            .ddmenu-bar
            {
                width: 100%;
                height: 100%;
                display: flex;
                position: relative;
                white-space: nowrap;
                background: transparent;
            }

            .ddmenu-entry
            {
                padding: 0;
                border: none;
                color: ` + this.conf.colors.menuoption + `;
                outline:none;
                cursor: pointer;
                font-size: 15px;
                margin-top: 1px;
                margin-left: 4px;
                margin-right: 4px;
                margin-bottom: 1px;
                background: transparent;
            }

            .ddmenu-default
            {
                color: ` + this.conf.colors.enabled + `;
            }

            .ddmenu-disabled
            {
                color: ` + this.conf.colors.disabled + `;
            }

            .ddmenu-menu
            {
                position: relative;
                display: inline-block;
            }

            .ddmenu-content
            {
                z-index: 1;
                display: none;
                overflow: none;
                min-width: 80px;
                position: absolute;
                background-color: #f1f1f1;
                color: ` + this.conf.colors.menuoption + `;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            }

            .ddmenu-option
            {
                border: none;
                color: black;
                outline:none;
                cursor: pointer;
                font-size: 15px;
                background: transparent;
            }

            .ddmenu-content .ddmenu-option
            {
                color: black;
                display: block;
                padding: 12px 16px;
                text-decoration: none;
            }

            .ddmenu-content .ddmenu-option:hover
            {
                background-color: #ddd;
            }

            .ddmenu-show
            {
                display: block;
            }
        `;
        return (style);
    }
    ngAfterViewInit() {
        var _a;
        this.html = (_a = this.elem) === null || _a === void 0 ? void 0 : _a.nativeElement;
    }
}
DropDownMenu.instances = 0;
DropDownMenu.calls = 0;
DropDownMenu.decorators = [
    { type: Component, args: [{
                selector: '',
                template: '<div #html></div>'
            },] }
];
DropDownMenu.ctorParameters = () => [
    { type: Context }
];
DropDownMenu.propDecorators = {
    elem: [{ type: ViewChild, args: ["html", { read: ElementRef },] }]
};
class MenuOption {
    constructor(elem) {
        this.options = [];
        this.elem = elem;
    }
}
class Option {
    constructor(option) {
        this.option = option;
    }
}

class MenuFactory {
    constructor(builder) {
        this.builder = builder;
    }
    create(menu) {
        let ref = this.builder.createComponent(DropDownMenu);
        ref.instance.display(menu);
        return (ref);
    }
}

class FormUtil {
    constructor() {
        this.utils = new Utils();
    }
    complete(options, create) {
        if (options == null) {
            if (create)
                options = {};
            else
                return (null);
        }
        if (!options.hasOwnProperty("wizard"))
            options.wizard = false;
        if (!options.hasOwnProperty("inherit"))
            options.inherit = true;
        if (!options.hasOwnProperty("width"))
            options.width = "99.65vw";
        if (!options.hasOwnProperty("height"))
            options.height = "99.5vh";
        if (!options.hasOwnProperty("offsetTop"))
            options.offsetTop = "0";
        if (!options.hasOwnProperty("offsetLeft"))
            options.offsetLeft = "0";
        return (options);
    }
    convert(form) {
        let fname = this.utils.getName(form.component);
        let navigable = true;
        form.windowopts = this.complete(form.windowopts);
        if (form.hasOwnProperty("navigable"))
            navigable = form.navigable;
        let path = "/" + fname;
        if (form.hasOwnProperty("path"))
            path = form.path;
        path = path.trim();
        if (!path.startsWith("/"))
            path = "/" + path;
        let def = {
            name: fname,
            path: form.path,
            title: form.title,
            navigable: navigable,
            component: form.component,
            windowdef: form.windowopts
        };
        return (def);
    }
    clone(base) {
        let clone = {
            name: base.name,
            path: base.path,
            title: base.title,
            windowdef: base.windowdef,
            windowopts: base.windowdef,
            component: base.component,
            navigable: base.navigable
        };
        return (clone);
    }
}

class ModalWindow {
    constructor(ctx, change) {
        this.change = change;
        this.top = null;
        this.left = null;
        this.width = "99vw";
        this.height = "98vh";
        this.tmargin = "1vh";
        this.minw = 0;
        this.minh = 0;
        this.offx = 0;
        this.offy = 0;
        this.move = false;
        this.resz = false;
        this.resizex = false;
        this.resizey = false;
        this.conf = ctx.conf;
    }
    get tcolor() {
        return (this.conf.colors.title);
    }
    get bcolor() {
        return (this.conf.colors.topbar);
    }
    get btncolor() {
        return (this.conf.colors.menuoption);
    }
    setForm(form) {
        this.resize(form, true);
        let impl = form.formref.instance["_impl_"];
        impl.setModalWindow(this);
        this.form = form;
    }
    getForm() {
        return (this.form.formref.instance);
    }
    newForm(form) {
        var _a;
        if (!((_a = form.windowopts) === null || _a === void 0 ? void 0 : _a.inherit))
            this.resize(form, false);
        let formelem = this.content.firstElementChild;
        if (formelem != null)
            this.content.removeChild(formelem);
        this.app.builder.getAppRef().detachView(this.form.formref.hostView);
        if (this.menuelem != null) {
            let menuelem = this.menu.firstElementChild;
            if (menuelem != null)
                this.menu.removeChild(this.menuelem);
            this.app.builder.getAppRef().detachView(this.menuref.hostView);
        }
        let impl = form.formref.instance["_impl_"];
        impl.setModalWindow(this);
        this.form = form;
        this.display();
    }
    setWinRef(winref) {
        this.winref = winref;
    }
    setApplication(app) {
        this.app = app;
    }
    close() {
        let impl = this.form.formref.instance["_impl_"];
        this.closeWindow();
        impl.cancel();
    }
    closeWindow() {
        WindowListener.remove("modal", "mouseup");
        WindowListener.remove("modal", "mousemove");
        WindowListener.remove("modal", "mousedown");
        let formelem = this.content.firstElementChild;
        if (formelem != null)
            this.content.removeChild(formelem);
        this.app.builder.getAppRef().detachView(this.form.formref.hostView);
        let element = this.winref.hostView.rootNodes[0];
        document.body.removeChild(element);
        this.app.builder.getAppRef().detachView(this.winref.hostView);
        this.winref.destroy();
        this.winref = null;
    }
    resize(form, pos) {
        if (form.windowopts.offsetLeft != null && form.windowopts.offsetLeft.trim().endsWith("%")) {
            let s = form.windowopts.offsetLeft.trim();
            let n = +s.substring(0, s.length - 1);
            form.windowopts.offsetLeft = (window.innerWidth * n / 100) + "px";
        }
        if (form.windowopts.width != null && form.windowopts.width.trim().endsWith("%")) {
            let s = form.windowopts.width.trim();
            let n = +s.substring(0, s.length - 1);
            form.windowopts.width = (window.innerWidth * n / 100) + "px";
        }
        if (form.windowopts.offsetTop != null && form.windowopts.offsetTop.trim().endsWith("%")) {
            let s = form.windowopts.offsetTop.trim();
            let n = +s.substring(0, s.length - 1);
            form.windowopts.offsetTop = (window.innerHeight * n / 100) + "px";
        }
        if (form.windowopts.height != null && form.windowopts.height.trim().endsWith("%")) {
            let s = form.windowopts.height.trim();
            let n = +s.substring(0, s.length - 1);
            form.windowopts.height = (window.innerHeight * n / 100) + "px";
        }
        if (pos) {
            this.top = form.windowopts.offsetTop;
            this.left = form.windowopts.offsetLeft;
            if (this.top == "undefined")
                this.top = null;
            if (this.left == "undefined")
                this.left = null;
        }
        this.width = form.windowopts.width;
        this.height = form.windowopts.height;
        if (form.windowopts.width == "") {
            this.left = "0";
            this.width = "100%";
        }
        if (form.windowopts.height == "") {
            this.top = "0";
            this.height = "100%";
        }
        this.change.detectChanges();
    }
    display() {
        if (this.form == null) {
            setTimeout(() => { this.display(); }, 10);
            return;
        }
        this.element = this.form.formref.hostView.rootNodes[0];
        this.app.builder.getAppRef().attachView(this.form.formref.hostView);
        this.content.appendChild(this.element);
        this.minh = 100;
        this.minw = 450;
        this.showmenu();
        this.change.detectChanges();
        this.posy = this.window.offsetTop;
        this.posx = this.window.offsetLeft;
        this.sizex = this.window.offsetWidth;
        this.sizey = this.window.offsetHeight;
        let resize = false;
        if (this.sizex < this.minw) {
            resize = true;
            this.sizex = this.minw;
            this.width = this.sizex + "px";
        }
        if (this.sizey < this.minh) {
            resize = true;
            this.sizey = this.minh;
            this.height = this.sizey + "px";
        }
        if (this.top == null || this.top.trim().length == 0) {
            resize = true;
            this.top = ((+window.innerHeight - this.sizey) / 3) + "px";
        }
        if (this.left == null || this.left.trim().length == 0) {
            resize = true;
            this.left = ((+window.innerWidth - this.sizex) / 3) + "px";
        }
        if (resize) {
            this.change.detectChanges();
            this.posy = this.window.offsetTop;
            this.posx = this.window.offsetLeft;
            this.sizex = this.window.offsetWidth;
            this.sizey = this.window.offsetHeight;
        }
    }
    showmenu() {
        let impl = this.form.formref.instance["_impl_"];
        this.menuelem = null;
        this.menuref = impl.getDropDownMenu();
        if (this.menuref == null)
            return;
        this.menuelem = this.menuref.hostView.rootNodes[0];
        this.app.builder.getAppRef().attachView(this.menuref.hostView);
        this.menu.appendChild(this.menuelem);
        let ddmenu = this.menuref.instance;
        this.initmenu(ddmenu);
    }
    initmenu(ddmenu) {
        if (ddmenu.getMenu() == null) {
            setTimeout(() => { this.initmenu(ddmenu); }, 10);
            return;
        }
        let impl = this.form.formref.instance["_impl_"];
        ddmenu.getMenu().getHandler().onFormChange(impl.form);
        this.minw = this.menu.clientWidth + 50;
        if (this.sizex < this.minw) {
            this.sizex = this.minw;
            this.width = this.sizex + "px";
            this.change.detectChanges();
        }
    }
    ngAfterViewInit() {
        var _a, _b, _c, _d;
        this.menu = (_a = this.menuElement) === null || _a === void 0 ? void 0 : _a.nativeElement;
        this.window = (_b = this.windowElement) === null || _b === void 0 ? void 0 : _b.nativeElement;
        this.topbar = (_c = this.topbarElement) === null || _c === void 0 ? void 0 : _c.nativeElement;
        this.content = (_d = this.contentElement) === null || _d === void 0 ? void 0 : _d.nativeElement;
        this.display();
        WindowListener.add("modal", this, "mouseup");
        WindowListener.add("modal", this, "mousemove");
        WindowListener.add("modal", this, "mousedown");
        this.topbar.addEventListener("mousedown", (event) => { this.startmove(event); });
    }
    onEvent(event) {
        switch (event.type) {
            case "mouseup":
                this.mouseup();
                break;
            case "mousemove":
                this.movePopup(event);
                this.resizePopup(event);
                this.resizemousemove(event);
                break;
            case "mousedown":
                this.startresize(event);
                break;
        }
    }
    startmove(event) {
        if (this.resizexy)
            return;
        this.move = true;
        event = event || window.event;
        event.preventDefault();
        this.offy = +event.clientY - this.posy;
        this.offx = +event.clientX - this.posx;
    }
    mouseup() {
        if (!this.move && !this.resz)
            return;
        this.move = false;
        this.resz = false;
        this.resizexy = false;
        this.window.style.cursor = "default";
        document.body.style.cursor = "default";
    }
    movePopup(event) {
        if (!this.move)
            return;
        event = event || window.event;
        let deltay = +event.clientY - this.posy;
        let deltax = +event.clientX - this.posx;
        this.posy += (deltay - this.offy);
        this.posx += (deltax - this.offx);
        if (this.posy > 0)
            this.top = this.posy + "px";
        if (this.posx > 0)
            this.left = this.posx + "px";
        this.change.detectChanges();
    }
    resizemousemove(event) {
        if (this.resz)
            return;
        event = event || window.event;
        let posx = +event.clientX;
        let posy = +event.clientY;
        let offx = this.posx + this.sizex - posx;
        let offy = this.posy + this.sizey - posy;
        let before = false;
        if (this.resizex || this.resizey)
            before = true;
        this.resizex = false;
        this.resizey = false;
        if (offx > -7 && offx < 10 && posy > this.posy - 7 && posy < this.posy + this.sizey + 7)
            this.resizex = true;
        if (offy > -7 && offy < 10 && posx > this.posx - 7 && posx < this.posx + this.sizex + 7)
            this.resizey = true;
        if (this.resizex && this.resizey) {
            this.resizex = true;
            this.resizey = true;
        }
        if (this.resizex && !this.resizey) {
            this.window.style.cursor = "e-resize";
            document.body.style.cursor = "e-resize";
        }
        if (this.resizey && !this.resizex) {
            this.window.style.cursor = "s-resize";
            document.body.style.cursor = "s-resize";
        }
        if (this.resizex && this.resizey) {
            this.window.style.cursor = "se-resize";
            document.body.style.cursor = "se-resize";
        }
        if (before && !this.resizexy) {
            this.window.style.cursor = "default";
            document.body.style.cursor = "default";
        }
    }
    startresize(event) {
        if (!this.resizexy)
            return;
        this.resz = true;
        event = event || window.event;
        event.preventDefault();
        this.offy = +event.clientY;
        this.offx = +event.clientX;
    }
    resizePopup(event) {
        if (!this.resz)
            return;
        event = event || window.event;
        let deltay = +event.clientY - this.offy;
        let deltax = +event.clientX - this.offx;
        if (this.resizex && (this.sizex > this.minw || deltax > 0)) {
            this.sizex += deltax;
            this.width = this.sizex + "px";
        }
        if (this.resizey && (this.sizey > this.minh || deltay > 0)) {
            this.sizey += deltay;
            this.height = this.sizey + "px";
        }
        this.offy = +event.clientY;
        this.offx = +event.clientX;
        this.change.detectChanges();
    }
    get resizexy() {
        if (this.resizex || this.resizey)
            return (true);
        return (false);
    }
    set resizexy(on) {
        this.resizex = on;
        this.resizey = on;
    }
}
ModalWindow.decorators = [
    { type: Component, args: [{
                selector: 'modalwindow',
                template: `
    <div class="modalwindow">
      <div #window class="modalwindow-modal-block" style="top: {{top}}; left: {{left}}">
        <div class="modalwindow-container" style="width: {{width}}; height: {{height}};">
		  <div #topbar class="modalwindow-topbar" style="color: {{tcolor}}; background-color: {{bcolor}}">
		    <span class="modalwindow-center" style="color: {{tcolor}};">
				<span class="modalwindow-corner"></span>
				<div #menu></div>
				<span class="modalwindow-close">
					<button class="modalwindow-button" style="color: {{btncolor}};" (click)="close()">X</button>
				</span>
			</span>
		  </div>
          <div class="modalwindow-block" style="margin-top: {{tmargin}};"><div #content></div></div>
        </div>
      </div>
    </div>
  `,
                changeDetection: ChangeDetectionStrategy.OnPush,
                styles: [`
    .modalwindow
    {
        top: 0;
        left: 0;
        z-index: 1;
        width: 100%;
        height: 100%;
        display: block;
        overflow: auto;
        position: fixed;
    }

    .modalwindow-modal-block
    {
      position: absolute;
      background-color: #fefefe;
    }

    .modalwindow-container
    {
        position: relative;
        border: 2px solid black;
    }

    .modalwindow-topbar
    {
        height: 1.70em;
        margin-left: 0;
        margin-right: 0;
        cursor:default;
		justify-content: center;
        border-bottom: 2px solid black;
    }

	.modalwindow-corner
	{
		width: 2.5em;
		display: block;
		position: relative;
	}

	.modalwindow-close
	{
		top: 0;
		right: 0;
		width: 1.75em;
		height: 1.70em;
		position: absolute;
		border-left: 1px solid black;
	}

	.modalwindow-button
	{
		top: 50%;
		width: 100%;
		height: 100%;
		outline:none;
		font-size: 0.75em;
		font-weight: bold;
		position: relative;
		background: transparent;
		transform: translateY(-50%);
		border: 0px solid transparent;
		box-shadow: 0px 0px 0px transparent;
		text-shadow: 0px 0px 0px transparent;
	}

	.modalwindow-center
	{
		top: 0;
		bottom: 0;
		width: 93%;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
	}

    .modalwindow-block
    {
        left: 0;
        top: 3vh;
        right: 0;
        bottom: 0;
		display: flex;
        overflow: auto;
        position: absolute;
		justify-content: center;
    }
`]
            },] }
];
ModalWindow.ctorParameters = () => [
    { type: Context },
    { type: ChangeDetectorRef }
];
ModalWindow.propDecorators = {
    menuElement: [{ type: ViewChild, args: ["menu", { read: ElementRef },] }],
    windowElement: [{ type: ViewChild, args: ["window", { read: ElementRef },] }],
    topbarElement: [{ type: ViewChild, args: ["topbar", { read: ElementRef },] }],
    contentElement: [{ type: ViewChild, args: ['content', { read: ElementRef },] }]
};

class FormsControl {
    constructor(app, builder) {
        this.app = app;
        this.builder = builder;
        this.utils = new Utils();
        this.formlist = [];
        this.forms = new Map();
    }
    setFormArea(formarea) {
        this.formarea = formarea;
    }
    setFormsDefinitions(forms) {
        let futil = new FormUtil();
        for (let i = 0; i < forms.length; i++) {
            let form = forms[i];
            let def = futil.convert(form);
            this.formlist.push(def);
            this.forms.set(def.name, def);
        }
        return (this.forms);
    }
    findFormByPath(path) {
        for (let i = 0; i < this.formlist.length; i++) {
            if (this.formlist[i].path == path)
                return (this.formlist[i].name);
        }
        return (null);
    }
    getFormsList() {
        return (this.formlist);
    }
    getFormsDefinitions() {
        return (this.forms);
    }
    closeform(form, destroy) {
        let name = this.utils.getName(form);
        let formdef = this.forms.get(name);
        if (formdef == null || formdef.formref == null)
            return;
        this.close(formdef, destroy);
    }
    close(formdef, destroy) {
        if (formdef.formref == null)
            return;
        let formsarea = this.formarea.getFormsArea();
        let element = formdef.formref.hostView.rootNodes[0];
        if (this.current != null && this.current.element == element) {
            this.current = null;
            formsarea.removeChild(element);
            this.builder.getAppRef().detachView(formdef.formref.hostView);
        }
        if (destroy) {
            formdef.formref.destroy();
            formdef.windowopts = null;
            formdef.formref = null;
        }
    }
    display(formdef) {
        if (formdef == null || formdef.formref == null)
            return;
        let formsarea = this.formarea.getFormsArea();
        let element = formdef.formref.hostView.rootNodes[0];
        let impl = formdef.formref.instance["_impl_"];
        if (formdef.windowopts == null) {
            this.current = { formdef: formdef, element: element };
            this.builder.getAppRef().attachView(formdef.formref.hostView);
            formsarea.appendChild(element);
        }
        else {
            let id = {
                impl: impl,
                ref: formdef.formref,
                name: formdef.name,
                modalopts: formdef.windowopts
            };
            impl.setInstanceID(id);
            let win = this.createWindow();
            win.setForm(formdef);
            win.setApplication(this.app);
        }
    }
    createWindow() {
        let winref = this.app.builder.createComponent(ModalWindow);
        let win = winref.instance;
        win.setWinRef(winref);
        let element = winref.hostView.rootNodes[0];
        this.builder.getAppRef().attachView(winref.hostView);
        document.body.appendChild(element);
        return (win);
    }
    getFormInstance(form) {
        let name = this.utils.getName(form);
        let formdef = this.forms.get(name);
        if (formdef == null)
            return (null);
        if (formdef.formref == null) {
            formdef.formref = this.createForm(formdef.component);
            if (formdef.windowdef != null && formdef.windowdef.wizard)
                formdef.windowopts = formdef.windowdef;
        }
        return (formdef);
    }
    createForm(component) {
        let ref = this.builder.createComponent(component);
        if (!(ref.instance instanceof Form)) {
            let name = ref.instance.constructor.name;
            console.log("Component " + name + " is not an instance of Form");
            return;
        }
        let impl = ref.instance["_impl_"];
        impl.setApplication(this.app);
        return (ref);
    }
}

class Connection {
    constructor(app) {
        this.app = app;
        this.url = null;
        this.conn = null;
        this.keepalive = 0;
        this.client = null;
        this.stmtid = 0;
        this.waitlim = 250;
        this.running = new Map();
        this.client = app.client;
    }
    connect(usr, pwd) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.url == null) {
                yield this.app.config.ready();
                let conf = yield this.app.config.others;
                this.url = conf["database.js"];
                if (this.url == null || this.url.length == 0)
                    this.url = window.location.origin;
            }
            if (this.conn != null) {
                this.alert("Already logged on");
                return;
            }
            if (usr == null || pwd == null) {
                this.alert("Username and password must be specified to logon");
                return;
            }
            let credentials = { usr: usr, pwd: pwd };
            let response = yield this.invoke("connect", credentials);
            if (response["status"] == "failed") {
                this.alert(response["message"]);
                return;
            }
            this.conn = response["id"];
            ;
            this.keepalive = response["keep-alive"];
            this.app.appstate.onConnect();
            this.keepAlive();
            return (response);
        });
    }
    commit() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.conn != null) {
                let response = yield this.invoke("commit", {});
                if (response["status"] != "ok")
                    this.alert(JSON.stringify(response));
                this.app.appstate.transactionChange(false);
                return (false);
            }
            return (true);
        });
    }
    rollback() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.conn != null) {
                let response = yield this.invoke("rollback", {});
                if (response["status"] != "ok") {
                    this.alert(JSON.stringify(response));
                    return (false);
                }
                this.app.appstate.transactionChange(false);
                return (false);
            }
            return (true);
        });
    }
    get connected() {
        return (this.conn != null);
    }
    disconnect() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.conn == null) {
                this.alert("not logged on");
                return;
            }
            let response = yield this.invoke("disconnect", {});
            if (response["status"] != "ok")
                this.alert(JSON.stringify(response));
            this.conn = null;
            this.keepalive = 0;
            this.app.appstate.transactionChange(false);
            this.app.appstate.onDisconnect();
        });
    }
    keepAlive() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.conn != null && +this.keepalive > 0) {
                let response = null;
                let body = { "keep-alive": true };
                yield this.client.post(this.url + "/" + this.conn + "/ping", body).toPromise().then(data => { response = data; }, error => { response = error; });
                if (response["status"] != "ok") {
                    this.keepalive = 0;
                    this.alert(JSON.stringify(response), "KeepAlive stopped");
                }
                setTimeout(() => { this.keepAlive(); }, this.keepalive * 1000);
            }
        });
    }
    invokestmt(stmt) {
        return __awaiter(this, void 0, void 0, function* () {
            return (this.invoke(SQLType[stmt.type], stmt.build()));
        });
    }
    invoke(cmd, body) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = this.url + "/";
            if (this.conn != null)
                url = url + this.conn + "/";
            if (this.conn == null && cmd != "connect")
                return ({ status: "failed", message: "Not logged on" });
            if (cmd == "lock" || cmd == "insert" || cmd == "update" || cmd == "delete")
                this.app.appstate.transactionChange(true);
            let stid = this.stmtid++;
            let start = new Date().getTime();
            this.running.set(stid, start);
            setTimeout(() => { this.showwait(); }, +this.waitlim + +10);
            return (this.client.post(url + cmd, body).toPromise().then(data => { return (this.onReply(stid, data)); }, error => { return (this.onReply(stid, error)); }));
        });
    }
    onReply(stid, data) {
        let response = null;
        this.running.delete(stid);
        this.showwait();
        if (!(data instanceof HttpErrorResponse))
            response = data;
        else
            response = { status: "failed", error: "500", message: JSON.stringify(data.message) };
        return (response);
    }
    alert(msg, title) {
        if (title == null)
            title = "Database Call Failed";
        MessageBox.show(this.app, msg, title);
    }
    showwait() {
        let now = new Date().getTime();
        let min = now;
        this.running.forEach((start) => {
            if (+start < +min)
                min = start;
        });
        let show = false;
        if (now - min > +this.waitlim)
            show = true;
        if (show)
            Wait.show(this.app);
        else
            Wait.close(this.app);
    }
}

class ApplicationState {
    constructor(app) {
        this.app = app;
        this.menu = null;
        this.form = null;
        this.transaction = false;
        this.appmenu = null;
        this.forms = new Map();
        this.menus = new Map();
        this.menu = new DefaultMenu();
        this.connection = new Connection(app);
    }
    addForm(form) {
        this.forms.set(form.guid, form);
    }
    dropForm(form) {
        this.forms.delete(form.guid);
    }
    addMenu(menu) {
        let mhdl = menu.getHandler();
        this.menus.set(mhdl.guid, mhdl);
    }
    dropMenu(menu) {
        if (menu != null) {
            let mhdl = menu.getHandler();
            this.menus.delete(mhdl.guid);
        }
    }
    clearAllForms() {
        return __awaiter(this, void 0, void 0, function* () {
            this.forms.forEach((form) => { form.clear(); });
        });
    }
    onConnect() {
        return __awaiter(this, void 0, void 0, function* () {
            this.menus.forEach((mhdl) => { mhdl.onConnect(); });
            let forms = [];
            this.forms.forEach((form) => __awaiter(this, void 0, void 0, function* () { forms.push(form); }));
            for (let f = 0; f < forms.length; f++) {
                let funcs = FormDefinitions.getOnConnect(forms[f].name);
                for (let i = 0; i < funcs.length; i++)
                    yield this.app.execfunc(forms[f], funcs[i]);
            }
            return (true);
        });
    }
    transactionChange(trans) {
        if (!trans)
            this.forms.forEach((form) => { form.onCommit(); });
        if (trans + "" != this.transaction + "") {
            this.transaction = trans;
            this.menus.forEach((mhdl) => { mhdl.onTransactionChange(); });
        }
    }
    onDisconnect() {
        return __awaiter(this, void 0, void 0, function* () {
            this.menus.forEach((mhdl) => { mhdl.onDisconnect(); });
            let forms = [];
            this.forms.forEach((form) => __awaiter(this, void 0, void 0, function* () { forms.push(form); }));
            for (let f = 0; f < forms.length; f++) {
                let funcs = FormDefinitions.getOnDisconnect(forms[f].name);
                for (let i = 0; i < funcs.length; i++)
                    yield this.app.execfunc(forms[f], funcs[i]);
            }
            return (true);
        });
    }
    get connected() {
        return (this.connection.connected);
    }
    alert(message, title, width, height) {
        MessageBox.show(this.app, message, title, width, height);
    }
}

class InstanceControl {
    constructor(ctrl) {
        this.ctrl = ctrl;
        this.utils = new Utils();
        this.futil = new FormUtil();
    }
    setFormsDefinitions(forms) {
        this.forms = forms;
    }
    getNewInstance(form, modal) {
        let name = this.utils.getName(form);
        if (name == null)
            return (null);
        let def = this.forms.get(name);
        if (def == null)
            return (null);
        let ref = this.ctrl.createForm(def.component);
        if (ref == null)
            return (null);
        let impl = ref.instance["_impl_"];
        if (modal == null)
            modal = def.windowdef;
        modal = this.futil.complete(modal, true);
        let id = {
            ref: ref,
            impl: impl,
            name: def.name,
            modalopts: modal
        };
        impl.setInstanceID(id);
        return (id);
    }
    getInstance(id) {
        let def = this.forms.get(id.name);
        let instance = this.futil.clone(def);
        if (id.ref == null)
            id.ref = this.ctrl.createForm(def.component);
        instance.formref = id.ref;
        instance.windowopts = id.modalopts;
        return (instance);
    }
    closeInstance(id, destroy) {
        let inst = this.getInstance(id);
        if (destroy) {
            inst.formref.destroy();
            inst.windowopts = null;
            inst.formref = null;
        }
    }
}

class Field {
    constructor(name, row) {
        this.seq = 0;
        this.value$ = "";
        this.current$ = false;
        this.enabled$ = false;
        this.field = null;
        this.fields$ = [];
        this.cfields$ = [];
        this.state$ = RecordState.na;
        this.ids = new Map();
        this.index = new Map();
        this.row$ = row;
        this.name$ = name;
    }
    ;
    get name() {
        return (this.name$);
    }
    get row() {
        return (this.row$);
    }
    set block(block) {
        this.block$ = block;
    }
    get block() {
        return (this.block$);
    }
    get fields() {
        return (this.fields$);
    }
    get cfields() {
        return (this.cfields$);
    }
    set valid(valid) {
        this.fields.forEach((inst) => { inst.valid = valid; });
        if (this.current)
            this.cfields.forEach((inst) => { inst.valid = valid; });
    }
    getInstance(guid) {
        return (this.index.get(guid));
    }
    getFirstInstance() {
        if (this.fields.length > 0)
            return (this.fields[0]);
        if (this.current && this.cfields.length > 0) {
            let inst = this.cfields[0];
            inst.row = this.row;
            return (inst);
        }
        return (null);
    }
    get state() {
        return (this.state$);
    }
    get readonly() {
        for (let i = 0; i < this.fields.length; i++) {
            if (this.fields[i].enabled) {
                if (!this.fields[i].readonly)
                    return (false);
            }
        }
        if (this.current$) {
            for (let i = 0; i < this.cfields.length; i++) {
                if (this.cfields[i].enabled) {
                    if (!this.cfields[i].readonly)
                        return (false);
                }
            }
        }
        return (true);
    }
    get current() {
        return (this.current$);
    }
    set current(flag) {
        this.current$ = flag;
        if (!flag)
            this.cfields.forEach((inst) => {
                inst.value = null;
                inst.disable();
            });
        else
            this.cfields.forEach((inst) => {
                inst.parent = this;
                inst.row = this.row;
                inst.value = this.value$;
                inst.state = this.state;
                inst.readonly = this.readonly;
                inst.enable();
            });
    }
    get value() {
        return (this.value$);
    }
    set value(value) {
        this.value$ = value;
        this.fields.forEach((inst) => { inst.value = value; });
        if (this.current)
            this.cfields.forEach((inst) => { inst.value = value; });
    }
    get enabled() {
        return (this.enabled$);
    }
    focus() {
        if (this.field != null && this.field.enabled) {
            if (this.field.focus())
                return (true);
        }
        for (let i = 0; i < this.fields.length; i++) {
            if (this.fields[i].enabled) {
                if (this.fields[i].focus())
                    return (true);
            }
        }
        if (this.current$) {
            for (let i = 0; i < this.cfields.length; i++) {
                if (this.cfields[i].enabled) {
                    if (this.cfields[i].focus())
                        return (true);
                }
            }
        }
        return (false);
    }
    add(field) {
        field.parent = this;
        if (field.row == -1) {
            this.cfields.push(field);
            if (field.guid == null)
                field.guid = "c:" + (this.seq++);
        }
        else {
            this.fields.push(field);
            field.guid = "f:" + (this.seq++);
        }
        this.index.set(field.guid, field);
        if (field.id.length > 0)
            this.ids.set(field.id, field);
    }
    get definition() {
        return (this.def);
    }
    setDefinition(def, cascade) {
        this.def = def;
        if (cascade) {
            for (let i = 0; i < this.fields.length; i++)
                this.fields[i].definition = def;
            for (let i = 0; i < this.cfields.length; i++)
                this.cfields[i].definition = def;
        }
    }
    set state(state) {
        this.state$ = state;
        this.fields.forEach((field) => { field.state = state; });
        if (this.current)
            this.cfields.forEach((field) => { field.state = state; });
    }
    enable(readonly) {
        this.enabled$ = true;
        this.fields.forEach((field) => { field.readonly = readonly; field.enable(); });
        if (this.current)
            this.cfields.forEach((field) => { field.readonly = readonly; field.enable(); });
    }
    disable() {
        this.enabled$ = false;
        this.fields.forEach((field) => { field.disable(); });
        if (this.current)
            this.cfields.forEach((field) => { field.disable(); });
    }
    validate() {
        let valid = true;
        let inst = null;
        for (let i = 0; i < this.fields.length; i++) {
            inst = this.fields[i];
            if (!this.fields[i].validate()) {
                valid = false;
                break;
            }
        }
        if (valid && this.current) {
            for (let i = 0; i < this.cfields.length; i++) {
                inst = this.cfields[i];
                if (!this.cfields[i].validate()) {
                    valid = false;
                    break;
                }
            }
        }
        this.valid = valid;
        if (inst != null)
            this.copy(inst);
        return (valid);
    }
    onEvent(event, field, type, key) {
        return __awaiter(this, void 0, void 0, function* () {
            if (type == "blur")
                this.field = null;
            if (type == "focus")
                this.field = field;
            if (type == "cchange" || type == "change")
                this.copy(field);
            if (this.block$ != null)
                this.block$.onEvent(event, field, type, key);
        });
    }
    copy(field) {
        this.value$ = field.value;
        this.fields.forEach((inst) => { if (inst != field)
            inst.value = this.value$; });
        this.cfields.forEach((inst) => { if (inst != field)
            inst.value = this.value$; });
    }
}

class Container {
    constructor() {
        this.fields$ = [];
        this.blocks = new Map();
    }
    register(field) {
        let bname = field.block;
        let block = this.blocks.get(bname);
        if (block == null) {
            block = new ContainerBlock(bname);
            this.blocks.set(bname, block);
        }
        block.add(field);
        block.fields.push(field);
        this.fields$.push(field);
    }
    get fields() {
        return (this.fields$);
    }
    getBlock(block) {
        return (this.blocks.get(block.toLowerCase()));
    }
    getBlocks() {
        let blocks = [];
        this.blocks.forEach((blk) => { blocks.push(blk); });
        return (blocks);
    }
    finish() {
        this.blocks.forEach((block) => { block["finish"](); });
    }
}
class ContainerBlock {
    constructor(name) {
        this.rows$ = 0;
        this.fields$ = [];
        this.current$ = [];
        this.records$ = new Map();
        this.name$ = name;
    }
    get name() {
        return (this.name$);
    }
    get rows() {
        return (this.rows$);
    }
    add(field) {
        let row = field.row;
        if (field.row == -1) {
            this.current$.push(field);
            return;
        }
        let rec = this.records$.get(+row);
        if (rec == null) {
            rec = new ContainerRecord(row);
            this.records$.set(+row, rec);
            if (field.row > this.rows$)
                this.rows$ = field.row;
        }
        rec.add(field);
    }
    get fields() {
        return (this.fields$);
    }
    get records() {
        let recs = [];
        this.records$.forEach((rec) => { recs.push(rec); });
        let sorted = recs.sort((a, b) => { return (a.row - b.row); });
        return (sorted);
    }
    getRecord(row) {
        return (this.records$.get(+row));
    }
    finish() {
        if (this.rows$ == 0) {
            let rec = new ContainerRecord(0);
            this.records$.set(0, rec);
            this.current$.forEach((field) => {
                field.row = 0;
                rec.add(field);
            });
            this.current$ = [];
        }
        else {
            this.records$.forEach((rec) => {
                this.current$.forEach((inst) => {
                    let group = rec.index.get(inst.name);
                    if (group != null)
                        group.add(inst);
                    else
                        rec.add(inst);
                });
            });
        }
    }
}
class ContainerRecord {
    constructor(row) {
        this.fields = [];
        this.index = new Map();
        this.row = row;
    }
    add(field) {
        let group = this.index.get(field.name);
        if (group == null) {
            group = new Field(field.name, this.row);
            this.index.set(field.name, group);
            this.fields.push(group);
        }
        group.add(field);
    }
}

class ContainerControl {
    constructor(builder) {
        this.builder = builder;
    }
    setContainer(container) {
        if (container == null)
            container = new Container();
        this.container = container;
    }
    getContainer() {
        let cont = this.container;
        return (cont);
    }
    dropContainer() {
        this.container = null;
    }
}

class ApplicationImpl {
    constructor(ctx, client, builder) {
        this.client = client;
        this.builder = builder;
        this.ready = 2;
        this.config$ = null;
        this.marea = null;
        this.apptitle = null;
        this.formlist = null;
        this.mfactory = null;
        this.formsctl = null;
        this.state = null;
        this.contctl = null;
        this.instances = null;
        this.app = ctx.app;
        this.config$ = ctx.conf;
        this.enable();
        this.loadConfig();
        this.state = new ApplicationState(this);
        this.contctl = new ContainerControl(builder);
        this.mfactory = new MenuFactory(this.builder);
        this.formsctl = new FormsControl(this, builder);
        this.instances = new InstanceControl(this.formsctl);
        this.setFormsDefinitions(FormDefinitions.getForms());
        this.state.appmenu = this.createmenu(this.state.menu);
    }
    loadConfig() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.config$.ready();
            if (this.config$.others.hasOwnProperty("title"))
                this.setTitle(this.config$.others["title"]);
            if (this.config$.others.hasOwnProperty("theme"))
                this.config$.setTheme(this.config$.others["theme"]);
            this.ready--;
            this.showLinkedForm();
        });
    }
    get config() {
        return (this.config$);
    }
    enable() {
        WindowListener.add("app", this, "keydown");
    }
    disable() {
        WindowListener.remove("app", "keydown");
    }
    get appstate() {
        return (this.state);
    }
    getApplication() {
        return (this.app);
    }
    setTitle(title) {
        this.apptitle = title;
        this.showTitle(title);
    }
    close() {
        this.closeform(this.state.form, true);
    }
    setMenu(menu) {
        this.deletemenu(this.state.menu);
        this.state.menu = menu;
        this.state.appmenu = this.createmenu(menu);
        this.showMenu(this.state.appmenu);
    }
    getMenu() {
        return (this.state.menu);
    }
    showTitle(title) {
        if (title == null)
            title = this.apptitle;
        document.title = title;
    }
    showPath(name, path) {
        let state = { additionalInformation: 'None' };
        let url = window.location.protocol + '//' + window.location.host;
        window.history.replaceState(state, name, url + path);
    }
    getFormsList() {
        return (this.formsctl.getFormsList());
    }
    getFormsDefinitions() {
        return (this.formsctl.getFormsDefinitions());
    }
    setFormList(formlist) {
        this.formlist = formlist;
    }
    setMenuArea(area) {
        this.marea = area;
        this.showMenu(this.state.appmenu);
    }
    setFormArea(area) {
        this.formsctl.setFormArea(area);
        this.ready--;
    }
    setContainer(container) {
        this.contctl.setContainer(container);
    }
    getContainer() {
        return (this.contctl.getContainer());
    }
    dropContainer() {
        this.contctl.dropContainer();
    }
    get connection() {
        return (this.appstate.connection);
    }
    get connected() {
        return (this.appstate.connected);
    }
    disconnect() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            yield this.appstate.connection.disconnect();
            (_a = this.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.focus();
        });
    }
    newForm(impl) {
        return __awaiter(this, void 0, void 0, function* () {
            let funcs = FormDefinitions.getOnInit(impl.name);
            for (let i = 0; i < funcs.length; i++)
                yield this.execfunc(impl, funcs[i]);
            funcs = FormDefinitions.getOnShow(impl.name);
            for (let i = 0; i < funcs.length; i++)
                yield this.execfunc(impl, funcs[i]);
            impl.onShow();
        });
    }
    preform(impl, parameters, formdef, path) {
        return __awaiter(this, void 0, void 0, function* () {
            impl.setParameters(parameters);
            if (!impl.initiated()) {
                impl.path = formdef.path;
                impl.title = formdef.title;
                this.state.addForm(impl);
                this.showTitle(formdef.title);
                if (path)
                    this.showPath(impl.name, formdef.path);
                return;
            }
            this.showTitle(impl.title);
            if (path)
                this.showPath(impl.name, impl.path);
            let funcs = FormDefinitions.getOnShow(impl.name);
            for (let i = 0; i < funcs.length; i++)
                yield this.execfunc(impl, funcs[i]);
            impl.onShow();
        });
    }
    postform(impl, destroy) {
        return __awaiter(this, void 0, void 0, function* () {
            impl.onHide();
            let funcs = FormDefinitions.getOnHide(impl.name);
            for (let i = 0; i < funcs.length; i++)
                yield this.execfunc(impl, funcs[i]);
            if (destroy) {
                this.state.dropForm(impl);
                let funcs = FormDefinitions.getOnDestroy(impl.name);
                for (let i = 0; i < funcs.length; i++)
                    yield this.execfunc(impl, funcs[i]);
            }
        });
    }
    execfunc(impl, func) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield impl.form[func]();
            }
            catch (error) {
                console.log(error);
            }
        });
    }
    callform(form, destroy, parameters) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.ready != 0) {
                setTimeout(() => { this.callform(form, destroy, parameters); }, 10);
                return;
            }
            if (this.state.form != null) {
                // Make sure changes has been validated
                if (!(yield this.state.form.validate()))
                    return;
                // get current form in chain
                let curr = this.state.form.getChain();
                // let form handle the showform
                yield curr.callform(form, destroy, parameters);
            }
        });
    }
    getCurrentForm() {
        if (this.ready != 0)
            return (null);
        if (this.state.form == null)
            return (null);
        return (this.state.form.getChain());
    }
    showform(form, destroy, parameters) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            if (this.ready != 0) {
                setTimeout(() => { this.showform(form, destroy, parameters); }, 10);
                return;
            }
            if (this.state.form != null) {
                // Make sure changes has been validated
                if (!(yield this.state.form.validate()))
                    return;
                // if form has called anoother form
                let curr = this.state.form.getChain();
                if (curr != this.state.form) {
                    // let form handle the showform
                    curr.showform(form, destroy, parameters);
                    return;
                }
                if (this.state.form.getModalWindow() != null)
                    return;
                this.closeform(this.state.form, false);
            }
            if (destroy)
                this.formsctl.closeform(form, destroy);
            let formdef = this.getFormInstance(form);
            if (formdef == null)
                return;
            let impl = formdef.formref.instance["_impl_"];
            yield this.preform(impl, parameters, formdef, true);
            this.state.form = impl;
            let fmenu = impl.getDropDownMenu();
            if (!((_a = formdef.windowopts) === null || _a === void 0 ? void 0 : _a.wizard))
                this.showMenu(fmenu);
            DropDownMenu.setForm(fmenu, formdef.formref.instance);
            this.formsctl.display(formdef);
        });
    }
    showinstance(inst) {
        if (this.ready == 0)
            this.formsctl.display(inst);
        else
            setTimeout(() => { this.showinstance(inst); }, 10);
    }
    closeform(impl, destroy) {
        if (impl == null)
            return;
        this.postform(impl, destroy);
        this.formsctl.closeform(impl.name, destroy);
        if (this.state.appmenu != null)
            DropDownMenu.setForm(this.state.appmenu, null);
        this.showPath("", "");
        this.showTitle(null);
        this.state.form = null;
        this.showMenu(this.state.appmenu);
    }
    getFormInstance(form) {
        return (this.formsctl.getFormInstance(form));
    }
    getNewInstance(form, modal) {
        return (this.instances.getNewInstance(form, modal));
    }
    getInstance(id) {
        return (this.instances.getInstance(id));
    }
    closeInstance(id, destroy) {
        this.postform(id.impl, destroy);
        this.instances.closeInstance(id, destroy);
    }
    showMenu(menu) {
        if (this.marea != null)
            this.marea.display(menu);
    }
    deletemenu(menu) {
        this.state.dropMenu(menu);
    }
    createmenu(menu) {
        if (menu == null)
            return (null);
        this.state.addMenu(menu);
        let ddmenu = this.mfactory.create(menu);
        return (ddmenu);
    }
    setFormsDefinitions(forms) {
        for (let i = 0; i < forms.length; i++) {
            let fname = forms[i].component.name.toLowerCase();
            forms[i].windowopts = FormDefinitions.getWindowOpts(fname);
            forms[i].databaseusage = DatabaseDefinitions.getFormUsage(fname);
        }
        let formsmap = this.formsctl.setFormsDefinitions(forms);
        this.instances.setFormsDefinitions(formsmap);
    }
    showLinkedForm() {
        if (this.ready != 0) {
            // Make time for application setup
            setTimeout(() => { this.showLinkedForm(); }, 500);
            return;
        }
        let form = decodeURI(window.location.pathname);
        if (form.length > 0)
            form = this.formsctl.findFormByPath(form);
        if (form != null) {
            let inst = this.formsctl.getFormsDefinitions().get(form);
            if (inst == null || !inst.navigable) {
                this.showPath("", "");
                return;
            }
            let params = new Map();
            let urlparams = new URLSearchParams(window.location.search);
            urlparams.forEach((value, key) => { params.set(key, value); });
            this.showform(form, false, params);
        }
    }
    onEvent(event) {
        return __awaiter(this, void 0, void 0, function* () {
            if (Wait.waiting())
                return;
            let keydef = {
                code: event.keyCode,
                alt: event.altKey,
                ctrl: event.ctrlKey,
                meta: event.metaKey,
                shift: event.shiftKey
            };
            let map = KeyMapper.map(keydef);
            let key = KeyMapper.keymap(map);
            if (key == keymap.connect) {
                this.app.connect();
                return;
            }
            if (key == keymap.disconnect) {
                this.app.disconnect();
                return;
            }
            if (key == keymap.close ||
                key == keymap.delete ||
                key == keymap.listval ||
                key == keymap.commit ||
                key == keymap.rollback ||
                key == keymap.clearform ||
                key == keymap.insertafter ||
                key == keymap.insertbefore ||
                key == keymap.enterquery ||
                key == keymap.executequery) {
                event.preventDefault();
                let form = this.getCurrentForm();
                if (form != null)
                    form.sendkey(event, key);
            }
        });
    }
}

class Application {
    // dont rename impl as it is read behind the scenes
    constructor(ctx, conf, client, builder) {
        this.conf = conf;
        ctx.app = this;
        ctx.conf = conf;
        this._impl_ = new ApplicationImpl(ctx, client, builder);
    }
    get title() {
        return (this.title$);
    }
    set title(title) {
        this.title$ = title;
        this._impl_.setTitle(title);
    }
    get form() {
        var _a;
        return ((_a = this._impl_.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.form);
    }
    set menu(menu) {
        this._impl_.setMenu(menu);
    }
    get menu() {
        return (this._impl_.getMenu());
    }
    get transaction() {
        return (this._impl_.appstate.transaction);
    }
    newform(form, parameters) {
        this._impl_.showform(form, true, parameters);
    }
    showform(form, parameters) {
        this._impl_.showform(form, false, parameters);
    }
    callform(form, parameters) {
        this._impl_.callform(form, false, parameters);
    }
    get colors() {
        return (this.conf.colors);
    }
    set theme(theme) {
        setTimeout(() => { this.conf.setTheme(theme); }, 50);
    }
    closeform(destroy) {
        if (destroy == undefined)
            destroy = false;
        let form = this._impl_.getCurrentForm();
        if (form != null)
            form.close(destroy);
    }
    connect() {
        if (!this._impl_.connected) {
            let pinst = new PopupInstance();
            pinst.display(this._impl_, LoginForm);
        }
    }
    disconnect() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this._impl_.connected) {
                yield this._impl_.appstate.clearAllForms();
                yield this._impl_.connection.rollback();
                yield this._impl_.disconnect();
            }
        });
    }
    commit() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this._impl_.connected)
                return;
            let form = this._impl_.getCurrentForm();
            if (form != null) {
                if (!(yield form.validate()))
                    return;
            }
            this._impl_.connection.commit();
        });
    }
    rollback() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this._impl_.connected) {
                yield this._impl_.appstate.clearAllForms();
                yield this._impl_.connection.rollback();
            }
        });
    }
    showKeyMap() {
        KeyMapHelp.show(this._impl_);
    }
    alert(message, title, width, height) {
        MessageBox.show(this._impl_, message, title, width, height);
    }
}
Application.ɵprov = ɵɵdefineInjectable({ factory: function Application_Factory() { return new Application(ɵɵinject(Context), ɵɵinject(Config), ɵɵinject(HttpClient), ɵɵinject(Builder)); }, token: Application, providedIn: "root" });
Application.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] }
];
Application.ctorParameters = () => [
    { type: Context },
    { type: Config },
    { type: HttpClient },
    { type: Builder }
];

class FormsLibrary {
}
FormsLibrary.decorators = [
    { type: NgModule, args: [{
                declarations: [FormList, FormArea, ModalWindow, MenuArea, LoginForm, FieldInstance, ListOfValuesImpl, Wait],
                exports: [FormList, FormArea, MenuArea, FieldInstance],
                imports: [CommonModule, HttpClientModule]
            },] }
];

/**
 * Generated bundle index. Do not edit.
 */

export { Application, Block, Case, Column, Condition, DateUtils, DefaultMenu, DefaultMenuHandler, FieldInstance, FieldTrigger, FieldTriggerEvent, FieldType, Form, FormArea, FormList, FormsLibrary, KeyTriggerEvent, MenuArea, MenuHandler, SQLTriggerEvent, Statement, Trigger, TriggerEvent, alias, block, column, connect, database, defaultTheme, destroy, disconnect, field, form, hide, init, join, key, keymap, keytrigger, listofvalues, show, table, trigger, window$1 as window, wizard, Context as ɵa, Config as ɵb, Builder as ɵc, ModalWindow as ɵd, LoginForm as ɵe, ListOfValuesImpl as ɵf, Wait as ɵg };
//# sourceMappingURL=forms.js.map
