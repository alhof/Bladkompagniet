export declare class DateUtils {
    parse(datestr: string, format?: string): Date;
    format(date: Date, format?: string): string;
}
