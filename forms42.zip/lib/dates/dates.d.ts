export interface datepart {
    token: string;
    delim: string;
}
export declare class dates {
    private static delim;
    private static deffmt;
    private static tokens$;
    private static formattokens;
    private static init;
    static setFormat(format: string): void;
    static parse(datestr: string, format?: string): Date;
    static format(date: Date, format?: string): string;
    private static reformat;
    private static split;
    private static replaceAll;
}
