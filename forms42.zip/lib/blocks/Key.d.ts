import { NameValuePair } from "../utils/NameValuePair";
export declare class Key {
    name: string;
    private values$;
    private columns$;
    private index;
    constructor(name: string);
    get(part: string | number): any;
    partof(part: string): boolean;
    set(name: string | number, value: any): void;
    addColumn(name: string): void;
    columns(): string[];
    get values(): NameValuePair[];
    toString(): string;
}
