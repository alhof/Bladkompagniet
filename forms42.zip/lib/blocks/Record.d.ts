import { Field } from "../input/Field";
import { FieldInstance } from "../input/FieldInstance";
export declare enum RecordState {
    na = 0,
    qmode = 1,
    insert = 2,
    update = 3
}
export declare class Record {
    private row$;
    private fields$;
    private current$;
    private enabled$;
    private state$;
    private index;
    constructor(row: number, fields: Field[], index: Map<string, Field>);
    set row(row: number);
    get row(): number;
    get fields(): Field[];
    focus(): void;
    set current(flag: boolean);
    get current(): boolean;
    clear(): void;
    set state(state: RecordState);
    get state(): RecordState;
    get enabled(): boolean;
    get readonly(): boolean;
    enable(readonly?: boolean): void;
    disable(): void;
    getField(name: string): Field;
    getFieldByGuid(name: string, guid: string): FieldInstance;
}
