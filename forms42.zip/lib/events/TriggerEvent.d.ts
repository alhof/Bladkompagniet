import { Trigger } from "./Triggers";
import { keymap } from "../keymap/KeyMap";
import { Statement } from "../database/Statement";
import { FieldInstance } from "../input/FieldInstance";
export declare enum Origin {
    Form = 0,
    Block = 1,
    Field = 2
}
export declare class TriggerEvent {
    private event$;
    private type$;
    private block$;
    private record$;
    constructor(block: string, record: number, jsevent?: any);
    get block(): string;
    get type(): Trigger;
    get event(): any;
    get record(): number;
}
export declare class KeyTriggerEvent extends TriggerEvent {
    private key$;
    private field$;
    private origin$;
    constructor(origin: Origin, block: string, field: FieldInstance, key: keymap, jsevent: any);
    get key(): keymap;
    get field(): string;
    get origin(): number;
}
export declare class FieldTriggerEvent extends TriggerEvent {
    private value$;
    private id$;
    private field$;
    private previous$;
    constructor(block: string, field: string, id: string, row: number, value: any, previous: any, jsevent?: any);
    get value(): any;
    get field(): string;
    get id(): string;
    get previous(): any;
}
export declare class SQLTriggerEvent extends TriggerEvent {
    private stmt$;
    constructor(block: string, row: number, stmt: Statement);
    get stmt(): Statement;
    set stmt(stmt: Statement);
}
