import { keymap } from "../keymap/KeyMap";
import { TriggerEvent } from "./TriggerEvent";
import { TriggerFunction } from "./TriggerFunction";
export declare enum Trigger {
    Key = 0,
    Lock = 1,
    Typing = 2,
    MouseClick = 3,
    MouseDoubleClick = 4,
    PreField = 5,
    PostField = 6,
    PostChange = 7,
    KeyPrevField = 8,
    KeyNextField = 9,
    KeyPrevBlock = 10,
    KeyNextBlock = 11,
    KeyEnterQuery = 12,
    KeyExecuteQuery = 13,
    WhenValidateField = 14,
    WhenValidateRecord = 15,
    PreQuery = 16,
    PostQuery = 17,
    PreInsert = 18,
    PreUpdate = 19,
    PreDelete = 20
}
export declare enum FieldTrigger {
    Key = 0,
    Typing = 1,
    MouseClick = 2,
    MouseDoubleClick = 3,
    PreField = 4,
    PostField = 5,
    PostChange = 6,
    WhenValidateField = 7,
    WhenValidateRecord = 8
}
export declare class Triggers {
    private triggers;
    private static fieldtriggers;
    private static init;
    addTrigger(instance: any, func: TriggerFunction, ttypes: Trigger | Trigger[], tfields?: string | string[], tkeys?: keymap | keymap[]): void;
    invokeTriggers(type: Trigger, event: TriggerEvent, key?: keymap): Promise<boolean>;
    invokeFieldTriggers(type: Trigger, field: string, event: TriggerEvent, key?: keymap): Promise<boolean>;
    private execfunc;
    private isFieldTrigger;
    private trgname;
    private keycode;
}
