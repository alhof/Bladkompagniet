import { Listener } from "./Listener";
export declare class TriggerEvents {
    types: Map<string, Listener[]>;
    fields: Map<string, Map<string, Listener[]>>;
}
