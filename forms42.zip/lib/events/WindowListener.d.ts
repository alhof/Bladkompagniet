export interface onEventListener {
    onEvent(event: any): void;
}
export declare class WindowListener {
    private static events;
    static add(id: string, clazz: onEventListener, event: string): void;
    static remove(id: string, event: string): void;
    private constructor();
    private start;
    private onEvent;
}
