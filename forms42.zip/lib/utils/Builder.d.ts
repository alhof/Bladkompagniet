import { Injector, ComponentFactoryResolver, ComponentRef, ApplicationRef } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class Builder {
    private resolver;
    private injector;
    private app;
    constructor(resolver: ComponentFactoryResolver, injector: Injector, app: ApplicationRef);
    createComponent(component: any): ComponentRef<any>;
    getAppRef(): ApplicationRef;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<Builder, never>;
}

//# sourceMappingURL=Builder.d.ts.map