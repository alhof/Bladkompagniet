import { Injector, ComponentFactoryResolver, ComponentRef, ApplicationRef } from '@angular/core';
export declare class Builder {
    private resolver;
    private injector;
    private app;
    constructor(resolver: ComponentFactoryResolver, injector: Injector, app: ApplicationRef);
    createComponent(component: any): ComponentRef<any>;
    getAppRef(): ApplicationRef;
}
