export interface NameValuePair {
    name: string;
    value?: any;
}
