export declare class Utils {
    getName(component: any): string;
    clone(obj: any): any;
    getType(component: any): string;
    getParams(func: any): string[];
}
