import { ApplicationImpl } from '../application/ApplicationImpl';
import { AfterViewInit } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class Wait implements AfterViewInit {
    private static ready;
    private static displayed;
    private static win;
    static show(app: ApplicationImpl): void;
    static waiting(): boolean;
    static close(app: ApplicationImpl): void;
    private input;
    private canvas;
    private inputElement;
    private canvasElement;
    ngAfterViewInit(): void;
    private focus;
    private showrunning;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<Wait, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<Wait, "ng-component", never, {}, {}, never, never>;
}

//# sourceMappingURL=Wait.d.ts.map