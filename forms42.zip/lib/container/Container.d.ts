import { Field } from "../input/Field";
import { FieldInstance } from "../input/FieldInstance";
export declare class Container {
    private fields$;
    private blocks;
    register(field: FieldInstance): void;
    get fields(): FieldInstance[];
    getBlock(block: string): ContainerBlock;
    getBlocks(): ContainerBlock[];
    finish(): void;
}
export declare class ContainerBlock {
    private name$;
    private rows$;
    private fields$;
    private current$;
    private records$;
    constructor(name: string);
    get name(): string;
    get rows(): number;
    add(field: FieldInstance): void;
    get fields(): FieldInstance[];
    get records(): ContainerRecord[];
    getRecord(row: number): ContainerRecord;
    private finish;
}
export declare class ContainerRecord {
    row: number;
    fields: Field[];
    index: Map<string, Field>;
    constructor(row: number);
    add(field: FieldInstance): void;
}
