import { Container } from "./Container";
import { Builder } from "../utils/Builder";
export declare class ContainerControl {
    private builder;
    private container;
    constructor(builder: Builder);
    setContainer(container?: Container): void;
    getContainer(): Container;
    dropContainer(): void;
}
