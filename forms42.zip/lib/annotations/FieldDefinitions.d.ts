import { FieldDefinition } from "../input/FieldDefinition";
export declare class FieldDefinitions {
    private static bfd;
    private static bfx;
    private static bcx;
    private static bidx;
    private static ffd;
    private static ffx;
    private static fcx;
    private static fidx;
    static add(form: boolean, comp: string, def: FieldDefinition): void;
    private static addformfield;
    private static addblockfield;
    private static addformid;
    private static addblockid;
    static getFormFieldOverride(form: string, block: string, fldid: string): FieldDefinition;
    static getFieldOverride(block: string, fldid: string): FieldDefinition;
    static getFormFields(form: string, block: string): FieldDefinition[];
    static getFields(block: string): FieldDefinition[];
    static getFormFieldIndex(form: string, block: string): Map<string, FieldDefinition>;
    static getFieldIndex(block: string): Map<string, FieldDefinition>;
    static getFormColumnIndex(form: string, block: string): Map<string, FieldDefinition>;
    static getColumnIndex(block: string): Map<string, FieldDefinition>;
    private static split;
}
