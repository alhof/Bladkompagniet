import { Form } from "../forms/Form";
export declare const show: (form: Form, func?: string) => void;
