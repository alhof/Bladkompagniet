import { KeyDefinition } from './KeyDefinition';
import { BlockDefinition } from '../blocks/BlockDefinition';
export declare class BlockDefinitions {
    private static alias;
    private static blocks;
    private static keys;
    static setDefaultAlias(block: string, alias: string): void;
    static getDefaultAlias(alias: string): string;
    static setBlock(form: string, def: BlockDefinition): void;
    static getBlocks(form: string): BlockDefinition[];
    static setKey(block: string, def: KeyDefinition): void;
    static getKeys(block: string): KeyDefinition[];
}
