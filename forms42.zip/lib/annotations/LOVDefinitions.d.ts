export interface LOVDefinition {
    inst: any;
    func: string;
    params: string[];
}
export declare class LOVDefinitions {
    private static bdefs;
    private static biddefs;
    private static fdefs;
    private static fiddefs;
    static add(isblock: boolean, cname: string, fieldspec: string, inst: any, func: string, params: string[]): void;
    private static addFormLov;
    private static addFormIdLov;
    private static addBlockLov;
    private static addBlockIdLov;
    static getblock(block: string): Map<string, LOVDefinition>;
    static getblockid(block: string): Map<string, LOVDefinition>;
    static getform(form: string, block: string): Map<string, LOVDefinition>;
    static getidform(form: string, block: string): Map<string, LOVDefinition>;
    private static split;
}
