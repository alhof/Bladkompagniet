export declare const alias: (alias: string) => (comp: any) => void;
