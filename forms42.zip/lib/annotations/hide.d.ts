import { Form } from "../forms/Form";
export declare const hide: (form: Form, func?: string) => void;
