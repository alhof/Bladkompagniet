import { Form } from "../forms/Form";
export declare const disconnect: (form: Form, func?: string) => void;
