import { Form } from "../forms/Form";
export declare const init: (form: Form, func?: string) => void;
