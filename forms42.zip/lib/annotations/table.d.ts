import { TableDefinition } from '../database/TableDefinition';
export declare const table: (definition: TableDefinition) => (comp: any) => void;
