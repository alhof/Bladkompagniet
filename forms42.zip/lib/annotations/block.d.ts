import { BlockDefinition } from './BlockDefinition';
export declare const block: (definition: BlockDefinition) => (comp: any, prop?: string) => void;
