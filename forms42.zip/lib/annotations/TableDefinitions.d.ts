import { TableDefinition } from "../database/TableDefinition";
export declare class TableDefinitions {
    private static index;
    static set(block: string, table: TableDefinition): void;
    static get(block: string): TableDefinition;
}
