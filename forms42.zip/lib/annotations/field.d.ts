import { FieldDefinition } from '../input/FieldDefinition';
export declare const field: (definition: FieldDefinition) => (comp: any) => void;
