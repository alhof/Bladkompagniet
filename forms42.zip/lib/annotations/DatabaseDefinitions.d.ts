import { DatabaseUsage } from "../database/DatabaseUsage";
export interface PropUsage {
    prop?: string;
    usage?: DatabaseUsage;
}
export declare class DatabaseDefinitions {
    private static bdefault;
    private static fdefault;
    static setFormUsage(form: string, usage: DatabaseUsage): void;
    static getFormUsage(form: string): DatabaseUsage;
    static setBlockDefault(block: string, usage: DatabaseUsage): void;
    static getBlockDefault(block: string): DatabaseUsage;
}
