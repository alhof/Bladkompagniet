import { DatabaseUsage } from "../database/DatabaseUsage";
export declare const database: (usage: DatabaseUsage) => (component: any) => void;
