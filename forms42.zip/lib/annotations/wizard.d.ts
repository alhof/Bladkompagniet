export declare const wizard: () => (form: any) => void;
