import { JOINDefinition } from './JOINDefinitions';
export declare const join: (definition: JOINDefinition) => (comp: any) => void;
