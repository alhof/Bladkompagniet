import { keymap } from "../keymap/KeyMap";
import { Trigger } from "../events/Triggers";
import { TriggerFunction } from "../events/TriggerFunction";
export interface TriggerDefinition {
    key?: keymap;
    field?: string;
    block: string;
    blktrg: boolean;
    trigger: Trigger;
    params: string[];
    func: TriggerFunction;
}
export declare class TriggerDefinitions {
    private static bftriggers;
    private static bktriggers;
    private static fktriggers;
    private static fftriggers;
    static add(isblock: boolean, cname: string, def: TriggerDefinition): void;
    private static addkt;
    private static addft;
    private static addFieldTrigger;
    private static addKeyTrigger;
    private static addFormFieldTrigger;
    private static addFormKeyTrigger;
    static getFieldTriggers(block: string): Map<string, TriggerDefinition>;
    static getKeyTriggers(block: string): Map<string, TriggerDefinition>;
    static getFormFieldTriggers(form: string, block: string): Map<string, TriggerDefinition>;
    static getFormKeyTriggers(form: string): Map<string, TriggerDefinition>;
    private static split;
}
