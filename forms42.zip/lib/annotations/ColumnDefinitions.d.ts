import { ColumnDefinition } from "../database/ColumnDefinition";
export declare class ColumnDefinitions {
    private static bcols;
    private static bcidx;
    static add(block: string, def: ColumnDefinition): void;
    static get(block: string): ColumnDefinition[];
    static getIndex(block: string): Map<string, ColumnDefinition>;
}
