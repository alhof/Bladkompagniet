export interface JOINDefinition {
    master: {
        alias: string;
        key: string;
    };
    detail: {
        alias: string;
        key: string;
    };
}
export declare class JOINDefinitions {
    private static defs;
    static add(form: string, def: JOINDefinition): void;
    static get(form: string): JOINDefinition[];
}
