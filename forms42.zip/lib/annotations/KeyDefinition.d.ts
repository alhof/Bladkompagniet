export interface KeyDefinition {
    name: string;
    unique: boolean;
    columns: string[];
}
