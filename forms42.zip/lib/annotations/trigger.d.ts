import { Trigger } from "../events/Triggers";
export declare const trigger: (trigger: Trigger, field?: string | string[]) => (comp: any, func?: string) => void;
