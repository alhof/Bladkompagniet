import { keymap } from "../keymap/KeyMap";
export declare const keytrigger: (key: keymap | keymap[]) => (comp: any, func?: string) => void;
