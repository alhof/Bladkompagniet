import { ColumnDefinition } from '../database/ColumnDefinition';
export declare const column: (definition: ColumnDefinition) => (comp: any) => void;
