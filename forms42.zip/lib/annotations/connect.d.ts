import { Form } from "../forms/Form";
export declare const connect: (form: Form, func?: string) => void;
