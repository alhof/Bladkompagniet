export declare const key: (name: string, unique: boolean, columns: string | string[]) => (comp: any) => void;
