import { WindowOptions } from '../forms/WindowOptions';
import { FormDefinition } from '../forms/FormsDefinition';
export declare class FormDefinitions {
    private static forms;
    private static oninit;
    private static onshow;
    private static onhide;
    private static onconn;
    private static ondisc;
    private static ondest;
    private static windowopts;
    static setForm(def: FormDefinition): void;
    static getForms(): FormDefinition[];
    static getWindowOpts(form: string): WindowOptions;
    static setOnInit(form: string, func: string): void;
    static setOnShow(form: string, func: string): void;
    static setOnHide(form: string, func: string): void;
    static setOnConnect(form: string, func: string): void;
    static setOnDisconnect(form: string, func: string): void;
    static setOnDestroy(form: string, func: string): void;
    static getOnInit(form: string): string[];
    static getOnShow(form: string): string[];
    static getOnHide(form: string): string[];
    static getOnConnect(form: string): string[];
    static getOnDisconnect(form: string): string[];
    static getOnDestroy(form: string): string[];
}
