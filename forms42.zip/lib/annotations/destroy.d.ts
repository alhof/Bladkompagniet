import { Form } from "../forms/Form";
export declare const destroy: (form: Form, func?: string) => void;
