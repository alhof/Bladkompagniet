export declare const listofvalues: (field: string | string[]) => (comp: any, func?: string) => void;
