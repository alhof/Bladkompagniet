export declare const form: (component: any, title: string, path: string, navigable?: boolean) => (_comp: any) => void;
