export declare const window: (inherit: boolean, width?: number | string, height?: number | string, top?: number | string, left?: number | string) => (form: any) => void;
