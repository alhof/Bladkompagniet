export declare class FormsLibrary {
}
