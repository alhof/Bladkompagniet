import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './menu/FormList';
import * as ɵngcc2 from './forms/FormArea';
import * as ɵngcc3 from './forms/ModalWindow';
import * as ɵngcc4 from './menu/MenuArea';
import * as ɵngcc5 from './database/LoginForm';
import * as ɵngcc6 from './input/FieldInstance';
import * as ɵngcc7 from './listval/ListOfValuesImpl';
import * as ɵngcc8 from './utils/Wait';
import * as ɵngcc9 from '@angular/common';
import * as ɵngcc10 from '@angular/common/http';
export declare class FormsLibrary {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<FormsLibrary, [typeof ɵngcc1.FormList, typeof ɵngcc2.FormArea, typeof ɵngcc3.ModalWindow, typeof ɵngcc4.MenuArea, typeof ɵngcc5.LoginForm, typeof ɵngcc6.FieldInstance, typeof ɵngcc7.ListOfValuesImpl, typeof ɵngcc8.Wait], [typeof ɵngcc9.CommonModule, typeof ɵngcc10.HttpClientModule], [typeof ɵngcc1.FormList, typeof ɵngcc2.FormArea, typeof ɵngcc4.MenuArea, typeof ɵngcc6.FieldInstance]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<FormsLibrary>;
}

//# sourceMappingURL=FormsLibrary.d.ts.map