import { Popup } from './Popup';
import { ComponentRef } from "@angular/core";
import { ApplicationImpl } from '../application/ApplicationImpl';
export declare class PopupInstance {
    popupref: ComponentRef<Popup>;
    display(app: ApplicationImpl, popup: any): void;
    popup(): Popup;
}
