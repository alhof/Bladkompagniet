import { Context } from "./Context";
import { Popup } from "../popup/Popup";
import { PopupWindow } from "../popup/PopupWindow";
import { ApplicationImpl } from "./ApplicationImpl";
import { AfterViewInit } from "@angular/core";
export declare class KeyMapHelp implements Popup, AfterViewInit {
    top?: string;
    left?: string;
    width?: string;
    height?: string;
    title: string;
    private html;
    private win;
    private map;
    private okbtn;
    private okelem;
    private mapelem;
    static show(app: ApplicationImpl): void;
    constructor(ctx: Context);
    close(_cancel: boolean): void;
    setWin(win: PopupWindow): void;
    ngAfterViewInit(): void;
}
