import { HttpClient } from "@angular/common/http";
import { KeyMap } from "../keymap/KeyMap";
import { Theme } from "./Themes";
import * as ɵngcc0 from '@angular/core';
export declare class Config {
    private client;
    private keymap;
    private colors$;
    private datefmt$;
    private config;
    private notifications;
    private invoker;
    private caltitle;
    private keymaphelp;
    private themes;
    private lang;
    constructor(client: HttpClient);
    private os;
    private load;
    private loaded;
    ready(): Promise<boolean>;
    get locale(): string;
    get datefmt(): string;
    set colors(theme: Theme);
    get colors(): Theme;
    get others(): any;
    notify(instance: any, func: string): void;
    setTheme(theme: string | Theme): void;
    get keymapping(): KeyMap;
    get keymaptitle(): string;
    get calendarname(): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<Config, never>;
}

//# sourceMappingURL=Config.d.ts.map