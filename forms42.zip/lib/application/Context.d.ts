import { Config } from "./Config";
import { Application } from "./Application";
import * as ɵngcc0 from '@angular/core';
export declare class Context {
    conf: Config;
    app: Application;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<Context, never>;
}

//# sourceMappingURL=Context.d.ts.map