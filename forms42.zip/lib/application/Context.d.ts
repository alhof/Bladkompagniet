import { Config } from "./Config";
import { Application } from "./Application";
export declare class Context {
    conf: Config;
    app: Application;
}
