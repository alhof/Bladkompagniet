export interface Theme {
    name: string;
    link: string;
    text: string;
    title: string;
    topbar: string;
    enabled: string;
    disabled: string;
    foldertree: string;
    buttontext: string;
    menuoption: string;
    rowindicator: string;
}
export declare class defaultTheme implements Theme {
    name: string;
    link: string;
    text: string;
    title: string;
    topbar: string;
    enabled: string;
    disabled: string;
    menuoption: string;
    buttontext: string;
    foldertree: string;
    rowindicator: string;
}
export declare class Indigo extends defaultTheme {
    name: string;
}
export declare class Grey extends defaultTheme {
    name: string;
    link: string;
    topbar: string;
    foldertree: string;
    rowindicator: string;
}
export declare class Pink extends defaultTheme {
    name: string;
    link: string;
    topbar: string;
    foldertree: string;
    rowindicator: string;
}
export declare class Yellow implements Theme {
    name: string;
    link: string;
    text: string;
    title: string;
    topbar: string;
    foldertree: string;
    enabled: string;
    disabled: string;
    menuoption: string;
    buttontext: string;
    rowindicator: string;
}
