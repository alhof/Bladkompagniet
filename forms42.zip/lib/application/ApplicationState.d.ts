import { Menu } from "../menu/Menu";
import { FormImpl } from "../forms/FormImpl";
import { ComponentRef } from "@angular/core";
import { MenuHandler } from "../menu/MenuHandler";
import { Connection } from "../database/Connection";
import { DropDownMenu } from "../menu/DropDownMenu";
import { ApplicationImpl } from "./ApplicationImpl";
export declare class ApplicationState {
    private app;
    menu: Menu;
    form: FormImpl;
    connection: Connection;
    transaction: boolean;
    appmenu: ComponentRef<DropDownMenu>;
    forms: Map<number, FormImpl>;
    menus: Map<number, MenuHandler>;
    constructor(app: ApplicationImpl);
    addForm(form: FormImpl): void;
    dropForm(form: FormImpl): void;
    addMenu(menu: Menu): void;
    dropMenu(menu: Menu): void;
    clearAllForms(): Promise<void>;
    onConnect(): Promise<boolean>;
    transactionChange(trans: boolean): void;
    onDisconnect(): Promise<boolean>;
    get connected(): boolean;
    alert(message: string, title?: string, width?: string, height?: string): void;
}
