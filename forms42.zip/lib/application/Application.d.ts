import { Theme } from "./Themes";
import { Config } from "./Config";
import { Menu } from "../menu/Menu";
import { Context } from "./Context";
import { Form } from "../forms/Form";
import { Builder } from "../utils/Builder";
import { HttpClient } from "@angular/common/http";
import * as ɵngcc0 from '@angular/core';
export declare class Application {
    private conf;
    private title$;
    private _impl_;
    constructor(ctx: Context, conf: Config, client: HttpClient, builder: Builder);
    get title(): string;
    set title(title: string);
    get form(): Form;
    set menu(menu: Menu);
    get menu(): Menu;
    get transaction(): boolean;
    newform(form: any, parameters?: Map<string, any>): void;
    showform(form: any, parameters?: Map<string, any>): void;
    callform(form: any, parameters?: Map<string, any>): void;
    get colors(): Theme;
    set theme(theme: string);
    closeform(destroy?: boolean): void;
    connect(): void;
    disconnect(): Promise<void>;
    commit(): Promise<void>;
    rollback(): Promise<void>;
    showKeyMap(): void;
    alert(message: string, title?: string, width?: string, height?: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<Application, never>;
}

//# sourceMappingURL=Application.d.ts.map