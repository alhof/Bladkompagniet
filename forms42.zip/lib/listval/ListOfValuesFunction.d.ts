import { ListOfValues } from "./ListOfValues";
export interface ListOfValuesFunction {
    (record: number): ListOfValues;
}
