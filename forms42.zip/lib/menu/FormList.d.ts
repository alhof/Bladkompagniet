import { Context } from '../application/Context';
import { AfterViewInit } from '@angular/core';
export declare class FormList implements AfterViewInit {
    private root;
    private conf;
    private page;
    private app;
    private html;
    private ready;
    private formsdef;
    name: string;
    private elem;
    constructor(ctx: Context);
    open(folder: string): void;
    private print;
    private parse;
    ngAfterViewInit(): void;
    setColors(): void;
    private toggle;
    private show;
    private folder;
    private forms;
    private form;
    private pre;
    private indent;
    private half;
    private styles;
}
