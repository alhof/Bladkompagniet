import { DropDownMenu } from './DropDownMenu';
import { Context } from '../application/Context';
import { AfterViewInit, ComponentRef, ChangeDetectorRef } from '@angular/core';
export declare class MenuArea implements AfterViewInit {
    private change;
    private app;
    private menu;
    private element;
    private menuref;
    private elem;
    constructor(ctx: Context, change: ChangeDetectorRef);
    remove(): void;
    display(menu: ComponentRef<DropDownMenu>): void;
    ngAfterViewInit(): void;
}
