import { DropDownMenu } from "./DropDownMenu";
import { Application } from "../application/Application";
export declare class MenuInterface {
    private menu$;
    private app$;
    constructor(menu: DropDownMenu);
    get app(): Application;
    isConnected(): boolean;
    enable(menu?: string): void;
    disable(menu?: string): void;
}
