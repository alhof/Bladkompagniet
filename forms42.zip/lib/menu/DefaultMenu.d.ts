import { Menu } from './Menu';
import { MenuEntry } from './MenuEntry';
import { MenuHandler } from './MenuHandler';
export declare class DefaultMenu implements Menu {
    private entries;
    private handler;
    constructor();
    getHandler(): MenuHandler;
    getEntries(): MenuEntry[];
}
