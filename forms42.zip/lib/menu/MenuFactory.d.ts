import { Menu } from './Menu';
import { Builder } from "../utils/Builder";
import { ComponentRef } from '@angular/core';
import { DropDownMenu } from './DropDownMenu';
export declare class MenuFactory {
    private builder;
    constructor(builder: Builder);
    create(menu?: Menu): ComponentRef<DropDownMenu>;
}
