import { Form } from '../forms/Form';
import { Application } from "../application/Application";
export declare abstract class MenuHandler {
    private static _id;
    private guid$;
    private __menu__;
    constructor();
    get guid(): number;
    get ready(): boolean;
    get app(): Application;
    enable(menu?: string): void;
    disable(menu?: string): void;
    get connected(): boolean;
    get transaction(): boolean;
    onFormChange(form: Form): void;
    abstract onInit(): void;
    abstract onConnect(): void;
    abstract onDisconnect(): void;
    abstract onTransactionChange(): void;
}
