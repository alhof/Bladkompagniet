import { InstanceID } from "./InstanceID";
import { FormInstance } from "./FormInstance";
import { FormsControl } from "./FormsControl";
import { WindowOptions } from "./WindowOptions";
export declare class InstanceControl {
    private ctrl;
    private utils;
    private forms;
    private futil;
    constructor(ctrl: FormsControl);
    setFormsDefinitions(forms: Map<string, FormInstance>): void;
    getNewInstance(form: any, modal?: WindowOptions): InstanceID;
    getInstance(id: InstanceID): FormInstance;
    closeInstance(id: InstanceID, destroy: boolean): void;
}
