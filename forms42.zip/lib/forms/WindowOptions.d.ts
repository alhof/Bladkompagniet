export interface WindowOptions {
    wizard?: boolean;
    inherit?: boolean;
    width?: string;
    height?: string;
    offsetTop?: string;
    offsetLeft?: string;
}
