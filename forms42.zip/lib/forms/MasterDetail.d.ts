import { Key } from "../blocks/Key";
import { FormImpl } from "./FormImpl";
import { BlockImpl } from "../blocks/BlockImpl";
import { JOINDefinition } from "../annotations/JOINDefinitions";
import { SQL } from "../database/Statement";
export interface dependencies {
    keycols: Set<string>;
    masters?: {
        block: BlockImpl;
        mkey: Key;
        dkey: Key;
    }[];
    details?: {
        block: BlockImpl;
        mkey: Key;
        dkey: Key;
    }[];
}
export declare class MasterDetail {
    private form;
    private master$;
    private waiting;
    private query;
    private blocks;
    private links;
    private defined;
    constructor(form: FormImpl);
    get master(): BlockImpl;
    set master(block: BlockImpl);
    getRoot(block?: BlockImpl): BlockImpl;
    cleardetails(block: BlockImpl): void;
    private clear;
    sync(block: BlockImpl, col: string): void;
    enterquery(block: BlockImpl): void;
    private enterdetailquery;
    clearfilters(block: BlockImpl): void;
    getDetailQuery(): Promise<SQL>;
    private subquery;
    private buildsubquery;
    querydetails(block: BlockImpl, init: boolean, ready: boolean): void;
    done(block: BlockImpl, success: boolean): void;
    finished(): void;
    getKeys(block: BlockImpl): Key[];
    addBlock(block: BlockImpl): void;
    addKeys(block: BlockImpl, keys: Map<string, Key>): void;
    addJoins(joins: JOINDefinition[]): void;
}
