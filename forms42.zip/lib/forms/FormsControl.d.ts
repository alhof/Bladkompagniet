import { FormArea } from "./FormArea";
import { Builder } from "../utils/Builder";
import { ModalWindow } from "./ModalWindow";
import { FormInstance } from "./FormInstance";
import { FormDefinition } from "./FormsDefinition";
import { ComponentRef } from '@angular/core';
import { ApplicationImpl } from "../application/ApplicationImpl";
export declare class FormsControl {
    private app;
    private builder;
    private current;
    private formarea;
    private utils;
    private formlist;
    private forms;
    constructor(app: ApplicationImpl, builder: Builder);
    setFormArea(formarea: FormArea): void;
    setFormsDefinitions(forms: FormDefinition[]): Map<string, FormInstance>;
    findFormByPath(path: string): string;
    getFormsList(): FormInstance[];
    getFormsDefinitions(): Map<string, FormInstance>;
    closeform(form: any, destroy: boolean): void;
    close(formdef: FormInstance, destroy: boolean): void;
    display(formdef: FormInstance): void;
    createWindow(): ModalWindow;
    getFormInstance(form: any): FormInstance;
    createForm(component: any): ComponentRef<any>;
}
