import { Menu } from "../menu/Menu";
import { Block } from "../blocks/Block";
import { keymap } from "../keymap/KeyMap";
import { Trigger } from "../events/Triggers";
import { Theme } from "../application/Themes";
import { Statement } from "../database/Statement";
import { TriggerFunction } from "../events/TriggerFunction";
import { TableDefinition } from "../database/TableDefinition";
import { AfterViewInit, OnInit } from "@angular/core";
import { ListOfValuesFunction } from "../listval/ListOfValuesFunction";
import * as ɵngcc0 from '@angular/core';
export interface CallBack {
    (form: Form, cancel: boolean): void;
}
export declare class Form implements OnInit, AfterViewInit {
    private _impl_;
    constructor();
    get name(): string;
    set title(title: string);
    get title(): string;
    set menu(menu: Menu);
    get menu(): Menu;
    focus(): void;
    get block(): Block;
    get connected(): boolean;
    groupfields(groups: string[]): void;
    get popup(): boolean;
    get colors(): Theme;
    getBlockFilter(block: string): string;
    getRowIndicator(block: string, row: number): string;
    getCurrentRow(block: string): number;
    getCurrentRecord(block: string): number;
    getBlock(block: string): Block;
    addListOfValues(block: string, func: ListOfValuesFunction, field: string, id?: string): void;
    newform(form: any, parameters?: Map<string, any>): void;
    showform(form: any, parameters?: Map<string, any>): void;
    callform(form: any, parameters?: Map<string, any>): Promise<Form>;
    getCallStack(): Form[];
    clearCallStack(): void;
    getTable(block: string): TableDefinition;
    get parameters(): Map<string, any>;
    getValue(block: string, record: number, field: string): any;
    setValue(block: string, record: number, field: string, value: any): Promise<boolean>;
    cancelled(): boolean;
    clear(): Promise<boolean>;
    cancel(): void;
    close(dismiss?: boolean): Promise<void>;
    sendKey(key: keymap): Promise<boolean>;
    setCallback(func: CallBack): void;
    addTrigger(func: TriggerFunction, types?: Trigger | Trigger[]): void;
    addKeyTrigger(func: TriggerFunction, keys?: keymap | keymap[]): void;
    enterquery(force?: boolean): void;
    executequery(force?: boolean): void;
    prevBlock(): void;
    nextBlock(): void;
    execute(stmt: Statement, firstrow?: boolean, firstcolumn?: boolean): Promise<any>;
    addFieldTrigger(listener: TriggerFunction, types: Trigger | Trigger[], fields?: string | string[]): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    alert(message: string, title?: string, width?: string, height?: string): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<Form, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<Form, "ng-component", never, {}, {}, never, never>;
}

//# sourceMappingURL=Form.d.ts.map