export declare enum FormState {
    normal = 0,
    entqry = 1,
    exeqry = 2
}
