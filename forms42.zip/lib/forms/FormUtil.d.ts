import { FormInstance } from "./FormInstance";
import { WindowOptions } from "./WindowOptions";
import { FormDefinition } from "../../public-api";
export declare class FormUtil {
    private utils;
    complete(options: WindowOptions, create?: boolean): WindowOptions;
    convert(form: FormDefinition): FormInstance;
    clone(base: FormInstance): FormInstance;
}
