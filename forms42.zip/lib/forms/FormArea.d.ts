import { Context } from '../application/Context';
import { AfterViewInit } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class FormArea implements AfterViewInit {
    private app;
    private formarea;
    constructor(ctx: Context);
    getFormsArea(): HTMLElement;
    ngAfterViewInit(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FormArea, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<FormArea, "formarea", never, {}, {}, never, never>;
}

//# sourceMappingURL=FormArea.d.ts.map