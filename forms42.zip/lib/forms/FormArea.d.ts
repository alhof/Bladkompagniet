import { Context } from '../application/Context';
import { AfterViewInit } from '@angular/core';
export declare class FormArea implements AfterViewInit {
    private app;
    private formarea;
    constructor(ctx: Context);
    getFormsArea(): HTMLElement;
    ngAfterViewInit(): void;
}
