import { BlockImpl } from "../blocks/BlockImpl";
import { dependencies, MasterDetail } from "./MasterDetail";
export declare class MasterDetailQuery {
    private md;
    private links;
    private root$;
    private finished;
    private detailblks;
    private masterblks;
    constructor(md: MasterDetail, links: Map<string, dependencies>, block: BlockImpl, col?: string);
    get root(): BlockImpl;
    private findblocks;
    waitfor(block: BlockImpl): void;
    ready(block: BlockImpl): void;
    done(block: BlockImpl): void;
    failed(block: BlockImpl): void;
    private remove;
    status(state: string): void;
    private execute;
    private isready;
    private state;
    private details;
}
