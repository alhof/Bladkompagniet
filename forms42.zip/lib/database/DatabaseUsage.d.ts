export declare class DBUsage {
    static merge(changes: DatabaseUsage, base: DatabaseUsage): DatabaseUsage;
    static override(overide: DatabaseUsage, base: DatabaseUsage): DatabaseUsage;
    static complete(base: DatabaseUsage): DatabaseUsage;
}
export interface DatabaseUsage {
    query?: boolean;
    insert?: boolean;
    update?: boolean;
    delete?: boolean;
}
