import { Popup } from "../popup/Popup";
import { Block } from "../blocks/Block";
import { Context } from "../application/Context";
import { PopupWindow } from "../popup/PopupWindow";
import { KeyTriggerEvent } from "../events/TriggerEvent";
import { AfterViewInit, OnInit } from "@angular/core";
export declare class LoginForm extends Block implements Popup, OnInit, AfterViewInit {
    private usr;
    private pwd;
    private win;
    private app;
    top: string;
    left: string;
    width: string;
    height: string;
    tmargin: string;
    title: string;
    constructor(ctx: Context);
    setWin(win: PopupWindow): void;
    close(cancel: boolean): void;
    onEvent(kevent: KeyTriggerEvent): Promise<boolean>;
    ngOnInit(): void;
    ngAfterViewInit(): void;
}
