import { Statement } from "./Statement";
import { ApplicationImpl } from "../application/ApplicationImpl";
export declare class Connection {
    private app;
    private url;
    private conn;
    private keepalive;
    private client;
    private stmtid;
    private waitlim;
    private running;
    constructor(app: ApplicationImpl);
    connect(usr: string, pwd: string): Promise<void>;
    commit(): Promise<boolean>;
    rollback(): Promise<boolean>;
    get connected(): boolean;
    disconnect(): Promise<void>;
    private keepAlive;
    invokestmt(stmt: Statement): Promise<any>;
    invoke(cmd: string, body: any): Promise<any>;
    private onReply;
    private alert;
    private showwait;
}
