import { Column } from "./Column";
export interface BindValue {
    value: any;
    name: string;
    type: Column;
}
