export declare enum Column {
    int = 0,
    date = 1,
    decimal = 2,
    integer = 3,
    varchar = 4,
    datetime = 5
}
