import { Column } from "./Column";
import { Condition } from "./Condition";
export declare enum SQLType {
    call = 0,
    lock = 1,
    select = 2,
    insert = 3,
    update = 4,
    delete = 5
}
export interface SQL {
    sql: string;
    rows?: number;
    cursor?: string;
    bindvalues: bindvalue[];
}
export interface bindvalue {
    value: any;
    name: string;
    type: string;
}
export declare class Statement {
    private sql$;
    private rows$;
    private subquery$;
    private table$;
    private order$;
    private limit$;
    private type$;
    private cursor$;
    private columns$;
    private errors;
    private override;
    private constraint$;
    private updates$;
    private condition$;
    private bindvalues;
    constructor(sql: string | SQLType);
    private findtype;
    set type(type: SQLType);
    get type(): SQLType;
    get sql(): string;
    set sql(sql: string);
    rows(rows: number): Statement;
    isFunction(): boolean;
    isSelect(): boolean;
    isInsert(): boolean;
    isUpdate(): boolean;
    isDelete(): boolean;
    set table(table: string);
    set limit(limit: string);
    set constraint(where: string);
    set order(order: string);
    set cursor(cursor: string);
    get cursor(): string;
    update(name: string, value: any, datatype?: Column): void;
    set columns(columns: string | string[]);
    setCondition(condition: Condition | Condition[]): void;
    pop(): Statement;
    push(): Statement;
    where(column: string, value: any, datatype?: Column): Statement;
    whand(column: string, value: any, datatype?: Column): Statement;
    and(column: string, value: any, datatype?: Column): Statement;
    or(column: string, value: any, datatype?: Column): Statement;
    returnvalue(column: string, datatype?: Column): Statement;
    bind(column: string, value: any, datatype?: Column): Statement;
    get subquery(): SQL;
    set subquery(subquery: SQL);
    validate(): string[];
    getCondition(): Condition;
    build(): SQL;
    private buildcall;
    private buildinsert;
    private buildupdate;
    private builddelete;
    private buildselect;
}
