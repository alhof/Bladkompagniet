export declare enum Case {
    upper = 0,
    lower = 1,
    mixed = 2
}
