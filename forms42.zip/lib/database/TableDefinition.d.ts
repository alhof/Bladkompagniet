export interface TableDefinition {
    name: string;
    where?: string;
    order?: string;
    limit?: string;
}
