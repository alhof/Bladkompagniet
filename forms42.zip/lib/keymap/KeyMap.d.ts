export interface Key {
    code: number;
    name?: string;
    alt?: boolean;
    ctrl?: boolean;
    meta?: boolean;
    shift?: boolean;
}
export interface KeyMap {
    enter: string;
    escape: string;
    undo: string;
    paste: string;
    zoom: string;
    close: string;
    listval: string;
    delete: string;
    dublicate: string;
    insertafter: string;
    insertbefore: string;
    commit: string;
    rollback: string;
    connect: string;
    disconnect: string;
    nextfield: string;
    prevfield: string;
    nextblock: string;
    prevblock: string;
    nextrecord: string;
    prevrecord: string;
    pageup: string;
    pagedown: string;
    clearform: string;
    clearblock: string;
    enterquery: string;
    executequery: string;
    map: string;
}
export declare enum keymap {
    enter = 0,
    escape = 1,
    undo = 2,
    paste = 3,
    close = 4,
    listval = 5,
    delete = 6,
    dublicate = 7,
    insertafter = 8,
    insertbefore = 9,
    commit = 10,
    rollback = 11,
    connect = 12,
    disconnect = 13,
    nextfield = 14,
    prevfield = 15,
    nextblock = 16,
    prevblock = 17,
    nextrecord = 18,
    prevrecord = 19,
    pageup = 20,
    pagedown = 21,
    clearform = 22,
    clearblock = 23,
    enterquery = 24,
    executequery = 25,
    zoom = 26
}
export declare class KeyMapper {
    private static keys;
    static index(map: KeyMap): void;
    static keymap(key: string): keymap;
    static map(key: Key): string;
    static parse(key: string): Key;
}
