export declare class KeyCodes {
    static backspace: number;
    static tab: number;
    static enter: number;
    static escape: number;
    static pageup: number;
    static pagedown: number;
    static end: number;
    static home: number;
    static up: number;
    static down: number;
    static left: number;
    static right: number;
    static insert: number;
    static delete: number;
    static f1: number;
    static f2: number;
    static f3: number;
    static f4: number;
    static f5: number;
    static f6: number;
    static f7: number;
    static f8: number;
    static f9: number;
    static f10: number;
    static f11: number;
    static f12: number;
}
