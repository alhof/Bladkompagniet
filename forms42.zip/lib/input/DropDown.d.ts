import { TextField } from './TextField';
export declare class DropDown extends TextField {
    get html(): string;
    focus(): void;
}
