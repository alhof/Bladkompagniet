import { Column } from "../database/Column";
export declare enum FieldType {
    date = 0,
    text = 1,
    radio = 2,
    integer = 3,
    decimal = 4,
    checkbox = 5,
    datetime = 6,
    password = 7,
    dropdown = 8
}
export declare class FieldImplementation {
    private static impl;
    private static init;
    static getClass(type: string): any;
    static guess(type: Column): FieldType;
}
export interface FieldInterface {
    value: any;
    html: string;
    size: number;
    enable: boolean;
    tabindex: number;
    readonly: boolean;
    element: HTMLElement;
    focus(): void;
    validate(): boolean;
}
