import { TextField } from "./TextField";
export declare class DateField extends TextField {
    private dateval;
    private formatted;
    get value(): any;
    set value(value: any);
    validate(): boolean;
}
