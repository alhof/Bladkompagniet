import { TextField } from './TextField';
export declare class Password extends TextField {
    get html(): string;
}
