import { FieldInterface } from "./FieldType";
export declare class TextField implements FieldInterface {
    element$: HTMLInputElement;
    get html(): string;
    set size(size: number);
    get tabindex(): number;
    get element(): HTMLElement;
    set tabindex(seq: number);
    set element(element: HTMLElement);
    get enable(): boolean;
    set enable(flag: boolean);
    get readonly(): boolean;
    set readonly(flag: boolean);
    get value(): any;
    set value(value: any);
    focus(): void;
    validate(): boolean;
}
