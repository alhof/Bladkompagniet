import { TextField } from './TextField';
export declare class CheckBox extends TextField {
    private actvalue;
    private chkvalue;
    get html(): string;
    get value(): any;
    set value(value: any);
}
