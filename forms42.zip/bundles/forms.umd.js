(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common/http'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('forms', ['exports', '@angular/core', '@angular/common/http', '@angular/common'], factory) :
    (global = global || self, factory(global.forms = {}, global.ng.core, global.ng.common.http, global.ng.common));
}(this, (function (exports, i0, i1, common) { 'use strict';

    var Utils = /** @class */ (function () {
        function Utils() {
        }
        Utils.prototype.getName = function (component) {
            if (component == null)
                return (null);
            var name = component.constructor.name;
            if (name == "String")
                name = component;
            if (name == "Function")
                name = component.name;
            return (name.toLowerCase());
        };
        Utils.prototype.clone = function (obj) {
            var clone = {};
            if (obj == null)
                return (null);
            Object.keys(obj).forEach(function (key) { clone[key] = obj[key]; });
            return (clone);
        };
        Utils.prototype.getType = function (component) {
            var type = null;
            var code = component.toString();
            if (code == "[object Object]")
                code = component.constructor.toString();
            if (code.startsWith("class")) {
                code = code.substring(0, code.indexOf("{"));
                var pos = code.indexOf("extends");
                if (pos > 0) {
                    var pos1 = code.indexOf("[", pos);
                    var pos2 = code.indexOf("]", pos1);
                    type = code.substring(pos1 + 2, pos2 - 1);
                }
            }
            return (type);
        };
        Utils.prototype.getParams = function (func) {
            var code = func.toString();
            code = code.replace(/\/\*[\s\S]*?\*\//g, '')
                .replace(/\/\/(.)*/g, '')
                .replace(/{[\s\S]*}/, '')
                .replace(/=>/g, '')
                .trim();
            var end = code.length - 1;
            var start = code.indexOf("(") + 1;
            var params = [];
            var tokens = code.substring(start, end).split(", ");
            tokens.forEach(function (element) {
                // Removing any default value
                element = element.replace(/=[\s\S]*/g, '').trim();
                if (element.length > 0)
                    params.push(element);
            });
            return (params);
        };
        return Utils;
    }());

    var BlockDefinitions = /** @class */ (function () {
        function BlockDefinitions() {
        }
        BlockDefinitions.setDefaultAlias = function (block, alias) {
            if (alias == null)
                alias = block;
            BlockDefinitions.alias.set(block, alias);
        };
        BlockDefinitions.getDefaultAlias = function (alias) {
            alias = alias.toLowerCase();
            var bname = BlockDefinitions.alias.get(alias);
            if (bname == null)
                bname = alias;
            return (bname);
        };
        BlockDefinitions.setBlock = function (form, def) {
            var blocks = BlockDefinitions.blocks.get(form.toLowerCase());
            if (blocks == null) {
                blocks = [];
                BlockDefinitions.blocks.set(form.toLowerCase(), blocks);
            }
            if (def.prop != null)
                blocks.push(def);
            else
                blocks.unshift(def);
        };
        BlockDefinitions.getBlocks = function (form) {
            var blocks = BlockDefinitions.blocks.get(form.toLowerCase());
            if (blocks == null)
                blocks = [];
            return (blocks);
        };
        BlockDefinitions.setKey = function (block, def) {
            var keys = BlockDefinitions.keys.get(block.toLowerCase());
            if (keys == null) {
                keys = [];
                BlockDefinitions.keys.set(block.toLowerCase(), keys);
            }
            keys.unshift(def);
        };
        BlockDefinitions.getKeys = function (block) {
            var keys = BlockDefinitions.keys.get(block.toLowerCase());
            if (keys == null)
                keys = [];
            return (keys);
        };
        return BlockDefinitions;
    }());
    BlockDefinitions.alias = new Map();
    BlockDefinitions.blocks = new Map();
    BlockDefinitions.keys = new Map();

    var key = function (name, unique, columns) {
        function define(comp) {
            var utils = new Utils();
            var cname = utils.getName(comp);
            var ctype = utils.getType(comp);
            if (ctype != "Block") {
                console.log("@key(" + name + ") can only be used on blocks");
                return;
            }
            var arr = true;
            var cols = [];
            if (columns.constructor.name == "String")
                arr = false;
            if (arr)
                cols = columns;
            else
                cols.push(columns);
            var lccols = [];
            cols.forEach(function (col) { lccols.push(col.toLowerCase()); });
            var def = { name: name.toLowerCase(), unique: unique, columns: lccols };
            BlockDefinitions.setKey(cname, def);
        }
        return (define);
    };

    var FormDefinitions = /** @class */ (function () {
        function FormDefinitions() {
        }
        FormDefinitions.setForm = function (def) {
            FormDefinitions.forms.unshift(def);
        };
        FormDefinitions.getForms = function () {
            return (FormDefinitions.forms);
        };
        FormDefinitions.getWindowOpts = function (form) {
            var wopts = FormDefinitions.windowopts.get(form);
            if (wopts == null) {
                wopts = {};
                FormDefinitions.windowopts.set(form, wopts);
            }
            return (wopts);
        };
        FormDefinitions.setOnInit = function (form, func) {
            var funcs = FormDefinitions.oninit.get(form);
            if (funcs == null)
                funcs = [];
            funcs.push(func);
            FormDefinitions.oninit.set(form, funcs);
        };
        FormDefinitions.setOnShow = function (form, func) {
            var funcs = FormDefinitions.onshow.get(form);
            if (funcs == null)
                funcs = [];
            funcs.push(func);
            FormDefinitions.onshow.set(form, funcs);
        };
        FormDefinitions.setOnHide = function (form, func) {
            var funcs = FormDefinitions.onhide.get(form);
            if (funcs == null)
                funcs = [];
            funcs.push(func);
            FormDefinitions.onhide.set(form, funcs);
        };
        FormDefinitions.setOnConnect = function (form, func) {
            var funcs = FormDefinitions.onconn.get(form);
            if (funcs == null)
                funcs = [];
            funcs.push(func);
            FormDefinitions.onconn.set(form, funcs);
        };
        FormDefinitions.setOnDisconnect = function (form, func) {
            var funcs = FormDefinitions.ondisc.get(form);
            if (funcs == null)
                funcs = [];
            funcs.push(func);
            FormDefinitions.ondisc.set(form, funcs);
        };
        FormDefinitions.setOnDestroy = function (form, func) {
            var funcs = FormDefinitions.ondest.get(form);
            if (funcs == null)
                funcs = [];
            funcs.push(func);
            FormDefinitions.ondest.set(form, funcs);
        };
        FormDefinitions.getOnInit = function (form) {
            var funcs = FormDefinitions.oninit.get(form);
            if (funcs == null)
                funcs = [];
            return (funcs);
        };
        FormDefinitions.getOnShow = function (form) {
            var funcs = FormDefinitions.onshow.get(form);
            if (funcs == null)
                funcs = [];
            return (funcs);
        };
        FormDefinitions.getOnHide = function (form) {
            var funcs = FormDefinitions.onhide.get(form);
            if (funcs == null)
                funcs = [];
            return (funcs);
        };
        FormDefinitions.getOnConnect = function (form) {
            var funcs = FormDefinitions.onconn.get(form);
            if (funcs == null)
                funcs = [];
            return (funcs);
        };
        FormDefinitions.getOnDisconnect = function (form) {
            var funcs = FormDefinitions.ondisc.get(form);
            if (funcs == null)
                funcs = [];
            return (funcs);
        };
        FormDefinitions.getOnDestroy = function (form) {
            var funcs = FormDefinitions.ondest.get(form);
            if (funcs == null)
                funcs = [];
            return (funcs);
        };
        return FormDefinitions;
    }());
    FormDefinitions.forms = [];
    FormDefinitions.oninit = new Map();
    FormDefinitions.onshow = new Map();
    FormDefinitions.onhide = new Map();
    FormDefinitions.onconn = new Map();
    FormDefinitions.ondisc = new Map();
    FormDefinitions.ondest = new Map();
    FormDefinitions.windowopts = new Map();

    var form = function (component, title, path, navigable) {
        function define(_comp) {
            var def = {
                path: path,
                title: title,
                component: component,
            };
            if (navigable != undefined)
                def["navigable"] = navigable;
            FormDefinitions.setForm(def);
        }
        return (define);
    };

    var init = function (form, func) {
        var utils = new Utils();
        var fname = utils.getName(form);
        var ctype = utils.getType(form);
        if (ctype != "Form") {
            console.log("@init can only be used on forms, found on '" + fname + "'");
            return;
        }
        FormDefinitions.setOnInit(fname, func);
    };

    var show = function (form, func) {
        var utils = new Utils();
        var fname = utils.getName(form);
        var ctype = utils.getType(form);
        if (ctype != "Form") {
            console.log("@show can only be used on forms, found on '" + fname + "'");
            return;
        }
        FormDefinitions.setOnShow(fname, func);
    };

    var hide = function (form, func) {
        var utils = new Utils();
        var fname = utils.getName(form);
        var ctype = utils.getType(form);
        if (ctype != "Form") {
            console.log("@hide can only be used on forms, found on '" + fname + "'");
            return;
        }
        FormDefinitions.setOnHide(fname, func);
    };

    var JOINDefinitions = /** @class */ (function () {
        function JOINDefinitions() {
        }
        JOINDefinitions.add = function (form, def) {
            var joins = JOINDefinitions.defs.get(form);
            if (joins == null) {
                joins = [];
                JOINDefinitions.defs.set(form, joins);
            }
            joins.unshift(def);
        };
        JOINDefinitions.get = function (form) {
            return (JOINDefinitions.defs.get(form.toLowerCase()));
        };
        return JOINDefinitions;
    }());
    JOINDefinitions.defs = new Map();

    var join = function (definition) {
        function define(comp) {
            var utils = new Utils();
            var form = utils.getName(comp);
            var ctype = utils.getType(comp);
            if (ctype != "Form") {
                console.log("@join(" + JSON.stringify(definition) + ") can only be used on forms");
                return;
            }
            definition.master.key = definition.master.key.toLowerCase();
            definition.master.alias = definition.master.alias.toLowerCase();
            definition.detail.key = definition.detail.key.toLowerCase();
            definition.detail.alias = definition.detail.alias.toLowerCase();
            JOINDefinitions.add(form.toLowerCase(), definition);
        }
        return (define);
    };

    var block = function (definition) {
        function define(comp, prop) {
            var utils = new Utils();
            var name = utils.getName(comp);
            var type = utils.getType(comp);
            if (type != "Form" && prop == null) {
                console.log("@block can only be used with forms");
                return;
            }
            if (definition.alias != null)
                definition.alias = definition.alias.toLowerCase();
            var def = {
                prop: prop,
                alias: definition.alias,
                component: definition.component,
                databaseopts: definition.databaseopts
            };
            BlockDefinitions.setBlock(name, def);
        }
        return (define);
    };

    var alias = function (alias) {
        function define(comp) {
            var utils = new Utils();
            var cname = utils.getName(comp);
            var ctype = utils.getType(comp);
            if (ctype != "Block") {
                console.log("@alias(" + alias + ") can only be used on blocks");
                return;
            }
            if (alias == null) {
                console.log("@alias(" + alias + ") cannot be null");
                return;
            }
            BlockDefinitions.setDefaultAlias(cname, alias.toLowerCase());
        }
        return (define);
    };

    var TableDefinitions = /** @class */ (function () {
        function TableDefinitions() {
        }
        TableDefinitions.set = function (block, table) {
            var def = TableDefinitions.index.get(block.toLowerCase());
            if (def != null) {
                if (table.hasOwnProperty("name"))
                    def.name = table.name;
                if (table.hasOwnProperty("order"))
                    def.order = table.order;
            }
            else {
                TableDefinitions.index.set(block.toLowerCase(), table);
            }
        };
        TableDefinitions.get = function (block) {
            return (TableDefinitions.index.get(block.toLowerCase()));
        };
        return TableDefinitions;
    }());
    TableDefinitions.index = new Map();

    var table = function (definition) {
        function define(comp) {
            var utils = new Utils();
            var cname = utils.getName(comp);
            var ctype = utils.getType(comp);
            if (ctype != "Block") {
                console.log("@table(" + definition.name + ") can only be used on blocks");
                return;
            }
            TableDefinitions.set(cname, definition);
        }
        return (define);
    };

    var FieldDefinitions = /** @class */ (function () {
        function FieldDefinitions() {
        }
        FieldDefinitions.add = function (form, comp, def) {
            var parts = FieldDefinitions.split(def.name);
            if (form) {
                if (parts.length < 2 || parts.length > 3) {
                    console.log("Form field " + def.name + " must be on the form block.field[.id], field definition ignored");
                    return;
                }
                def.name = parts[1];
                var id = null;
                var block = parts[0];
                if (parts.length > 2)
                    id = parts[2];
                if (id != null)
                    FieldDefinitions.addformid(comp, block, id, def);
                else
                    FieldDefinitions.addformfield(comp, block, def);
            }
            else {
                if (parts.length > 2) {
                    console.log("Block field " + def.name + " must be on the form field[.id], field definition ignored");
                    return;
                }
                var id = null;
                if (parts.length > 1) {
                    id = parts[1];
                    def.name = parts[0];
                }
                if (id != null)
                    FieldDefinitions.addblockid(comp, id, def);
                else
                    FieldDefinitions.addblockfield(comp, def);
            }
        };
        FieldDefinitions.addformfield = function (form, block, def) {
            var formbfd = FieldDefinitions.ffd.get(form);
            var formbfx = FieldDefinitions.ffx.get(form);
            var formbcx = FieldDefinitions.fcx.get(form);
            if (formbfd == null) {
                formbfd = new Map();
                FieldDefinitions.ffd.set(form, formbfd);
                formbfx = new Map();
                FieldDefinitions.ffx.set(form, formbfx);
                formbcx = new Map();
                FieldDefinitions.fcx.set(form, formbcx);
            }
            var fields = formbfd.get(block);
            var index = formbfx.get(block);
            var columns = formbcx.get(block);
            if (fields == null) {
                fields = [];
                formbfd.set(block, fields);
                index = new Map();
                formbfx.set(block, index);
                columns = new Map();
                formbcx.set(block, columns);
            }
            if (index.get(def.name) != null) {
                console.log("Field " + def.name + " defined twice on block '" + form + "." + block + "', ignored");
                return;
            }
            if (columns.get(def.name) != null) {
                console.log("Column " + def.column + " bound to more than 1 field on block '" + form + "." + block + "', ignored");
                def.column = null;
            }
            fields.unshift(def);
            index.set(def.name, def);
            if (def.column != null)
                columns.set(def.column, def);
        };
        FieldDefinitions.addblockfield = function (block, def) {
            var fields = FieldDefinitions.bfd.get(block);
            var index = FieldDefinitions.bfx.get(block);
            var columns = FieldDefinitions.bcx.get(block);
            if (fields == null) {
                fields = [];
                FieldDefinitions.bfd.set(block, fields);
                index = new Map();
                FieldDefinitions.bfx.set(block, index);
                columns = new Map();
                FieldDefinitions.bcx.set(block, columns);
            }
            if (def.hasOwnProperty("column")) {
                if (def.column != null)
                    def.column = def.column.toLowerCase();
            }
            if (index.get(def.name) != null) {
                console.log("Field " + def.name + " defined twice on block '" + block + "', ignored");
                return;
            }
            if (columns.get(def.name) != null) {
                console.log("Column " + def.column + " bound to more than 1 field on block '" + block + "', ignored");
                def.column = null;
            }
            fields.unshift(def);
            index.set(def.name, def);
            if (def.column != null)
                columns.set(def.column, def);
        };
        FieldDefinitions.addformid = function (form, block, id, def) {
            var formids = FieldDefinitions.fidx.get(form);
            if (formids == null) {
                formids = new Map();
                FieldDefinitions.fidx.set(form, formids);
            }
            var blockids = formids.get(block);
            if (blockids == null) {
                blockids = new Map();
                formids.set(block, blockids);
            }
            if (blockids.get(def.name + "." + id) != null) {
                console.log("Field " + form + "." + def.name + "." + id + " defined twice, ignored");
                return;
            }
            if (def.column != null) {
                console.log("Field " + form + "." + def.name + "." + id + " cannot override column definition, ignored");
                def.column = null;
            }
            blockids.set(def.name + "." + id, def);
        };
        FieldDefinitions.addblockid = function (block, id, def) {
            var blockids = FieldDefinitions.bidx.get(block);
            if (blockids == null) {
                blockids = new Map();
                FieldDefinitions.bidx.set(block, blockids);
            }
            if (blockids.get(def.name + "." + id) != null) {
                console.log("Field " + def.name + "." + id + " defined twice, ignored");
                return;
            }
            if (def.column != null) {
                console.log("Field " + def.name + "." + id + " cannot override column definition, ignored");
                def.column = null;
            }
            blockids.set(def.name + "." + id, def);
        };
        FieldDefinitions.getFormFieldOverride = function (form, block, fldid) {
            var formids = FieldDefinitions.fidx.get(form);
            if (formids == null)
                return (null);
            var blockids = formids.get(block.toLowerCase());
            if (blockids != null)
                return (blockids.get(fldid.toLowerCase()));
            return (null);
        };
        FieldDefinitions.getFieldOverride = function (block, fldid) {
            var blockids = FieldDefinitions.bidx.get(block.toLowerCase());
            if (blockids != null)
                return (blockids.get(fldid.toLowerCase()));
            return (null);
        };
        FieldDefinitions.getFormFields = function (form, block) {
            var formbfd = FieldDefinitions.ffd.get(form.toLowerCase());
            if (formbfd == null)
                return ([]);
            var fields = formbfd.get(block.toLowerCase());
            if (fields == null)
                return ([]);
            return (fields);
        };
        FieldDefinitions.getFields = function (block) {
            var fields = FieldDefinitions.bfd.get(block.toLowerCase());
            if (fields == null)
                return ([]);
            return (fields);
        };
        FieldDefinitions.getFormFieldIndex = function (form, block) {
            var formbfx = FieldDefinitions.ffx.get(form.toLowerCase());
            if (formbfx == null)
                return (new Map());
            var index = formbfx.get(block.toLowerCase());
            if (index == null)
                return (new Map());
            return (new Map(index));
        };
        FieldDefinitions.getFieldIndex = function (block) {
            var index = FieldDefinitions.bfx.get(block.toLowerCase());
            if (index == null)
                return (new Map());
            return (new Map(index));
        };
        FieldDefinitions.getFormColumnIndex = function (form, block) {
            var formbcx = FieldDefinitions.fcx.get(form.toLowerCase());
            if (formbcx == null)
                return (new Map());
            var index = formbcx.get(block.toLowerCase());
            if (index == null)
                return (new Map());
            return (new Map(index));
        };
        FieldDefinitions.getColumnIndex = function (block) {
            var index = FieldDefinitions.bcx.get(block.toLowerCase());
            if (index == null)
                index = new Map();
            return (new Map(index));
        };
        FieldDefinitions.split = function (name) {
            var tokens = name.split(".");
            for (var i = 0; i < tokens.length; i++)
                tokens[i] = tokens[i].trim().toLowerCase();
            return (tokens);
        };
        return FieldDefinitions;
    }());
    // List and indexes for fields, columns and fields with id, respectively for form
    FieldDefinitions.bfd = new Map();
    FieldDefinitions.bfx = new Map();
    FieldDefinitions.bcx = new Map();
    FieldDefinitions.bidx = new Map();
    FieldDefinitions.ffd = new Map();
    FieldDefinitions.ffx = new Map();
    FieldDefinitions.fcx = new Map();
    FieldDefinitions.fidx = new Map();

    var field = function (definition) {
        function define(comp) {
            var form = false;
            var utils = new Utils();
            var cname = utils.getName(comp);
            var ctype = utils.getType(comp);
            if (ctype != "Block" && ctype != "Form") {
                console.log("@field(" + JSON.stringify(definition) + ") can only be used on blocks and forms");
                return;
            }
            if (ctype == "Form")
                form = true;
            FieldDefinitions.add(form, cname, definition);
        }
        return (define);
    };

    var ColumnDefinitions = /** @class */ (function () {
        function ColumnDefinitions() {
        }
        ColumnDefinitions.add = function (block, def) {
            var columns = ColumnDefinitions.bcols.get(block);
            var index = ColumnDefinitions.bcidx.get(block);
            if (columns == null) {
                columns = [];
                ColumnDefinitions.bcols.set(block, columns);
                index = new Map();
                ColumnDefinitions.bcidx.set(block, index);
            }
            if (index.get(def.name) != null) {
                console.log("Block " + block + " column " + def.name + " defined twice, ignored");
                return;
            }
            columns.unshift(def);
            index.set(def.name, def);
        };
        ColumnDefinitions.get = function (block) {
            var columns = ColumnDefinitions.bcols.get(block.toLowerCase());
            if (columns == null)
                columns = [];
            return (columns);
        };
        ColumnDefinitions.getIndex = function (block) {
            var index = ColumnDefinitions.bcidx.get(block.toLowerCase());
            if (index == null)
                index = new Map();
            return (index);
        };
        return ColumnDefinitions;
    }());
    ColumnDefinitions.bcols = new Map();
    ColumnDefinitions.bcidx = new Map();

    var column = function (definition) {
        function define(comp) {
            var utils = new Utils();
            var cname = utils.getName(comp);
            var ctype = utils.getType(comp);
            if (ctype != "Block") {
                console.log("@column(" + definition.name + "," + definition.type + ") can only be used on blocks");
                return;
            }
            ColumnDefinitions.add(cname, definition);
            definition.name = definition.name.toLowerCase();
        }
        return (define);
    };

    var wizard = function () {
        function define(form) {
            var utils = new Utils();
            var fname = utils.getName(form);
            var ctype = utils.getType(form);
            if (ctype != "Form") {
                console.log("@wizard can only be used on forms");
                return;
            }
            var wopt = FormDefinitions.getWindowOpts(fname);
            wopt.wizard = true;
        }
        return (define);
    };

    var window$1 = function (inherit, width, height, top, left) {
        function define(form) {
            var utils = new Utils();
            var fname = utils.getName(form);
            var ctype = utils.getType(form);
            if (ctype != "Form") {
                console.log("@window can only be used on forms");
                return;
            }
            if (top != null && top.constructor.name == "Number")
                top += "px";
            if (left != null && left.constructor.name == "Number")
                left += "px";
            if (width != null && width.constructor.name == "Number")
                width += "px";
            if (height != null && height.constructor.name == "Number")
                height += "px";
            var wopt = FormDefinitions.getWindowOpts(fname);
            wopt.inherit = inherit;
            wopt.offsetTop = "" + top;
            wopt.width = "" + width;
            wopt.height = "" + height;
            wopt.offsetLeft = "" + left;
        }
        return (define);
    };

    var connect = function (form, func) {
        var utils = new Utils();
        var fname = utils.getName(form);
        var ctype = utils.getType(form);
        if (ctype != "Form") {
            console.log("@connect can only be used on forms, found on '" + fname + "'");
            return;
        }
        FormDefinitions.setOnConnect(fname, func);
    };

    var destroy = function (form, func) {
        var utils = new Utils();
        var fname = utils.getName(form);
        var ctype = utils.getType(form);
        if (ctype != "Form") {
            console.log("@destroy can only be used on forms, found on '" + fname + "'");
            return;
        }
        FormDefinitions.setOnDestroy(fname, func);
    };

    (function (keymap) {
        keymap[keymap["enter"] = 0] = "enter";
        keymap[keymap["escape"] = 1] = "escape";
        keymap[keymap["undo"] = 2] = "undo";
        keymap[keymap["paste"] = 3] = "paste";
        keymap[keymap["close"] = 4] = "close";
        keymap[keymap["listval"] = 5] = "listval";
        keymap[keymap["delete"] = 6] = "delete";
        keymap[keymap["dublicate"] = 7] = "dublicate";
        keymap[keymap["insertafter"] = 8] = "insertafter";
        keymap[keymap["insertbefore"] = 9] = "insertbefore";
        keymap[keymap["commit"] = 10] = "commit";
        keymap[keymap["rollback"] = 11] = "rollback";
        keymap[keymap["connect"] = 12] = "connect";
        keymap[keymap["disconnect"] = 13] = "disconnect";
        keymap[keymap["nextfield"] = 14] = "nextfield";
        keymap[keymap["prevfield"] = 15] = "prevfield";
        keymap[keymap["nextblock"] = 16] = "nextblock";
        keymap[keymap["prevblock"] = 17] = "prevblock";
        keymap[keymap["nextrecord"] = 18] = "nextrecord";
        keymap[keymap["prevrecord"] = 19] = "prevrecord";
        keymap[keymap["pageup"] = 20] = "pageup";
        keymap[keymap["pagedown"] = 21] = "pagedown";
        keymap[keymap["clearform"] = 22] = "clearform";
        keymap[keymap["clearblock"] = 23] = "clearblock";
        keymap[keymap["enterquery"] = 24] = "enterquery";
        keymap[keymap["executequery"] = 25] = "executequery";
        keymap[keymap["zoom"] = 26] = "zoom";
    })(exports.keymap || (exports.keymap = {}));
    var KeyMapper = /** @class */ (function () {
        function KeyMapper() {
        }
        KeyMapper.index = function (map) {
            Object.keys(map).forEach(function (key) {
                var val = map[key];
                var km = exports.keymap[key];
                KeyMapper.keys.set(val, km);
            });
        };
        KeyMapper.keymap = function (key) {
            return (KeyMapper.keys.get(key));
        };
        KeyMapper.map = function (key) {
            var sig = key.code + ":";
            sig += key.shift ? "t" : "f";
            sig += key.ctrl ? "t" : "f";
            sig += key.alt ? "t" : "f";
            sig += key.meta ? "t" : "f";
            return (sig);
        };
        KeyMapper.parse = function (key) {
            var pos = key.indexOf(":");
            var shf = key[pos + 1] == 't';
            var ctl = key[pos + 2] == 't';
            var alt = key[pos + 3] == 't';
            var mta = key[pos + 4] == 't';
            var code = +key.substring(0, pos);
            return ({ code: code, shift: shf, ctrl: ctl, alt: alt, meta: mta });
        };
        return KeyMapper;
    }());
    KeyMapper.keys = new Map();

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from) {
        for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
            to[j] = from[i];
        return to;
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }
    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    var TriggerEvents = /** @class */ (function () {
        function TriggerEvents() {
            this.types = new Map();
            this.fields = new Map();
        }
        return TriggerEvents;
    }());

    (function (Trigger) {
        Trigger[Trigger["Key"] = 0] = "Key";
        Trigger[Trigger["Lock"] = 1] = "Lock";
        Trigger[Trigger["Typing"] = 2] = "Typing";
        Trigger[Trigger["MouseClick"] = 3] = "MouseClick";
        Trigger[Trigger["MouseDoubleClick"] = 4] = "MouseDoubleClick";
        Trigger[Trigger["PreField"] = 5] = "PreField";
        Trigger[Trigger["PostField"] = 6] = "PostField";
        Trigger[Trigger["PostChange"] = 7] = "PostChange";
        Trigger[Trigger["KeyPrevField"] = 8] = "KeyPrevField";
        Trigger[Trigger["KeyNextField"] = 9] = "KeyNextField";
        Trigger[Trigger["KeyPrevBlock"] = 10] = "KeyPrevBlock";
        Trigger[Trigger["KeyNextBlock"] = 11] = "KeyNextBlock";
        Trigger[Trigger["KeyEnterQuery"] = 12] = "KeyEnterQuery";
        Trigger[Trigger["KeyExecuteQuery"] = 13] = "KeyExecuteQuery";
        Trigger[Trigger["WhenValidateField"] = 14] = "WhenValidateField";
        Trigger[Trigger["WhenValidateRecord"] = 15] = "WhenValidateRecord";
        Trigger[Trigger["PreQuery"] = 16] = "PreQuery";
        Trigger[Trigger["PostQuery"] = 17] = "PostQuery";
        Trigger[Trigger["PreInsert"] = 18] = "PreInsert";
        Trigger[Trigger["PreUpdate"] = 19] = "PreUpdate";
        Trigger[Trigger["PreDelete"] = 20] = "PreDelete";
    })(exports.Trigger || (exports.Trigger = {}));
    (function (FieldTrigger) {
        FieldTrigger[FieldTrigger["Key"] = 0] = "Key";
        FieldTrigger[FieldTrigger["Typing"] = 1] = "Typing";
        FieldTrigger[FieldTrigger["MouseClick"] = 2] = "MouseClick";
        FieldTrigger[FieldTrigger["MouseDoubleClick"] = 3] = "MouseDoubleClick";
        FieldTrigger[FieldTrigger["PreField"] = 4] = "PreField";
        FieldTrigger[FieldTrigger["PostField"] = 5] = "PostField";
        FieldTrigger[FieldTrigger["PostChange"] = 6] = "PostChange";
        FieldTrigger[FieldTrigger["WhenValidateField"] = 7] = "WhenValidateField";
        FieldTrigger[FieldTrigger["WhenValidateRecord"] = 8] = "WhenValidateRecord";
    })(exports.FieldTrigger || (exports.FieldTrigger = {}));
    var Triggers = /** @class */ (function () {
        function Triggers() {
            this.triggers = new TriggerEvents();
        }
        Triggers.init = function () {
            if (Triggers.fieldtriggers == null) {
                Triggers.fieldtriggers = new Set();
                Object.keys(exports.FieldTrigger).forEach(function (type) {
                    if (isNaN(Number(type)))
                        Triggers.fieldtriggers.add(type);
                });
            }
        };
        Triggers.prototype.addTrigger = function (instance, func, ttypes, tfields, tkeys) {
            var _this = this;
            var keys = [];
            var fields = [];
            var types = [];
            var tasa = false;
            if (ttypes.constructor.name == "Array")
                tasa = true;
            if (tasa)
                types = ttypes;
            else
                types.push(ttypes);
            if (tfields != null) {
                var fasa = false;
                if (tfields.constructor.name == "Array")
                    fasa = true;
                if (fasa)
                    fields = tfields;
                else
                    fields.push(tfields);
            }
            if (tkeys != null) {
                var kasa = false;
                if (tkeys.constructor.name == "Array")
                    kasa = true;
                if (kasa)
                    keys = tkeys;
                else
                    keys.push(tkeys);
            }
            if (fields.length > 0) {
                fields.forEach(function (field) {
                    field = field.toLowerCase();
                    var triggers = _this.triggers.fields.get(field);
                    if (triggers == null) {
                        triggers = new Map();
                        _this.triggers.fields.set(field, triggers);
                    }
                    types.forEach(function (type) {
                        if (type == exports.Trigger.Key) {
                            keys.forEach(function (key) {
                                var code = _this.keycode(key);
                                var lsnrs = triggers.get(code);
                                if (lsnrs == null) {
                                    lsnrs = [];
                                    triggers.set(code, lsnrs);
                                }
                                lsnrs.push({ inst: instance, func: func });
                            });
                        }
                        else if (_this.isFieldTrigger(type)) {
                            var name = _this.trgname(type);
                            var lsnrs = triggers.get(name);
                            if (lsnrs == null) {
                                lsnrs = [];
                                triggers.set(name, lsnrs);
                            }
                            lsnrs.push({ inst: instance, func: func });
                        }
                    });
                });
            }
            else {
                types.forEach(function (type) {
                    if (type == exports.Trigger.Key) {
                        keys.forEach(function (key) {
                            var code = _this.keycode(key);
                            var lsnrs = _this.triggers.types.get(code);
                            if (lsnrs == null) {
                                lsnrs = [];
                                _this.triggers.types.set(code, lsnrs);
                            }
                            lsnrs.push({ inst: instance, func: func });
                        });
                    }
                    else {
                        var name = _this.trgname(type);
                        var lsnrs = _this.triggers.types.get(name);
                        if (lsnrs == null) {
                            lsnrs = [];
                            _this.triggers.types.set(name, lsnrs);
                        }
                        lsnrs.push({ inst: instance, func: func });
                    }
                });
            }
        };
        Triggers.prototype.invokeTriggers = function (type, event, key) {
            return __awaiter(this, void 0, void 0, function () {
                var code, lsnrs, i, name, lsnrs, i;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            event["type$"] = type;
                            if (!(type == exports.Trigger.Key && key != null)) return [3 /*break*/, 5];
                            code = this.keycode(key);
                            lsnrs = this.triggers.types.get(code);
                            if (!(lsnrs != null)) return [3 /*break*/, 4];
                            i = 0;
                            _a.label = 1;
                        case 1:
                            if (!(i < lsnrs.length)) return [3 /*break*/, 4];
                            return [4 /*yield*/, this.execfunc(lsnrs[i], event)];
                        case 2:
                            if (!(_a.sent()))
                                return [2 /*return*/, (false)];
                            _a.label = 3;
                        case 3:
                            i++;
                            return [3 /*break*/, 1];
                        case 4: return [3 /*break*/, 9];
                        case 5:
                            name = this.trgname(type);
                            lsnrs = this.triggers.types.get(name);
                            if (!(lsnrs != null)) return [3 /*break*/, 9];
                            i = 0;
                            _a.label = 6;
                        case 6:
                            if (!(i < lsnrs.length)) return [3 /*break*/, 9];
                            return [4 /*yield*/, this.execfunc(lsnrs[i], event)];
                        case 7:
                            if (!(_a.sent()))
                                return [2 /*return*/, (false)];
                            _a.label = 8;
                        case 8:
                            i++;
                            return [3 /*break*/, 6];
                        case 9: return [2 /*return*/, (true)];
                    }
                });
            });
        };
        Triggers.prototype.invokeFieldTriggers = function (type, field, event, key) {
            return __awaiter(this, void 0, void 0, function () {
                var triggers, code, lsnrs, i, name, lsnrs, i;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            triggers = this.triggers.fields.get(field);
                            if (triggers == null)
                                return [2 /*return*/, (this.invokeTriggers(type, event, key))];
                            event["type$"] = type;
                            if (!(type == exports.Trigger.Key && key != null)) return [3 /*break*/, 5];
                            code = this.keycode(key);
                            lsnrs = triggers.get(code);
                            if (!(lsnrs != null)) return [3 /*break*/, 4];
                            i = 0;
                            _a.label = 1;
                        case 1:
                            if (!(i < lsnrs.length)) return [3 /*break*/, 4];
                            return [4 /*yield*/, this.execfunc(lsnrs[i], event)];
                        case 2:
                            if (!(_a.sent()))
                                return [2 /*return*/, (false)];
                            _a.label = 3;
                        case 3:
                            i++;
                            return [3 /*break*/, 1];
                        case 4: return [3 /*break*/, 9];
                        case 5:
                            name = this.trgname(type);
                            lsnrs = triggers.get(name);
                            if (!(lsnrs != null)) return [3 /*break*/, 9];
                            i = 0;
                            _a.label = 6;
                        case 6:
                            if (!(i < lsnrs.length)) return [3 /*break*/, 9];
                            return [4 /*yield*/, this.execfunc(lsnrs[i], event)];
                        case 7:
                            if (!(_a.sent()))
                                return [2 /*return*/, (false)];
                            _a.label = 8;
                        case 8:
                            i++;
                            return [3 /*break*/, 6];
                        case 9: return [2 /*return*/, (this.invokeTriggers(type, event, key))];
                    }
                });
            });
        };
        Triggers.prototype.execfunc = function (lsnr, event) {
            return __awaiter(this, void 0, void 0, function () {
                var error_1;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            _a.trys.push([0, 2, , 3]);
                            return [4 /*yield*/, lsnr.inst[lsnr.func.name](event)];
                        case 1: return [2 /*return*/, (_a.sent())];
                        case 2:
                            error_1 = _a.sent();
                            console.log(error_1);
                            return [2 /*return*/, (false)];
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        Triggers.prototype.isFieldTrigger = function (trigger) {
            Triggers.init();
            return (Triggers.fieldtriggers.has(exports.Trigger[trigger]));
        };
        Triggers.prototype.trgname = function (trigger) {
            return (exports.Trigger[trigger].toLowerCase());
        };
        Triggers.prototype.keycode = function (key) {
            return (exports.keymap[key].toLowerCase());
        };
        return Triggers;
    }());
    Triggers.fieldtriggers = null;

    var TriggerDefinitions = /** @class */ (function () {
        function TriggerDefinitions() {
        }
        TriggerDefinitions.add = function (isblock, cname, def) {
            if (def.key == null)
                this.addft(isblock, cname, def);
            else
                this.addkt(isblock, cname, def);
        };
        TriggerDefinitions.addkt = function (isblock, cname, def) {
            if (isblock)
                TriggerDefinitions.addKeyTrigger(cname, def);
            else
                TriggerDefinitions.addFormKeyTrigger(cname, def);
        };
        TriggerDefinitions.addft = function (isblock, cname, def) {
            var parts = TriggerDefinitions.split(def.field);
            if (isblock && parts.length > 1) {
                console.log("trigger must specify field without '.' or ' '");
                return;
            }
            if (!isblock && parts.length > 2) {
                console.log("trigger must specify blockalias.field without ' '");
                return;
            }
            var form = null;
            var block = null;
            var field = null;
            if (isblock) {
                block = cname;
                if (parts.length > 0)
                    field = parts.shift();
            }
            else {
                form = cname;
                block = parts.shift();
                def.block = block;
                if (parts.length > 0)
                    field = parts.shift();
            }
            def.field = field;
            if (isblock)
                TriggerDefinitions.addFieldTrigger(block, field, def);
            else
                TriggerDefinitions.addFormFieldTrigger(form, block, field, def);
        };
        TriggerDefinitions.addFieldTrigger = function (block, field, def) {
            var triggers = TriggerDefinitions.bftriggers.get(block);
            if (triggers == null) {
                triggers = new Map();
                TriggerDefinitions.bftriggers.set(block, triggers);
            }
            triggers.set(field + "[" + exports.Trigger[def.trigger] + "]", def);
        };
        TriggerDefinitions.addKeyTrigger = function (block, def) {
            var triggers = TriggerDefinitions.bktriggers.get(block);
            if (triggers == null) {
                triggers = new Map();
                TriggerDefinitions.bktriggers.set(block, triggers);
            }
            triggers.set(exports.keymap[def.key] + "[" + exports.Trigger[def.trigger] + "]", def);
        };
        TriggerDefinitions.addFormFieldTrigger = function (form, block, field, def) {
            if (block == null)
                block = "";
            var ftriggers = TriggerDefinitions.fftriggers.get(form);
            if (ftriggers == null) {
                ftriggers = new Map();
                TriggerDefinitions.fftriggers.set(form, ftriggers);
            }
            var triggers = ftriggers.get(block);
            if (triggers == null) {
                triggers = new Map();
                ftriggers.set(block, triggers);
            }
            triggers.set(field + "[" + exports.Trigger[def.trigger] + "]", def);
        };
        TriggerDefinitions.addFormKeyTrigger = function (form, def) {
            var triggers = TriggerDefinitions.fktriggers.get(form);
            if (triggers == null) {
                triggers = new Map();
                TriggerDefinitions.fktriggers.set(form, triggers);
            }
            triggers.set(exports.keymap[def.key] + "[" + exports.Trigger[def.trigger] + "]", def);
        };
        TriggerDefinitions.getFieldTriggers = function (block) {
            return (new Map(TriggerDefinitions.bftriggers.get(block.toLowerCase())));
        };
        TriggerDefinitions.getKeyTriggers = function (block) {
            return (new Map(TriggerDefinitions.bktriggers.get(block.toLowerCase())));
        };
        TriggerDefinitions.getFormFieldTriggers = function (form, block) {
            if (block == null)
                block = "";
            var triggers = TriggerDefinitions.fftriggers.get(form.toLowerCase());
            if (triggers != null)
                return (new Map(triggers.get(block.toLowerCase())));
            return (new Map());
        };
        TriggerDefinitions.getFormKeyTriggers = function (form) {
            return (new Map(TriggerDefinitions.fktriggers.get(form.toLowerCase())));
        };
        TriggerDefinitions.split = function (name) {
            if (name == null)
                return ([]);
            var tokens = name.trim().split(".");
            for (var i = 0; i < tokens.length; i++)
                tokens[i] = tokens[i].trim().toLowerCase();
            return (tokens);
        };
        return TriggerDefinitions;
    }());
    TriggerDefinitions.bftriggers = new Map();
    TriggerDefinitions.bktriggers = new Map();
    TriggerDefinitions.fktriggers = new Map();
    TriggerDefinitions.fftriggers = new Map();

    var trigger = function (trigger, field) {
        function define(comp, func) {
            var utils = new Utils();
            var cname = utils.getName(comp);
            var ctype = utils.getType(comp);
            var params = utils.getParams(comp[func]);
            if (params.length != 1) {
                console.log("function " + func + " must take 1 TriggerEvent argument");
                return;
            }
            if (ctype != "Block" && ctype != "Form") {
                console.log("@trigger can only be applied on Block or Form");
                return;
            }
            var blktrg = false;
            if (ctype == "Block")
                blktrg = true;
            var fields = [];
            if (field == null)
                field = [null];
            if (field.constructor.name == "Array")
                fields = field;
            else
                fields.push(field);
            fields.forEach(function (fld) {
                var trg = {
                    field: fld,
                    block: null,
                    blktrg: blktrg,
                    params: params,
                    func: comp[func],
                    trigger: trigger
                };
                TriggerDefinitions.add(blktrg, cname, trg);
            });
        }
        return (define);
    };

    var DBUsage = /** @class */ (function () {
        function DBUsage() {
        }
        DBUsage.merge = function (changes, base) {
            var utils = new Utils();
            if (changes == null)
                return (base);
            var merged = utils.clone(base);
            if (changes.hasOwnProperty("query"))
                merged.query = changes.query;
            if (changes.hasOwnProperty("insert"))
                merged.insert = changes.insert;
            if (changes.hasOwnProperty("update"))
                merged.update = changes.update;
            if (changes.hasOwnProperty("delete"))
                merged.delete = changes.delete;
            return (merged);
        };
        DBUsage.override = function (overide, base) {
            var utils = new Utils();
            if (overide == null)
                return (base);
            var merged = utils.clone(base);
            if (overide.hasOwnProperty("query") && !overide.query)
                merged.query = false;
            if (overide.hasOwnProperty("insert") && !overide.insert)
                merged.insert = false;
            if (overide.hasOwnProperty("update") && !overide.update)
                merged.update = false;
            if (overide.hasOwnProperty("delete") && !overide.delete)
                merged.delete = false;
            return (merged);
        };
        DBUsage.complete = function (base) {
            var utils = new Utils();
            if (base == null)
                base = {};
            else
                base = utils.clone(base);
            if (!base.hasOwnProperty("query"))
                base.query = true;
            if (!base.hasOwnProperty("insert"))
                base.insert = true;
            if (!base.hasOwnProperty("update"))
                base.update = true;
            if (!base.hasOwnProperty("delete"))
                base.delete = true;
            return (base);
        };
        return DBUsage;
    }());

    var DatabaseDefinitions = /** @class */ (function () {
        function DatabaseDefinitions() {
        }
        DatabaseDefinitions.setFormUsage = function (form, usage) {
            DatabaseDefinitions.fdefault.set(form, usage);
        };
        DatabaseDefinitions.getFormUsage = function (form) {
            var usage = DatabaseDefinitions.fdefault.get(form.toLowerCase());
            return (usage);
        };
        DatabaseDefinitions.setBlockDefault = function (block, usage) {
            DatabaseDefinitions.bdefault.set(block, usage);
        };
        DatabaseDefinitions.getBlockDefault = function (block) {
            var usage = null;
            var base = {
                query: true,
                insert: true,
                update: true,
                delete: true
            };
            if (block != null)
                usage = DatabaseDefinitions.bdefault.get(block.toLowerCase());
            return (DBUsage.merge(usage, base));
        };
        return DatabaseDefinitions;
    }());
    DatabaseDefinitions.bdefault = new Map();
    DatabaseDefinitions.fdefault = new Map();

    var database = function (usage) {
        function define(component) {
            var utils = new Utils();
            var comp = utils.getName(component);
            var type = utils.getType(component);
            if (type == "Form") {
                DatabaseDefinitions.setFormUsage(comp, usage);
                return;
            }
            if (type == "Block") {
                DatabaseDefinitions.setBlockDefault(comp, usage);
                return;
            }
            console.log("@database can only be used in conjunction with Form or Block");
        }
        return (define);
    };

    var keytrigger = function (key) {
        function define(comp, func) {
            var utils = new Utils();
            var cname = utils.getName(comp);
            var ctype = utils.getType(comp);
            var params = utils.getParams(comp[func]);
            if (params.length != 1) {
                console.log("function " + func + " must take 1 TriggerEvent argument");
                return;
            }
            if (ctype != "Block" && ctype != "Form") {
                console.log("@keytrigger can only be applied on Block or Form");
                return;
            }
            var block = false;
            if (ctype == "Block")
                block = true;
            var keys = [];
            if (key.constructor.name == "Array")
                keys = key;
            else
                keys.push(key);
            keys.forEach(function (key) {
                var trg = {
                    key: key,
                    block: null,
                    blktrg: block,
                    params: params,
                    func: comp[func],
                    trigger: exports.Trigger.Key
                };
                TriggerDefinitions.add(block, cname, trg);
            });
        }
        return (define);
    };

    var disconnect = function (form, func) {
        var utils = new Utils();
        var fname = utils.getName(form);
        var ctype = utils.getType(form);
        if (ctype != "Form") {
            console.log("@disconnect can only be used on forms, found on '" + fname + "'");
            return;
        }
        FormDefinitions.setOnDisconnect(fname, func);
    };

    var LOVDefinitions = /** @class */ (function () {
        function LOVDefinitions() {
        }
        LOVDefinitions.add = function (isblock, cname, fieldspec, inst, func, params) {
            var form = null;
            var block = null;
            var field = null;
            var id = false;
            var parts = LOVDefinitions.split(fieldspec);
            if (isblock) {
                block = cname;
            }
            else {
                form = cname;
                block = parts.shift();
            }
            if (parts.length == 0 || parts.length > 2) {
                console.log("@listofvalues must specify [alias.]field[.id], not '" + fieldspec + "'");
                return;
            }
            field = parts.shift();
            if (parts.length > 0) {
                id = true;
                field += "." + parts.shift();
            }
            var def = {
                inst: inst,
                func: func,
                params: params
            };
            if (form != null) {
                if (!id)
                    LOVDefinitions.addFormLov(form, block, field, def);
                else
                    LOVDefinitions.addFormIdLov(form, block, field, def);
            }
            else {
                if (!id)
                    LOVDefinitions.addBlockLov(block, field, def);
                else
                    LOVDefinitions.addBlockIdLov(block, field, def);
            }
        };
        LOVDefinitions.addFormLov = function (form, block, field, def) {
            var fdefs = LOVDefinitions.fdefs.get(form);
            if (fdefs == null) {
                fdefs = new Map();
                LOVDefinitions.fdefs.set(form, fdefs);
            }
            var bdefs = fdefs.get(block);
            if (bdefs == null) {
                bdefs = new Map();
                fdefs.set(block, bdefs);
            }
            bdefs.set(field, def);
        };
        LOVDefinitions.addFormIdLov = function (form, block, field, def) {
            var fdefs = LOVDefinitions.fiddefs.get(form);
            if (fdefs == null) {
                fdefs = new Map();
                LOVDefinitions.fiddefs.set(form, fdefs);
            }
            var bdefs = fdefs.get(block);
            if (bdefs == null) {
                bdefs = new Map();
                fdefs.set(block, bdefs);
            }
            bdefs.set(field, def);
        };
        LOVDefinitions.addBlockLov = function (block, field, def) {
            var bdefs = LOVDefinitions.bdefs.get(block);
            if (bdefs == null) {
                bdefs = new Map();
                LOVDefinitions.bdefs.set(block, bdefs);
            }
            bdefs.set(field, def);
        };
        LOVDefinitions.addBlockIdLov = function (block, field, def) {
            var bdefs = LOVDefinitions.biddefs.get(block);
            if (bdefs == null) {
                bdefs = new Map();
                LOVDefinitions.biddefs.set(block, bdefs);
            }
            bdefs.set(field, def);
        };
        LOVDefinitions.getblock = function (block) {
            return (new Map(LOVDefinitions.bdefs.get(block.toLowerCase())));
        };
        LOVDefinitions.getblockid = function (block) {
            return (new Map(LOVDefinitions.biddefs.get(block.toLowerCase())));
        };
        LOVDefinitions.getform = function (form, block) {
            var fdefs = LOVDefinitions.fdefs.get(form.toLowerCase());
            if (fdefs != null)
                return (new Map(fdefs.get(block.toLowerCase())));
            return (new Map());
        };
        LOVDefinitions.getidform = function (form, block) {
            var fdefs = LOVDefinitions.fiddefs.get(form.toLowerCase());
            if (fdefs != null)
                return (new Map(fdefs.get(block.toLowerCase())));
            return (new Map());
        };
        LOVDefinitions.split = function (name) {
            var tokens = name.trim().split(".");
            for (var i = 0; i < tokens.length; i++)
                tokens[i] = tokens[i].trim().toLowerCase();
            return (tokens);
        };
        return LOVDefinitions;
    }());
    LOVDefinitions.bdefs = new Map();
    LOVDefinitions.biddefs = new Map();
    LOVDefinitions.fdefs = new Map();
    LOVDefinitions.fiddefs = new Map();

    var listofvalues = function (field) {
        function define(comp, func) {
            var utils = new Utils();
            var cname = utils.getName(comp);
            var ctype = utils.getType(comp);
            var params = utils.getParams(comp[func]);
            if (ctype != "Block" && ctype != "Form") {
                console.log("@listofvalues can only be applied on Block or Form");
                return;
            }
            var block = false;
            if (ctype == "Block")
                block = true;
            var fields = [];
            if (field.constructor.name == "Array")
                fields = field;
            else
                fields.push(field);
            fields.forEach(function (fld) { LOVDefinitions.add(block, cname, fld, comp, func, params); });
        }
        return (define);
    };

    var Origin;
    (function (Origin) {
        Origin[Origin["Form"] = 0] = "Form";
        Origin[Origin["Block"] = 1] = "Block";
        Origin[Origin["Field"] = 2] = "Field";
    })(Origin || (Origin = {}));
    var TriggerEvent = /** @class */ (function () {
        function TriggerEvent(block, record, jsevent) {
            this.block$ = block;
            this.record$ = record;
            this.event$ = jsevent;
        }
        Object.defineProperty(TriggerEvent.prototype, "block", {
            get: function () {
                return (this.block$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TriggerEvent.prototype, "type", {
            get: function () {
                return (this.type$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TriggerEvent.prototype, "event", {
            get: function () {
                return (this.event$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TriggerEvent.prototype, "record", {
            get: function () {
                return (this.record$);
            },
            enumerable: false,
            configurable: true
        });
        return TriggerEvent;
    }());
    var KeyTriggerEvent = /** @class */ (function (_super) {
        __extends(KeyTriggerEvent, _super);
        function KeyTriggerEvent(origin, block, field, key, jsevent) {
            var _this = _super.call(this, block, 0, jsevent) || this;
            _this.key$ = key;
            _this.origin$ = origin;
            if (field != null) {
                _this.field$ = field.name;
                _this["record$"] = field.row;
            }
            return _this;
        }
        Object.defineProperty(KeyTriggerEvent.prototype, "key", {
            get: function () {
                return (this.key$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(KeyTriggerEvent.prototype, "field", {
            get: function () {
                return (this.field$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(KeyTriggerEvent.prototype, "origin", {
            get: function () {
                return (this.origin$);
            },
            enumerable: false,
            configurable: true
        });
        return KeyTriggerEvent;
    }(TriggerEvent));
    var FieldTriggerEvent = /** @class */ (function (_super) {
        __extends(FieldTriggerEvent, _super);
        function FieldTriggerEvent(block, field, id, row, value, previous, jsevent) {
            var _this = _super.call(this, block, row, jsevent) || this;
            _this.id$ = id;
            _this.field$ = field;
            _this.value$ = value;
            _this.previous$ = previous;
            return _this;
        }
        Object.defineProperty(FieldTriggerEvent.prototype, "value", {
            get: function () {
                return (this.value$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldTriggerEvent.prototype, "field", {
            get: function () {
                return (this.field$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldTriggerEvent.prototype, "id", {
            get: function () {
                return (this.id$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldTriggerEvent.prototype, "previous", {
            get: function () {
                return (this.previous$);
            },
            enumerable: false,
            configurable: true
        });
        return FieldTriggerEvent;
    }(TriggerEvent));
    var SQLTriggerEvent = /** @class */ (function (_super) {
        __extends(SQLTriggerEvent, _super);
        function SQLTriggerEvent(block, row, stmt) {
            var _this = _super.call(this, block, row, null) || this;
            _this.stmt$ = stmt;
            return _this;
        }
        Object.defineProperty(SQLTriggerEvent.prototype, "stmt", {
            get: function () {
                return (this.stmt$);
            },
            set: function (stmt) {
                this.stmt$ = stmt;
            },
            enumerable: false,
            configurable: true
        });
        return SQLTriggerEvent;
    }(TriggerEvent));

    var Context = /** @class */ (function () {
        function Context() {
        }
        return Context;
    }());
    Context.ɵprov = i0.ɵɵdefineInjectable({ factory: function Context_Factory() { return new Context(); }, token: Context, providedIn: "root" });
    Context.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root',
                },] }
    ];

    var MenuArea = /** @class */ (function () {
        function MenuArea(ctx, change) {
            this.change = change;
            this.app = ctx.app["_impl_"];
        }
        MenuArea.prototype.remove = function () {
            if (this.element != null) {
                var menuelem = this.menu.firstElementChild;
                if (menuelem != null)
                    this.menu.removeChild(menuelem);
                this.app.builder.getAppRef().detachView(this.menuref.hostView);
            }
            this.change.detectChanges();
        };
        MenuArea.prototype.display = function (menu) {
            var _this = this;
            if (menu == null) {
                this.remove();
                return;
            }
            if (this.menu == null) {
                setTimeout(function () { _this.display(menu); }, 10);
                return;
            }
            if (this.element != null) {
                var menuelem = this.menu.firstElementChild;
                if (menuelem != null)
                    this.menu.removeChild(menuelem);
                this.app.builder.getAppRef().detachView(this.menuref.hostView);
            }
            this.menuref = menu;
            this.element = menu.hostView.rootNodes[0];
            this.app.builder.getAppRef().attachView(this.menuref.hostView);
            this.menu.appendChild(this.element);
            this.change.detectChanges();
        };
        MenuArea.prototype.ngAfterViewInit = function () {
            var _a;
            this.menu = (_a = this.elem) === null || _a === void 0 ? void 0 : _a.nativeElement;
            this.app.setMenuArea(this);
        };
        return MenuArea;
    }());
    MenuArea.decorators = [
        { type: i0.Component, args: [{
                    selector: 'menuarea',
                    template: "\n\t\t<div #menu></div>\n\t",
                    changeDetection: i0.ChangeDetectionStrategy.OnPush
                },] }
    ];
    MenuArea.ctorParameters = function () { return [
        { type: Context },
        { type: i0.ChangeDetectorRef }
    ]; };
    MenuArea.propDecorators = {
        elem: [{ type: i0.ViewChild, args: ["menu", { read: i0.ElementRef },] }]
    };

    var MenuHandler = /** @class */ (function () {
        // dont rename __menu__ as it is set behind the scenes
        function MenuHandler() {
            this.__menu__ = null;
            this.guid$ = MenuHandler._id++;
        }
        Object.defineProperty(MenuHandler.prototype, "guid", {
            get: function () {
                return (this.guid$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MenuHandler.prototype, "ready", {
            get: function () {
                return (this.__menu__ != null);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MenuHandler.prototype, "app", {
            get: function () {
                return (this.__menu__.app);
            },
            enumerable: false,
            configurable: true
        });
        MenuHandler.prototype.enable = function (menu) {
            this.__menu__.enable(menu);
        };
        MenuHandler.prototype.disable = function (menu) {
            this.__menu__.disable(menu);
        };
        Object.defineProperty(MenuHandler.prototype, "connected", {
            get: function () {
                return (this.__menu__.isConnected());
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MenuHandler.prototype, "transaction", {
            get: function () {
                return (this.app.transaction);
            },
            enumerable: false,
            configurable: true
        });
        // For overwrite by application menus
        MenuHandler.prototype.onFormChange = function (form) {
        };
        return MenuHandler;
    }());
    MenuHandler._id = 0;

    var DefaultMenuHandler = /** @class */ (function (_super) {
        __extends(DefaultMenuHandler, _super);
        function DefaultMenuHandler() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        DefaultMenuHandler.prototype.onInit = function () {
            this.init();
        };
        DefaultMenuHandler.prototype.onConnect = function () {
            this.init();
        };
        DefaultMenuHandler.prototype.onDisconnect = function () {
            this.init();
        };
        DefaultMenuHandler.prototype.onFormChange = function (form) {
            this.form = form;
            if (this.ready)
                this.init();
        };
        DefaultMenuHandler.prototype.onTransactionChange = function () {
            if (this.transaction)
                this.enable("/transaction");
            else
                this.disable("/transaction");
        };
        DefaultMenuHandler.prototype.init = function () {
            this.disable();
            this.enable("/form/shortkeys");
            if (this.form != null) {
                this.enable("/form/close");
                this.enable("/section/next");
                this.enable("/section/previous");
                if (this.connected) {
                    this.enable("/form");
                    this.enable("/section");
                    this.enable("/record");
                    this.enable("/connection/disconnect");
                }
                else {
                    this.enable("/connection/connect");
                }
            }
            else {
                if (this.connected) {
                    this.enable("/connection/disconnect");
                }
                else {
                    this.enable("/connection/connect");
                }
            }
            this.onTransactionChange();
        };
        DefaultMenuHandler.prototype.connect = function () {
            this.app.connect();
            this.init();
        };
        DefaultMenuHandler.prototype.disconnect = function () {
            this.app.disconnect();
            this.init();
        };
        DefaultMenuHandler.prototype.commit = function () {
            this.app.commit();
        };
        DefaultMenuHandler.prototype.rollback = function () {
            this.app.rollback();
        };
        DefaultMenuHandler.prototype.clear = function () {
            var _a;
            (_a = this.form) === null || _a === void 0 ? void 0 : _a.sendKey(exports.keymap.clearform);
        };
        DefaultMenuHandler.prototype.cancel = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.cancel();
        };
        DefaultMenuHandler.prototype.enterFormQuery = function () {
            var _a;
            (_a = this.form) === null || _a === void 0 ? void 0 : _a.enterquery();
        };
        DefaultMenuHandler.prototype.executeFormQuery = function () {
            var _a;
            (_a = this.form) === null || _a === void 0 ? void 0 : _a.executequery();
        };
        DefaultMenuHandler.prototype.enterQuery = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.sendKey(exports.keymap.enterquery);
        };
        DefaultMenuHandler.prototype.executeQuery = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.sendKey(exports.keymap.executequery);
        };
        DefaultMenuHandler.prototype.deleteRecord = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.delete();
        };
        DefaultMenuHandler.prototype.insertRecordAfter = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.insert(false);
        };
        DefaultMenuHandler.prototype.insertRecordBefore = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.insert(true);
        };
        DefaultMenuHandler.prototype.nextRecord = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.nextrecord();
        };
        DefaultMenuHandler.prototype.prevRecord = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.prevrecord();
        };
        DefaultMenuHandler.prototype.nextBlock = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.nextblock();
        };
        DefaultMenuHandler.prototype.prevBlock = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.prevblock();
        };
        DefaultMenuHandler.prototype.pageUp = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.pageup();
        };
        DefaultMenuHandler.prototype.pageDown = function () {
            var _a, _b;
            (_b = (_a = this.form) === null || _a === void 0 ? void 0 : _a.block) === null || _b === void 0 ? void 0 : _b.pagedown();
        };
        DefaultMenuHandler.prototype.close = function () {
            var _a;
            (_a = this.form) === null || _a === void 0 ? void 0 : _a.close(false);
            this.init();
        };
        DefaultMenuHandler.prototype.showkeymap = function () {
            this.app.showKeyMap();
        };
        return DefaultMenuHandler;
    }(MenuHandler));

    var DefaultMenu = /** @class */ (function () {
        function DefaultMenu() {
            this.entries =
                [
                    {
                        name: "Form", title: "Form actions", options: [
                            { name: "enter query", action: "enterFormQuery" },
                            { name: "execute query", action: "executeFormQuery" },
                            { name: "clear", action: "clear" },
                            { name: "close", action: "close" },
                            { name: "shortkeys", action: "showkeymap" },
                        ]
                    },
                    {
                        name: "Section", title: "Block actions", options: [
                            { name: "enter query", action: "enterQuery" },
                            { name: "execute query", action: "executeQuery" },
                            { name: "clear filter", action: "executeQuery" },
                            { name: "next", action: "nextBlock" },
                            { name: "previous", action: "prevBlock" },
                        ]
                    },
                    {
                        name: "Record", title: "Record actions", options: [
                            { name: "insert below", action: "insertRecordAfter" },
                            { name: "insert above", action: "insertRecordBefore" },
                            { name: "delete", action: "deleteRecord" },
                            { name: "next", action: "nextRecord" },
                            { name: "previous", action: "prevRecord" },
                            { name: "pagedown", action: "pageDown" },
                            { name: "pageup", action: "pageUp" },
                        ]
                    },
                    {
                        name: "Transaction", title: "Transaction Menu", options: [
                            { name: "commit", action: "commit" },
                            { name: "rollback", action: "rollback" },
                        ]
                    },
                    {
                        name: "Connection", title: "Connection to database", options: [
                            { name: "connect", action: "connect" },
                            { name: "disconnect", action: "disconnect" },
                        ]
                    }
                ];
            this.handler = new DefaultMenuHandler();
        }
        DefaultMenu.prototype.getHandler = function () {
            return (this.handler);
        };
        DefaultMenu.prototype.getEntries = function () {
            return (this.entries);
        };
        return DefaultMenu;
    }());

    var Key = /** @class */ (function () {
        function Key(name) {
            this.name = name;
            this.values$ = [];
            this.columns$ = [];
            this.index = new Map();
        }
        Key.prototype.get = function (part) {
            var col = -1;
            if (part.constructor.name == "Number")
                col = +part;
            else
                col = this.index.get("" + part);
            return (this.values$[col]);
        };
        Key.prototype.partof = function (part) {
            return (this.columns$.includes(part, 0));
        };
        Key.prototype.set = function (name, value) {
            var col = -1;
            if (name.constructor.name == "Number")
                col = +name;
            else
                col = this.index.get("" + name);
            this.values$[col] = value;
        };
        Key.prototype.addColumn = function (name) {
            this.index.set(name, this.columns$.length);
            this.values$.push(name);
            this.columns$.push(name);
        };
        Key.prototype.columns = function () {
            return (this.columns$);
        };
        Object.defineProperty(Key.prototype, "values", {
            get: function () {
                var map = [];
                for (var i = 0; i < this.columns$.length; i++)
                    map.push({ name: this.columns$[i], value: this.values$[i] });
                return (map);
            },
            enumerable: false,
            configurable: true
        });
        Key.prototype.toString = function () {
            var str = this.name + " [";
            for (var i = 0; i < this.columns$.length; i++)
                str += this.columns$[i] + " = " + this.values$[i] + ", ";
            return (str.substring(0, str.length - 2) + "]");
        };
        return Key;
    }());

    var RecordState;
    (function (RecordState) {
        RecordState[RecordState["na"] = 0] = "na";
        RecordState[RecordState["qmode"] = 1] = "qmode";
        RecordState[RecordState["insert"] = 2] = "insert";
        RecordState[RecordState["update"] = 3] = "update";
    })(RecordState || (RecordState = {}));
    var Record = /** @class */ (function () {
        function Record(row, fields, index) {
            this.row$ = 0;
            this.fields$ = [];
            this.current$ = false;
            this.enabled$ = false;
            this.state$ = RecordState.na;
            this.index = new Map();
            this.row$ = row;
            this.index = index;
            this.fields$ = fields;
        }
        Object.defineProperty(Record.prototype, "row", {
            get: function () {
                return (this.row$);
            },
            set: function (row) {
                this.row$ = row;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Record.prototype, "fields", {
            get: function () {
                return (this.fields$);
            },
            enumerable: false,
            configurable: true
        });
        Record.prototype.focus = function () {
            for (var i = 0; i < this.fields$.length; i++)
                if (this.fields$[i].focus())
                    return;
        };
        Object.defineProperty(Record.prototype, "current", {
            get: function () {
                return (this.current$);
            },
            set: function (flag) {
                this.current$ = flag;
                this.fields$.forEach(function (field) { field.current = flag; });
            },
            enumerable: false,
            configurable: true
        });
        Record.prototype.clear = function () {
            this.fields$.forEach(function (field) { field.value = null; field.disable(); });
            if (this.current)
                this.fields$.forEach(function (field) { field.current = true; field.disable(); });
        };
        Object.defineProperty(Record.prototype, "state", {
            get: function () {
                return (this.state$);
            },
            set: function (state) {
                this.state$ = state;
                this.fields$.forEach(function (field) { field.state = state; });
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Record.prototype, "enabled", {
            get: function () {
                return (this.enabled$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Record.prototype, "readonly", {
            get: function () {
                for (var i = 0; i < this.fields$.length; i++)
                    if (!this.fields$[i].readonly)
                        return (false);
                return (true);
            },
            enumerable: false,
            configurable: true
        });
        Record.prototype.enable = function (readonly) {
            var _this = this;
            this.enabled$ = true;
            this.fields$.forEach(function (field) {
                field.state = _this.state$;
                field.enable(readonly);
            });
        };
        Record.prototype.disable = function () {
            this.enabled$ = false;
            this.fields$.forEach(function (field) { field.disable(); });
        };
        Record.prototype.getField = function (name) {
            if (name == null)
                return (null);
            return (this.index.get(name.toLowerCase()));
        };
        Record.prototype.getFieldByGuid = function (name, guid) {
            var field = this.index.get(name.toLowerCase());
            if (field != null)
                return (field.getInstance(guid));
            return (null);
        };
        return Record;
    }());

    var TextField = /** @class */ (function () {
        function TextField() {
        }
        Object.defineProperty(TextField.prototype, "html", {
            get: function () {
                return ("<input type='text'></input>");
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "size", {
            set: function (size) {
                this.element$.size = size;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "tabindex", {
            get: function () {
                return (this.element$.tabIndex);
            },
            set: function (seq) {
                this.element$.tabIndex = seq;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "element", {
            get: function () {
                return (this.element$);
            },
            set: function (element) {
                this.element$ = element;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "enable", {
            get: function () {
                return (!this.element$.disabled);
            },
            set: function (flag) {
                this.element$.disabled = !flag;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "readonly", {
            get: function () {
                return (this.element$.readOnly);
            },
            set: function (flag) {
                this.element$.readOnly = flag;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "value", {
            get: function () {
                return (this.element$.value);
            },
            set: function (value) {
                this.element$.value = value;
            },
            enumerable: false,
            configurable: true
        });
        TextField.prototype.focus = function () {
            this.element$.focus();
            this.element$.select();
        };
        TextField.prototype.validate = function () {
            return (true);
        };
        return TextField;
    }());

    var DropDown = /** @class */ (function (_super) {
        __extends(DropDown, _super);
        function DropDown() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(DropDown.prototype, "html", {
            get: function () {
                return ("<select></select>");
            },
            enumerable: false,
            configurable: true
        });
        DropDown.prototype.focus = function () {
            this.element$.focus();
        };
        return DropDown;
    }(TextField));

    var Password = /** @class */ (function (_super) {
        __extends(Password, _super);
        function Password() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(Password.prototype, "html", {
            get: function () {
                return ("<input type='password'></input>");
            },
            enumerable: false,
            configurable: true
        });
        return Password;
    }(TextField));

    var CheckBox = /** @class */ (function (_super) {
        __extends(CheckBox, _super);
        function CheckBox() {
            var _this = _super.apply(this, __spread(arguments)) || this;
            _this.actvalue = null;
            _this.chkvalue = null;
            return _this;
        }
        Object.defineProperty(CheckBox.prototype, "html", {
            get: function () {
                return ("<input type='checkbox'></input>");
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(CheckBox.prototype, "value", {
            get: function () {
                return (this.actvalue);
            },
            set: function (value) {
                if (this.chkvalue == null) {
                    this.chkvalue = value;
                    return;
                }
                this.actvalue = value;
                // cheat compiler
                var checkbox = this.element;
                if (value == this.chkvalue)
                    checkbox.checked = true;
                else
                    checkbox.checked = false;
            },
            enumerable: false,
            configurable: true
        });
        return CheckBox;
    }(TextField));

    var token = /d{1,4}|M{1,4}|YY(?:YY)?|S{1,3}|Do|ZZ|Z|([HhMsDm])\1?|[aA]|"[^"]*"|'[^']*'/g;
    var twoDigitsOptional = "[1-9]\\d?";
    var twoDigits = "\\d\\d";
    var threeDigits = "\\d{3}";
    var fourDigits = "\\d{4}";
    var word = "[^\\s]+";
    var literal = /\[([^]*?)\]/gm;
    function shorten(arr, sLen) {
        var newArr = [];
        for (var i = 0, len = arr.length; i < len; i++) {
            newArr.push(arr[i].substr(0, sLen));
        }
        return newArr;
    }
    var monthUpdate = function (arrName) { return function (v, i18n) {
        var lowerCaseArr = i18n[arrName].map(function (v) { return v.toLowerCase(); });
        var index = lowerCaseArr.indexOf(v.toLowerCase());
        if (index > -1) {
            return index;
        }
        return null;
    }; };
    var ɵ0 = monthUpdate;
    function assign(origObj) {
        var e_1, _a;
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        try {
            for (var args_1 = __values(args), args_1_1 = args_1.next(); !args_1_1.done; args_1_1 = args_1.next()) {
                var obj = args_1_1.value;
                for (var key in obj) {
                    // @ts-ignore ex
                    origObj[key] = obj[key];
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (args_1_1 && !args_1_1.done && (_a = args_1.return)) _a.call(args_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return origObj;
    }
    var dayNames = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
    ];
    var monthNames = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
    ];
    var monthNamesShort = shorten(monthNames, 3);
    var dayNamesShort = shorten(dayNames, 3);
    var defaultI18n = {
        dayNamesShort: dayNamesShort,
        dayNames: dayNames,
        monthNamesShort: monthNamesShort,
        monthNames: monthNames,
        amPm: ["am", "pm"],
        DoFn: function (dayOfMonth) {
            return (dayOfMonth +
                ["th", "st", "nd", "rd"][dayOfMonth % 10 > 3
                    ? 0
                    : ((dayOfMonth - (dayOfMonth % 10) !== 10 ? 1 : 0) * dayOfMonth) % 10]);
        }
    };
    var globalI18n = assign({}, defaultI18n);
    var setGlobalDateI18n = function (i18n) { return (globalI18n = assign(globalI18n, i18n)); };
    var ɵ1 = setGlobalDateI18n;
    var regexEscape = function (str) { return str.replace(/[|\\{()[^$+*?.-]/g, "\\$&"); };
    var ɵ2 = regexEscape;
    var pad = function (val, len) {
        if (len === void 0) { len = 2; }
        val = String(val);
        while (val.length < len) {
            val = "0" + val;
        }
        return val;
    };
    var ɵ3 = pad;
    var ɵ4 = function (dateObj) { return String(dateObj.getDate()); }, ɵ5 = function (dateObj) { return pad(dateObj.getDate()); }, ɵ6 = function (dateObj, i18n) { return i18n.DoFn(dateObj.getDate()); }, ɵ7 = function (dateObj) { return String(dateObj.getDay()); }, ɵ8 = function (dateObj) { return pad(dateObj.getDay()); }, ɵ9 = function (dateObj, i18n) { return i18n.dayNamesShort[dateObj.getDay()]; }, ɵ10 = function (dateObj, i18n) { return i18n.dayNames[dateObj.getDay()]; }, ɵ11 = function (dateObj) { return String(dateObj.getMonth() + 1); }, ɵ12 = function (dateObj) { return pad(dateObj.getMonth() + 1); }, ɵ13 = function (dateObj, i18n) { return i18n.monthNamesShort[dateObj.getMonth()]; }, ɵ14 = function (dateObj, i18n) { return i18n.monthNames[dateObj.getMonth()]; }, ɵ15 = function (dateObj) { return pad(String(dateObj.getFullYear()), 4).substr(2); }, ɵ16 = function (dateObj) { return pad(dateObj.getFullYear(), 4); }, ɵ17 = function (dateObj) { return String(dateObj.getHours() % 12 || 12); }, ɵ18 = function (dateObj) { return pad(dateObj.getHours() % 12 || 12); }, ɵ19 = function (dateObj) { return String(dateObj.getHours()); }, ɵ20 = function (dateObj) { return pad(dateObj.getHours()); }, ɵ21 = function (dateObj) { return String(dateObj.getMinutes()); }, ɵ22 = function (dateObj) { return pad(dateObj.getMinutes()); }, ɵ23 = function (dateObj) { return String(dateObj.getSeconds()); }, ɵ24 = function (dateObj) { return pad(dateObj.getSeconds()); }, ɵ25 = function (dateObj) { return String(Math.round(dateObj.getMilliseconds() / 100)); }, ɵ26 = function (dateObj) { return pad(Math.round(dateObj.getMilliseconds() / 10), 2); }, ɵ27 = function (dateObj) { return pad(dateObj.getMilliseconds(), 3); }, ɵ28 = function (dateObj, i18n) { return dateObj.getHours() < 12 ? i18n.amPm[0] : i18n.amPm[1]; }, ɵ29 = function (dateObj, i18n) { return dateObj.getHours() < 12
        ? i18n.amPm[0].toUpperCase()
        : i18n.amPm[1].toUpperCase(); };
    var formatFlags = {
        D: ɵ4,
        DD: ɵ5,
        Do: ɵ6,
        d: ɵ7,
        dd: ɵ8,
        ddd: ɵ9,
        dddd: ɵ10,
        M: ɵ11,
        MM: ɵ12,
        MMM: ɵ13,
        MMMM: ɵ14,
        YY: ɵ15,
        YYYY: ɵ16,
        h: ɵ17,
        hh: ɵ18,
        H: ɵ19,
        HH: ɵ20,
        m: ɵ21,
        mm: ɵ22,
        s: ɵ23,
        ss: ɵ24,
        S: ɵ25,
        SS: ɵ26,
        SSS: ɵ27,
        a: ɵ28,
        A: ɵ29,
        ZZ: function (dateObj) {
            var offset = dateObj.getTimezoneOffset();
            return ((offset > 0 ? "-" : "+") +
                pad(Math.floor(Math.abs(offset) / 60) * 100 + (Math.abs(offset) % 60), 4));
        },
        Z: function (dateObj) {
            var offset = dateObj.getTimezoneOffset();
            return ((offset > 0 ? "-" : "+") +
                pad(Math.floor(Math.abs(offset) / 60), 2) +
                ":" +
                pad(Math.abs(offset) % 60, 2));
        }
    };
    var monthParse = function (v) { return +v - 1; };
    var ɵ30 = monthParse;
    var emptyDigits = [null, twoDigitsOptional];
    var emptyWord = [null, word];
    var ɵ31 = function (v, i18n) {
        var val = v.toLowerCase();
        if (val === i18n.amPm[0]) {
            return 0;
        }
        else if (val === i18n.amPm[1]) {
            return 1;
        }
        return null;
    };
    var amPm = [
        "isPm",
        word,
        ɵ31
    ];
    var ɵ32 = function (v) {
        var parts = (v + "").match(/([+-]|\d\d)/gi);
        if (parts) {
            var minutes = +parts[1] * 60 + parseInt(parts[2], 10);
            return parts[0] === "+" ? minutes : -minutes;
        }
        return 0;
    };
    var timezoneOffset = [
        "timezoneOffset",
        "[^\\s]*?[\\+\\-]\\d\\d:?\\d\\d|[^\\s]*?Z?",
        ɵ32
    ];
    var ɵ33 = function (v) { return parseInt(v, 10); }, ɵ34 = function (v) {
        var now = new Date();
        var cent = +("" + now.getFullYear()).substr(0, 2);
        return +("" + (+v > 68 ? cent - 1 : cent) + v);
    }, ɵ35 = function (v) { return +v * 100; }, ɵ36 = function (v) { return +v * 10; };
    var parseFlags = {
        D: ["day", twoDigitsOptional],
        DD: ["day", twoDigits],
        Do: ["day", twoDigitsOptional + word, ɵ33],
        M: ["month", twoDigitsOptional, monthParse],
        MM: ["month", twoDigits, monthParse],
        YY: [
            "year",
            twoDigits,
            ɵ34
        ],
        h: ["hour", twoDigitsOptional, undefined, "isPm"],
        hh: ["hour", twoDigits, undefined, "isPm"],
        H: ["hour", twoDigitsOptional],
        HH: ["hour", twoDigits],
        m: ["minute", twoDigitsOptional],
        mm: ["minute", twoDigits],
        s: ["second", twoDigitsOptional],
        ss: ["second", twoDigits],
        YYYY: ["year", fourDigits],
        S: ["millisecond", "\\d", ɵ35],
        SS: ["millisecond", twoDigits, ɵ36],
        SSS: ["millisecond", threeDigits],
        d: emptyDigits,
        dd: emptyDigits,
        ddd: emptyWord,
        dddd: emptyWord,
        MMM: ["month", word, monthUpdate("monthNamesShort")],
        MMMM: ["month", word, monthUpdate("monthNames")],
        a: amPm,
        A: amPm,
        ZZ: timezoneOffset,
        Z: timezoneOffset
    };
    // Some common format strings
    var globalMasks = {
        default: "ddd MMM DD YYYY HH:mm:ss",
        shortDate: "M/D/YY",
        mediumDate: "MMM D, YYYY",
        longDate: "MMMM D, YYYY",
        fullDate: "dddd, MMMM D, YYYY",
        isoDate: "YYYY-MM-DD",
        isoDateTime: "YYYY-MM-DDTHH:mm:ssZ",
        shortTime: "HH:mm",
        mediumTime: "HH:mm:ss",
        longTime: "HH:mm:ss.SSS"
    };
    var setGlobalDateMasks = function (masks) { return assign(globalMasks, masks); };
    var ɵ37 = setGlobalDateMasks;
    /***
     * Format a date
     * @method format
     * @param {Date|number} dateObj
     * @param {string} mask Format of the date, i.e. 'mm-dd-yy' or 'shortDate'
     * @returns {string} Formatted date string
     */
    var format = function (dateObj, mask, i18n) {
        if (mask === void 0) { mask = globalMasks["default"]; }
        if (i18n === void 0) { i18n = {}; }
        if (typeof dateObj === "number") {
            dateObj = new Date(dateObj);
        }
        if (Object.prototype.toString.call(dateObj) !== "[object Date]" ||
            isNaN(dateObj.getTime())) {
            throw new Error("Invalid Date pass to format");
        }
        mask = globalMasks[mask] || mask;
        var literals = [];
        // Make literals inactive by replacing them with @@@
        mask = mask.replace(literal, function ($0, $1) {
            literals.push($1);
            return "@@@";
        });
        var combinedI18nSettings = assign(assign({}, globalI18n), i18n);
        // Apply formatting rules
        mask = mask.replace(token, function ($0) { return formatFlags[$0](dateObj, combinedI18nSettings); });
        // Inline literal values back into the formatted value
        return mask.replace(/@@@/g, function () { return literals.shift(); });
    };
    var ɵ38 = format;
    /**
     * Parse a date string into a Javascript Date object /
     * @method parse
     * @param {string} dateStr Date string
     * @param {string} format Date parse format
     * @param {i18n} I18nSettingsOptional Full or subset of I18N settings
     * @returns {Date|null} Returns Date object. Returns null what date string is invalid or doesn't match format
     */
    function parse(dateStr, format, i18n) {
        if (i18n === void 0) { i18n = {}; }
        if (typeof format !== "string") {
            throw new Error("Invalid format in fecha parse");
        }
        // Check to see if the format is actually a mask
        format = globalMasks[format] || format;
        // Avoid regular expression denial of service, fail early for really long strings
        // https://www.owasp.org/index.php/Regular_expression_Denial_of_Service_-_ReDoS
        if (dateStr.length > 1000) {
            return null;
        }
        // Default to the beginning of the year.
        var today = new Date();
        var dateInfo = {
            year: today.getFullYear(),
            month: 0,
            day: 1,
            hour: 0,
            minute: 0,
            second: 0,
            millisecond: 0,
            isPm: null,
            timezoneOffset: null
        };
        var parseInfo = [];
        var literals = [];
        // Replace all the literals with @@@. Hopefully a string that won't exist in the format
        var newFormat = format.replace(literal, function ($0, $1) {
            literals.push(regexEscape($1));
            return "@@@";
        });
        var specifiedFields = {};
        var requiredFields = {};
        // Change every token that we find into the correct regex
        newFormat = regexEscape(newFormat).replace(token, function ($0) {
            var info = parseFlags[$0];
            var _a = __read(info, 4), field = _a[0], regex = _a[1], requiredField = _a[3];
            // Check if the person has specified the same field twice. This will lead to confusing results.
            if (specifiedFields[field]) {
                throw new Error("Invalid format. " + field + " specified twice in format");
            }
            specifiedFields[field] = true;
            // Check if there are any required fields. For instance, 12 hour time requires AM/PM specified
            if (requiredField) {
                requiredFields[requiredField] = true;
            }
            parseInfo.push(info);
            return "(" + regex + ")";
        });
        // Check all the required fields are present
        Object.keys(requiredFields).forEach(function (field) {
            if (!specifiedFields[field]) {
                throw new Error("Invalid format. " + field + " is required in specified format");
            }
        });
        // Add back all the literals after
        newFormat = newFormat.replace(/@@@/g, function () { return literals.shift(); });
        // Check if the date string matches the format. If it doesn't return null
        var matches = dateStr.match(new RegExp(newFormat, "i"));
        if (!matches) {
            return null;
        }
        var combinedI18nSettings = assign(assign({}, globalI18n), i18n);
        // For each match, call the parser function for that date part
        for (var i = 1; i < matches.length; i++) {
            var _a = __read(parseInfo[i - 1], 3), field = _a[0], parser = _a[2];
            var value = parser
                ? parser(matches[i], combinedI18nSettings)
                : +matches[i];
            // If the parser can't make sense of the value, return null
            if (value == null) {
                return null;
            }
            dateInfo[field] = value;
        }
        if (dateInfo.isPm === 1 && dateInfo.hour != null && +dateInfo.hour !== 12) {
            dateInfo.hour = +dateInfo.hour + 12;
        }
        else if (dateInfo.isPm === 0 && +dateInfo.hour === 12) {
            dateInfo.hour = 0;
        }
        var dateWithoutTZ = new Date(dateInfo.year, dateInfo.month, dateInfo.day, dateInfo.hour, dateInfo.minute, dateInfo.second, dateInfo.millisecond);
        var validateFields = [
            ["month", "getMonth"],
            ["day", "getDate"],
            ["hour", "getHours"],
            ["minute", "getMinutes"],
            ["second", "getSeconds"]
        ];
        for (var i = 0, len = validateFields.length; i < len; i++) {
            // Check to make sure the date field is within the allowed range. Javascript dates allows values
            // outside the allowed range. If the values don't match the value was invalid
            if (specifiedFields[validateFields[i][0]] &&
                dateInfo[validateFields[i][0]] !== dateWithoutTZ[validateFields[i][1]]()) {
                return null;
            }
        }
        if (dateInfo.timezoneOffset == null) {
            return dateWithoutTZ;
        }
        return new Date(Date.UTC(dateInfo.year, dateInfo.month, dateInfo.day, dateInfo.hour, dateInfo.minute - dateInfo.timezoneOffset, dateInfo.second, dateInfo.millisecond));
    }
    var fecha = {
        format: format,
        parse: parse,
        defaultI18n: defaultI18n,
        setGlobalDateI18n: setGlobalDateI18n,
        setGlobalDateMasks: setGlobalDateMasks
    };

    var dates = /** @class */ (function () {
        function dates() {
        }
        dates.init = function (format) {
            dates.deffmt = format;
            this.tokens$ = dates.split(format, "-/:. ");
            for (var i = 0; i < this.tokens$.length; i++) {
                if (this.tokens$[i].delim != " ") {
                    dates.delim = this.tokens$[i].delim;
                    break;
                }
            }
            dates.formattokens = new Set();
            dates.formattokens.add("m");
            dates.formattokens.add("d");
            dates.formattokens.add("o");
            dates.formattokens.add("d");
            dates.formattokens.add("y");
            dates.formattokens.add("a");
            dates.formattokens.add("h");
            dates.formattokens.add("s");
            dates.formattokens.add("z");
        };
        dates.setFormat = function (format) {
            dates.init(format);
        };
        dates.parse = function (datestr, format) {
            if (format == null)
                format = dates.deffmt;
            if (datestr == null || datestr.trim().length == 0)
                return (null);
            var date = parse(datestr, format);
            if (date == null)
                datestr = dates.reformat(datestr);
            if (datestr == null)
                return (null);
            return (parse(datestr, format));
        };
        dates.format = function (date, format$1) {
            if (format$1 == null)
                format$1 = dates.deffmt;
            return (format(date, format$1));
        };
        dates.reformat = function (datestr) {
            var ndate = "";
            if (!isNaN(+datestr)) {
                var pos = 0;
                for (var i = 0; i < 3; i++) {
                    var len = dates.tokens$[i].token.length;
                    ndate += datestr.substring(pos, pos + len) + dates.tokens$[i].delim;
                    pos += len;
                }
                return (ndate);
            }
            if (dates.delim != "-")
                datestr = dates.replaceAll(datestr, "-", dates.delim);
            if (dates.delim != "/")
                datestr = dates.replaceAll(datestr, "/", dates.delim);
            if (dates.delim != ".")
                datestr = dates.replaceAll(datestr, ".", dates.delim);
            var parts = dates.split(datestr, dates.delim + ": ");
            for (var i = 0; i < parts.length; i++) {
                var numeric = !isNaN(+parts[i].token);
                if (numeric && parts[i].token.length == 1)
                    parts[i].token = "0" + parts[i].token;
            }
            parts.forEach(function (part) { ndate += part.token + part.delim; });
            return (ndate);
        };
        dates.split = function (str, splitter) {
            var parts = [];
            var delimiters = new Set();
            for (var i = 0; i < splitter.length; i++)
                delimiters.add(splitter[i] + "");
            var pos = 0;
            for (var i = 0; i < str.length; i++) {
                if (delimiters.has(str[i] + "")) {
                    parts.push({ token: str.substring(pos, i), delim: str[i] });
                    pos = i + 1;
                }
            }
            if (pos < str.length)
                parts.push({ token: str.substring(pos, str.length), delim: "" });
            return (parts);
        };
        dates.replaceAll = function (str, search, replace) {
            while (str.indexOf(search) >= 0)
                str = str.replace(search, replace);
            return (str);
        };
        return dates;
    }());
    // Current implementation from
    // https://github.com/taylorhakes/fecha/blob/master/README.md
    dates.delim = null;
    dates.deffmt = null;
    dates.tokens$ = null;
    dates.formattokens = null;

    var DateField = /** @class */ (function (_super) {
        __extends(DateField, _super);
        function DateField() {
            var _this = _super.apply(this, __spread(arguments)) || this;
            _this.dateval = null;
            _this.formatted = null;
            return _this;
        }
        Object.defineProperty(DateField.prototype, "value", {
            get: function () {
                if (this.element$.value == this.formatted) {
                    // Invalid date
                    if (this.formatted.length > 0 && this.dateval == null)
                        return (this.formatted);
                    return (this.dateval);
                }
                return (this.element$.value);
            },
            set: function (value) {
                if (value == null || value.constructor.name != "Date") {
                    if (value != this.formatted || value != this.element$.value) {
                        this.dateval = null;
                        this.formatted = value;
                        this.element$.value = value;
                    }
                }
                else {
                    this.dateval = value;
                    this.formatted = dates.format(value);
                    this.element$.value = this.formatted;
                }
            },
            enumerable: false,
            configurable: true
        });
        DateField.prototype.validate = function () {
            var strval = this.element$.value;
            if (strval == this.formatted) {
                if (strval != null && dates.parse(strval) == null)
                    return (false);
                return (true);
            }
            this.formatted = null;
            this.dateval = dates.parse(strval);
            if (this.dateval == null && strval != null)
                return (false);
            if (this.dateval != null)
                this.formatted = dates.format(this.dateval);
            this.element$.value = this.formatted;
            return (true);
        };
        return DateField;
    }(TextField));

    var RadioButton = /** @class */ (function (_super) {
        __extends(RadioButton, _super);
        function RadioButton() {
            var _this = _super.apply(this, __spread(arguments)) || this;
            _this.actvalue = null;
            _this.chkvalue = null;
            return _this;
        }
        Object.defineProperty(RadioButton.prototype, "html", {
            get: function () {
                return ("<input type='radio'></input>");
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(RadioButton.prototype, "value", {
            get: function () {
                return (this.actvalue);
            },
            set: function (value) {
                if (this.chkvalue == null) {
                    this.chkvalue = value;
                    return;
                }
                this.actvalue = value;
                // cheat compiler
                var radio = this.element;
                if (value == this.chkvalue)
                    radio.checked = true;
                else
                    radio.checked = false;
            },
            enumerable: false,
            configurable: true
        });
        return RadioButton;
    }(TextField));

    (function (Column) {
        Column[Column["int"] = 0] = "int";
        Column[Column["date"] = 1] = "date";
        Column[Column["decimal"] = 2] = "decimal";
        Column[Column["integer"] = 3] = "integer";
        Column[Column["varchar"] = 4] = "varchar";
        Column[Column["datetime"] = 5] = "datetime";
    })(exports.Column || (exports.Column = {}));

    (function (FieldType) {
        FieldType[FieldType["date"] = 0] = "date";
        FieldType[FieldType["text"] = 1] = "text";
        FieldType[FieldType["radio"] = 2] = "radio";
        FieldType[FieldType["integer"] = 3] = "integer";
        FieldType[FieldType["decimal"] = 4] = "decimal";
        FieldType[FieldType["checkbox"] = 5] = "checkbox";
        FieldType[FieldType["datetime"] = 6] = "datetime";
        FieldType[FieldType["password"] = 7] = "password";
        FieldType[FieldType["dropdown"] = 8] = "dropdown";
    })(exports.FieldType || (exports.FieldType = {}));
    var FieldImplementation = /** @class */ (function () {
        function FieldImplementation() {
        }
        FieldImplementation.init = function () {
            if (FieldImplementation.impl != null)
                return;
            FieldImplementation.impl = new Map();
            Object.keys(exports.FieldType).forEach(function (type) {
                if (isNaN(Number(type)))
                    FieldImplementation.impl.set(type, TextField);
            });
            FieldImplementation.impl.set(exports.FieldType[exports.FieldType.date], DateField);
            FieldImplementation.impl.set(exports.FieldType[exports.FieldType.radio], RadioButton);
            FieldImplementation.impl.set(exports.FieldType[exports.FieldType.checkbox], CheckBox);
            FieldImplementation.impl.set(exports.FieldType[exports.FieldType.password], Password);
            FieldImplementation.impl.set(exports.FieldType[exports.FieldType.dropdown], DropDown);
            FieldImplementation.impl.set(exports.FieldType[exports.FieldType.datetime], DateField);
        };
        FieldImplementation.getClass = function (type) {
            FieldImplementation.init();
            return (FieldImplementation.impl.get(type));
        };
        FieldImplementation.guess = function (type) {
            var ftype = exports.FieldType.text;
            if (type != null) {
                ftype = exports.FieldType.text;
                if (type == exports.Column.date)
                    ftype = exports.FieldType.date;
                if (type == exports.Column.integer)
                    ftype = exports.FieldType.integer;
                if (type == exports.Column.decimal)
                    ftype = exports.FieldType.decimal;
                if (type == exports.Column.datetime)
                    ftype = exports.FieldType.datetime;
            }
            return (ftype);
        };
        return FieldImplementation;
    }());
    FieldImplementation.impl = null;

    var FormState;
    (function (FormState) {
        FormState[FormState["normal"] = 0] = "normal";
        FormState[FormState["entqry"] = 1] = "entqry";
        FormState[FormState["exeqry"] = 2] = "exeqry";
    })(FormState || (FormState = {}));

    var KeyCodes = /** @class */ (function () {
        function KeyCodes() {
        }
        return KeyCodes;
    }());
    KeyCodes.backspace = 8;
    KeyCodes.tab = 9;
    KeyCodes.enter = 13;
    KeyCodes.escape = 27;
    KeyCodes.pageup = 33;
    KeyCodes.pagedown = 34;
    KeyCodes.end = 35;
    KeyCodes.home = 36;
    KeyCodes.up = 38;
    KeyCodes.down = 40;
    KeyCodes.left = 37;
    KeyCodes.right = 39;
    KeyCodes.insert = 45;
    KeyCodes.delete = 46;
    KeyCodes.f1 = 112;
    KeyCodes.f2 = 113;
    KeyCodes.f3 = 114;
    KeyCodes.f4 = 115;
    KeyCodes.f5 = 116;
    KeyCodes.f6 = 117;
    KeyCodes.f7 = 118;
    KeyCodes.f8 = 119;
    KeyCodes.f9 = 120;
    KeyCodes.f10 = 121;
    KeyCodes.f11 = 122;
    KeyCodes.f12 = 123;

    var WindowListener = /** @class */ (function () {
        function WindowListener() {
        }
        WindowListener.add = function (id, clazz, event) {
            var events = WindowListener.events.get(event);
            if (events == null) {
                events = new Map();
                WindowListener.events.set(event, events);
                var listener = new WindowListener();
                listener.start(event);
            }
            events.set(id, clazz);
        };
        WindowListener.remove = function (id, event) {
            var events = WindowListener.events.get(event);
            events.delete(id);
        };
        WindowListener.prototype.start = function (eventtype) {
            var _this = this;
            window.addEventListener(eventtype, function (event) { _this.onEvent(event); });
        };
        WindowListener.prototype.onEvent = function (event) {
            var events = WindowListener.events.get(event.type);
            events.forEach(function (clazz) { clazz.onEvent(event); });
        };
        return WindowListener;
    }());
    WindowListener.events = new Map();

    var PopupWindow = /** @class */ (function () {
        function PopupWindow(ctx, change) {
            this.change = change;
            this.top = null;
            this.left = null;
            this.width = "300px";
            this.height = "200px";
            this.tmargin = "8px";
            this.minw = 0;
            this.minh = 0;
            this.offx = 0;
            this.offy = 0;
            this.move = false;
            this.resz = false;
            this.resizex = false;
            this.resizey = false;
            this.app = ctx.app["_impl_"];
        }
        Object.defineProperty(PopupWindow.prototype, "tcolor", {
            get: function () {
                return (this.app.config.colors.title);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PopupWindow.prototype, "bcolor", {
            get: function () {
                return (this.app.config.colors.topbar);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PopupWindow.prototype, "btncolor", {
            get: function () {
                return (this.app.config.colors.buttontext);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PopupWindow.prototype, "title", {
            set: function (title) {
                this.title$ = title;
            },
            enumerable: false,
            configurable: true
        });
        PopupWindow.prototype.setPopup = function (pinst) {
            this.pinst = pinst;
            this.popup = pinst.popupref.instance;
            this.popup.setWin(this);
            this.title$ = this.popup.title;
            if (this.popup.hasOwnProperty("top"))
                this.top = this.popup.top;
            if (this.popup.hasOwnProperty("left"))
                this.left = this.popup.left;
            if (this.popup.hasOwnProperty("width"))
                this.width = this.popup.width;
            if (this.popup.hasOwnProperty("height"))
                this.height = this.popup.height;
        };
        PopupWindow.prototype.setWinRef = function (winref) {
            this.winref = winref;
        };
        PopupWindow.prototype.close = function (cancel) {
            this.closeWindow();
            this.popup.close(cancel);
        };
        PopupWindow.prototype.closeWindow = function () {
            if (this.winref == null)
                return;
            WindowListener.remove("modal", "mouseup");
            WindowListener.remove("modal", "mousemove");
            WindowListener.remove("modal", "mousedown");
            var formelem = this.content.firstElementChild;
            if (formelem != null)
                this.content.removeChild(formelem);
            this.app.builder.getAppRef().detachView(this.pinst.popupref.hostView);
            var element = this.winref.hostView.rootNodes[0];
            document.body.removeChild(element);
            this.app.builder.getAppRef().detachView(this.winref.hostView);
            this.winref.destroy();
            this.winref = null;
        };
        PopupWindow.prototype.display = function () {
            var _this = this;
            if (this.pinst == null) {
                setTimeout(function () { _this.display(); }, 10);
                return;
            }
            this.element = this.pinst.popupref.hostView.rootNodes[0];
            this.app.builder.getAppRef().attachView(this.pinst.popupref.hostView);
            this.content.appendChild(this.element);
            this.minh = 150;
            this.minw = 250;
            this.titlebar.innerHTML = this.title$;
            this.change.detectChanges();
            this.posy = this.window.offsetTop;
            this.posx = this.window.offsetLeft;
            this.sizex = this.window.offsetWidth;
            this.sizey = this.window.offsetHeight;
            var resize = false;
            if (this.sizex < this.minw) {
                resize = true;
                this.sizex = this.minw;
                this.width = this.sizex + "px";
            }
            if (this.sizey < this.minh) {
                resize = true;
                this.sizey = this.minh;
                this.height = this.sizey + "px";
            }
            if (this.top == null || this.top.trim.length == 0) {
                resize = true;
                this.top = ((+window.innerHeight - this.sizey) / 3) + "px";
            }
            if (this.left == null || this.left.trim.length == 0) {
                resize = true;
                this.left = ((+window.innerWidth - this.sizex) / 1.5) + "px";
            }
            if (resize) {
                this.change.detectChanges();
                this.posy = this.window.offsetTop;
                this.posx = this.window.offsetLeft;
                this.sizex = this.window.offsetWidth;
                this.sizey = this.window.offsetHeight;
            }
        };
        PopupWindow.prototype.ngAfterViewInit = function () {
            var _this = this;
            var _a, _b, _c, _d;
            this.window = (_a = this.windowElement) === null || _a === void 0 ? void 0 : _a.nativeElement;
            this.topbar = (_b = this.topbarElement) === null || _b === void 0 ? void 0 : _b.nativeElement;
            this.content = (_c = this.contentElement) === null || _c === void 0 ? void 0 : _c.nativeElement;
            this.titlebar = (_d = this.titlebarElement) === null || _d === void 0 ? void 0 : _d.nativeElement;
            this.display();
            WindowListener.add("modal", this, "mouseup");
            WindowListener.add("modal", this, "mousemove");
            WindowListener.add("modal", this, "mousedown");
            this.topbar.addEventListener("mousedown", function (event) { _this.startmove(event); });
        };
        PopupWindow.prototype.onEvent = function (event) {
            switch (event.type) {
                case "mouseup":
                    this.mouseup();
                    break;
                case "mousemove":
                    this.movePopup(event);
                    this.resizePopup(event);
                    this.resizemousemove(event);
                    break;
                case "mousedown":
                    this.startresize(event);
                    break;
            }
        };
        PopupWindow.prototype.startmove = function (event) {
            if (this.resizexy)
                return;
            this.move = true;
            event = event || window.event;
            event.preventDefault();
            this.offy = +event.clientY - this.posy;
            this.offx = +event.clientX - this.posx;
        };
        PopupWindow.prototype.mouseup = function () {
            if (!this.move && !this.resz)
                return;
            this.move = false;
            this.resz = false;
            this.resizexy = false;
            this.window.style.cursor = "default";
            document.body.style.cursor = "default";
        };
        PopupWindow.prototype.movePopup = function (event) {
            if (!this.move)
                return;
            event = event || window.event;
            var deltay = +event.clientY - this.posy;
            var deltax = +event.clientX - this.posx;
            this.posy += (deltay - this.offy);
            this.posx += (deltax - this.offx);
            if (this.posy > 0)
                this.top = this.posy + "px";
            if (this.posx > 0)
                this.left = this.posx + "px";
            this.change.detectChanges();
        };
        PopupWindow.prototype.resizemousemove = function (event) {
            if (this.resz)
                return;
            event = event || window.event;
            var posx = +event.clientX;
            var posy = +event.clientY;
            var offx = this.posx + this.sizex - posx;
            var offy = this.posy + this.sizey - posy;
            var before = false;
            if (this.resizex || this.resizey)
                before = true;
            this.resizex = false;
            this.resizey = false;
            if (offx > -7 && offx < 10 && posy > this.posy - 7 && posy < this.posy + this.sizey + 7)
                this.resizex = true;
            if (offy > -7 && offy < 10 && posx > this.posx - 7 && posx < this.posx + this.sizex + 7)
                this.resizey = true;
            if (this.resizex && this.resizey) {
                this.resizex = true;
                this.resizey = true;
            }
            if (this.resizex && !this.resizey) {
                this.window.style.cursor = "e-resize";
                document.body.style.cursor = "e-resize";
            }
            if (this.resizey && !this.resizex) {
                this.window.style.cursor = "s-resize";
                document.body.style.cursor = "s-resize";
            }
            if (this.resizex && this.resizey) {
                this.window.style.cursor = "se-resize";
                document.body.style.cursor = "se-resize";
            }
            if (before && !this.resizexy) {
                this.window.style.cursor = "default";
                document.body.style.cursor = "default";
            }
        };
        PopupWindow.prototype.startresize = function (event) {
            if (!this.resizexy)
                return;
            this.resz = true;
            event = event || window.event;
            event.preventDefault();
            this.offy = +event.clientY;
            this.offx = +event.clientX;
        };
        PopupWindow.prototype.resizePopup = function (event) {
            if (!this.resz)
                return;
            event = event || window.event;
            var deltay = +event.clientY - this.offy;
            var deltax = +event.clientX - this.offx;
            if (this.resizex && (this.sizex > this.minw || deltax > 0)) {
                this.sizex += deltax;
                this.width = this.sizex + "px";
            }
            if (this.resizey && (this.sizey > this.minh || deltay > 0)) {
                this.sizey += deltay;
                this.height = this.sizey + "px";
            }
            this.offy = +event.clientY;
            this.offx = +event.clientX;
            this.change.detectChanges();
        };
        Object.defineProperty(PopupWindow.prototype, "resizexy", {
            get: function () {
                if (this.resizex || this.resizey)
                    return (true);
                return (false);
            },
            set: function (on) {
                this.resizex = on;
                this.resizey = on;
            },
            enumerable: false,
            configurable: true
        });
        return PopupWindow;
    }());
    PopupWindow.decorators = [
        { type: i0.Component, args: [{
                    selector: 'popupwindow',
                    template: "\n    <div class=\"popupwindow\">\n      <div #window class=\"popupwindow-modal-block\" style=\"top: {{top}}; left: {{left}}\">\n        <div class=\"popupwindow-container\" style=\"width: {{width}}; height: {{height}};\">\n\t\t  <div #topbar class=\"popupwindow-topbar\" style=\"color: {{tcolor}}; background-color: {{bcolor}}\">\n\t\t    <span class=\"popupwindow-center\" style=\"color: {{tcolor}};\">\n\t\t\t\t<span class=\"popupwindow-corner\"></span>\n\t\t\t\t<div #title></div>\n                <span class=\"popupwindow-close\">\n                    <button class=\"popupwindow-button\" style=\"color: {{btncolor}};\" (click)=\"close(true)\">X</button>\n                </span>\n\t\t\t</span>\n\t\t   </div>\n          <div class=\"popupwindow-block\" style=\"margin-top: {{tmargin}};\"><div #content></div></div>\n        </div>\n      </div>\n    </div>\n  ",
                    changeDetection: i0.ChangeDetectionStrategy.OnPush,
                    styles: ["\n    .popupwindow\n    {\n        top: 0;\n        left: 0;\n        z-index: 1;\n        width: 100%;\n        height: 100%;\n        display: block;\n        overflow: auto;\n        position: fixed;\n    }\n\n    .popupwindow-modal-block\n    {\n      position: absolute;\n      background-color: #fefefe;\n    }\n\n    .popupwindow-container\n    {\n        position: relative;\n        border: 2px solid black;\n    }\n\n    .popupwindow-topbar\n    {\n        height: 1.70em;\n        margin-left: 0;\n        margin-right: 0;\n        cursor:default;\n\t\tjustify-content: center;\n        border-bottom: 2px solid black;\n    }\n\n\t.popupwindow-corner\n\t{\n\t\twidth: 1.5em;\n\t\tdisplay: block;\n\t\tposition: relative;\n\t}\n\n\t.popupwindow-close\n\t{\n\t\ttop: 0;\n\t\tright: 0;\n\t\twidth: 1.75em;\n\t\theight: 1.70em;\n\t\tposition: absolute;\n\t\tborder-left: 1px solid black;\n\t}\n\n\t.popupwindow-button\n\t{\n\t\ttop: 50%;\n\t\twidth: 100%;\n\t\theight: 100%;\n\t\toutline:none;\n\t\tfont-size: 0.75em;\n\t\tfont-weight: bold;\n\t\tposition: relative;\n\t\tbackground: transparent;\n\t\ttransform: translateY(-50%);\n\t\tborder: 0px solid transparent;\n\t\tbox-shadow: 0px 0px 0px transparent;\n\t\ttext-shadow: 0px 0px 0px transparent;\n\t}\n\n\t.popupwindow-center\n\t{\n\t\ttop: 0;\n\t\tbottom: 0;\n\t\twidth: 93%;\n\t\theight: 100%;\n\t\tdisplay: flex;\n\t\talign-items: center;\n\t\tjustify-content: center;\n\t}\n\n    .popupwindow-block\n    {\n        left: 0;\n        top: 3vh;\n        right: 0;\n        bottom: 0;\n\t\tdisplay: flex;\n        overflow: auto;\n        position: absolute;\n\t\tjustify-content: center;\n    }\n"]
                },] }
    ];
    PopupWindow.ctorParameters = function () { return [
        { type: Context },
        { type: i0.ChangeDetectorRef }
    ]; };
    PopupWindow.propDecorators = {
        titlebarElement: [{ type: i0.ViewChild, args: ["title", { read: i0.ElementRef },] }],
        windowElement: [{ type: i0.ViewChild, args: ["window", { read: i0.ElementRef },] }],
        topbarElement: [{ type: i0.ViewChild, args: ["topbar", { read: i0.ElementRef },] }],
        contentElement: [{ type: i0.ViewChild, args: ['content', { read: i0.ElementRef },] }]
    };

    var PopupInstance = /** @class */ (function () {
        function PopupInstance() {
        }
        PopupInstance.prototype.display = function (app, popup) {
            this.popupref = app.builder.createComponent(popup);
            var winref = app.builder.createComponent(PopupWindow);
            var win = winref.instance;
            win.setPopup(this);
            win.setWinRef(winref);
            var element = winref.hostView.rootNodes[0];
            app.builder.getAppRef().attachView(winref.hostView);
            document.body.appendChild(element);
        };
        PopupInstance.prototype.popup = function () {
            return (this.popupref.instance);
        };
        return PopupInstance;
    }());

    var DatePicker = /** @class */ (function () {
        function DatePicker(ctx) {
            this.ctx = ctx;
            this.top = null;
            this.left = null;
            this.title = null;
            this.width = "256px";
            this.height = "256px";
            this.cdate = null;
            this.win = null;
            this.cal = null;
            this.days = null;
            this.years = null;
            this.months = null;
            this.app = ctx.app["_impl_"];
            this.title = ctx.conf.calendarname;
        }
        DatePicker.show = function (app, impl, record, field, date) {
            var pinst = new PopupInstance();
            pinst.display(app, DatePicker);
            var datepicker = pinst.popup();
            datepicker.date = date;
            datepicker.setDestination(impl, record, field);
        };
        DatePicker.prototype.close = function (_cancel) {
            this.win.closeWindow();
        };
        Object.defineProperty(DatePicker.prototype, "date", {
            set: function (date) {
                if (date == null)
                    date = new Date();
                this.cdate = date;
            },
            enumerable: false,
            configurable: true
        });
        DatePicker.prototype.setDestination = function (impl, record, field) {
            this.impl = impl;
            this.field = field;
            this.record = record;
        };
        DatePicker.prototype.pick = function (event) {
            var year = +this.years.value;
            var month = +this.months.value;
            var day = +event.target.innerHTML;
            var cday = this.cdate.getUTCDate();
            var cmonth = this.cdate.getUTCMonth();
            var cyear = this.cdate.getUTCFullYear();
            if (year != cyear || month != cmonth || day != cday) {
                this.cdate = new Date(Date.UTC(year, month - 1, day));
                // Truncate
                this.cdate = new Date(this.cdate.toDateString());
                this.impl.setValue(this.record, this.field, this.cdate);
                this.impl.focus();
            }
            this.close(false);
        };
        DatePicker.prototype.setWin = function (win) {
            this.win = win;
        };
        DatePicker.prototype.ngAfterViewInit = function () {
            var _a;
            this.cal = (_a = this.calelem) === null || _a === void 0 ? void 0 : _a.nativeElement;
            this.build(this.cdate, 75, 75);
        };
        DatePicker.prototype.navigate = function (event) {
            if (event.keyCode == KeyCodes.tab) {
                event.preventDefault();
                if (event.target.name == "months")
                    this.years.focus();
                else
                    this.months.focus();
                return;
            }
            if (event.keyCode == KeyCodes.escape)
                this.close(true);
        };
        DatePicker.prototype.weekdays = function (locale) {
            var fmt = new Intl.DateTimeFormat(locale, { weekday: "short" }).format;
            var names = __spread(Array(7).keys()).map(function (d) { return fmt(new Date(Date.UTC(2021, 1, d))); });
            for (var i = 0; i < 7; i++) {
                if (names[i].endsWith("."))
                    names[i] = names[i].substring(0, names[i].length - 1);
            }
            var sun = names[0];
            names.shift();
            names.push(sun);
            return (names);
        };
        DatePicker.prototype.monthnames = function (locale) {
            var fmt = new Intl.DateTimeFormat(locale, { month: "short" }).format;
            var names = __spread(Array(12).keys()).map(function (m) { return fmt(new Date(Date.UTC(2021, m))); });
            for (var i = 0; i < 12; i++) {
                if (names[i].endsWith("."))
                    names[i] = names[i].substring(0, names[i].length - 1);
            }
            return (names);
        };
        DatePicker.prototype.build = function (date, bef, aft) {
            this.styles();
            var month = date.getUTCMonth();
            var year = date.getUTCFullYear();
            var months = this.monthnames(this.ctx.conf.locale);
            this.years = document.createElement("select");
            this.months = document.createElement("select");
            this.years.name = "years";
            this.months.name = "months";
            this.addFieldTriggers(this.years);
            this.addFieldTriggers(this.months);
            this.months.classList.add("datepicker-month");
            for (var i = 0; i < 12; i++) {
                var option = document.createElement("option");
                option.text = months[i];
                option.value = (i + 1) + "";
                this.months.appendChild(option);
            }
            this.months.selectedIndex = month;
            this.cal.appendChild(this.months);
            this.years.classList.add("datepicker-year");
            for (var i = year - bef; i < year + aft; i++) {
                var option = document.createElement("option");
                option.text = i + "";
                option.value = i + "";
                this.years.appendChild(option);
            }
            this.years.selectedIndex = bef;
            this.cal.appendChild(this.years);
            this.days = document.createElement("div");
            this.days.classList.add("datepicker-days");
            this.cal.appendChild(this.days);
            this.draw();
            this.months.focus();
        };
        DatePicker.prototype.draw = function () {
            var cday = this.cdate.getDate();
            var cmonth = this.cdate.getMonth();
            var cyear = this.cdate.getFullYear();
            var year = +this.years.value;
            var month = +this.months.value;
            if (year != cyear || month != +cmonth + +1)
                cday = 0;
            var days = new Date(Date.UTC(year, month, 0)).getUTCDate();
            var first = new Date(Date.UTC(year, month - 1, 1)).getUTCDay();
            var last = new Date(Date.UTC(year, month - 1, days)).getUTCDay();
            last = last == 0 ? 7 : last;
            first = first == 0 ? 7 : first;
            var squares = [];
            for (var i = 1; i < first; i++)
                squares.push([false, 0]);
            for (var i = 0; i < days; i++)
                squares.push([true, i]);
            while (squares.length % 7 != 0)
                squares.push([false, 0]);
            var names = this.weekdays(this.ctx.conf.locale);
            var table = document.createElement("table");
            table.classList.add("datepicker-table");
            var row = table.insertRow();
            names.forEach(function (day) {
                var cell = row.insertCell();
                cell.classList.add("datepicker-head");
                cell.innerHTML = day;
            });
            for (var i = 0; i < squares.length; i++) {
                if (i % 7 == 0)
                    row = table.insertRow();
                var cell = row.insertCell();
                if (squares[i][0]) {
                    var dom = +squares[i][1] + +1;
                    cell.innerHTML = dom + "";
                    cell.classList.add("datepicker-day");
                    if (dom == cday)
                        cell.classList.add("datepicker-current");
                    this.addDayTriggers(cell);
                }
                else {
                    cell.classList.add("datepicker-blank");
                }
            }
            this.days.innerHTML = "";
            this.days.appendChild(table);
        };
        DatePicker.prototype.addDayTriggers = function (cell) {
            var _this = this;
            cell.addEventListener("click", function (event) { _this.pick(event); });
        };
        DatePicker.prototype.addFieldTriggers = function (change) {
            var _this = this;
            change.addEventListener("change", function () { _this.draw(); });
            change.addEventListener("keydown", function (event) { _this.navigate(event); });
        };
        DatePicker.prototype.styles = function () {
            this.cal.innerHTML =
                "\n        <style>\n            .datepicker-month\n            {\n                width: 64px;\n                font-size: 15px;\n                margin-left: 16px;\n            }\n\n            .datepicker-year\n            {\n                width: 64px;\n                font-size: 15px;\n                margin-left: 32px;\n            }\n\n            .datepicker-table\n            {\n                width: 100%;\n                margin-top: 14px;\n                border-collapse: separate;\n            }\n\n            .datepicker-head\n            {\n                font-weight: bold;\n                text-align: center;\n                color: " + this.app.config.colors.text + ";\n            }\n\n            .datepicker-day\n            {\n                color: " + this.app.config.colors.buttontext + ";\n                padding: 5px;\n                width: 14.28%;\n                text-align: center;\n                background: " + this.app.config.colors.topbar + ";\n            }\n\n            .datepicker-blank\n            {\n                background: #ddd;\n            }\n\n            .datepicker-current\n            {\n                font-size: 16px;\n                font-weight: bold;\n            }\n\n            .datepicker-day:hover\n            {\n                cursor: pointer;\n                font-weight: bold;\n                font-style: italic;\n            }\n        </style>\n        ";
        };
        return DatePicker;
    }());
    DatePicker.decorators = [
        { type: i0.Component, args: [{
                    template: "\n        <div #calendar></div>\n    "
                },] }
    ];
    DatePicker.ctorParameters = function () { return [
        { type: Context }
    ]; };
    DatePicker.propDecorators = {
        calelem: [{ type: i0.ViewChild, args: ["calendar", { read: i0.ElementRef },] }]
    };

    var MessageBox = /** @class */ (function () {
        function MessageBox(ctx) {
            this.top = "20%";
            this.left = "25%";
            this.width$ = "100px";
            this.height$ = "100px";
            this.title$ = "alert";
            this.message = "the message";
            this.msg = null;
            this.btn = null;
            this.app = ctx.app["_impl_"];
        }
        MessageBox.show = function (app, message, title, width, height) {
            var pinst = new PopupInstance();
            pinst.display(app, MessageBox);
            var mbox = pinst.popup();
            mbox.title = title;
            mbox.message = message;
            if (width != null)
                mbox.width = width;
            if (height != null)
                mbox.height = height;
        };
        Object.defineProperty(MessageBox.prototype, "bcolor", {
            get: function () {
                return (this.app.config.colors.topbar);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MessageBox.prototype, "tcolor", {
            get: function () {
                return (this.app.config.colors.buttontext);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MessageBox.prototype, "width", {
            get: function () {
                return (this.width$);
            },
            set: function (width) {
                this.width$ = width;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MessageBox.prototype, "height", {
            get: function () {
                return (this.height$);
            },
            set: function (height) {
                this.height$ = height;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MessageBox.prototype, "title", {
            get: function () {
                return (this.title$);
            },
            set: function (title) {
                this.title$ = title;
                this.win.title = this.title;
            },
            enumerable: false,
            configurable: true
        });
        MessageBox.prototype.setWin = function (win) {
            this.win = win;
        };
        MessageBox.prototype.close = function (_cancel) {
            var _this = this;
            var _a;
            this.btn.removeEventListener("click", function () { _this.close(false); });
            this.btn.removeEventListener("keydown", function () { _this.close(false); });
            this.win.closeWindow();
            (_a = this.app.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.focus();
        };
        MessageBox.prototype.ngAfterViewInit = function () {
            var _this = this;
            var _a, _b;
            this.msg = (_a = this.msgelem) === null || _a === void 0 ? void 0 : _a.nativeElement;
            this.btn = (_b = this.acceptelem) === null || _b === void 0 ? void 0 : _b.nativeElement;
            setTimeout(function () { _this.addTriggers(); }, 1);
            this.msg.innerHTML = this.message;
            this.keepFocus(0);
        };
        MessageBox.prototype.addTriggers = function () {
            var _this = this;
            this.btn.addEventListener("click", function () { _this.close(false); });
            this.btn.addEventListener("keydown", function () { _this.close(false); });
        };
        MessageBox.prototype.keepFocus = function (delay) {
            var _this = this;
            this.btn.focus();
            setTimeout(function () { _this.keepFocus(delay + 1); }, delay);
        };
        return MessageBox;
    }());
    MessageBox.decorators = [
        { type: i0.Component, args: [{
                    selector: '',
                    template: "\n        <div class=\"messagebox\">\n            <div #msg class=\"messagebox-msg\"></div>\n            <div class=\"messagebox-buttom\">\n                <button #accept class=\"messagebox-btn\" style=\"color: {{tcolor}}; background-color: {{bcolor}};\">Ok</button>\n            </div>\n        </div>\n        ",
                    styles: ["\n        .messagebox\n        {\n            top: 0px;\n            left: 1px;\n            right: 1px;\n            bottom: 0px;\n            display: block;\n            position: absolute;\n        }\n\n        .messagebox-msg\n        {\n            height: 80px;\n            display: flex;\n            text-align: center;\n            word-wrap: break-all;\n            justify-content: center;\n        }\n\n        .messagebox-buttom\n        {\n            right: 1px;\n            bottom: 4px;\n            witdh: 35px;\n            height: 35px;\n            display: block;\n            position: absolute;\n        }\n\n        .messagebox-btn\n        {\n            border: none;\n            padding: 10px;\n            outline: none;\n            font-size: 15px;\n            cursor: pointer;\n            text-align: center;\n            border-radius: 100%;\n            display: inline-block;\n            text-decoration: none;\n        }\n    "]
                },] }
    ];
    MessageBox.ctorParameters = function () { return [
        { type: Context }
    ]; };
    MessageBox.propDecorators = {
        msgelem: [{ type: i0.ViewChild, args: ["msg", { read: i0.ElementRef },] }],
        acceptelem: [{ type: i0.ViewChild, args: ["accept", { read: i0.ElementRef },] }]
    };

    var Condition = /** @class */ (function () {
        function Condition(column, value, datatype) {
            this.level$ = 0;
            this.type$ = "and";
            this.prev$ = null;
            this.next$ = null;
            this.bindvalues$ = [];
            this.error$ = null;
            this.column$ = column;
            this.datatype$ = datatype;
            this.placeholder$ = column + Condition.ubid();
            if (this.column$ == null) {
                this.error$ = "cannot construct condition on unspecified column. Value = " + value;
                return;
            }
            if (value != null) {
                var type = value.constructor.name.toLowerCase();
                if (type == "date") {
                    this.datatype$ = exports.Column.date;
                    this.value$ = value.getTime();
                    this.datebtwn();
                    this.bindvalues$.push({ name: this.placeholder$[0], value: this.value$[0], type: this.datatype$ });
                    this.bindvalues$.push({ name: this.placeholder$[1], value: this.value$[1], type: this.datatype$ });
                    return;
                }
                if (type == "number") {
                    this.value$ = value;
                    this.operator$ = "=";
                    this.datatype$ = exports.Column.decimal;
                    this.bindvalues$.push({ name: this.placeholder$, value: this.value$, type: this.datatype$ });
                    return;
                }
            }
            if (value != null && (value + "").trim().length > 0 && this.datatype$ == null) {
                value = (value + "").trim();
                var numeric = !isNaN(+value);
                if (numeric)
                    this.datatype$ = exports.Column.decimal;
            }
            if (value == null) {
                this.operator$ = "is null";
                return;
            }
            if (this.datatype$ == null)
                this.datatype$ = exports.Column.varchar;
            this.operator$ = "";
            var quoted = false;
            if (value.startsWith("<"))
                this.operator$ = "<";
            else if (value.startsWith(">"))
                this.operator$ = ">";
            if (this.operator$.length == 1) {
                value = value.substring(1).trim();
                if (value.startsWith("="))
                    this.operator$ += "=";
            }
            if (this.operator$.length == 2)
                value = value.substring(1).trim();
            if (value.startsWith('"') && value.endsWith('"')) {
                quoted = true;
                value = value.substring(1, value.length - 1);
            }
            if (value.startsWith("'") && value.endsWith("'")) {
                quoted = true;
                value = value.substring(1, value.length - 1);
            }
            if (!quoted) {
                var like = false;
                if (value.indexOf("%") >= 0)
                    like = true;
                if (value.indexOf("_") >= 0)
                    like = true;
                if (like)
                    this.operator$ = "like";
            }
            this.value$ = value.trim();
            if (this.operator$.length == 0)
                this.operator$ = "=";
            if (this.datatype$ == exports.Column.decimal && isNaN(+this.value$)) {
                this.error$ = "Unable to parse " + this.value$ + " as number";
                return;
            }
            if (this.datatype$ == exports.Column.integer && isNaN(+this.value$)) {
                this.error$ = "Unable to parse " + this.value$ + " as number";
                return;
            }
            if (this.datatype$ == exports.Column.date) {
                var date = dates.parse(this.value$);
                if (date == null) {
                    this.error$ = "Unable to parse '" + this.value$ + "' as date";
                    return;
                }
                this.value$ = date.getTime();
                if (this.operator$ == "=")
                    this.datebtwn();
            }
            if (this.operator$ != "between") {
                this.bindvalues$.push({ name: this.placeholder$, value: this.value$, type: this.datatype$ });
            }
            else {
                this.bindvalues$.push({ name: this.placeholder$[0], value: this.value$[0], type: this.datatype$ });
                this.bindvalues$.push({ name: this.placeholder$[1], value: this.value$[1], type: this.datatype$ });
            }
        }
        Condition.ubid = function () {
            if (++Condition.id > 9999)
                Condition.id = 1;
            var ubid = "" + Condition.id;
            while (ubid.length < 4)
                ubid = "0" + ubid;
            return ("_" + ubid);
        };
        Condition.where = function (column, value, datatype) {
            var condition = new Condition(column, value, datatype);
            condition.type$ = "where";
            return (condition);
        };
        Condition.prototype.datebtwn = function () {
            this.operator$ = "between";
            var sdate = this.value$;
            // add 24 hours - minus 1 sec
            var edate = sdate + 60 * 60 * 24 * 1000 - 1000;
            this.value$ = [sdate, edate];
            this.placeholder$ = [this.placeholder$ + "_0", this.placeholder$ + "_1"];
        };
        Object.defineProperty(Condition.prototype, "column", {
            get: function () {
                return (this.column$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Condition.prototype, "placeholder", {
            get: function () {
                return (this.placeholder$);
            },
            enumerable: false,
            configurable: true
        });
        Condition.prototype.getValue = function () {
            if (this.bindvalues$.length == 0)
                return (null);
            if (this.bindvalues$.length == 1)
                return (this.bindvalues$[0].value);
            if (this.bindvalues$.length > 1) {
                var vals_1 = [];
                this.bindvalues$.forEach(function (bv) { vals_1.push(bv.value); });
                return (vals_1);
            }
        };
        Condition.prototype.setCondition = function (condition) {
            this.error$ = null;
            this.condition$ = condition;
        };
        Condition.prototype.error = function () {
            return (this.error$);
        };
        Condition.prototype.or = function () {
            this.type$ = "or";
            return (this);
        };
        Condition.prototype.and = function () {
            this.type$ = "and";
            return (this);
        };
        Condition.prototype.where = function () {
            this.type$ = "where";
            return (this);
        };
        Condition.prototype.next = function (next) {
            if (next == null)
                return (this.next$);
            if (this.next$ != null)
                this.next$.prev$ = next;
            this.next$ = next;
            next.prev$ = this;
            return (next);
        };
        Condition.prototype.prev = function (prev) {
            if (prev == null)
                return (this.prev$);
            if (this.prev$ != null)
                this.prev$.next$ = prev;
            this.prev$ = prev;
            prev.next$ = this;
            return (prev);
        };
        Condition.prototype.first = function () {
            var pc = this;
            while (pc.prev$ != null)
                pc = pc.prev$;
            return (pc);
        };
        Condition.prototype.last = function () {
            var nc = this;
            while (nc.next$ != null)
                nc = nc.next$;
            return (nc);
        };
        Condition.prototype.pop = function () {
            this.level$ = -1;
            return (this);
        };
        Condition.prototype.push = function () {
            this.level$ = +1;
            return (this);
        };
        Condition.prototype.errors = function () {
            var errors = [];
            var cd = this.first();
            while (cd != null) {
                if (cd.error() != null)
                    errors.push(cd.error());
                cd = cd.next$;
            }
            return (errors);
        };
        Condition.prototype.getAllBindvalues = function () {
            var bindvalues = [];
            var cd = this.first();
            while (cd != null) {
                cd.bindvalues$.forEach(function (bindvalue) { bindvalues.push(bindvalue); });
                cd = cd.next$;
            }
            return (bindvalues);
        };
        Condition.prototype.split = function () {
            var conditions = [];
            var cd = this.first();
            while (cd != null) {
                conditions.push(cd);
                cd = cd.next$;
            }
            return (conditions);
        };
        Condition.prototype.toString = function () {
            var nc = this;
            while (nc.prev$ != null)
                nc = nc.prev$;
            if (nc.next$ == null)
                return (nc.type$ + " " + this.clause(nc));
            var str = (nc.level$ == 0) ? "where " : "where (";
            str += this.clause(nc);
            if (nc.next$ != null)
                str += " " + nc.type$ + " ";
            while (nc.next$ != null) {
                nc = nc.next$;
                if (+nc.level$ > 0)
                    str += "(";
                str += this.clause(nc);
                if (+nc.level$ < 0)
                    str += ")";
                if (nc.next$ != null)
                    str += " " + nc.type$ + " ";
            }
            return (str);
        };
        Condition.prototype.clause = function (cond) {
            if (cond.condition$ != null)
                return (cond.condition$);
            if (cond.operator$.startsWith("is"))
                return (cond.column$ + " " + cond.operator$);
            else if (cond.operator$ == "between")
                return (cond.column$ + " between :" + cond.placeholder$[0] + " and :" + cond.placeholder$[1]);
            else
                return (cond.column$ + " " + cond.operator$ + " :" + cond.placeholder$);
        };
        return Condition;
    }());
    Condition.id = 1;

    var SQLType;
    (function (SQLType) {
        SQLType[SQLType["call"] = 0] = "call";
        SQLType[SQLType["lock"] = 1] = "lock";
        SQLType[SQLType["select"] = 2] = "select";
        SQLType[SQLType["insert"] = 3] = "insert";
        SQLType[SQLType["update"] = 4] = "update";
        SQLType[SQLType["delete"] = 5] = "delete";
    })(SQLType || (SQLType = {}));
    var Statement = /** @class */ (function () {
        function Statement(sql) {
            this.sql$ = null;
            this.rows$ = null;
            this.subquery$ = null;
            this.table$ = null;
            this.order$ = null;
            this.limit$ = null;
            this.type$ = null;
            this.cursor$ = null;
            this.columns$ = [];
            this.errors = null;
            this.override = false;
            this.constraint$ = null;
            this.updates$ = [];
            this.condition$ = null;
            this.bindvalues = [];
            if (sql != null) {
                if (sql.constructor.name == "String")
                    this.sql$ = "" + sql;
                else
                    this.type$ = sql;
            }
            this.findtype();
        }
        Statement.prototype.findtype = function () {
            if (this.sql$ != null) {
                this.type$ = SQLType.call;
                var test = this.sql$.trim().substring(0, 7).trim().toLowerCase();
                if (test == "select")
                    this.type$ = SQLType.select;
                if (test == "insert")
                    this.type$ = SQLType.insert;
                if (test == "update")
                    this.type$ = SQLType.update;
                if (test == "delete")
                    this.type$ = SQLType.delete;
            }
        };
        Object.defineProperty(Statement.prototype, "type", {
            get: function () {
                return (this.type$);
            },
            set: function (type) {
                this.type$ = type;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Statement.prototype, "sql", {
            get: function () {
                return (this.build().sql);
            },
            set: function (sql) {
                this.sql$ = sql;
                this.findtype();
                this.override = true;
            },
            enumerable: false,
            configurable: true
        });
        Statement.prototype.rows = function (rows) {
            this.rows$ = rows;
            return (this);
        };
        Statement.prototype.isFunction = function () {
            return (this.type == SQLType.call);
        };
        Statement.prototype.isSelect = function () {
            return (this.type == SQLType.select);
        };
        Statement.prototype.isInsert = function () {
            return (this.type == SQLType.insert);
        };
        Statement.prototype.isUpdate = function () {
            return (this.type == SQLType.update);
        };
        Statement.prototype.isDelete = function () {
            return (this.type == SQLType.delete);
        };
        Object.defineProperty(Statement.prototype, "table", {
            set: function (table) {
                this.table$ = table;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Statement.prototype, "limit", {
            set: function (limit) {
                this.limit$ = limit;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Statement.prototype, "constraint", {
            set: function (where) {
                this.constraint$ = where;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Statement.prototype, "order", {
            set: function (order) {
                this.order$ = order;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Statement.prototype, "cursor", {
            get: function () {
                return (this.cursor$);
            },
            set: function (cursor) {
                this.cursor$ = cursor;
            },
            enumerable: false,
            configurable: true
        });
        Statement.prototype.update = function (name, value, datatype) {
            if (value != null && datatype == null) {
                var type = value.constructor.name.toLowerCase();
                if (type == "date") {
                    datatype = exports.Column.date;
                    value = value.getTime();
                }
                if (type == "number")
                    datatype = exports.Column.decimal;
            }
            if (value != null && (value + "").trim().length > 0 && datatype == null) {
                value = (value + "").trim();
                var numeric = !isNaN(+value);
                if (numeric)
                    datatype = exports.Column.decimal;
            }
            if (datatype == null)
                datatype = exports.Column.varchar;
            this.updates$.push({ name: name, value: value, type: datatype });
        };
        Object.defineProperty(Statement.prototype, "columns", {
            set: function (columns) {
                var _this = this;
                this.columns$ = [];
                if (columns.constructor.name == "String") {
                    this.columns$.push("" + columns);
                }
                else {
                    columns.forEach(function (column) {
                        _this.columns$.push("" + column);
                    });
                }
            },
            enumerable: false,
            configurable: true
        });
        Statement.prototype.setCondition = function (condition) {
            if (condition.constructor.name == "Array") {
                var arr = condition;
                this.condition$ = arr[0];
                for (var i = 1; i < arr.length; i++)
                    this.condition$ = this.condition$.and().next(arr[i]);
                this.condition$ = this.condition$.first();
            }
            else {
                this.condition$ = condition;
            }
        };
        Statement.prototype.pop = function () {
            if (this.condition$ != null)
                this.condition$.pop();
            return (this);
        };
        Statement.prototype.push = function () {
            if (this.condition$ != null)
                this.condition$.push();
            return (this);
        };
        Statement.prototype.where = function (column, value, datatype) {
            if (this.condition$ == null) {
                this.condition$ = new Condition(column, value, datatype);
                this.condition$.where();
            }
            else {
                var cd = new Condition(column, value, datatype);
                this.condition$ = this.condition$.where().next(cd);
            }
            return (this);
        };
        Statement.prototype.whand = function (column, value, datatype) {
            if (this.condition$ != null)
                return (this.and(column, value, datatype));
            else
                return (this.where(column, value, datatype));
        };
        Statement.prototype.and = function (column, value, datatype) {
            if (this.condition$ == null) {
                this.condition$ = new Condition(column, value, datatype);
            }
            else {
                var cd = new Condition(column, value, datatype);
                this.condition$ = this.condition$.and().next(cd);
            }
            return (this);
        };
        Statement.prototype.or = function (column, value, datatype) {
            if (this.condition$ == null) {
                this.condition$ = new Condition(column, value, datatype);
            }
            else {
                var cd = new Condition(column, value, datatype);
                this.condition$ = this.condition$.or().next(cd);
            }
            return (this);
        };
        Statement.prototype.returnvalue = function (column, datatype) {
            this.bindvalues.unshift({ name: column, value: null, type: datatype });
            return (this);
        };
        Statement.prototype.bind = function (column, value, datatype) {
            if (value != null && datatype == null) {
                var type = value.constructor.name.toLowerCase();
                if (type == "date") {
                    datatype = exports.Column.date;
                    value = value.getTime();
                }
                if (type == "number")
                    datatype = exports.Column.decimal;
            }
            if (value != null && (value + "").trim().length > 0 && datatype == null) {
                value = (value + "").trim();
                var numeric = !isNaN(+value);
                if (numeric)
                    datatype = exports.Column.decimal;
            }
            if (datatype == null)
                datatype = exports.Column.varchar;
            this.bindvalues.push({ name: column, value: value, type: datatype });
            return (this);
        };
        Object.defineProperty(Statement.prototype, "subquery", {
            get: function () {
                return (this.subquery$);
            },
            set: function (subquery) {
                this.subquery$ = subquery;
            },
            enumerable: false,
            configurable: true
        });
        Statement.prototype.validate = function () {
            if (this.errors != null)
                return (this.errors);
            this.errors = [];
            if (this.condition$ != null)
                this.errors = this.condition$.errors();
            return (this.errors);
        };
        Statement.prototype.getCondition = function () {
            return (this.condition$);
        };
        Statement.prototype.build = function () {
            switch (this.type) {
                case SQLType.call: return (this.buildcall());
                case SQLType.lock: return (this.buildselect());
                case SQLType.select: return (this.buildselect());
                case SQLType.insert: return (this.buildinsert());
                case SQLType.update: return (this.buildupdate());
                case SQLType.delete: return (this.builddelete());
                default: console.log("don't know how to build " + SQLType[this.type]);
            }
        };
        Statement.prototype.buildcall = function () {
            var bindvals = [];
            this.bindvalues.forEach(function (bindv) {
                bindvals.push({
                    name: bindv.name,
                    type: exports.Column[bindv.type].toLowerCase(),
                    value: bindv.value
                });
            });
            return ({ sql: this.sql$, bindvalues: bindvals });
        };
        Statement.prototype.buildinsert = function () {
            var bindvals = [];
            this.bindvalues.forEach(function (bindv) {
                bindvals.push({
                    name: bindv.name,
                    type: exports.Column[bindv.type].toLowerCase(),
                    value: bindv.value
                });
            });
            this.sql$ = "insert into " + this.table$ + " (";
            for (var i = 0; i < bindvals.length; i++) {
                this.sql$ += bindvals[i].name;
                if (i < bindvals.length - 1)
                    this.sql$ += ",";
            }
            this.sql$ += ") values (";
            for (var i = 0; i < bindvals.length; i++) {
                this.sql$ += ":" + bindvals[i].name;
                if (i < bindvals.length - 1)
                    this.sql$ += ",";
            }
            this.sql$ += ")";
            return ({ sql: this.sql$, bindvalues: bindvals });
        };
        Statement.prototype.buildupdate = function () {
            var updates = [];
            var bindvals = [];
            for (var i = 0; i < this.updates$.length; i++) {
                updates.push({
                    name: this.updates$[i].name,
                    type: exports.Column[this.updates$[i].type].toLowerCase(),
                    value: this.updates$[i].value
                });
            }
            // Bindvalues for the update
            updates.forEach(function (bindv) { bindvals.push(bindv); });
            var bindvalues = this.bindvalues;
            if (this.condition$ != null)
                this.condition$.getAllBindvalues().forEach(function (bind) { bindvalues.push(bind); });
            // Bindvalues for the whereclause
            this.bindvalues.forEach(function (bindv) {
                bindvals.push({
                    name: bindv.name,
                    type: exports.Column[bindv.type].toLowerCase(),
                    value: bindv.value
                });
            });
            this.sql$ = "update " + this.table$ + " set ";
            for (var i = 0; i < updates.length; i++) {
                this.sql$ += updates[i].name + " = :" + updates[i].name;
                if (i < updates.length - 1)
                    this.sql$ += ", ";
            }
            if (this.constraint$ != null)
                this.sql$ += " " + this.constraint$;
            if (this.condition$ != null)
                this.sql$ += " " + this.condition$.toString();
            return ({ sql: this.sql$, bindvalues: bindvals });
        };
        Statement.prototype.builddelete = function () {
            var sql = this.sql$;
            if (sql == null)
                sql = "delete from " + this.table$;
            if (this.constraint$ != null)
                sql += " " + this.constraint$;
            var bindvalues = this.bindvalues;
            if (this.condition$ != null) {
                sql += " " + this.condition$.toString();
                this.condition$.getAllBindvalues().forEach(function (bind) { bindvalues.push(bind); });
            }
            var bindvals = [];
            bindvalues.forEach(function (bindv) {
                bindvals.push({
                    name: bindv.name,
                    type: exports.Column[bindv.type].toLowerCase(),
                    value: bindv.value
                });
            });
            return ({ sql: sql, bindvalues: bindvals });
        };
        Statement.prototype.buildselect = function () {
            var sql = this.sql$;
            if (sql == null) {
                sql = "select ";
                if (this.columns$ != null) {
                    for (var i = 0; i < this.columns$.length - 1; i++)
                        sql += this.columns$[i] + ", ";
                    sql += this.columns$[this.columns$.length - 1];
                }
                if (this.table$ != null)
                    sql += " from " + this.table$;
            }
            if (!this.override) {
                var whand = " where ";
                if (this.condition$ != null) {
                    sql += " " + this.condition$.toString();
                    whand = " and ";
                }
                if (this.constraint$ != null) {
                    sql += whand + this.constraint$;
                    whand = " and ";
                }
                if (this.subquery$ != null) {
                    sql += whand + this.subquery$.sql;
                    whand = " and ";
                }
                // Don't order by if lock
                if (this.type$ == SQLType.select && this.order$ != null)
                    sql += " order by " + this.order$;
                if (this.limit$ != null)
                    sql += " " + this.limit$;
            }
            var bindvalues = this.bindvalues;
            if (this.condition$ != null)
                this.condition$.getAllBindvalues().forEach(function (bind) { bindvalues.push(bind); });
            var bindvals = [];
            bindvalues.forEach(function (bindv) {
                bindvals.push({
                    name: bindv.name,
                    type: exports.Column[bindv.type].toLowerCase(),
                    value: bindv.value
                });
            });
            if (this.subquery$ != null) {
                this.subquery$.bindvalues.forEach(function (bindv) { bindvals.push(bindv); });
            }
            var sqlstmt = { sql: sql, bindvalues: bindvals };
            if (this.rows$ != null)
                sqlstmt["rows"] = this.rows$;
            return (sqlstmt);
        };
        return Statement;
    }());

    var Table = /** @class */ (function () {
        function Table(conn, table, key, columns, fielddef, rows) {
            var _this = this;
            this.keys = [];
            this.dates = [];
            this.index = new Map();
            this.key = key;
            this.conn = conn;
            this.table = table;
            this.fetch$ = rows;
            this.criterias = [];
            this.columns$ = columns;
            this.fielddef = fielddef;
            this.cursor = table.name + Date.now();
            if (this.key == null) {
                this.key = new Key("primary");
                this.columns$.forEach(function (col) { _this.key.addColumn(col.name); });
            }
            if (this.table.where != null) {
                this.table.where = this.table.where.trim();
                if (this.table.where.startsWith("where "))
                    this.table.where = this.table.where.substring(6);
                if (this.table.where.startsWith("and "))
                    this.table.where = this.table.where.substring(4);
                if (this.table.where.length == 0)
                    this.table.where = null;
            }
            this.fetch$ *= 4;
            if (this.fetch$ < 10)
                this.fetch$ = 10;
            this.cnames = [];
            this.columns$.forEach(function (column) {
                _this.cnames.push(column.name);
                _this.index.set(column.name, column);
                var date = false;
                if (column.type == exports.Column.date)
                    date = true;
                _this.dates.push(date);
            });
        }
        Object.defineProperty(Table.prototype, "name", {
            get: function () {
                return (this.table.name);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Table.prototype, "tabdef", {
            get: function () {
                return (this.table);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Table.prototype, "columns", {
            get: function () {
                return (this.cnames);
            },
            enumerable: false,
            configurable: true
        });
        Table.prototype.mandatory = function (column) {
            var def = this.index.get(column);
            if (def == null || def.mandatory == null)
                return (false);
            return (def.mandatory);
        };
        Table.prototype.databasecolumn = function (column) {
            return (this.index.has(column.toLowerCase()));
        };
        Object.defineProperty(Table.prototype, "fielddata", {
            get: function () {
                return (this.fielddata$);
            },
            set: function (fielddata) {
                this.fielddata$ = fielddata;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Table.prototype, "searchfilter", {
            get: function () {
                return (this.criterias);
            },
            set: function (filter) {
                this.criterias = filter;
            },
            enumerable: false,
            configurable: true
        });
        Table.prototype.lock = function (record, data) {
            return __awaiter(this, void 0, void 0, function () {
                var cols, i, where, stmt, i, type, lock, response, rows, row, i, cval, problem;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            cols = [];
                            for (i = 0; i < this.columns.length; i++)
                                cols.push({ name: this.columns[i], value: data[i] });
                            where = true;
                            stmt = new Statement(SQLType.lock);
                            stmt.columns = this.columns;
                            stmt.table = this.table.name;
                            for (i = 0; i < this.keys[record].length; i++) {
                                type = this.index.get(this.columns[i]).type;
                                if (!where)
                                    stmt.and(this.columns[i], this.keys[record][i], type);
                                else
                                    stmt.where(this.columns[i], this.keys[record][i], type);
                                where = false;
                            }
                            lock = stmt.build();
                            return [4 /*yield*/, this.conn.invoke("lock", lock)];
                        case 1:
                            response = _a.sent();
                            if (response["status"] == "failed") {
                                console.log(JSON.stringify(response));
                                return [2 /*return*/, ({ status: "failed", message: "Row is locked by another user. Try later" })];
                            }
                            rows = response["rows"];
                            if (rows.length == 0) {
                                console.log("Row[" + record + "] has been deleted by another user. Requery to see changes");
                                return [2 /*return*/, ({ status: "failed", message: "Row[" + record + "] has been deleted by another user. Requery to see changes" })];
                            }
                            row = rows[0];
                            for (i = 0; i < this.columns.length; i++) {
                                cval = cols[i].value;
                                if (cval != null && this.dates[i])
                                    cval = cval.getTime();
                                if (row[this.columns[i]] != cval) {
                                    problem = cols[i].name + "[" + record + "], db: " + row[this.columns[i]] + " != " + cval;
                                    console.log("Row has been changed by another user. Requery to see changes");
                                    return [2 /*return*/, ({ status: "failed", message: "Row has been changed by another user. Requery to see changes" })];
                                }
                            }
                            return [2 /*return*/, ({ status: "ok" })];
                    }
                });
            });
        };
        Table.prototype.insert = function (record, data) {
            return __awaiter(this, void 0, void 0, function () {
                var cols, i, stmt, keyval, i, cval, type, insert, response;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            cols = [];
                            for (i = 0; i < this.columns.length; i++)
                                cols.push({ name: this.columns[i], value: data[i] });
                            stmt = new Statement(SQLType.insert);
                            stmt.columns = this.columns;
                            stmt.table = this.table.name;
                            keyval = [];
                            for (i = 0; i < this.columns.length; i++) {
                                cval = cols[i].value;
                                type = this.index.get(this.columns[i]).type;
                                if (cval != null && this.dates[i])
                                    cval = cval.getTime();
                                if (i < this.key.columns().length)
                                    keyval.push(cval);
                                stmt.bind(cols[i].name, cval, type);
                            }
                            insert = stmt.build();
                            this.keys.splice(+record, 0, keyval);
                            return [4 /*yield*/, this.conn.invoke("insert", insert)];
                        case 1:
                            response = _a.sent();
                            return [2 /*return*/, (response)];
                    }
                });
            });
        };
        Table.prototype.update = function (record, data) {
            return __awaiter(this, void 0, void 0, function () {
                var keyupd, keyval, stmt, i, val, type, where, i, type, update, response;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            keyupd = [];
                            keyval = this.keys[+record];
                            stmt = new Statement(SQLType.update);
                            for (i = 0; i < data.length; i++) {
                                if (i < this.key.columns().length)
                                    keyupd.push(keyval[i]);
                                if (data[i].value.updated) {
                                    val = data[i].value.newvalue;
                                    type = this.index.get(data[i].name).type;
                                    if (val != null && this.dates[i])
                                        val = val.getTime();
                                    if (i < this.key.columns().length)
                                        keyupd[i] = val;
                                    stmt.update(data[i].name, val, type);
                                }
                            }
                            where = true;
                            if (this.table.where != null && this.table.where.trim.length > 0) {
                                where = false;
                                stmt.constraint = this.table.where;
                            }
                            for (i = 0; i < keyval.length; i++) {
                                type = this.index.get(this.columns[i]).type;
                                if (!where)
                                    stmt.and(this.columns[i], keyval[i], type);
                                else
                                    stmt.where(this.columns[i], keyval[i], type);
                                where = false;
                            }
                            stmt.table = this.table.name;
                            update = stmt.build();
                            return [4 /*yield*/, this.conn.invoke("update", update)];
                        case 1:
                            response = _a.sent();
                            if (response["status"] != "failed")
                                this.keys[+record] = keyupd;
                            return [2 /*return*/, (response)];
                    }
                });
            });
        };
        Table.prototype.delete = function (record) {
            return __awaiter(this, void 0, void 0, function () {
                var keyval, stmt, where, i, type, delrow, response, keys;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            keyval = this.keys[+record];
                            stmt = new Statement(SQLType.delete);
                            where = true;
                            if (this.table.where != null && this.table.where.trim.length > 0) {
                                where = false;
                                stmt.constraint = this.table.where;
                            }
                            for (i = 0; i < keyval.length; i++) {
                                type = this.index.get(this.columns[i]).type;
                                if (!where)
                                    stmt.and(this.columns[i], keyval[i], type);
                                else
                                    stmt.where(this.columns[i], keyval[i], type);
                                where = false;
                            }
                            stmt.table = this.table.name;
                            delrow = stmt.build();
                            return [4 /*yield*/, this.conn.invoke("delete", delrow)];
                        case 1:
                            response = _a.sent();
                            if (response["status"] == "failed")
                                return [2 /*return*/, (response)];
                            keys = this.keys.slice(0, record);
                            keys = keys.concat(this.keys.slice(+record + 1, this.keys.length));
                            this.keys = keys;
                            return [2 /*return*/, (response)];
                    }
                });
            });
        };
        Table.prototype.parseQuery = function (keys, subquery, fields) {
            var _this = this;
            var stmt = new Statement(SQLType.select);
            stmt.cursor = this.cursor;
            stmt.columns = this.cnames;
            stmt.table = this.table.name;
            stmt.order = this.table.order;
            var where = true;
            if (this.table.limit != null)
                stmt.limit = this.table.limit;
            if (this.table.where != null) {
                where = false;
                stmt.constraint = this.table.where;
            }
            if (fields.length > 0) {
                this.criterias = [];
                fields.forEach(function (field) {
                    if (field.value != null && ("" + field.value).trim() != "")
                        _this.criterias.push({ name: field.name, value: field.value });
                });
            }
            keys.forEach(function (key) {
                key.values.forEach(function (part) {
                    var col = part.name;
                    // Check if key column is mapped to diff. name
                    var def = _this.fielddef.get(col);
                    if (def != null)
                        col = def.column;
                    var type = _this.index.get(col).type;
                    if (!where)
                        stmt.and(col, part.value, type);
                    else
                        stmt.where(col, part.value, type);
                    where = false;
                });
            });
            this.criterias.forEach(function (field) {
                var def = _this.fielddef.get(field.name);
                if (def.column != null) {
                    var type = _this.index.get(def.column).type;
                    if (!where)
                        stmt.and(def.column, field.value, type);
                    else
                        stmt.where(def.column, field.value, type);
                    where = false;
                }
            });
            if (subquery != null)
                stmt.subquery = subquery;
            return (stmt);
        };
        Table.prototype.executequery = function (stmt) {
            return __awaiter(this, void 0, void 0, function () {
                var response;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            this.keys = [];
                            this.eof = false;
                            this.fielddata.clear();
                            this.select = stmt.build();
                            this.select.rows = this.fetch$;
                            this.select.cursor = stmt.cursor;
                            return [4 /*yield*/, this.conn.invoke("select", this.select)];
                        case 1:
                            response = _a.sent();
                            if (response["status"] == "failed")
                                return [2 /*return*/, (response)];
                            this.addRows(response["rows"]);
                            return [2 /*return*/, (response)];
                    }
                });
            });
        };
        Table.prototype.fetch = function (stmt) {
            return __awaiter(this, void 0, void 0, function () {
                var fetch, response;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (this.eof)
                                return [2 /*return*/, ({ status: "ok" })];
                            fetch = { cursor: stmt.cursor, rows: this.fetch$ };
                            return [4 /*yield*/, this.conn.invoke("fetch", fetch)];
                        case 1:
                            response = _a.sent();
                            if (response["status"] == "failed")
                                return [2 /*return*/, (response)];
                            this.addRows(response["rows"]);
                            return [2 /*return*/, (response)];
                    }
                });
            });
        };
        Table.prototype.addRows = function (rows) {
            var _this = this;
            var klen = this.key.values.length;
            if (rows.length < this.fetch$)
                this.eof = true;
            rows.forEach(function (row) {
                // Table is not defined
                if (_this.cnames.length == 0) {
                    var keys = Object.keys(row);
                    var flds = _this.fielddata.fields;
                    for (var i = 0; i < keys.length; i++)
                        _this.cnames.push(keys[i]);
                    for (var i = 0; i < keys.length - flds.length; i++)
                        flds.unshift(keys[i]);
                    _this.fielddata.fields = flds;
                }
                var col = 0;
                var keyval = [];
                var drow = _this.fielddata.newrow();
                Object.keys(row).forEach(function (key) {
                    var val = row[key];
                    if (_this.dates[col] && ("" + val).length > 0)
                        val = new Date(+val);
                    drow.setValue(col++, val);
                    if (keyval.length < klen)
                        keyval.push(val);
                });
                _this.keys.push(keyval);
                _this.fielddata.add(drow);
            });
        };
        return Table;
    }());

    var FieldData = /** @class */ (function () {
        function FieldData(block, table, fields, fielddef) {
            this.data = [];
            this.index = new Map();
            this.block = block;
            this.table$ = table;
            this.fields$ = fields;
            this.fielddef = fielddef;
            if (table != null)
                this.table$.fielddata = this;
            if (fields != null) {
                for (var i = 0; i < fields.length; i++)
                    this.index.set(fields[i].toLowerCase(), i);
            }
        }
        Object.defineProperty(FieldData.prototype, "table", {
            get: function () {
                return (this.table$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldData.prototype, "tabdef", {
            get: function () {
                var _a;
                return ((_a = this.table$) === null || _a === void 0 ? void 0 : _a.tabdef);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldData.prototype, "database", {
            get: function () {
                return (this.table != null);
            },
            enumerable: false,
            configurable: true
        });
        FieldData.prototype.databasecolumn = function (column) {
            if (this.table == null)
                return (false);
            return (this.table.databasecolumn(column));
        };
        Object.defineProperty(FieldData.prototype, "fields", {
            get: function () {
                return (this.fields$);
            },
            set: function (fields) {
                this.index.clear();
                this.fields$ = fields;
                for (var i = 0; i < fields.length; i++)
                    this.index.set(fields[i].toLowerCase(), i);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldData.prototype, "columns", {
            get: function () {
                if (this.table == null)
                    return (null);
                else
                    return (this.table.columns);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldData.prototype, "fetched", {
            get: function () {
                return (this.data.length);
            },
            enumerable: false,
            configurable: true
        });
        FieldData.prototype.removeLocks = function () {
            this.data.forEach(function (row) { row.locked = false; });
        };
        FieldData.prototype.lock = function (record) {
            return __awaiter(this, void 0, void 0, function () {
                var response;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (record < 0 || record >= this.data.length)
                                return [2 /*return*/, ({ status: "failed", message: "row " + record + " does not exist" })];
                            if (this.data[record].locked)
                                return [2 /*return*/, ({ status: "failed", message: "row " + record + " already locked" })];
                            if (this.table == null)
                                return [2 /*return*/, ({ status: "ok" })];
                            response = { status: "ok" };
                            if (!(this.table != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.table.lock(record, this.data[+record].values)];
                        case 1:
                            response = _b.sent();
                            if (response["status"] == "failed")
                                return [2 /*return*/, (response)];
                            _b.label = 2;
                        case 2:
                            this.data[record].locked = true;
                            return [2 /*return*/, (response)];
                    }
                });
            });
        };
        FieldData.prototype.locked = function (record) {
            if (record < 0 || record >= this.data.length)
                return (false);
            if (this.data[+record].state == RecordState.insert)
                return (true);
            return (this.data[+record].locked);
        };
        FieldData.prototype.mandatory = function (column) {
            var _a;
            var md = false;
            if (this.table != null)
                md = this.table.mandatory(column);
            if (!md) {
                md = (_a = this.fielddef.get(column)) === null || _a === void 0 ? void 0 : _a.mandatory;
                if (md == null)
                    md = false;
            }
            return (md);
        };
        FieldData.prototype.getNonValidated = function (record) {
            if (record < 0 || record >= this.data.length)
                return ([]);
            var row = this.data[record];
            var cols = [];
            for (var i = 0; i < row.fields.length; i++) {
                if (this.mandatory(this.fields[i]) && row.fields[i].value$ == null) {
                    cols.push(this.columns[i]);
                }
                else if (!row.fields[i].validated) {
                    cols.push(this.columns[i]);
                }
            }
            return (cols);
        };
        FieldData.prototype.validated = function (record, fields) {
            if (record < 0 || record >= this.data.length)
                return (true);
            var row = this.data[record];
            if (fields) {
                for (var i = 0; i < row.fields.length; i++) {
                    if (this.mandatory(this.fields[i]) && row.fields[i].value$ == null)
                        return (false);
                    if (!row.fields[i].validated)
                        return (false);
                }
                return (true);
            }
            return (row.validated);
        };
        FieldData.prototype.newrow = function () {
            var row = new Row(0, this);
            return (row);
        };
        FieldData.prototype.add = function (row) {
            this.data.push(row);
        };
        FieldData.prototype.column = function (fname) {
            return (this.index.get(fname.toLowerCase()));
        };
        FieldData.prototype.clear = function () {
            this.data = [];
        };
        FieldData.prototype.getValue = function (record, column) {
            if (+record < 0 || +record >= +this.data.length) {
                console.log("get " + column + "[" + record + "] record does not exist");
                return (null);
            }
            var colno = this.index.get(column.toLowerCase());
            if (colno == null) {
                console.log("get " + column + "[" + record + "] column does not exist");
                return (null);
            }
            var rec = this.data[+record];
            return (rec.fields[+colno].value$);
        };
        FieldData.prototype.getValidated = function (record, column) {
            if (record < 0 || record >= this.data.length) {
                console.log("set " + column + "[" + record + "] row does not exist");
                return (true);
            }
            var rec = this.data[+record];
            if (column == null)
                return (rec.validated);
            var colno = this.index.get(column.toLowerCase());
            if (colno == null) {
                console.log("set " + column + "[" + record + "] column does not exist");
                return;
            }
            return (rec.fields[+colno].validated);
        };
        FieldData.prototype.setValidated = function (record, column) {
            return __awaiter(this, void 0, void 0, function () {
                var rec, scn, response, scn, columns, i, status, response, colno;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (record < 0 || record >= this.data.length)
                                return [2 /*return*/, ({ status: "failed", message: "set " + column + "[" + record + "] validated failed, row does not exist" })];
                            rec = this.data[+record];
                            if (!(column == null)) return [3 /*break*/, 6];
                            if (rec.validated)
                                return [2 /*return*/, ({ status: "failed", message: "Record already validated" })];
                            if (!(rec.state == RecordState.insert)) return [3 /*break*/, 3];
                            if (!(this.table != null)) return [3 /*break*/, 2];
                            scn = rec.scn;
                            return [4 /*yield*/, this.table.insert(record, this.data[+record].values)];
                        case 1:
                            response = _b.sent();
                            if (response["status"] == "failed")
                                return [2 /*return*/, (response)];
                            rec.dbn = scn;
                            _b.label = 2;
                        case 2: return [3 /*break*/, 5];
                        case 3:
                            if (!(this.table != null)) return [3 /*break*/, 5];
                            scn = rec.scn;
                            columns = [];
                            for (i = 0; i < this.columns.length; i++) {
                                status = { updated: false };
                                if (+rec.fields[i].scn > +rec.dbn) {
                                    status.updated = true;
                                    status.newvalue = rec.fields[i].value$;
                                }
                                columns.push({ name: this.columns[i], value: status });
                            }
                            return [4 /*yield*/, this.table.update(record, columns)];
                        case 4:
                            response = _b.sent();
                            if (response["status"] == "failed")
                                return [2 /*return*/, (response)];
                            rec.dbn = scn;
                            _b.label = 5;
                        case 5:
                            rec.validated = true;
                            if (rec.state == RecordState.insert)
                                rec.state = RecordState.update;
                            return [2 /*return*/, ({ status: "ok" })];
                        case 6:
                            colno = this.index.get(column.toLowerCase());
                            if (colno == null)
                                return [2 /*return*/, ({ status: "failed", message: "set " + column + "[" + record + "] validated failed, column does not exist" })];
                            if (this.table != null && +colno < this.table.columns.length)
                                rec.fields[+colno].validated = true;
                            return [2 /*return*/, ({ status: "ok" })];
                    }
                });
            });
        };
        FieldData.prototype.setValue = function (record, column, value) {
            if (record < 0 || record >= this.data.length) {
                console.log("set " + column + "[" + record + "] row does not exist");
                return (false);
            }
            var colno = this.index.get(column.toLowerCase());
            if (colno == null) {
                console.log("set " + column + "[" + record + "] column does not exist");
                return (false);
            }
            var rec = this.data[+record];
            if (rec.fields[+colno].value$ == value)
                return (false);
            var scn = +rec.scn + 1;
            if (this.table != null && +colno < this.table.columns.length) {
                rec.validated = false;
                rec.fields[+colno].validated = false;
            }
            rec.scn = scn;
            rec.fields[+colno].setValue(scn, value);
            return (true);
        };
        FieldData.prototype.state = function (record, state) {
            if (record >= this.data.length)
                return (RecordState.na);
            if (state != null)
                this.data[record].state = state;
            return (this.data[record].state);
        };
        Object.defineProperty(FieldData.prototype, "searchfilter", {
            get: function () {
                if (this.table == null)
                    return (null);
                return (this.table.searchfilter);
            },
            set: function (filter) {
                if (this.table != null)
                    this.table.searchfilter = filter;
            },
            enumerable: false,
            configurable: true
        });
        FieldData.prototype.parseQuery = function (keys, subquery, fields) {
            if (this.table == null)
                return (null);
            return (this.table.parseQuery(keys, subquery, fields));
        };
        FieldData.prototype.executequery = function (stmt) {
            return __awaiter(this, void 0, void 0, function () {
                var response, rows, i, event;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            this.query = stmt;
                            if (this.table == null)
                                return [2 /*return*/, ({ status: "ok" })];
                            return [4 /*yield*/, this.table.executequery(stmt)];
                        case 1:
                            response = _b.sent();
                            if (response["status"] != "failed") {
                                rows = response["rows"];
                                for (i = 0; i < rows.length; i++) {
                                    event = new SQLTriggerEvent(this.block.alias, i, null);
                                    this.block.invokeTriggers(exports.Trigger.PostQuery, event);
                                }
                            }
                            return [2 /*return*/, (response)];
                    }
                });
            });
        };
        FieldData.prototype.insert = function (record) {
            var data = [];
            if (record > this.data.length)
                record = this.data.length;
            data = this.data.slice(0, record);
            data[+record] = new Row(0, this);
            data[+record].locked = true;
            data[+record].state = RecordState.insert;
            data = data.concat(this.data.slice(record, this.data.length));
            this.data = data;
            return (true);
        };
        FieldData.prototype.delete = function (record) {
            return __awaiter(this, void 0, void 0, function () {
                var data, response;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            data = [];
                            response = { status: "ok" };
                            if (record < 0 || record >= this.data.length)
                                return [2 /*return*/, (response)];
                            if (this.data[+record].state == RecordState.insert) {
                                data = this.data.slice(0, record);
                                data = data.concat(this.data.slice(+record + 1, this.data.length));
                                this.data = data;
                                return [2 /*return*/, (response)];
                            }
                            if (!(this.table != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.table.delete(record)];
                        case 1:
                            response = _b.sent();
                            if (response["status"] == "failed")
                                return [2 /*return*/, (response)];
                            _b.label = 2;
                        case 2:
                            data = this.data.slice(0, record);
                            data = data.concat(this.data.slice(+record + 1, this.data.length));
                            this.data = data;
                            return [2 /*return*/, (response)];
                    }
                });
            });
        };
        Object.defineProperty(FieldData.prototype, "rows", {
            get: function () {
                return (this.data.length);
            },
            enumerable: false,
            configurable: true
        });
        FieldData.prototype.fetch = function (offset, rows) {
            return __awaiter(this, void 0, void 0, function () {
                var response, rows_1, i, event, avail;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (!(this.data.length <= +offset + rows && this.query != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.table.fetch(this.query)];
                        case 1:
                            response = _b.sent();
                            if (response["status"] == "failed") {
                                this.block.alert(JSON.stringify(response), "Database");
                                return [2 /*return*/, (0)];
                            }
                            else {
                                rows_1 = response["rows"];
                                if (rows_1 != null) {
                                    for (i = 1; i <= rows_1.length; i++) {
                                        event = new SQLTriggerEvent(this.block.alias, +i + +offset, null);
                                        this.block.invokeTriggers(exports.Trigger.PostQuery, event);
                                    }
                                }
                            }
                            _b.label = 2;
                        case 2:
                            avail = this.data.length - offset - 1;
                            if (avail < 0)
                                avail = 0;
                            return [2 /*return*/, (avail)];
                    }
                });
            });
        };
        FieldData.prototype.get = function (start, rows) {
            var values = [];
            if (start < 0)
                start = 0;
            var end = +start + rows;
            if (end > this.data.length)
                end = this.data.length;
            for (var i = start; i < end; i++)
                values.push(this.data[i].values);
            return (values);
        };
        return FieldData;
    }());
    var Row = /** @class */ (function () {
        function Row(scn, table, values) {
            this.scn = 0;
            this.dbn = 0;
            this.fields = [];
            this.locked = false;
            this.validated = true;
            this.state = RecordState.na;
            this.scn = scn;
            for (var i_1 = 0; i_1 < table.fields.length; i_1++)
                this.fields.push(new Column(scn));
            var i = 0;
            if (values != null)
                this.fields.forEach(function (column) { column.setValue(scn, values[i++]); });
        }
        Row.prototype.setValue = function (col, value) {
            // Used by table
            this.fields[col].value$ = value;
        };
        Object.defineProperty(Row.prototype, "values", {
            get: function () {
                var values = [];
                this.fields.forEach(function (col) {
                    values.push(col.value$);
                });
                return (values);
            },
            enumerable: false,
            configurable: true
        });
        Row.prototype.print = function () {
            var i = 0;
            var values = "";
            this.fields.forEach(function (col) {
                var val = col.value$;
                if (val == null)
                    val = "";
                values += i + " " + col.value$ + ", ";
                i++;
            });
            values = values.substring(0, values.length - 2);
            console.log(values);
        };
        return Row;
    }());
    var Column = /** @class */ (function () {
        function Column(scn, value) {
            this.scn = 0;
            this.validated = true;
            this.scn = scn;
            this.value$ = value;
            if (value == undefined)
                this.value$ = null;
        }
        Column.prototype.setValue = function (scn, value) {
            this.scn = scn;
            this.value$ = value;
            if (value == undefined)
                this.value$ = null;
        };
        return Column;
    }());

    var ListOfValuesImpl = /** @class */ (function () {
        function ListOfValuesImpl(ctx) {
            this.last = "";
            this.minlen = 0;
            this.prefix = "";
            this.postfix = "";
            this.wait = false;
            this.rows = 10;
            this.size = 20;
            this.top = null;
            this.left = null;
            this.width = null;
            this.height = null;
            this.title = null;
            this.app = ctx.app["_impl_"];
        }
        ListOfValuesImpl.show = function (app, impl, lov) {
            var pinst = new PopupInstance();
            pinst.display(app, ListOfValuesImpl);
            var lovwin = pinst.popup();
            lovwin.setDefinition(lov);
            lovwin.setBlockImpl(impl);
        };
        ListOfValuesImpl.prototype.setDefinition = function (lov) {
            this.lov = lov;
            this.title = lov.title;
            this.width = lov.width;
            this.height = lov.height;
            this.rows = lov.rows ? lov.rows : 12;
            this.fetch = lov.rows ? lov.rows : 12;
            if (this.size == null)
                this.size = 25;
            var width = this.size * 12;
            var height = this.rows * 28 + 16;
            if (this.width == null)
                this.width = width + "px";
            if (this.height == null)
                this.height = height + "px";
            this.win.title = this.title;
            this.win.width = this.width;
            this.win.height = this.height;
            if (this.lov.minlen != null)
                this.minlen = this.lov.minlen;
            if (this.lov.prefix != null)
                this.prefix = this.lov.prefix;
            if (this.lov.postfix != null)
                this.postfix = this.lov.postfix;
        };
        ListOfValuesImpl.prototype.setBlockImpl = function (impl) {
            this.iblock = impl[0];
            this.sblock = impl[1];
            this.rblock = impl[2];
        };
        ListOfValuesImpl.prototype.close = function (_cancel) {
            var _a;
            this.app.enable();
            this.win.closeWindow();
            (_a = this.app.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.focus();
        };
        ListOfValuesImpl.prototype.setWin = function (win) {
            this.win = win;
        };
        ListOfValuesImpl.prototype.ngOnInit = function () {
            this.app.disable();
            this.app.setContainer();
        };
        ListOfValuesImpl.prototype.ngAfterViewInit = function () {
            var _this = this;
            var container = this.app.getContainer();
            container.finish();
            this.sblock.setFields(container.getBlock("search").fields);
            this.rblock.setFields(container.getBlock("result").fields);
            this.rblock.usage = { query: true };
            container.getBlock("search").records.forEach(function (rec) {
                _this.sblock.addRecord(new Record(rec.row, rec.fields, rec.index));
                _this.filter = _this.sblock.getField(rec.row, "filter");
                var filtdef = { name: "filter", type: exports.FieldType.text };
                if (_this.lov.case != null)
                    filtdef.case = _this.lov.case;
                _this.filter.setDefinition(filtdef, true);
                _this.filter.enable(false);
            });
            var fielddef = new Map();
            var descdef = { name: "description", type: exports.FieldType.text, fieldoptions: { update: false } };
            fielddef.set("description", descdef);
            container.getBlock("result").records.forEach(function (rec) {
                _this.rblock.addRecord(new Record(rec.row, rec.fields, rec.index));
                _this.description = _this.rblock.getField(rec.row, "description");
                _this.description.setDefinition(descdef, true);
                _this.description.enable(true);
            });
            var conn = this.app.appstate.connection;
            var table = new Table(conn, { name: "none" }, null, [], null, this.fetch);
            this.rblock.setApplication(this.app);
            this.rblock.data = new FieldData(this.rblock, table, ["description"], fielddef);
            this.app.dropContainer();
            var keys = [
                exports.keymap.enter,
                exports.keymap.escape,
                exports.keymap.nextrecord,
                exports.keymap.prevrecord,
                exports.keymap.nextfield,
                exports.keymap.prevfield
            ];
            this.sblock.addKeyTrigger(this, this.onkey, keys);
            this.rblock.addKeyTrigger(this, this.onkey, keys);
            this.sblock.addTrigger(this, this.search, exports.Trigger.Typing);
            this.rblock.addTrigger(this, this.prequery, exports.Trigger.PreQuery);
            this.rblock.addTrigger(this, this.onMouse, exports.Trigger.MouseDoubleClick);
            this.rblock.navigable = false;
            this.filter.focus();
            if (this.lov.autoquery) {
                this.last = " ";
                this.search(null);
            }
        };
        ListOfValuesImpl.prototype.search = function (_event) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    this.execute();
                    return [2 /*return*/, (true)];
                });
            });
        };
        ListOfValuesImpl.prototype.execute = function () {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (this.wait) {
                                setTimeout(function () { _this.execute(); }, 200);
                                return [2 /*return*/];
                            }
                            if (this.filter.value == this.last)
                                return [2 /*return*/];
                            this.wait = true;
                            this.last = this.filter.value;
                            if (this.last == null)
                                this.last = "";
                            if (!(this.last.length < this.minlen)) return [3 /*break*/, 1];
                            this.rblock.clear();
                            return [3 /*break*/, 3];
                        case 1: return [4 /*yield*/, this.rblock.keyexeqry()];
                        case 2:
                            _b.sent();
                            _b.label = 3;
                        case 3:
                            this.wait = false;
                            return [2 /*return*/];
                    }
                });
            });
        };
        ListOfValuesImpl.prototype.prequery = function (event) {
            return __awaiter(this, void 0, void 0, function () {
                var stmt;
                return __generator(this, function (_b) {
                    stmt = new Statement(this.lov.sql);
                    stmt.cursor = event.stmt.cursor;
                    if (this.lov.bindvalues != null)
                        this.lov.bindvalues.forEach(function (bv) { stmt.bind(bv.name, bv.value, bv.type); });
                    if (this.filter.value == null)
                        this.filter.value = "";
                    stmt.bind("filter", this.prefix + this.filter.value + this.postfix);
                    event.stmt = stmt;
                    return [2 /*return*/, (true)];
                });
            });
        };
        ListOfValuesImpl.prototype.onMouse = function (event) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    this.picked(event.record);
                    return [2 /*return*/, (true)];
                });
            });
        };
        ListOfValuesImpl.prototype.onkey = function (event) {
            return __awaiter(this, void 0, void 0, function () {
                var record;
                return __generator(this, function (_b) {
                    if (event.type == exports.Trigger.Key && event.field == "filter") {
                        if (event.key == exports.keymap.prevfield)
                            event.event.preventDefault();
                        if (event.key == exports.keymap.nextfield || event.key == exports.keymap.nextrecord) {
                            this.rblock.navigable = true;
                            this.rblock.focus(0);
                        }
                    }
                    if (event.type == exports.Trigger.Key && event.field == "description") {
                        if (event.key == exports.keymap.nextfield || event.key == exports.keymap.prevfield) {
                            this.sblock.focus();
                            event.event.preventDefault();
                            this.rblock.navigable = false;
                        }
                    }
                    if (event.type == exports.Trigger.Key && event.key == exports.keymap.escape)
                        this.close(false);
                    if (event.type == exports.Trigger.Key && event.key == exports.keymap.enter) {
                        record = -1;
                        if (event.field == "filter" && this.rblock.fetched == 1)
                            record = 0;
                        if (event.field == "description")
                            record = event.record;
                        if (record >= 0)
                            this.picked(record);
                    }
                    return [2 /*return*/, (true)];
                });
            });
        };
        ListOfValuesImpl.prototype.picked = function (record) {
            var _this = this;
            this.lov.fieldmap.forEach(function (col, fld) {
                var val = _this.rblock.getValue(record, fld);
                _this.iblock.setValue(_this.iblock.record, col, val);
            });
            this.close(false);
        };
        return ListOfValuesImpl;
    }());
    ListOfValuesImpl.decorators = [
        { type: i0.Component, args: [{
                    template: "\n        <div class=\"lov\">\n        <table>\n            <tr>\n                <td class=\"lov-center\"><field class=\"lov-search\" size=\"15\" name=\"filter\" block=\"search\"></field></td>\n            </tr>\n\n            <tr class=\"lov-spacer\"></tr>\n\n            <tr *ngFor=\"let item of [].constructor(rows); let row = index\">\n                <td><field class=\"lov-result\" size=\"{{size}}\" name=\"description\" row=\"{{row}}\" block=\"result\"></field></td>\n            </tr>\n\n            <tr class=\"lov-spacer\"></tr>\n        </table>\n        </div>\n    ",
                    styles: ["\n            .lov-spacer\n            {\n                height: 8px;\n            }\n\n            .lov-center\n            {\n                border: none;\n                display: flex;\n                justify-content: center;\n            }\n        "]
                },] }
    ];
    ListOfValuesImpl.ctorParameters = function () { return [
        { type: Context }
    ]; };

    var BlockImpl = /** @class */ (function () {
        function BlockImpl(block) {
            this.block = block;
            this.row$ = 0;
            this.offset = 0;
            this.form$ = null;
            this.ready$ = false;
            this.records$ = [];
            this.querying$ = false;
            this.disabled$ = false;
            this.navigable$ = true;
            this.lastqry = [];
            this.fields$ = [];
            this.triggers = new Triggers();
            this.state = FormState.normal;
            this.fieldidx$ = new Map();
            this.dbusage$ =
                {
                    query: false,
                    update: true,
                    insert: false,
                    delete: false
                };
            if (block != null) {
                this.name$ = block.constructor.name;
                if (this.name$ == "Block")
                    this.name$ = "anonymous";
            }
        }
        Object.defineProperty(BlockImpl.prototype, "name", {
            get: function () {
                return (this.name$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "alias", {
            get: function () {
                return (this.alias$);
            },
            set: function (alias) {
                this.alias$ = alias;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "table", {
            get: function () {
                var _a;
                return ((_a = this.data) === null || _a === void 0 ? void 0 : _a.tabdef);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "row", {
            get: function () {
                return (this.row$);
            },
            set: function (row) {
                this.row$ = row;
            },
            enumerable: false,
            configurable: true
        });
        BlockImpl.prototype.exists = function (record) {
            if (+record < +this.data.rows)
                return (true);
            return (false);
        };
        BlockImpl.prototype.displayed = function (record) {
            if (+record < +this.offset)
                return (false);
            if (+record > +this.sum(this.offset, this.rows))
                return (false);
            var row = +record - +this.offset;
            var state = this.records[+row].state;
            if (state == RecordState.na || state == RecordState.qmode)
                return (false);
            return (true);
        };
        Object.defineProperty(BlockImpl.prototype, "rows", {
            get: function () {
                return (this.records$.length);
            },
            enumerable: false,
            configurable: true
        });
        BlockImpl.prototype.database = function () {
            var _a;
            return ((_a = this.data) === null || _a === void 0 ? void 0 : _a.database);
        };
        Object.defineProperty(BlockImpl.prototype, "datarows", {
            get: function () {
                if (this.data == null)
                    return (0);
                return (this.data.rows);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "columns", {
            get: function () {
                if (this.data == null)
                    return (null);
                else
                    return (this.data.columns);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "ready", {
            get: function () {
                return (this.ready$);
            },
            set: function (ready) {
                this.ready$ = ready;
                var rec = this.getRecord(0);
                if (rec != null) {
                    rec.enable(true);
                    rec.current = true;
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "navigable", {
            get: function () {
                return (this.navigable$);
            },
            set: function (navigable) {
                this.navigable$ = navigable;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "record", {
            get: function () {
                return (this.sum(this.row, this.offset));
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "fetched", {
            get: function () {
                if (this.data == null)
                    return (0);
                return (this.data.fetched);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "field", {
            get: function () {
                return (this.field$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "fields", {
            get: function () {
                if (this.data == null)
                    return (null);
                else
                    return (this.data.fields);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "clazz", {
            get: function () {
                if (this.block == null)
                    return (null);
                return (this.block.constructor.name.toLowerCase());
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "data", {
            get: function () {
                return (this.data$);
            },
            set: function (data) {
                this.data$ = data;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(BlockImpl.prototype, "form", {
            get: function () {
                return (this.form$);
            },
            set: function (form) {
                this.form$ = form;
            },
            enumerable: false,
            configurable: true
        });
        BlockImpl.prototype.setFieldDefinition = function (def) {
            var inst = this.fieldidx$.get(def.name);
            if (inst != null) {
                var fields = inst.parent.fields;
                var cfields = inst.parent.cfields;
                fields.forEach(function (fld) {
                    if (fld.id == inst.id)
                        fld.definition = def;
                });
                cfields.forEach(function (fld) {
                    if (fld.id == inst.id)
                        fld.definition = def;
                });
                return (true);
            }
            return (false);
        };
        BlockImpl.prototype.setPossibleValues = function (field, values, enforce) {
            var inst = this.fieldidx$.get(field);
            if (inst != null) {
                var fields = inst.parent.fields;
                var cfields = inst.parent.cfields;
                fields.forEach(function (fld) {
                    if (fld.id == inst.id)
                        fld.setPossibleValues(values, enforce);
                });
                cfields.forEach(function (fld) {
                    if (fld.id == inst.id)
                        fld.setPossibleValues(values, enforce);
                });
                return (true);
            }
            return (false);
        };
        BlockImpl.prototype.setFields = function (fields) {
            var _this = this;
            this.fields$ = fields;
            fields.forEach(function (inst) {
                var name = inst.name;
                if (inst.id != null && inst.id.length > 0)
                    name += "." + inst.id;
                _this.fieldidx$.set(name, inst);
            });
        };
        BlockImpl.prototype.setMasterDetail = function (md) {
            this.masterdetail = md;
        };
        BlockImpl.prototype.setListOfValues = function (lovs) {
            this.lovs = lovs;
        };
        BlockImpl.prototype.setIdListOfValues = function (lovs) {
            this.idlovs = lovs;
        };
        BlockImpl.prototype.addListOfValues = function (form, func, field, id) {
            var utils = new Utils();
            var lovdef = null;
            var params = utils.getParams(func);
            if (!form)
                lovdef = { inst: this.block, func: func.name, params: params };
            else
                lovdef = { inst: this.form.form, func: func.name, params: params };
            if (id == null)
                this.lovs.set(field.toLowerCase(), lovdef);
            else
                this.idlovs.set(field.toLowerCase(), lovdef);
        };
        BlockImpl.prototype.removeListOfValues = function (field, id) {
            if (id == null)
                this.lovs.delete(field.toLowerCase());
            else
                this.idlovs.delete(field.toLowerCase() + "." + id.toLowerCase());
        };
        Object.defineProperty(BlockImpl.prototype, "querymode", {
            get: function () {
                return (this.state == FormState.entqry);
            },
            enumerable: false,
            configurable: true
        });
        BlockImpl.prototype.focus = function (row) {
            var _a;
            if (!this.navigable)
                return;
            if (row != null && row >= 0 && row < this.rows) {
                if ((_a = this.records[+row]) === null || _a === void 0 ? void 0 : _a.enabled) {
                    this.row = row;
                    this.records[+row].current = true;
                }
            }
            var rec = this.records[+this.row];
            if (this.field != null) {
                var field = rec.getField(this.field.name);
                var inst = rec.getFieldByGuid(this.field.name, this.field.guid);
                if (inst === null || inst === void 0 ? void 0 : inst.focus())
                    return;
                if (field === null || field === void 0 ? void 0 : field.focus())
                    return;
            }
            for (var i = 0; i < this.fields$.length; i++) {
                if (this.fields$[i].row == this.row)
                    if (this.fields$[i].focus())
                        return;
            }
            rec === null || rec === void 0 ? void 0 : rec.focus();
        };
        BlockImpl.prototype.getValue = function (record, column) {
            if (this.state == FormState.entqry) {
                var field = this.records[0].getField(column);
                return (field === null || field === void 0 ? void 0 : field.value);
            }
            if (this.data == null)
                return (null);
            return (this.data.getValue(+record, column));
        };
        BlockImpl.prototype.setValue = function (record, column, value) {
            return __awaiter(this, void 0, void 0, function () {
                var field, previous, trgevent, field;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.data == null)
                                return [2 /*return*/, (false)];
                            if (this.state == FormState.entqry) {
                                field = this.records[0].getField(column);
                                if (field != null)
                                    field.value = value;
                                return [2 /*return*/, (true)];
                            }
                            previous = this.data.getValue(+record, column);
                            return [4 /*yield*/, this.lockrecord(record, column)];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            if (!this.data.setValue(+record, column, value))
                                return [2 /*return*/, (false)];
                            this.data.setValidated(record, column);
                            trgevent = new FieldTriggerEvent(this.alias, column, null, +record, value, previous);
                            this.invokeFieldTriggers(exports.Trigger.PostChange, column, trgevent);
                            if (+record >= +this.offset && +record < this.sum(this.offset, this.rows)) {
                                field = this.records[record - this.offset].getField(column);
                                if (field != null)
                                    field.value = value;
                            }
                            if (record == this.record && this.masterdetail != null && value != previous)
                                this.masterdetail.sync(this, column);
                            return [2 /*return*/];
                    }
                });
            });
        };
        Object.defineProperty(BlockImpl.prototype, "records", {
            get: function () {
                return (this.records$);
            },
            enumerable: false,
            configurable: true
        });
        BlockImpl.prototype.getRecord = function (row) {
            if (+row < +this.records$.length)
                return (this.records$[+row]);
            return (null);
        };
        BlockImpl.prototype.getField = function (row, name) {
            var _a;
            return ((_a = this.records[+row]) === null || _a === void 0 ? void 0 : _a.getField(name));
        };
        BlockImpl.prototype.addRecord = function (record) {
            var _this = this;
            this.records.push(record);
            record.fields.forEach(function (inst) { inst.block = _this; });
            if (this.records.length == 1) {
                record.current = true;
                this.field$ = record.fields[0].getFirstInstance();
            }
        };
        Object.defineProperty(BlockImpl.prototype, "usage", {
            get: function () {
                return (this.dbusage$);
            },
            set: function (usage) {
                this.dbusage$ = usage;
            },
            enumerable: false,
            configurable: true
        });
        BlockImpl.prototype.setApplication = function (app) {
            this.app = app;
        };
        BlockImpl.prototype.sendkey = function (event, key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (event == null)
                                event = new KeyTriggerEvent(Origin.Block, this.alias, null, key, null);
                            return [4 /*yield*/, this.onEvent(event, this.field, "key", key)];
                        case 1: return [2 /*return*/, (_h.sent())];
                    }
                });
            });
        };
        Object.defineProperty(BlockImpl.prototype, "searchfilter", {
            get: function () {
                if (this.data == null)
                    return (null);
                return (this.data.searchfilter);
            },
            set: function (filter) {
                if (this.data != null)
                    this.data.searchfilter = filter;
            },
            enumerable: false,
            configurable: true
        });
        BlockImpl.prototype.removeLocks = function () {
            if (this.data != null)
                this.data.removeLocks();
        };
        BlockImpl.prototype.execute = function (stmt, firstrow, firstcolumn) {
            return __awaiter(this, void 0, void 0, function () {
                var errors, msg_1, response, rows, row, columns;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (stmt == null)
                                return [2 /*return*/, (null)];
                            errors = stmt.validate();
                            if (errors.length > 0) {
                                msg_1 = "<table>";
                                errors.forEach(function (err) { msg_1 += "<tr><td>" + err + "</td></tr>"; });
                                msg_1 += "</table>";
                                this.alert(msg_1, "Execute");
                                return [2 /*return*/, (null)];
                            }
                            return [4 /*yield*/, this.app.appstate.connection.invokestmt(stmt)];
                        case 1:
                            response = _h.sent();
                            if (response["status"] == "failed")
                                this.alert(JSON.stringify(response), "Execute SQL Failed");
                            rows = response["rows"];
                            if (rows == null) {
                                if (firstcolumn)
                                    return [2 /*return*/, (null)];
                                return [2 /*return*/, ([])];
                            }
                            if (!firstrow)
                                return [2 /*return*/, (rows)];
                            row = [];
                            if (rows.length > 0)
                                row = rows[0];
                            if (!firstcolumn)
                                return [2 /*return*/, (row)];
                            columns = Object.keys(row);
                            if (columns.length == 0)
                                return [2 /*return*/, (null)];
                            return [2 /*return*/, (row[columns[0]])];
                    }
                });
            });
        };
        BlockImpl.prototype.showDatePicker = function (field, row) {
            if (row == null || row == -1)
                row = this.row;
            var record = this.sum(this.offset, row);
            var fld = this.records[+record].getField(field);
            var value = new Date();
            if (fld != null)
                value = fld.value;
            DatePicker.show(this.app, this, record, field, value);
        };
        BlockImpl.prototype.showListOfValues = function (field, id, row) {
            var _a;
            if (field == null)
                return;
            if (row == null || row == -1)
                row = this.row;
            if (!this.app.connected)
                return;
            if (!this.records[+row].enabled)
                return;
            if (this.records[+row].state == RecordState.na)
                return;
            var ldef = null;
            field = field.trim().toLowerCase();
            if (this.idlovs != null && id != null && id.trim().length > 0) {
                id = id.trim().toLowerCase();
                ldef = this.idlovs.get(field + "." + id);
            }
            else if (this.lovs != null) {
                ldef = this.lovs.get(field);
            }
            if (ldef != null) {
                var lov = null;
                var record = this.sum(row, this.offset);
                if (ldef.params.length == 0)
                    lov = ldef.inst[ldef.func]();
                else
                    lov = ldef.inst[ldef.func](record);
                var blocks = [this, new BlockImpl(), new BlockImpl()];
                if (!lov.force && ((_a = this.records[+row].getField(field)) === null || _a === void 0 ? void 0 : _a.readonly))
                    return;
                ListOfValuesImpl.show(this.app, blocks, lov);
            }
        };
        BlockImpl.prototype.keyinsert = function (after) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.data == null)
                                return [2 /*return*/, (false)];
                            if (!this.usage.insert)
                                return [2 /*return*/, (false)];
                            if (this.data.database && !this.app.connected)
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.insert(after)];
                        case 1: return [2 /*return*/, (_h.sent())];
                    }
                });
            });
        };
        BlockImpl.prototype.keydelete = function () {
            return __awaiter(this, void 0, void 0, function () {
                var rec;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.data == null)
                                return [2 /*return*/, (false)];
                            if (this.row >= this.data.rows)
                                return [2 /*return*/, (true)];
                            if (this.state == FormState.entqry)
                                return [2 /*return*/, (true)];
                            rec = this.records[+this.row];
                            if (rec.state == RecordState.na)
                                return [2 /*return*/, (true)];
                            if (this.data.database && !this.app.connected)
                                return [2 /*return*/, (false)];
                            if (!this.usage.delete && rec.state != RecordState.insert)
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.delete()];
                        case 1: return [2 /*return*/, (_h.sent())];
                    }
                });
            });
        };
        BlockImpl.prototype.keyentqry = function (force) {
            return __awaiter(this, void 0, void 0, function () {
                var event;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (force == null)
                                force = false;
                            if (!force) {
                                if (this.data == null)
                                    return [2 /*return*/, (false)];
                                if (!this.usage.query)
                                    return [2 /*return*/, (false)];
                                if (this.data.database && !this.app.connected)
                                    return [2 /*return*/, (false)];
                            }
                            event = new KeyTriggerEvent(Origin.Block, this.alias, null, exports.keymap.enterquery, null);
                            this.invokeTriggers(exports.Trigger.Key, event, exports.keymap.enterquery);
                            return [4 /*yield*/, this.enterqry()];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            if (this.masterdetail != null)
                                this.masterdetail.enterquery(this);
                            this.focus(0);
                            return [2 /*return*/, (true)];
                    }
                });
            });
        };
        BlockImpl.prototype.keyexeqry = function (force) {
            return __awaiter(this, void 0, void 0, function () {
                var subquery, status;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.masterdetail != null) {
                                if (this.masterdetail.master != null && this.masterdetail.master != this)
                                    return [2 /*return*/, (this.masterdetail.master.keyexeqry(force))];
                                if (this.state != FormState.entqry)
                                    this.masterdetail.clearfilters(this);
                            }
                            if (force == null)
                                force = false;
                            if (!force) {
                                if (this.data == null || !this.usage.query) {
                                    if (this.masterdetail != null)
                                        this.masterdetail.master = null;
                                    return [2 /*return*/, (false)];
                                }
                                if (this.data.database && !this.app.connected) {
                                    if (this.masterdetail != null)
                                        this.masterdetail.master = null;
                                    return [2 /*return*/, (false)];
                                }
                            }
                            subquery = null;
                            if (!(this.masterdetail != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.masterdetail.getDetailQuery()];
                        case 1:
                            subquery = _h.sent();
                            this.masterdetail.querydetails(this, true, false);
                            _h.label = 2;
                        case 2: return [4 /*yield*/, this.executeqry(subquery)];
                        case 3:
                            status = _h.sent();
                            this.focus(0);
                            return [2 /*return*/, (status)];
                    }
                });
            });
        };
        BlockImpl.prototype.cancelqry = function () {
            this.records[0].current = true;
            this.records[0].clear();
            this.records[0].disable();
            this.state = FormState.normal;
            this.records[0].state = RecordState.na;
            this.records[0].enable(true);
        };
        BlockImpl.prototype.enterqry = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.data.database && !this.app.connected)
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.validate()];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.clear()];
                        case 2:
                            _h.sent();
                            this.row = 0;
                            this.searchfilter = [];
                            this.state = FormState.entqry;
                            this.records[0].state = RecordState.qmode;
                            this.records[0].enable(false);
                            return [2 /*return*/, (true)];
                    }
                });
            });
        };
        Object.defineProperty(BlockImpl.prototype, "querying", {
            get: function () {
                return (this.querying$);
            },
            enumerable: false,
            configurable: true
        });
        // Public because of master-detail. Dont call direct
        BlockImpl.prototype.executeqry = function (subquery) {
            return __awaiter(this, void 0, void 0, function () {
                var keys, fields, stmt, errors, msg_2, event, response;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.data.database && !this.app.connected)
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.validate()];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            keys = [];
                            fields = [];
                            if (this.querying$) {
                                if (this.masterdetail != null)
                                    this.masterdetail.done(this, false);
                                return [2 /*return*/, (false)];
                            }
                            this.querying$ = true;
                            if (this.state == FormState.entqry) {
                                fields = this.records[0].fields;
                                this.records[0].disable();
                            }
                            if (this.masterdetail != null)
                                keys = this.masterdetail.getKeys(this);
                            stmt = this.data.parseQuery(keys, subquery, fields);
                            this.lastqry = this.searchfilter;
                            return [4 /*yield*/, this.clear()];
                        case 2:
                            _h.sent();
                            errors = stmt.validate();
                            if (errors.length > 0) {
                                msg_2 = "<table>";
                                errors.forEach(function (err) { msg_2 += "<tr><td>" + err + "</td></tr>"; });
                                msg_2 += "</table>";
                                this.alert(msg_2, "Query Condition");
                                this.querying$ = false;
                                if (this.masterdetail != null)
                                    this.masterdetail.done(this, false);
                                return [2 /*return*/, (false)];
                            }
                            event = new SQLTriggerEvent(this.alias, 0, stmt);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.PreQuery, event)];
                        case 3:
                            if (!(_h.sent())) {
                                this.querying$ = false;
                                if (this.masterdetail != null)
                                    this.masterdetail.done(this, false);
                                return [2 /*return*/, (false)];
                            }
                            this.state = FormState.exeqry;
                            stmt = event.stmt; // could be replaced by trigger
                            return [4 /*yield*/, this.data.executequery(stmt)];
                        case 4:
                            response = _h.sent();
                            if (response["status"] == "failed") {
                                this.alert(JSON.stringify(response), "Database Query");
                                this.querying$ = false;
                                if (this.masterdetail != null)
                                    this.masterdetail.done(this, false);
                                this.state = FormState.normal;
                                return [2 /*return*/, (false)];
                            }
                            if (this.masterdetail != null)
                                this.masterdetail.querydetails(this, false, true);
                            this.row = 0;
                            return [4 /*yield*/, this.display(0)];
                        case 5:
                            _h.sent();
                            this.querying$ = false;
                            this.state = FormState.normal;
                            this.records[0].current = true;
                            if (this.masterdetail != null)
                                this.masterdetail.done(this, true);
                            return [2 /*return*/, (true)];
                    }
                });
            });
        };
        BlockImpl.prototype.createControlRecord = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_h) {
                    if (!this.data.database) {
                        if (!this.data.insert(this.sum(this.row, this.offset, 1)))
                            return [2 /*return*/, (-1)];
                        this.records[+this.row].state = RecordState.update;
                        this.records[+this.row].enable(false);
                        return [2 /*return*/, (this.record)];
                    }
                    return [2 /*return*/, (-1)];
                });
            });
        };
        BlockImpl.prototype.insert = function (after) {
            return __awaiter(this, void 0, void 0, function () {
                var off, scroll, row, move, rec;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.data.database && !this.app.connected)
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.validate()];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            off = after ? 1 : 0;
                            if (!this.data.insert(this.sum(this.row, this.offset, off)))
                                return [2 /*return*/, (false)];
                            if (this.masterdetail != null)
                                this.masterdetail.cleardetails(this);
                            if (!(this.data.rows == 1)) return [3 /*break*/, 3];
                            return [4 /*yield*/, this.display(this.offset)];
                        case 2:
                            _h.sent();
                            if (this.form == null)
                                this.disableall();
                            else
                                this.form.disableall();
                            this.records[0].enable(false);
                            this.focus(0);
                            return [2 /*return*/, (true)];
                        case 3:
                            scroll = 0;
                            row = this.row;
                            if (after && this.row == this.rows - 1)
                                scroll = 1;
                            if (!after && this.row == 0)
                                scroll = -1;
                            move = 0;
                            if (scroll == 0)
                                move = after ? 1 : 0;
                            return [4 /*yield*/, this.display(this.sum(this.offset, scroll))];
                        case 4:
                            _h.sent();
                            row = this.sum(row, move);
                            rec = this.records[+row];
                            rec.current = true;
                            if (this.form == null)
                                this.disableall();
                            else
                                this.form.disableall();
                            this.records[+row].enable(false);
                            this.focus(row);
                            return [2 /*return*/, (true)];
                    }
                });
            });
        };
        BlockImpl.prototype.delete = function () {
            return __awaiter(this, void 0, void 0, function () {
                var record, response_1, response, row;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.data == null)
                                return [2 /*return*/, (false)];
                            if (this.data.database && !this.app.connected)
                                return [2 /*return*/, (false)];
                            record = this.sum(this.row, this.offset);
                            if (!!this.data.locked(record)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.data.lock(record)];
                        case 1:
                            response_1 = _h.sent();
                            if (response_1["status"] == "failed") {
                                this.alert(response_1["message"], "Lock Failure");
                                return [2 /*return*/, (false)];
                            }
                            _h.label = 2;
                        case 2: return [4 /*yield*/, this.data.delete(this.sum(this.row, this.offset))];
                        case 3:
                            response = _h.sent();
                            if (response["status"] == "failed") {
                                this.alert(JSON.stringify(response), "Delete Failed");
                                return [2 /*return*/, (false)];
                            }
                            if (this.masterdetail != null)
                                this.masterdetail.cleardetails(this);
                            // current view is not full
                            if (+this.data.rows - this.offset < this.rows) {
                                this.offset--;
                                if (this.offset < 0)
                                    this.offset = 0;
                            }
                            row = this.row;
                            return [4 /*yield*/, this.display(this.offset)];
                        case 4:
                            _h.sent();
                            // no records at current position
                            if (this.sum(row, this.offset) >= this.data.rows)
                                row = this.data.rows - this.offset - 1;
                            if (row < 0)
                                this.row = 0;
                            this.focus(row);
                            if (this.masterdetail != null)
                                this.masterdetail.querydetails(this, true, true);
                            return [2 /*return*/];
                    }
                });
            });
        };
        BlockImpl.prototype.lockrecord = function (record, field) {
            return __awaiter(this, void 0, void 0, function () {
                var trgevent, response, row, value, ffield;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.data == null)
                                return [2 /*return*/, (true)];
                            if (this.state != FormState.normal)
                                return [2 /*return*/, (true)];
                            if (!this.data.databasecolumn(field))
                                return [2 /*return*/, (true)];
                            if (this.data.locked(record))
                                return [2 /*return*/, (true)];
                            trgevent = new TriggerEvent(this.alias, record, null);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Lock, trgevent)];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.data.lock(record)];
                        case 2:
                            response = _h.sent();
                            if (response["status"] == "failed") {
                                row = +record - +this.offset;
                                this.alert(response["message"], "Lock Failure");
                                value = this.getValue(record, field);
                                ffield = this.records[+row].getField(field);
                                if (ffield != null)
                                    ffield.value = value;
                                return [2 /*return*/, (false)];
                            }
                            return [2 /*return*/, (true)];
                    }
                });
            });
        };
        BlockImpl.prototype.validate = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0: return [4 /*yield*/, this.validatefield(this.field)];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.validaterecord()];
                        case 2: return [2 /*return*/, (_h.sent())];
                    }
                });
            });
        };
        BlockImpl.prototype.validatefield = function (field) {
            return __awaiter(this, void 0, void 0, function () {
                var previous, trgevent;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (field == null)
                                return [2 /*return*/, (true)];
                            if (this.data == null)
                                return [2 /*return*/, (true)];
                            if (this.row >= this.data.rows)
                                return [2 /*return*/, (true)];
                            if (this.state != FormState.normal)
                                return [2 /*return*/, (true)];
                            if (this.records[+this.row].state == RecordState.na)
                                return [2 /*return*/, (true)];
                            previous = this.data.getValue(this.sum(field.row, this.offset), field.name);
                            // Nothing has changed
                            if (field.value == previous)
                                return [2 /*return*/, (this.data.getValidated(this.sum(field.row, this.offset), field.name))];
                            return [4 /*yield*/, this.lockrecord(this.sum(field.row, this.offset), field.name)];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (true)];
                            if (!field.validate()) {
                                field.valid = false;
                                this.data.setValue(this.sum(field.row, this.offset), field.name, field.value);
                                return [2 /*return*/, (false)];
                            }
                            this.data.setValue(+field.row + this.offset, field.name, field.value);
                            trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, previous, null);
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.WhenValidateField, field.name, trgevent)];
                        case 2:
                            if (!(_h.sent())) {
                                field.valid = false;
                                return [2 /*return*/, (false)];
                            }
                            field.parent.valid = true;
                            this.data.setValidated(this.sum(field.row, this.offset), field.name);
                            if (!(field.value != previous)) return [3 /*break*/, 4];
                            if (this.sum(field.row, this.offset) == this.record && this.masterdetail != null)
                                this.masterdetail.sync(this, field.name);
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.PostChange, field.name, trgevent)];
                        case 3:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            if (this.records[+this.row].state == RecordState.insert) {
                                if (this.data.validated(this.record, true))
                                    this.validaterecord();
                            }
                            _h.label = 4;
                        case 4: return [2 /*return*/, (true)];
                    }
                });
            });
        };
        BlockImpl.prototype.validaterecord = function () {
            return __awaiter(this, void 0, void 0, function () {
                var rec, cols, trgevent, insert, response, title;
                var _this = this;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (this.data == null)
                                return [2 /*return*/, (true)];
                            if (this.row >= this.data.rows)
                                return [2 /*return*/, (true)];
                            if (this.state == FormState.entqry)
                                return [2 /*return*/, (true)];
                            rec = this.records[+this.row];
                            if (rec.state == RecordState.na)
                                return [2 /*return*/, (true)];
                            // Check fields is validated
                            if (!this.data.validated(this.record, true)) {
                                cols = this.data.getNonValidated(this.record);
                                this.alert("The following columns are not valid:<br><br>" + cols, "Validate Record");
                                cols.forEach(function (col) { _this.records[+_this.record].getField(col).valid = false; });
                                return [2 /*return*/, (false)];
                            }
                            // Check record is validated
                            if (this.data.validated(this.record, false))
                                return [2 /*return*/, (true)];
                            trgevent = new TriggerEvent(this.alias, this.record, null);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.WhenValidateRecord, trgevent)];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            insert = (rec.state == RecordState.insert);
                            return [4 /*yield*/, this.data.setValidated(this.record)];
                        case 2:
                            response = _h.sent();
                            if (response["status"] == "failed") {
                                title = insert ? "Insert" : "Update";
                                this.alert(JSON.stringify(response), title + " Failed");
                                return [2 /*return*/, (false)];
                            }
                            if (insert) {
                                if (this.form == null)
                                    this.enableall();
                                else
                                    this.form.enableall();
                            }
                            return [2 /*return*/, (true)];
                    }
                });
            });
        };
        BlockImpl.prototype.clearblock = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0: return [4 /*yield*/, this.clear()];
                        case 1:
                            _h.sent();
                            this.focus(0);
                            this.searchfilter = [];
                            if (this.data)
                                this.data.clear();
                            return [2 /*return*/];
                    }
                });
            });
        };
        BlockImpl.prototype.clear = function () {
            return __awaiter(this, void 0, void 0, function () {
                var r;
                return __generator(this, function (_h) {
                    if (this.rows == null)
                        return [2 /*return*/];
                    this.field$ = this.fields$[0];
                    for (r = 0; r < this.rows; r++) {
                        this.records[+r].clear();
                        this.records[+r].disable();
                        this.records[+r].state = RecordState.na;
                    }
                    this.records[0].current = true;
                    this.records[0].state = RecordState.na;
                    if (!this.disabled$)
                        this.records[0].enable(true);
                    return [2 /*return*/];
                });
            });
        };
        BlockImpl.prototype.disableall = function () {
            return __awaiter(this, void 0, void 0, function () {
                var r;
                return __generator(this, function (_h) {
                    this.disabled$ = true;
                    for (r = 0; r < this.rows; r++)
                        this.records[+r].disable();
                    return [2 /*return*/];
                });
            });
        };
        BlockImpl.prototype.enableall = function () {
            return __awaiter(this, void 0, void 0, function () {
                var r;
                return __generator(this, function (_h) {
                    this.disabled$ = false;
                    for (r = 0; r < this.rows; r++) {
                        if (this.records[+r].state != RecordState.na)
                            this.records[+r].enable(false);
                    }
                    return [2 /*return*/];
                });
            });
        };
        BlockImpl.prototype.display = function (start) {
            return __awaiter(this, void 0, void 0, function () {
                var columns, rows, r, rec, state, c, field, execs, c, field, value, fname, trgevent, i;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0: return [4 /*yield*/, this.clear()];
                        case 1:
                            _h.sent();
                            this.offset = start;
                            if (this.data == null)
                                return [2 /*return*/];
                            if (this.sum(this.offset, this.rows) > +this.data.rows)
                                this.offset = this.data.rows - this.rows;
                            if (this.offset < 0)
                                this.offset = 0;
                            columns = this.data.fields;
                            rows = this.data.get(this.offset, this.rows);
                            r = 0;
                            _h.label = 2;
                        case 2:
                            if (!(r < rows.length)) return [3 /*break*/, 8];
                            rec = this.getRecord(r);
                            state = this.data.state(this.sum(this.offset, r));
                            for (c = 0; c < rows[r].length; c++) {
                                field = rec.getField(columns[c]);
                                if (field != null)
                                    field.value = rows[r][c];
                            }
                            if (!(state == RecordState.na)) return [3 /*break*/, 6];
                            execs = [];
                            for (c = 0; c < rows[r].length; c++) {
                                field = rec.getField(columns[c]);
                                value = rows[r][c];
                                fname = columns[c];
                                if (field != null)
                                    fname = field.name;
                                trgevent = new FieldTriggerEvent(this.alias, fname, null, this.sum(r, this.offset), value, value);
                                execs.push(this.invokeFieldTriggers(exports.Trigger.PostChange, fname, trgevent));
                            }
                            execs.push(this.invokeTriggers(exports.Trigger.PostChange, new TriggerEvent(this.alias, this.sum(r, this.offset))));
                            state = this.data.state(this.sum(this.offset, r), RecordState.update);
                            i = 0;
                            _h.label = 3;
                        case 3:
                            if (!(i < execs.length)) return [3 /*break*/, 6];
                            return [4 /*yield*/, execs[i]];
                        case 4:
                            _h.sent();
                            _h.label = 5;
                        case 5:
                            i++;
                            return [3 /*break*/, 3];
                        case 6:
                            rec.state = state;
                            if (!this.disabled$)
                                rec.enable(false);
                            _h.label = 7;
                        case 7:
                            r++;
                            return [3 /*break*/, 2];
                        case 8: return [2 /*return*/];
                    }
                });
            });
        };
        BlockImpl.prototype.addTrigger = function (instance, func, types) {
            this.triggers.addTrigger(instance, func, types);
        };
        BlockImpl.prototype.addKeyTrigger = function (instance, func, keys) {
            this.triggers.addTrigger(instance, func, exports.Trigger.Key, null, keys);
        };
        BlockImpl.prototype.addFieldTrigger = function (instance, func, types, fields, keys) {
            this.triggers.addTrigger(instance, func, types, fields, keys);
        };
        BlockImpl.prototype.onEvent = function (event, field, type, key) {
            var _a, _b, _c, _d, _e, _f, _g;
            return __awaiter(this, void 0, void 0, function () {
                var trgevent, state, previous, type_1, i, nvp, previous, row, offset, fetched, row, offset, fetched;
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            trgevent = null;
                            if (event == null)
                                event = { type: type };
                            if (this.records.length == 0)
                                return [2 /*return*/, (true)];
                            if (!(type == "focus")) return [3 /*break*/, 4];
                            this.field$ = field;
                            if (this.form != null)
                                this.form.block = this;
                            if (this.state == FormState.entqry)
                                return [2 /*return*/, (true)];
                            if (!(this.row != field.row)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.validate()];
                        case 1:
                            if (!(_h.sent())) {
                                this.records[+this.row].current = true;
                                this.field.focus();
                                return [2 /*return*/, (false)];
                            }
                            state = this.records[field.row].state;
                            if (this.masterdetail != null && state != RecordState.na)
                                this.masterdetail.querydetails(this, true, true);
                            _h.label = 2;
                        case 2:
                            this.row = field.row;
                            this.records$[+field.row].current = true;
                            trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, field.value, event);
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.PreField, field.name, trgevent)];
                        case 3: return [2 /*return*/, (_h.sent())];
                        case 4:
                            if (!(type == "blur")) return [3 /*break*/, 6];
                            if (this.state == FormState.entqry)
                                return [2 /*return*/, (true)];
                            trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, field.value, event);
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.PostField, field.name, trgevent)];
                        case 5: return [2 /*return*/, (_h.sent())];
                        case 6:
                            if (!(type == "fchange")) return [3 /*break*/, 8];
                            if (this.state == FormState.entqry || this.data == null)
                                return [2 /*return*/, (true)];
                            return [4 /*yield*/, this.lockrecord(this.sum(field.row, this.offset), field.name)];
                        case 7: return [2 /*return*/, (_h.sent())];
                        case 8:
                            if (type == "cchange") {
                                if (this.state == FormState.entqry)
                                    return [2 /*return*/, (true)];
                                previous = this.getValue(this.sum(field.row, this.offset), field.name);
                                trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, previous, event);
                                return [2 /*return*/, (this.invokeFieldTriggers(exports.Trigger.Typing, field.name, trgevent))];
                            }
                            if (!(type == "change")) return [3 /*break*/, 10];
                            // Current row field firing after move
                            if (field.row != this.row)
                                return [2 /*return*/, (true)];
                            return [4 /*yield*/, this.validatefield(field)];
                        case 9:
                            // This will fire appropiate triggers
                            if (!(_h.sent())) {
                                this.field.focus();
                                return [2 /*return*/, (false)];
                            }
                            return [2 /*return*/, (true)];
                        case 10:
                            if (!(type == "key" && key == exports.keymap.enter)) return [3 /*break*/, 14];
                            if (this.state == FormState.entqry)
                                key = exports.keymap.executequery;
                            if (!(((_a = this.records[+this.row]) === null || _a === void 0 ? void 0 : _a.state) == RecordState.insert)) return [3 /*break*/, 12];
                            return [4 /*yield*/, this.validaterecord()];
                        case 11:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            _h.label = 12;
                        case 12:
                            if (!(((_b = this.records[+this.row]) === null || _b === void 0 ? void 0 : _b.state) == RecordState.update)) return [3 /*break*/, 14];
                            return [4 /*yield*/, this.validaterecord()];
                        case 13:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            _h.label = 14;
                        case 14:
                            // Cancel
                            if (type == "key" && key == exports.keymap.escape) {
                                if (this.state == FormState.entqry) {
                                    this.cancelqry();
                                    this.focus();
                                }
                                if (((_c = this.records[+this.row]) === null || _c === void 0 ? void 0 : _c.state) == RecordState.insert) {
                                    this.enableall();
                                    key = exports.keymap.delete;
                                }
                            }
                            // ListOfValues / Datepicker
                            if (type == "key" && key == exports.keymap.listval) {
                                if (event != null && event["preventDefault"] != null)
                                    event.preventDefault();
                                type_1 = field.definition.type;
                                if (type_1 == exports.FieldType.date || type_1 == exports.FieldType.datetime) {
                                    if (!field.readonly)
                                        DatePicker.show(this.app, this, this.record, field.name, field.value);
                                    return [2 /*return*/, (true)];
                                }
                                this.showListOfValues(field.name, field.id, this.row);
                                return [2 /*return*/, (true)];
                            }
                            if (!(type == "key" && key == exports.keymap.enterquery)) return [3 /*break*/, 23];
                            if (!(this.state == FormState.entqry)) return [3 /*break*/, 19];
                            i = 0;
                            _h.label = 15;
                        case 15:
                            if (!(i < this.lastqry.length)) return [3 /*break*/, 18];
                            nvp = this.lastqry[i];
                            return [4 /*yield*/, this.setValue(0, nvp.name, nvp.value)];
                        case 16:
                            _h.sent();
                            _h.label = 17;
                        case 17:
                            i++;
                            return [3 /*break*/, 15];
                        case 18: return [2 /*return*/, (true)];
                        case 19: return [4 /*yield*/, this.validate()];
                        case 20:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.keyentqry()];
                        case 21:
                            if (!(_h.sent())) {
                                field.focus();
                                return [2 /*return*/, (false)];
                            }
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 22: return [2 /*return*/, (_h.sent())];
                        case 23:
                            if (!(type == "key" && key == exports.keymap.executequery)) return [3 /*break*/, 27];
                            return [4 /*yield*/, this.validate()];
                        case 24:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 25:
                            if (!(_h.sent()))
                                return [2 /*return*/, (true)];
                            return [4 /*yield*/, this.keyexeqry()];
                        case 26: return [2 /*return*/, (_h.sent())];
                        case 27:
                            if (!(type == "key" && key == exports.keymap.delete)) return [3 /*break*/, 31];
                            if (event != null && event["preventDefault"] != null)
                                event.preventDefault();
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            if (!(((_d = this.records[+this.row]) === null || _d === void 0 ? void 0 : _d.state) == RecordState.update)) return [3 /*break*/, 29];
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 28:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            _h.label = 29;
                        case 29: return [4 /*yield*/, this.keydelete()];
                        case 30: return [2 /*return*/, (_h.sent())];
                        case 31:
                            if (!(type == "key" && key == exports.keymap.insertafter)) return [3 /*break*/, 35];
                            return [4 /*yield*/, this.validate()];
                        case 32:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 33:
                            if (!(_h.sent()))
                                return [2 /*return*/, (true)];
                            return [4 /*yield*/, this.keyinsert(true)];
                        case 34:
                            if (!(_h.sent())) {
                                field.focus();
                                return [2 /*return*/, (false)];
                            }
                            return [2 /*return*/, (true)];
                        case 35:
                            if (!(type == "key" && key == exports.keymap.insertbefore)) return [3 /*break*/, 39];
                            return [4 /*yield*/, this.validate()];
                        case 36:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 37:
                            if (!(_h.sent()))
                                return [2 /*return*/, (true)];
                            return [4 /*yield*/, this.keyinsert(false)];
                        case 38:
                            if (!(_h.sent())) {
                                field.focus();
                                return [2 /*return*/, (false)];
                            }
                            return [2 /*return*/, (true)];
                        case 39:
                            if (!(type == "key" && (key == exports.keymap.nextfield || key == exports.keymap.prevfield))) return [3 /*break*/, 43];
                            if (!(this.state != FormState.entqry && ((_e = this.records[+this.row]) === null || _e === void 0 ? void 0 : _e.state) != RecordState.na)) return [3 /*break*/, 43];
                            previous = this.data.getValue(this.sum(field.row, this.offset), field.name);
                            if (field.dirty) {
                                // ctrl-z doesn't refresh
                                if (field.value == previous)
                                    field.parent.copy(field);
                            }
                            trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, previous, event);
                            if (!(key == exports.keymap.prevfield)) return [3 /*break*/, 41];
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.KeyPrevField, field.name, trgevent, key)];
                        case 40:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            _h.label = 41;
                        case 41:
                            if (!(key == exports.keymap.nextfield)) return [3 /*break*/, 43];
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.KeyNextField, field.name, trgevent, key)];
                        case 42:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            _h.label = 43;
                        case 43:
                            if (!(type == "key" && key == exports.keymap.nextrecord)) return [3 /*break*/, 49];
                            return [4 /*yield*/, this.validate()];
                        case 44:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 45:
                            if (!(_h.sent()))
                                return [2 /*return*/, (true)];
                            row = this.sum(field.row, 1);
                            if (this.data == null)
                                return [2 /*return*/, (false)];
                            if (!(+row >= +this.rows)) return [3 /*break*/, 48];
                            row = +this.rows - 1;
                            if (this.data == null)
                                return [2 /*return*/, (false)];
                            offset = this.sum(field.row, this.offset);
                            return [4 /*yield*/, this.data.fetch(offset, 1)];
                        case 46:
                            fetched = _h.sent();
                            if (fetched == 0)
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.display(this.sum(this.offset, 1))];
                        case 47:
                            _h.sent();
                            _h.label = 48;
                        case 48:
                            if ((_f = this.records[+row]) === null || _f === void 0 ? void 0 : _f.enabled) {
                                this.focus(row);
                                if (this.masterdetail != null)
                                    this.masterdetail.querydetails(this, true, true);
                            }
                            return [2 /*return*/, (true)];
                        case 49:
                            if (!(type == "key" && key == exports.keymap.prevrecord)) return [3 /*break*/, 54];
                            if (this.record == 0)
                                return [2 /*return*/, (true)];
                            return [4 /*yield*/, this.validate()];
                        case 50:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 51:
                            if (!(_h.sent()))
                                return [2 /*return*/, (true)];
                            row = +field.row - 1;
                            if (this.data == null)
                                return [2 /*return*/, (false)];
                            if (!(+row < 0)) return [3 /*break*/, 53];
                            row = 0;
                            return [4 /*yield*/, this.display(this.offset - 1)];
                        case 52:
                            _h.sent();
                            _h.label = 53;
                        case 53:
                            this.focus(row);
                            if (this.masterdetail != null)
                                this.masterdetail.querydetails(this, true, true);
                            return [2 /*return*/, (true)];
                        case 54:
                            if (!(type == "key" && key == exports.keymap.pagedown)) return [3 /*break*/, 59];
                            return [4 /*yield*/, this.validate()];
                        case 55:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 56:
                            if (!(_h.sent()))
                                return [2 /*return*/, (true)];
                            offset = this.sum(this.offset, field.row);
                            return [4 /*yield*/, this.data.fetch(offset, this.rows)];
                        case 57:
                            fetched = _h.sent();
                            if (fetched == 0)
                                return [2 /*return*/, (false)];
                            return [4 /*yield*/, this.display(this.sum(this.offset, this.rows))];
                        case 58:
                            _h.sent();
                            this.focus();
                            if (this.masterdetail != null)
                                this.masterdetail.querydetails(this, true, true);
                            return [2 /*return*/, (true)];
                        case 59:
                            if (!(type == "key" && key == exports.keymap.pageup)) return [3 /*break*/, 63];
                            if (this.record == 0)
                                return [2 /*return*/, (true)];
                            return [4 /*yield*/, this.validate()];
                        case 60:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 61:
                            if (!(_h.sent()))
                                return [2 /*return*/, (true)];
                            return [4 /*yield*/, this.display(+this.offset - this.rows)];
                        case 62:
                            _h.sent();
                            this.focus();
                            if (this.masterdetail != null)
                                this.masterdetail.querydetails(this, true, true);
                            return [2 /*return*/, (true)];
                        case 63:
                            if (!(type == "key" && (key == exports.keymap.prevblock || key == exports.keymap.nextblock))) return [3 /*break*/, 68];
                            if (!(this.state != FormState.entqry && ((_g = this.records[+this.row]) === null || _g === void 0 ? void 0 : _g.state) != RecordState.na)) return [3 /*break*/, 68];
                            return [4 /*yield*/, this.validate()];
                        case 64:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, null, event);
                            if (!(key == exports.keymap.prevblock)) return [3 /*break*/, 66];
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.KeyPrevBlock, field.name, trgevent, key)];
                        case 65:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            _h.label = 66;
                        case 66:
                            if (!(key == exports.keymap.nextblock)) return [3 /*break*/, 68];
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.KeyNextBlock, field.name, trgevent, key)];
                        case 67:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            _h.label = 68;
                        case 68:
                            if (!(type == "key" && key == exports.keymap.clearblock)) return [3 /*break*/, 70];
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, null, exports.keymap.clearblock, null);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, event, exports.keymap.clearblock)];
                        case 69:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            this.clearblock();
                            _h.label = 70;
                        case 70:
                            if (!(type == "key" && key == exports.keymap.clearform && this.form != null)) return [3 /*break*/, 72];
                            return [4 /*yield*/, this.form.onEvent(event, field, type, key)];
                        case 71:
                            _h.sent();
                            _h.label = 72;
                        case 72:
                            if (!(type == "key" && key == exports.keymap.prevfield && this.form != null)) return [3 /*break*/, 74];
                            return [4 /*yield*/, this.form.onEvent(event, field, type, key)];
                        case 73:
                            _h.sent();
                            _h.label = 74;
                        case 74:
                            if (!(type == "key" && key == exports.keymap.nextfield && this.form != null)) return [3 /*break*/, 76];
                            return [4 /*yield*/, this.form.onEvent(event, field, type, key)];
                        case 75:
                            _h.sent();
                            _h.label = 76;
                        case 76:
                            if (!(type == "key" && key == exports.keymap.prevblock && this.form != null)) return [3 /*break*/, 78];
                            return [4 /*yield*/, this.form.onEvent(event, field, type, key)];
                        case 77:
                            _h.sent();
                            _h.label = 78;
                        case 78:
                            if (!(type == "key" && key == exports.keymap.nextblock && this.form != null)) return [3 /*break*/, 80];
                            return [4 /*yield*/, this.form.onEvent(event, field, type, key)];
                        case 79:
                            _h.sent();
                            _h.label = 80;
                        case 80:
                            if (!(type == "key")) return [3 /*break*/, 82];
                            if (event != null && event["preventDefault"] != null)
                                event.preventDefault();
                            trgevent = new KeyTriggerEvent(Origin.Block, this.alias, field, key, event);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, trgevent, key)];
                        case 81: return [2 /*return*/, (_h.sent())];
                        case 82:
                            if (!(type == "click")) return [3 /*break*/, 84];
                            trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, field.value, event);
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.MouseClick, field.name, trgevent, key)];
                        case 83: return [2 /*return*/, (_h.sent())];
                        case 84:
                            if (!(type == "dblclick")) return [3 /*break*/, 86];
                            trgevent = new FieldTriggerEvent(this.alias, field.name, field.id, this.sum(field.row, this.offset), field.value, field.value, event);
                            return [4 /*yield*/, this.invokeFieldTriggers(exports.Trigger.MouseDoubleClick, field.name, trgevent, key)];
                        case 85: return [2 /*return*/, (_h.sent())];
                        case 86: return [2 /*return*/, (true)];
                    }
                });
            });
        };
        BlockImpl.prototype.invokeTriggers = function (type, event, key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (!(this.form != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.form.invokeTriggers(type, event, key)];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            _h.label = 2;
                        case 2: return [4 /*yield*/, this.triggers.invokeTriggers(type, event, key)];
                        case 3: return [2 /*return*/, (_h.sent())];
                    }
                });
            });
        };
        BlockImpl.prototype.invokeFieldTriggers = function (type, field, event, key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_h) {
                    switch (_h.label) {
                        case 0:
                            if (!(this.form != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.form.invokeFieldTriggers(type, field, event, key)];
                        case 1:
                            if (!(_h.sent()))
                                return [2 /*return*/, (false)];
                            _h.label = 2;
                        case 2: return [4 /*yield*/, this.triggers.invokeFieldTriggers(type, field, event, key)];
                        case 3: return [2 /*return*/, (_h.sent())];
                    }
                });
            });
        };
        BlockImpl.prototype.sleep = function (ms) {
            return (new Promise(function (resolve) { return setTimeout(resolve, ms); }));
        };
        BlockImpl.prototype.alert = function (msg, title, width, height) {
            if (title == null)
                title = this.alias;
            MessageBox.show(this.app, msg, title, width, height);
        };
        BlockImpl.prototype.sum = function (n1, n2, n3) {
            var s = +n1 + +n2;
            if (n3 != null)
                s = +s + +n3;
            return (s);
        };
        return BlockImpl;
    }());

    var Block = /** @class */ (function () {
        // dont rename impl as it is read behind the scenes
        function Block() {
            this._impl_ = new BlockImpl(this);
        }
        Object.defineProperty(Block.prototype, "form", {
            get: function () {
                return (this._impl_.form.form);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Block.prototype, "table", {
            get: function () {
                return (this._impl_.table);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Block.prototype, "connected", {
            get: function () {
                return (this.form.connected);
            },
            enumerable: false,
            configurable: true
        });
        Block.prototype.getValue = function (record, field) {
            return (this._impl_.getValue(record, field));
        };
        Block.prototype.setValue = function (record, field, value) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this._impl_.setValue(record, field, value)];
                        case 1: return [2 /*return*/, (_a.sent())];
                    }
                });
            });
        };
        Object.defineProperty(Block.prototype, "querymode", {
            get: function () {
                return (this._impl_.querymode);
            },
            enumerable: false,
            configurable: true
        });
        Block.prototype.empty = function () {
            return (this._impl_.getRecord(0).state == RecordState.na);
        };
        Block.prototype.cancel = function () {
            this._impl_.sendkey(null, exports.keymap.escape);
        };
        Object.defineProperty(Block.prototype, "ready", {
            get: function () {
                return (this._impl_.ready);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Block.prototype, "searchfilter", {
            get: function () {
                return (this._impl_.searchfilter);
            },
            set: function (filter) {
                this._impl_.searchfilter = filter;
            },
            enumerable: false,
            configurable: true
        });
        Block.prototype.sendKey = function (key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this._impl_.sendkey(null, key)];
                        case 1: return [2 /*return*/, (_a.sent())];
                    }
                });
            });
        };
        Block.prototype.enterquery = function (override) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, (this._impl_.keyentqry(override))];
                });
            });
        };
        Block.prototype.executequery = function (override) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, (this._impl_.keyexeqry(override))];
                });
            });
        };
        Block.prototype.nextrecord = function () {
            this._impl_.sendkey(null, exports.keymap.nextrecord);
        };
        Block.prototype.prevrecord = function () {
            this._impl_.sendkey(null, exports.keymap.prevrecord);
        };
        Block.prototype.nextblock = function () {
            this._impl_.sendkey(null, exports.keymap.nextblock);
        };
        Block.prototype.prevblock = function () {
            this._impl_.sendkey(null, exports.keymap.prevblock);
        };
        Block.prototype.pageup = function () {
            this._impl_.sendkey(null, exports.keymap.pageup);
        };
        Block.prototype.pagedown = function () {
            this._impl_.sendkey(null, exports.keymap.pagedown);
        };
        Object.defineProperty(Block.prototype, "row", {
            get: function () {
                return (this._impl_.row);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Block.prototype, "record", {
            get: function () {
                return (this._impl_.record);
            },
            enumerable: false,
            configurable: true
        });
        Block.prototype.createControlRecord = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, (this._impl_.createControlRecord())];
                });
            });
        };
        Block.prototype.delete = function (override) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    if (override)
                        return [2 /*return*/, (this._impl_.delete())];
                    else
                        return [2 /*return*/, (this._impl_.sendkey(null, exports.keymap.delete))];
                    return [2 /*return*/];
                });
            });
        };
        Block.prototype.setFieldDefinition = function (def) {
            return (this._impl_.setFieldDefinition(def));
        };
        Block.prototype.setPossibleValues = function (field, values, enforce) {
            return (this._impl_.setPossibleValues(field, values, enforce));
        };
        Block.prototype.showDatePicker = function (field, row) {
            this._impl_.showDatePicker(field, row);
        };
        Block.prototype.showListOfValues = function (field, id, row) {
            this._impl_.showListOfValues(field, id, row);
        };
        Block.prototype.insert = function (above, override) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    if (above == null)
                        above = false;
                    if (override)
                        return [2 /*return*/, (this._impl_.insert(!above))];
                    else {
                        if (!above)
                            return [2 /*return*/, (this._impl_.sendkey(null, exports.keymap.insertafter))];
                        else
                            return [2 /*return*/, (this._impl_.sendkey(null, exports.keymap.insertbefore))];
                    }
                    return [2 /*return*/];
                });
            });
        };
        Block.prototype.execute = function (stmt, firstrow, firstcolumn) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, (this._impl_.execute(stmt, firstrow, firstcolumn))];
                });
            });
        };
        Block.prototype.addListOfValues = function (func, field, id) {
            this._impl_.addListOfValues(false, func, field, id);
        };
        Block.prototype.addTrigger = function (listener, types) {
            this._impl_.addTrigger(this, listener, types);
        };
        Block.prototype.addKeyTrigger = function (listener, keys) {
            this._impl_.addKeyTrigger(this, listener, keys);
        };
        Block.prototype.addFieldTrigger = function (listener, types, fields) {
            this._impl_.addFieldTrigger(this, listener, types, fields);
        };
        Block.prototype.alert = function (message, title, width, height) {
            this._impl_.alert(message, title, width, height);
        };
        return Block;
    }());

    var MasterDetailQuery = /** @class */ (function () {
        function MasterDetailQuery(md, links, block, col) {
            this.md = md;
            this.links = links;
            this.finished = 0;
            this.detailblks = new Map();
            this.masterblks = new Map();
            this.root$ = block;
            this.findblocks(block.alias, col);
        }
        Object.defineProperty(MasterDetailQuery.prototype, "root", {
            get: function () {
                return (this.root$);
            },
            enumerable: false,
            configurable: true
        });
        MasterDetailQuery.prototype.findblocks = function (block, col) {
            var _this = this;
            var dep = this.links.get(block);
            if (this.details(dep)) {
                this.masterblks.set(block, false);
                dep.details.forEach(function (det) {
                    if (col == null || det.mkey.partof(col)) {
                        _this.findblocks(det.block.alias, null);
                        _this.detailblks.set(det.block.alias, 0);
                    }
                });
            }
        };
        MasterDetailQuery.prototype.waitfor = function (block) {
            this.detailblks.set(block.alias, 1);
        };
        MasterDetailQuery.prototype.ready = function (block) {
            this.masterblks.set(block.alias, true);
            var dep = this.links.get(block.alias);
            if (this.detailblks.size == 0) {
                this.md.finished();
                return;
            }
            if (this.details(dep))
                this.execute(dep);
            else
                this.state(block, 2);
        };
        MasterDetailQuery.prototype.done = function (block) {
            this.finished++;
            this.state(block, 3);
            if (this.finished == this.detailblks.size)
                this.md.finished();
        };
        MasterDetailQuery.prototype.failed = function (block) {
            this.remove(block);
            if (this.finished == this.detailblks.size)
                this.md.finished();
        };
        MasterDetailQuery.prototype.remove = function (block) {
            var _this = this;
            if (this.detailblks.get(block.alias) < 2) {
                this.detailblks.delete(block.alias);
                var dep = this.links.get(block.alias);
                if (dep != null && dep.details != null) {
                    dep.details.forEach(function (det) { _this.remove(det.block); });
                }
            }
            else {
                this.finished++;
                this.state(block, 3);
            }
        };
        MasterDetailQuery.prototype.status = function (state) {
            console.log(state + " finished: " + this.finished + " " + this.detailblks.size);
            this.detailblks.forEach(function (state, blk) { console.log(blk + " " + state); });
        };
        MasterDetailQuery.prototype.execute = function (dep) {
            return __awaiter(this, void 0, void 0, function () {
                var i;
                return __generator(this, function (_a) {
                    if (dep.details != null) {
                        for (i = 0; i < dep.details.length; i++) {
                            if (this.isready(dep.details[i].block)) {
                                dep.details[i].block.executeqry();
                                this.state(dep.details[i].block, 1);
                            }
                        }
                    }
                    return [2 /*return*/];
                });
            });
        };
        MasterDetailQuery.prototype.isready = function (block) {
            var _this = this;
            var ready = true;
            var dep = this.links.get(block.alias);
            if (dep.masters != null) {
                dep.masters.forEach(function (master) {
                    var alias = master.block.alias;
                    var ok = _this.masterblks.get(alias);
                    if (ok == null || !ok)
                        ready = false;
                });
            }
            return (ready);
        };
        MasterDetailQuery.prototype.state = function (block, state) {
            this.detailblks.set(block.alias, state);
        };
        MasterDetailQuery.prototype.details = function (dep) {
            return (dep != null && dep.details != null);
        };
        return MasterDetailQuery;
    }());

    var MasterDetail = /** @class */ (function () {
        function MasterDetail(form) {
            this.form = null;
            this.master$ = null;
            this.waiting = null;
            this.query = null;
            this.blocks = new Map();
            this.links = new Map();
            this.defined = new Map();
            this.form = form;
        }
        Object.defineProperty(MasterDetail.prototype, "master", {
            get: function () {
                return (this.master$);
            },
            set: function (block) {
                this.master$ = block;
            },
            enumerable: false,
            configurable: true
        });
        MasterDetail.prototype.getRoot = function (block) {
            if (block == null)
                block = Array.from(this.blocks)[0]["1"];
            var dep = this.links.get(block.alias);
            while (dep != null && dep.masters != null && dep.masters.length > 0) {
                block = dep.masters[0].block;
                dep = this.links.get(block.alias);
            }
            return (block);
        };
        MasterDetail.prototype.cleardetails = function (block) {
            var _this = this;
            var dep = this.links.get(block.alias);
            if (dep != null && dep.details != null)
                dep.details.forEach(function (det) { return _this.clear(det.block); });
        };
        MasterDetail.prototype.clear = function (block) {
            var _this = this;
            block.clear();
            var dep = this.links.get(block.alias);
            if (dep != null && dep.details != null)
                dep.details.forEach(function (det) { return _this.clear(det.block); });
        };
        MasterDetail.prototype.sync = function (block, col) {
            var dep = this.links.get(block.alias);
            if (dep != null) {
                if (!dep.keycols.has(col))
                    return;
                this.master = block;
                this.query = new MasterDetailQuery(this, this.links, block, col);
                this.query.ready(block);
            }
        };
        MasterDetail.prototype.enterquery = function (block) {
            this.master$ = block;
            this.enterdetailquery(block);
        };
        MasterDetail.prototype.enterdetailquery = function (block) {
            var _this = this;
            var dep = this.links.get(block.alias);
            if (dep != null && dep.details != null) {
                dep.details.forEach(function (det) {
                    if (det.block.usage.query)
                        det.block.enterqry();
                    _this.enterdetailquery(det.block);
                });
            }
        };
        MasterDetail.prototype.clearfilters = function (block) {
            var _this = this;
            block.searchfilter = [];
            var dep = this.links.get(block.alias);
            if (dep != null && dep.details != null) {
                dep.details.forEach(function (det) {
                    det.block.searchfilter = [];
                    _this.clearfilters(det.block);
                });
            }
        };
        // Build subquery from details
        MasterDetail.prototype.getDetailQuery = function () {
            return __awaiter(this, void 0, void 0, function () {
                var block, dep, sub, i, subq, bindvals_1;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0:
                            block = this.master$;
                            this.master$ = null;
                            if (block == null)
                                return [2 /*return*/, (null)];
                            dep = this.links.get(block.alias);
                            sub = {
                                lev: 0,
                                sql: null,
                                subs: [],
                                mcols: [],
                                dcols: [],
                                bindvalues: [],
                                mtab: null
                            };
                            if (!(dep != null && dep.details != null)) return [3 /*break*/, 4];
                            i = 0;
                            _c.label = 1;
                        case 1:
                            if (!(i < dep.details.length)) return [3 /*break*/, 4];
                            return [4 /*yield*/, this.subquery(sub, dep.details[i])];
                        case 2:
                            _c.sent();
                            _c.label = 3;
                        case 3:
                            i++;
                            return [3 /*break*/, 1];
                        case 4:
                            subq = null;
                            this.buildsubquery(sub);
                            if (sub.sql.length > 0) {
                                bindvals_1 = [];
                                sub.bindvalues.forEach(function (bindv) {
                                    bindvals_1.push({
                                        name: bindv.name,
                                        type: exports.Column[bindv.type].toLowerCase(),
                                        value: bindv.value
                                    });
                                });
                                subq = { sql: sub.sql, bindvalues: bindvals_1 };
                            }
                            return [2 /*return*/, (subq)];
                    }
                });
            });
        };
        MasterDetail.prototype.subquery = function (parent, detail) {
            var _a, _b;
            return __awaiter(this, void 0, void 0, function () {
                var mkey, dkey, block, sub, fields, stmt, event, dep, i;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0:
                            mkey = detail.mkey;
                            dkey = detail.dkey;
                            block = detail.block;
                            if (!block.querymode) return [3 /*break*/, 5];
                            sub = {
                                sql: null,
                                subs: [],
                                bindvalues: [],
                                lev: +parent.lev + 1,
                                mcols: mkey.columns(),
                                dcols: dkey.columns(),
                                mtab: (_b = (_a = block.data) === null || _a === void 0 ? void 0 : _a.table) === null || _b === void 0 ? void 0 : _b.name
                            };
                            parent.subs.push(sub);
                            fields = block.records[0].fields;
                            stmt = block.data.parseQuery([], null, fields);
                            event = new SQLTriggerEvent(block.alias, 0, stmt);
                            return [4 /*yield*/, block.invokeTriggers(exports.Trigger.PreQuery, event)];
                        case 1:
                            if (!(_c.sent()))
                                return [2 /*return*/];
                            block.cancelqry();
                            if (block.searchfilter.length > 0) {
                                stmt.order = null;
                                stmt.columns = dkey.columns();
                                sub.sql = stmt.build().sql;
                                sub.bindvalues = stmt.getCondition().getAllBindvalues();
                            }
                            dep = this.links.get(block.alias);
                            if (!(dep != null && dep.details != null)) return [3 /*break*/, 5];
                            i = 0;
                            _c.label = 2;
                        case 2:
                            if (!(i < dep.details.length)) return [3 /*break*/, 5];
                            return [4 /*yield*/, this.subquery(sub, dep.details[i])];
                        case 3:
                            _c.sent();
                            _c.label = 4;
                        case 4:
                            i++;
                            return [3 /*break*/, 2];
                        case 5: return [2 /*return*/];
                    }
                });
            });
        };
        MasterDetail.prototype.buildsubquery = function (sub) {
            var children = false;
            for (var i = 0; i < sub.subs.length; i++) {
                this.buildsubquery(sub.subs[i]);
                if (sub.subs[i].sql != null && sub.subs[i].sql.length > 0)
                    children = true;
            }
            var sql = "";
            var and = false;
            var where = false;
            if (sub.sql != null) {
                and = true;
            }
            else if (children && sub.mtab != null) {
                where = true;
                sub.sql = "select " + sub.dcols + " from " + sub.mtab;
            }
            if (children) {
                for (var i = 0; i < sub.subs.length; i++) {
                    if (sub.subs[i].sql != null && sub.subs[i].sql.length > 0) {
                        if (and)
                            sql += " and ";
                        if (where)
                            sql += " where ";
                        sql += "(" + sub.subs[i].mcols + ") in (";
                        sql += sub.subs[i].sql;
                        sql += ")";
                        sub.subs[i].bindvalues.forEach(function (bind) { sub.bindvalues.push(bind); });
                        and = true;
                        where = false;
                    }
                }
            }
            if (sub.sql == null)
                sub.sql = sql;
            else
                sub.sql += sql;
        };
        MasterDetail.prototype.querydetails = function (block, init, ready) {
            if (init == null)
                init = false;
            if (init) {
                if (this.query != null) {
                    this.waiting = block;
                    return;
                }
                this.master = block;
                this.query = new MasterDetailQuery(this, this.links, block);
            }
            if (ready)
                this.query.ready(block);
            else
                this.query.waitfor(block);
        };
        MasterDetail.prototype.done = function (block, success) {
            if (success)
                this.query.done(block);
            else
                this.query.failed(block);
        };
        MasterDetail.prototype.finished = function () {
            var block = null;
            if (this.waiting != null) {
                block = this.waiting;
                this.waiting = null;
                this.query = new MasterDetailQuery(this, this.links, block);
                this.query.ready(block);
            }
            else {
                this.query = null;
                this.master = null;
            }
        };
        MasterDetail.prototype.getKeys = function (block) {
            var keys = [];
            var dep = this.links.get(block.alias);
            if (dep != null && dep.masters != null) {
                dep.masters.forEach(function (master) {
                    var c = 0;
                    var record = master.block.record;
                    master.mkey.columns().forEach(function (col) {
                        var val = null;
                        if (record < master.block.datarows)
                            val = master.block.getValue(record, col);
                        master.dkey.set(c++, val);
                    });
                    keys.push(master.dkey);
                });
            }
            return (keys);
        };
        MasterDetail.prototype.addBlock = function (block) {
            this.blocks.set(block.alias, block);
        };
        MasterDetail.prototype.addKeys = function (block, keys) {
            this.defined.set(block.alias, keys);
        };
        MasterDetail.prototype.addJoins = function (joins) {
            var _this = this;
            if (joins == null)
                return;
            joins.forEach(function (join) {
                var skip = false;
                var master = _this.blocks.get(join.master.alias);
                var detail = _this.blocks.get(join.detail.alias);
                if (master == null) {
                    skip = true;
                    console.log("Master block " + join.master.alias + " in join on form " + _this.form.name + " does not exist");
                }
                if (detail == null) {
                    skip = true;
                    console.log("Detail block " + join.detail.alias + " in join on form " + _this.form.name + " does not exist");
                }
                if (!skip) {
                    var keys = null;
                    keys = _this.defined.get(join.master.alias);
                    var mkey = keys === null || keys === void 0 ? void 0 : keys.get(join.master.key);
                    keys = _this.defined.get(join.detail.alias);
                    var dkey = keys === null || keys === void 0 ? void 0 : keys.get(join.detail.key);
                    if (mkey == null) {
                        skip = true;
                        console.log("Join on form " + _this.form.name + ". Cannot find key " + join.master.key + " on block " + join.master.alias);
                    }
                    if (dkey == null) {
                        skip = true;
                        console.log("Join on form " + _this.form.name + ". Cannot find key " + join.detail.key + " on block " + join.detail.alias);
                    }
                    if (!skip) {
                        var mdep_1 = _this.links.get(master.alias);
                        if (mdep_1 == null) {
                            mdep_1 = { keycols: new Set() };
                            _this.links.set(master.alias, mdep_1);
                        }
                        if (mdep_1.details == null)
                            mdep_1.details = [];
                        dkey.columns().forEach(function (col) { mdep_1.keycols.add(col); });
                        mdep_1.details.push({ block: detail, mkey: mkey, dkey: dkey });
                        var ddep = _this.links.get(detail.alias);
                        if (ddep == null) {
                            ddep = { keycols: new Set() };
                            _this.links.set(detail.alias, ddep);
                        }
                        if (ddep.masters == null)
                            ddep.masters = [];
                        ddep.masters.push({ block: master, mkey: mkey, dkey: dkey });
                    }
                }
            });
        };
        return MasterDetail;
    }());

    var FormImpl = /** @class */ (function () {
        function FormImpl(form$) {
            this.form$ = form$;
            this.blocks = [];
            this.cancelled = false;
            this.initiated$ = false;
            this.fields$ = [];
            this.triggers = new Triggers();
            this.parameters = new Map();
            this.stack = new Map();
            this.blkindex = new Map();
            this.creationerror = false;
            this.guid$ = FormImpl.id++;
            var utils = new Utils();
            this.name$ = utils.getName(form$);
        }
        Object.defineProperty(FormImpl.prototype, "guid", {
            get: function () {
                return (this.guid$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FormImpl.prototype, "form", {
            get: function () {
                return (this.form$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FormImpl.prototype, "name", {
            get: function () {
                return (this.name$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FormImpl.prototype, "path", {
            get: function () {
                return (this.path$);
            },
            set: function (path) {
                this.path$ = path;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FormImpl.prototype, "title", {
            get: function () {
                return (this.title$);
            },
            set: function (title) {
                this.title$ = title;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FormImpl.prototype, "block", {
            get: function () {
                return (this.block$);
            },
            set: function (block) {
                var _a;
                if (this.block != null && this.block != block)
                    if (!((_a = this.block) === null || _a === void 0 ? void 0 : _a.validate()))
                        return;
                this.block$ = block;
            },
            enumerable: false,
            configurable: true
        });
        FormImpl.prototype.enterquery = function (force) {
            var _a;
            (_a = this.depencies.getRoot()) === null || _a === void 0 ? void 0 : _a.keyentqry(force);
        };
        FormImpl.prototype.executequery = function (force) {
            var _a;
            (_a = this.depencies.getRoot()) === null || _a === void 0 ? void 0 : _a.keyexeqry(force);
        };
        Object.defineProperty(FormImpl.prototype, "popup", {
            get: function () {
                return (this.win != null);
            },
            enumerable: false,
            configurable: true
        });
        FormImpl.prototype.getCurrentRow = function (block) {
            var blk = this.getBlock(block);
            if (blk == null)
                return (0);
            return (blk.row);
        };
        FormImpl.prototype.getCurrentRecord = function (block) {
            var blk = this.getBlock(block);
            if (blk == null)
                return (0);
            return (blk.record);
        };
        FormImpl.prototype.getBlock = function (bname) {
            return (this.blkindex.get(bname.toLowerCase()));
        };
        FormImpl.prototype.clear = function () {
            var _a;
            return __awaiter(this, void 0, void 0, function () {
                var i, event;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            i = 0;
                            _b.label = 1;
                        case 1:
                            if (!(i < this.blocks.length)) return [3 /*break*/, 4];
                            event = new KeyTriggerEvent(Origin.Form, this.blocks[i].alias, null, exports.keymap.clearblock, null);
                            return [4 /*yield*/, this.blocks[i].sendkey(event, exports.keymap.clearblock)];
                        case 2:
                            _b.sent();
                            _b.label = 3;
                        case 3:
                            i++;
                            return [3 /*break*/, 1];
                        case 4:
                            if (this.blocks.length > 0)
                                this.block = this.blocks[0];
                            (_a = this.block) === null || _a === void 0 ? void 0 : _a.focus();
                            return [2 /*return*/, (true)];
                    }
                });
            });
        };
        FormImpl.prototype.enableall = function () {
            this.blocks.forEach(function (block) { block.enableall(); });
        };
        FormImpl.prototype.disableall = function () {
            this.blocks.forEach(function (block) { block.disableall(); });
        };
        FormImpl.prototype.focus = function () {
            var _a;
            (_a = this.block) === null || _a === void 0 ? void 0 : _a.focus();
        };
        FormImpl.prototype.getChain = function () {
            if (this.next == null)
                return (this);
            return (this.next.getChain());
        };
        FormImpl.prototype.initiated = function () {
            return (this.initiated$);
        };
        FormImpl.prototype.setMenu = function (menu) {
            if (this.app == null) {
                this.menu$ = menu;
                return;
            }
            this.app.deletemenu(this.menu$);
            this.ddmenu = this.app.createmenu(menu);
            this.app.showMenu(this.ddmenu);
            this.menu$ = menu;
        };
        FormImpl.prototype.getMenu = function () {
            return (this.menu$);
        };
        FormImpl.prototype.getApplication = function () {
            return (this.app);
        };
        FormImpl.prototype.setRoot = function (root) {
            this.root = root;
        };
        FormImpl.prototype.setParent = function (parent) {
            this.parent = parent;
        };
        FormImpl.prototype.setApplication = function (app) {
            this.app = app;
            if (this.menu$ == null)
                this.menu$ = new DefaultMenu();
            this.conn = app.appstate.connection;
            this.ddmenu = app.createmenu(this.menu$);
        };
        FormImpl.prototype.getInstanceID = function () {
            return (this.inst);
        };
        FormImpl.prototype.setInstanceID = function (inst) {
            this.inst = inst;
        };
        FormImpl.prototype.setModalWindow = function (win) {
            this.win = win;
        };
        FormImpl.prototype.getModalWindow = function () {
            return (this.win);
        };
        FormImpl.prototype.setCallback = function (func) {
            this.callbackfunc = func;
        };
        FormImpl.prototype.setParameters = function (params) {
            if (params != null)
                this.parameters = params;
            else
                this.parameters = new Map();
        };
        FormImpl.prototype.getParameters = function () {
            return (this.parameters);
        };
        FormImpl.prototype.getDropDownMenu = function () {
            return (this.ddmenu);
        };
        FormImpl.prototype.onCommit = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    this.blocks.forEach(function (blk) { blk.removeLocks(); });
                    return [2 /*return*/];
                });
            });
        };
        FormImpl.prototype.execute = function (stmt, firstrow, firstcolumn) {
            return __awaiter(this, void 0, void 0, function () {
                var response, rows, row, columns;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, this.app.appstate.connection.invokestmt(stmt)];
                        case 1:
                            response = _b.sent();
                            if (response["status"] == "failed")
                                this.alert(JSON.stringify(response), "Execute SQL Failed");
                            rows = response["rows"];
                            if (rows == null) {
                                if (firstcolumn)
                                    return [2 /*return*/, (null)];
                                return [2 /*return*/, ([])];
                            }
                            if (!firstrow)
                                return [2 /*return*/, (rows)];
                            row = [];
                            if (rows.length > 0)
                                row = rows[0];
                            if (!firstcolumn)
                                return [2 /*return*/, (row)];
                            columns = Object.keys(row);
                            if (columns.length == 0)
                                return [2 /*return*/, (null)];
                            return [2 /*return*/, (row[columns[0]])];
                    }
                });
            });
        };
        FormImpl.prototype.newForm = function (container) {
            var _this = this;
            var utils = new Utils();
            this.depencies = new MasterDetail(this);
            // Add all form key triggers
            var fktriggers = TriggerDefinitions.getFormKeyTriggers(this.name);
            fktriggers.forEach(function (def) { _this.triggers.addTrigger(_this.form, def.func, def.trigger, def.field, def.key); });
            // Create blocks
            var blockdef = BlockDefinitions.getBlocks(this.name);
            blockdef.forEach(function (bdef) { _this.createBlock(bdef); });
            if (this.creationerror)
                return;
            // DatabaseUsage for this form
            var fusage = DatabaseDefinitions.getFormUsage(this.name);
            // Merge form, block and block usage. Form usage overides
            blockdef.forEach(function (bdef) { _this.setBlockUsage(fusage, bdef); });
            container.finish();
            // Get all fields per block
            var bfields = new Map();
            container.getBlocks().forEach(function (cb) {
                var block = _this.blkindex.get(cb.name);
                if (block == null) {
                    var dblk = new Block();
                    block = dblk["_impl_"];
                    _this.blocks.push(block);
                    _this.blkindex.set(cb.name, block);
                    block.form = _this;
                    block.alias = cb.name;
                    block.setApplication(_this.app);
                    console.log("Block " + cb.name + " auto-created");
                }
                bfields.set(block.alias, cb.fields);
                cb.records.forEach(function (rec) { block.addRecord(new Record(rec.row, rec.fields, rec.index)); });
            });
            this.blkindex.forEach(function (block) {
                _this.depencies.addBlock(block);
                block.setMasterDetail(_this.depencies);
                // Finish setup for each block
                var keydefs = BlockDefinitions.getKeys(block.clazz);
                var tabdef = utils.clone(TableDefinitions.get(block.clazz));
                // Column definitions
                var colindex = ColumnDefinitions.getIndex(block.clazz);
                // Columns mapped to fields. Form definitions overrides
                var colfields = FieldDefinitions.getColumnIndex(block.clazz);
                var colffields = FieldDefinitions.getFormColumnIndex(_this.name, block.alias);
                colffields.forEach(function (def, fld) { colfields.set(fld, def); });
                // Create keys and decide on primary
                var pkey = null;
                var keys = new Map();
                keydefs.forEach(function (kdef) {
                    var key = keys.get(kdef.name);
                    if (key == null) {
                        key = new Key(kdef.name);
                        keys.set(kdef.name, key);
                        kdef.columns.forEach(function (col) {
                            var fdef = colfields.get(col);
                            if (fdef != null)
                                col = fdef.name;
                            key.addColumn(col);
                        });
                        if (kdef.unique && pkey == null)
                            pkey = key;
                        if (kdef.name.startsWith("primary"))
                            pkey = key;
                    }
                    else {
                        console.log("key " + kdef.name + " is defined twice");
                    }
                });
                _this.depencies.addKeys(block, keys);
                var fields = [];
                var sorted = [];
                // List of data-fields. First pkey
                if (pkey != null) {
                    pkey.columns().forEach(function (part) {
                        var fname = part;
                        var fdef = colfields.get(part);
                        if (fdef != null)
                            fname = fdef.name;
                        sorted.push(colindex.get(part));
                        fields.push(fname);
                    });
                }
                // Then other columns. First gather all definitions
                var columns = ColumnDefinitions.get(block.clazz);
                var fieldidx = FieldDefinitions.getFieldIndex(block.clazz);
                var ffieldidx = FieldDefinitions.getFormFieldIndex(_this.name, block.alias);
                // Override by form
                ffieldidx.forEach(function (def, fld) { fieldidx.set(fld, def); });
                columns.forEach(function (column) {
                    var nonkey = true;
                    if (pkey != null && pkey.partof(column.name))
                        nonkey = false;
                    if (nonkey) {
                        sorted.push(column);
                        var fname = null;
                        var field = colfields.get(column.name);
                        if (field != null)
                            fname = field.name;
                        else {
                            field = fieldidx.get(column.name);
                            if (field == null)
                                fname = column.name;
                            else {
                                fname = field.name;
                                field.column = column.name;
                            }
                        }
                        fields.push(fname);
                    }
                });
                columns = sorted;
                // Then other defined fields (block or form)
                fieldidx.forEach(function (field) {
                    if (!fields.includes(field.name, 0))
                        fields.push(field.name);
                });
                // Field overrides.
                var overideidx = FieldDefinitions.getFieldIndex(block.clazz);
                // Set field properties and add undefined fields
                var bfieldlist = bfields.get(block.alias);
                if (bfieldlist != null)
                    bfieldlist.forEach(function (inst) {
                        var fdef = utils.clone(fieldidx.get(inst.name));
                        if (fdef == null) {
                            // Auto create field definition
                            fdef = { name: inst.name };
                            fieldidx.set(inst.name, fdef);
                            if (!fields.includes(inst.name, 0))
                                fields.push(inst.name);
                        }
                        if (fdef.column == null) {
                            // Map to column, unless column is mapped otherwise
                            var cdef_1 = colindex.get(fdef.name);
                            if (cdef_1 != null && colfields.get(fdef.name) == null)
                                fdef.column = fdef.name;
                        }
                        // Save default definition
                        fieldidx.set(inst.name, fdef);
                        // Override def
                        if (inst.id.length > 0) {
                            var id = inst.name + "." + inst.id;
                            var iddef = utils.clone(FieldDefinitions.getFormFieldOverride(_this.name, block.alias, id));
                            if (iddef == null)
                                iddef = utils.clone(FieldDefinitions.getFieldOverride(block.clazz, id));
                            if (iddef != null) {
                                overideidx.set(id, iddef);
                                iddef.column = fdef.column;
                                fdef = iddef;
                            }
                        }
                        var cdef = colindex.get(fdef.column);
                        if (fdef.column != null && !fdef.hasOwnProperty("case"))
                            fdef.case = cdef.case;
                        if (fdef.column != null && !fdef.hasOwnProperty("default"))
                            fdef.default = cdef.default;
                        if (fdef.column != null && !fdef.hasOwnProperty("mandatory"))
                            fdef.mandatory = cdef.mandatory;
                        if (fdef.type == null)
                            fdef.type = FieldImplementation.guess(cdef === null || cdef === void 0 ? void 0 : cdef.type);
                        if (fdef.fieldoptions == null)
                            fdef.fieldoptions = {};
                        if (!block.usage.update)
                            fdef.fieldoptions.update = false;
                        inst.definition = fdef;
                        if (inst.parent.definition == null)
                            inst.parent.setDefinition(fdef, false);
                    });
                var def = new Map();
                var ovf = new Map();
                var lovs = new Map();
                var idlovs = new Map();
                def = LOVDefinitions.getblock(block.name);
                def.forEach(function (lov, fld) { lovs.set(fld, lov); });
                def = LOVDefinitions.getblockid(block.name);
                def.forEach(function (lov, fld) { lovs.set(fld, lov); });
                ovf = LOVDefinitions.getform(_this.name, block.alias);
                ovf.forEach(function (lov, fld) { lovs.set(fld, lov); });
                ovf = LOVDefinitions.getidform(_this.name, block.alias);
                ovf.forEach(function (lov, fld) { idlovs.set(fld, lov); });
                block.setListOfValues(lovs);
                block.setIdListOfValues(idlovs);
                // Form triggers
                var ftriggers = TriggerDefinitions.getFormFieldTriggers(_this.name, null);
                // Field triggers for block
                var bftriggers = TriggerDefinitions.getFieldTriggers(block.name);
                var fftriggers = TriggerDefinitions.getFormFieldTriggers(_this.name, block.alias);
                // Form overrides
                ftriggers.forEach(function (def, trg) { bftriggers.set(trg, def); });
                fftriggers.forEach(function (def, trg) { bftriggers.set(trg, def); });
                bftriggers.forEach(function (def) {
                    if (!def.blktrg && def.block == block.alias) {
                        // Blocktrigger defined on form
                        block["triggers"].addTrigger(_this.form, def.func, def.trigger, def.field);
                    }
                    else {
                        if (!def.blktrg)
                            _this.triggers.addTrigger(_this.form, def.func, def.trigger, def.field);
                        else
                            block["triggers"].addTrigger(block.block, def.func, def.trigger, def.field);
                    }
                });
                // Key triggers for block
                var bktriggers = TriggerDefinitions.getKeyTriggers(block.name);
                // delete block-triggers if defined on form
                fktriggers.forEach(function (_def, trg) { bktriggers.delete(trg); });
                bktriggers.forEach(function (def) { block["triggers"].addTrigger(block.block, def.func, def.trigger, def.field, def.key); });
                // Create data-backing table
                var table = null;
                var rows = block.records.length;
                if (tabdef != null)
                    table = new Table(_this.conn, tabdef, pkey, columns, fieldidx, rows);
                block.data = new FieldData(block, table, fields, fieldidx);
                // Start form
                block.ready = true;
            });
            // Get all fields on form
            this.fields$ = container.fields;
            if (this.blocks.length > 0)
                this.block$ = this.blocks[0];
            this.groupfields();
            this.blocks.forEach(function (block) {
                if (block.records.length > 0)
                    block.records[0].enable(true);
            });
            this.depencies.addJoins(JOINDefinitions.get(this.name));
            this.app.newForm(this);
            this.initiated$ = true;
            if (this.fields$.length > 0)
                this.fields$[0].focus();
        };
        FormImpl.prototype.showform = function (form, destroy, parameters) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (!this.validate())
                                return [2 /*return*/];
                            if (!(this.win == null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.app.showform(form, destroy, parameters)];
                        case 1:
                            _b.sent();
                            return [3 /*break*/, 4];
                        case 2: return [4 /*yield*/, this.replaceform(form, destroy, parameters)];
                        case 3:
                            _b.sent();
                            _b.label = 4;
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        FormImpl.prototype.replaceform = function (form, destroy, parameters) {
            return __awaiter(this, void 0, void 0, function () {
                var utils, name, id, inst;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            utils = new Utils();
                            name = utils.getName(form);
                            id = this.parent.stack.get(name);
                            this.onHide();
                            // newform
                            if (destroy)
                                this.app.closeform(this, destroy);
                            // create
                            if (id == null) {
                                id = this.app.getNewInstance(form);
                                this.parent.stack.set(id.name, id);
                            }
                            this.parent.next = id.impl;
                            id.impl.setParent(this.parent);
                            inst = this.app.getInstance(id);
                            return [4 /*yield*/, this.app.preform(id.impl, parameters, inst, false)];
                        case 1:
                            _b.sent();
                            if (this.win != null) {
                                this.win.newForm(inst);
                                id.impl.setRoot(this.root);
                            }
                            else {
                                id.impl.setRoot(this);
                                this.app.showinstance(inst);
                            }
                            return [2 /*return*/];
                    }
                });
            });
        };
        FormImpl.prototype.callform = function (form, destroy, parameters) {
            return __awaiter(this, void 0, void 0, function () {
                var utils, name, id, inst;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            utils = new Utils();
                            name = utils.getName(form);
                            id = this.stack.get(name);
                            this.onHide();
                            // newform
                            if (id != null && destroy) {
                                this.app.closeform(id.impl, destroy);
                                id = null;
                            }
                            // create
                            if (id == null) {
                                id = this.app.getNewInstance(form);
                                if (id == null)
                                    return [2 /*return*/, (null)];
                                this.stack.set(name, id);
                            }
                            this.next = id.impl;
                            id.impl.setParent(this);
                            inst = this.app.getInstance(id);
                            return [4 /*yield*/, this.app.preform(id.impl, parameters, inst, false)];
                        case 1:
                            _b.sent();
                            if (this.win != null) {
                                this.win.newForm(inst);
                                id.impl.setRoot(this.root);
                            }
                            else {
                                id.impl.setRoot(this);
                                this.app.showinstance(inst);
                            }
                            return [2 /*return*/, (id.impl)];
                    }
                });
            });
        };
        FormImpl.prototype.wasCancelled = function () {
            return (this.cancelled);
        };
        FormImpl.prototype.cancel = function () {
            this.cancelled = true;
            this.close(true);
        };
        FormImpl.prototype.onClose = function (impl, cancelled) {
            this.next = null;
            try {
                if (this.callbackfunc != null)
                    this.form[this.callbackfunc.name](impl.form, cancelled);
            }
            catch (error) {
                console.log(error);
            }
            if (cancelled && this.parent != null)
                this.parent.onClose(this, cancelled);
        };
        FormImpl.prototype.close = function (destroy) {
            return __awaiter(this, void 0, void 0, function () {
                var win, menu, root, _b, pinst, inst;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0:
                            win = (this.win != null);
                            menu = (this.root == null);
                            root = (this.parent == null);
                            _b = !this.cancelled && !destroy;
                            if (!_b) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.validate()];
                        case 1:
                            _b = !(_c.sent());
                            _c.label = 2;
                        case 2:
                            if (_b)
                                return [2 /*return*/];
                            this.next = null;
                            if (this.parent != null)
                                this.parent.onClose(this, this.cancelled);
                            if (this.cancelled) {
                                this.cancelled = false;
                                if (menu) {
                                    //chain, started from "menu", was cancelled
                                    this.app.closeform(this, true);
                                }
                                else {
                                    //chain, started from form, was cancelled
                                    this.parent.stack.delete(this.name);
                                    this.app.closeInstance(this.inst, true);
                                    this.app.showTitle(this.root.title);
                                }
                                if (!menu)
                                    this.root.onShow();
                                return [2 /*return*/];
                            }
                            if (!win) {
                                //Normal behaivior
                                this.app.closeform(this, destroy);
                                if (!root)
                                    this.parent.onShow();
                                return [2 /*return*/];
                            }
                            if (win && root) {
                                //Root window
                                this.app.closeform(this, destroy);
                                if (!root)
                                    this.parent.onShow();
                                this.win.closeWindow();
                                return [2 /*return*/];
                            }
                            //child closed
                            this.app.closeInstance(this.inst, destroy);
                            if (destroy)
                                this.parent.stack.delete(this.name);
                            pinst = this.parent.getInstanceID();
                            this.app.showTitle(this.parent.title);
                            if (pinst != null) {
                                inst = this.app.getInstance(pinst);
                                this.win.newForm(inst);
                            }
                            else
                                this.win.closeWindow();
                            this.parent.onShow();
                            return [2 /*return*/];
                    }
                });
            });
        };
        FormImpl.prototype.getCallStack = function () {
            var stack = [];
            this.stack.forEach(function (id) {
                stack.push(id.impl.form);
            });
            return (stack);
        };
        FormImpl.prototype.clearStack = function () {
            var _this = this;
            this.stack.forEach(function (id) {
                id.impl.clearStack();
                if (id.ref != null)
                    _this.app.closeInstance(id, true);
            });
            this.stack.clear();
        };
        FormImpl.prototype.createBlock = function (blockdef) {
            var impl = this.blkindex.get(blockdef.alias);
            if (impl != null) {
                console.log("Block alias " + blockdef.alias + " defined twice");
                return;
            }
            var block = null;
            if (blockdef.prop != null) {
                block = this.form[blockdef.prop];
                if (block == null && blockdef.component != null) {
                    block = new blockdef.component();
                    this.form[blockdef.prop] = block;
                }
            }
            else {
                if (blockdef.component != null)
                    block = new blockdef.component();
            }
            if (block != null)
                impl = block["_impl_"];
            if (impl == null) {
                this.creationerror = true;
                console.log(this.name + " cannot create instance of " + blockdef.alias + " bailing out");
                return;
            }
            var cname = block.constructor.name;
            if (!(impl instanceof BlockImpl)) {
                this.creationerror = true;
                console.log("component: " + cname + " is not an instance of block bailing out");
                return;
            }
            var alias = blockdef.alias;
            if (alias == null) {
                alias = block.constructor.name;
                alias = BlockDefinitions.getDefaultAlias(alias);
            }
            alias = alias.toLowerCase();
            impl.alias = alias;
            blockdef.alias = alias;
            this.blocks.push(impl);
            this.blkindex.set(alias, impl);
            impl.form = this;
            impl.setApplication(this.app);
        };
        FormImpl.prototype.setBlockUsage = function (fusage, blockdef) {
            var block = this.blkindex.get(blockdef.alias);
            var usage = {};
            var pusage = blockdef.databaseopts;
            var dusage = DatabaseDefinitions.getBlockDefault(block.clazz);
            if (dusage == null)
                dusage = {};
            if (pusage == null)
                pusage = {};
            if (fusage == null)
                fusage = {};
            usage = DBUsage.merge(pusage, dusage);
            usage = DBUsage.override(fusage, usage);
            usage = DBUsage.complete(usage);
            block.usage = usage;
        };
        // Sort fields by group and set tabindex
        FormImpl.prototype.groupfields = function (groups) {
            var _this = this;
            var seq = 1;
            if (groups == null)
                groups = [];
            var index = new Map();
            this.fields$.forEach(function (field) {
                var group = index.get(field.group);
                if (group == null) {
                    group = [];
                    index.set(field.group, group);
                    var exists = false;
                    for (var i = 0; i < groups.length; i++) {
                        if (groups[i] == field.group) {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists)
                        groups.push(field.group);
                }
                group.push(field);
            });
            groups.forEach(function (name) {
                var group = index.get(name);
                if (group != null) {
                    group.forEach(function (field) { field.seq = seq++; });
                }
            });
            this.fields$ = this.fields$.sort(function (a, b) { return (a.seq - b.seq); });
            var blocks = new Map();
            this.fields$.forEach(function (field) {
                var fields = blocks.get(field.block);
                if (fields == null) {
                    fields = [];
                    blocks.set(field.block, fields);
                }
                fields.push(field);
            });
            blocks.forEach(function (fields, bname) { _this.blkindex.get(bname).setFields(fields); });
        };
        FormImpl.prototype.validate = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (!(this.block == null)) return [3 /*break*/, 1];
                            return [2 /*return*/, (true)];
                        case 1: return [4 /*yield*/, this.block.validate()];
                        case 2: return [2 /*return*/, (_b.sent())];
                    }
                });
            });
        };
        FormImpl.prototype.onShow = function () {
        };
        FormImpl.prototype.onHide = function () {
        };
        FormImpl.prototype.sendkey = function (event, key) {
            var _a;
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (!(key == exports.keymap.close)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.close(false)];
                        case 1:
                            _b.sent();
                            return [2 /*return*/, (true)];
                        case 2:
                            if (event == null)
                                event = new KeyTriggerEvent(Origin.Form, null, null, exports.keymap.clearblock, null);
                            return [4 /*yield*/, ((_a = this.block) === null || _a === void 0 ? void 0 : _a.sendkey(event, key))];
                        case 3: return [2 /*return*/, (_b.sent())];
                    }
                });
            });
        };
        FormImpl.prototype.addTrigger = function (instance, func, types) {
            this.triggers.addTrigger(instance, func, types);
        };
        FormImpl.prototype.addKeyTrigger = function (instance, func, keys) {
            this.triggers.addTrigger(instance, func, exports.Trigger.Key, null, keys);
        };
        FormImpl.prototype.addFieldTrigger = function (instance, func, types, fields, keys) {
            this.triggers.addTrigger(instance, func, types, fields, keys);
        };
        FormImpl.prototype.onEvent = function (event, field, type, key) {
            return __awaiter(this, void 0, void 0, function () {
                var row, seq, block, i, row, seq, block, i, seq, block, row, next, i, blk, nb, nf, seq, block, row, next, i, blk, nb, nf, event_1;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (this.app == null)
                                return [2 /*return*/];
                            if (type == "focus")
                                this.block = this.blkindex.get(field.block);
                            if (type == "key" && key == exports.keymap.prevfield) {
                                if (event["preventDefault"] != null)
                                    event.preventDefault();
                                row = field.row;
                                seq = field.seq - 1;
                                block = field.block;
                                for (i = 0; i < this.fields$.length; i++) {
                                    if (--seq < 0)
                                        seq = this.fields$.length - 1;
                                    if (this.fields$[seq].row == row && this.fields$[seq].block == block) {
                                        if (this.fields$[seq].enabled) {
                                            this.fields$[seq].focus();
                                            break;
                                        }
                                    }
                                }
                            }
                            if (type == "key" && key == exports.keymap.nextfield) {
                                if (event["preventDefault"] != null)
                                    event.preventDefault();
                                row = field.row;
                                seq = field.seq - 1;
                                block = field.block;
                                for (i = 0; i < this.fields$.length; i++) {
                                    if (++seq >= this.fields$.length)
                                        seq = 0;
                                    if (this.fields$[seq].row == row && this.fields$[seq].block == block) {
                                        if (this.fields$[seq].enabled) {
                                            this.fields$[seq].focus();
                                            break;
                                        }
                                    }
                                }
                            }
                            if (type == "key" && key == exports.keymap.prevblock) {
                                if (event["preventDefault"] != null)
                                    event.preventDefault();
                                seq = field.seq - 1;
                                block = field.block;
                                row = 0;
                                next = "";
                                for (i = 0; i < this.fields$.length; i++) {
                                    if (--seq < 0)
                                        seq = this.fields$.length - 1;
                                    if (this.fields$[seq].block != block) {
                                        blk = this.fields$[seq].block;
                                        if (blk != next) {
                                            nb = this.blkindex.get(blk);
                                            nf = nb.field;
                                            if (nf.enabled) {
                                                nf.focus();
                                                break;
                                            }
                                            next = blk;
                                            row = nb.row;
                                        }
                                        if (this.fields$[seq].row == row && this.fields$[seq].enabled) {
                                            this.fields$[seq].focus();
                                            break;
                                        }
                                    }
                                }
                            }
                            if (type == "key" && key == exports.keymap.nextblock) {
                                if (event["preventDefault"] != null)
                                    event.preventDefault();
                                seq = field.seq - 1;
                                block = field.block;
                                row = 0;
                                next = "";
                                for (i = 0; i < this.fields$.length; i++) {
                                    if (++seq >= this.fields$.length)
                                        seq = 0;
                                    if (this.fields$[seq].block != block) {
                                        blk = this.fields$[seq].block;
                                        if (blk != next) {
                                            nb = this.blkindex.get(blk);
                                            nf = nb.field;
                                            if (nf.enabled) {
                                                nf.focus();
                                                break;
                                            }
                                            next = blk;
                                            row = nb.row;
                                        }
                                        if (this.fields$[seq].row == row && this.fields$[seq].enabled) {
                                            this.fields$[seq].focus();
                                            break;
                                        }
                                    }
                                }
                            }
                            if (!(type == "key" && key == exports.keymap.clearform)) return [3 /*break*/, 2];
                            event_1 = new KeyTriggerEvent(Origin.Form, null, null, exports.keymap.clearform, null);
                            return [4 /*yield*/, this.invokeTriggers(exports.Trigger.Key, event_1, exports.keymap.clearform)];
                        case 1:
                            if (!(_b.sent()))
                                return [2 /*return*/, (false)];
                            this.clear();
                            _b.label = 2;
                        case 2: return [2 /*return*/];
                    }
                });
            });
        };
        FormImpl.prototype.invokeTriggers = function (type, event, key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, this.triggers.invokeTriggers(type, event, key)];
                        case 1: return [2 /*return*/, (_b.sent())];
                    }
                });
            });
        };
        FormImpl.prototype.invokeFieldTriggers = function (type, field, event, key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, this.triggers.invokeFieldTriggers(type, field, event, key)];
                        case 1: return [2 /*return*/, (_b.sent())];
                    }
                });
            });
        };
        FormImpl.prototype.alert = function (msg, title, width, height) {
            MessageBox.show(this.app, msg, title, width, height);
        };
        return FormImpl;
    }());
    FormImpl.id = 0;

    var Form = /** @class */ (function () {
        // dont rename impl as it is read behind the scenes
        function Form() {
            this._impl_ = new FormImpl(this);
        }
        Object.defineProperty(Form.prototype, "name", {
            get: function () {
                return (this.constructor.name);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Form.prototype, "title", {
            get: function () {
                return (this._impl_.title);
            },
            set: function (title) {
                this._impl_.title = title;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Form.prototype, "menu", {
            get: function () {
                return (this._impl_.getMenu());
            },
            set: function (menu) {
                this._impl_.setMenu(menu);
            },
            enumerable: false,
            configurable: true
        });
        Form.prototype.focus = function () {
            this._impl_.focus();
        };
        Object.defineProperty(Form.prototype, "block", {
            get: function () {
                var _a;
                return ((_a = this._impl_.block) === null || _a === void 0 ? void 0 : _a.block);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Form.prototype, "connected", {
            get: function () {
                return (this._impl_.getApplication().connected);
            },
            enumerable: false,
            configurable: true
        });
        Form.prototype.groupfields = function (groups) {
            this._impl_.groupfields(groups);
        };
        Object.defineProperty(Form.prototype, "popup", {
            get: function () {
                return (this._impl_.popup);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Form.prototype, "colors", {
            get: function () {
                return (this._impl_.getApplication().config.colors);
            },
            enumerable: false,
            configurable: true
        });
        Form.prototype.getBlockFilter = function (block) {
            var blk = this.getBlock(block);
            if (blk != null && blk.searchfilter.length > 0)
                return (this.colors.rowindicator);
            return ("");
        };
        Form.prototype.getRowIndicator = function (block, row) {
            if (row == this.getCurrentRow(block))
                return (this.colors.rowindicator);
            return ("");
        };
        Form.prototype.getCurrentRow = function (block) {
            return (this._impl_.getCurrentRow(block));
        };
        Form.prototype.getCurrentRecord = function (block) {
            return (this._impl_.getCurrentRecord(block));
        };
        Form.prototype.getBlock = function (block) {
            var impl = this._impl_.getBlock(block);
            if (impl != null)
                return (impl.block);
            return (null);
        };
        Form.prototype.addListOfValues = function (block, func, field, id) {
            var impl = this._impl_.getBlock(block);
            if (impl != null)
                impl.addListOfValues(true, func, field, id);
        };
        Form.prototype.newform = function (form, parameters) {
            this._impl_.showform(form, true, parameters);
        };
        Form.prototype.showform = function (form, parameters) {
            this._impl_.showform(form, false, parameters);
        };
        Form.prototype.callform = function (form, parameters) {
            return __awaiter(this, void 0, void 0, function () {
                var impl;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, this._impl_.callform(form, false, parameters)];
                        case 1:
                            impl = _b.sent();
                            if (impl != null)
                                return [2 /*return*/, (impl.form)];
                            return [2 /*return*/, (null)];
                    }
                });
            });
        };
        Form.prototype.getCallStack = function () {
            return (this._impl_.getCallStack());
        };
        Form.prototype.clearCallStack = function () {
            this._impl_.clearStack();
        };
        Form.prototype.getTable = function (block) {
            var _a;
            return ((_a = this.getBlock(block)) === null || _a === void 0 ? void 0 : _a.table);
        };
        Object.defineProperty(Form.prototype, "parameters", {
            get: function () {
                return (this._impl_.getParameters());
            },
            enumerable: false,
            configurable: true
        });
        Form.prototype.getValue = function (block, record, field) {
            var blk = this.getBlock(block);
            if (blk != null)
                return (blk.getValue(record, field));
            return (null);
        };
        Form.prototype.setValue = function (block, record, field, value) {
            return __awaiter(this, void 0, void 0, function () {
                var blk;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            blk = this.getBlock(block);
                            if (!(blk != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, blk.setValue(record, field, value)];
                        case 1: return [2 /*return*/, (_b.sent())];
                        case 2: return [2 /*return*/, (false)];
                    }
                });
            });
        };
        Form.prototype.cancelled = function () {
            return (this._impl_.wasCancelled());
        };
        Form.prototype.clear = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, this._impl_.clear()];
                        case 1: return [2 /*return*/, (_b.sent())];
                    }
                });
            });
        };
        Form.prototype.cancel = function () {
            this._impl_.cancel();
        };
        Form.prototype.close = function (dismiss) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, this._impl_.close(dismiss)];
                        case 1:
                            _b.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        Form.prototype.sendKey = function (key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, this._impl_.sendkey(null, key)];
                        case 1: return [2 /*return*/, (_b.sent())];
                    }
                });
            });
        };
        Form.prototype.setCallback = function (func) {
            this._impl_.setCallback(func);
        };
        Form.prototype.addTrigger = function (func, types) {
            this._impl_.addTrigger(this, func, types);
        };
        Form.prototype.addKeyTrigger = function (func, keys) {
            this._impl_.addKeyTrigger(this, func, keys);
        };
        Form.prototype.enterquery = function (force) {
            this._impl_.enterquery(force);
        };
        Form.prototype.executequery = function (force) {
            this._impl_.executequery(force);
        };
        Form.prototype.prevBlock = function () {
            this._impl_.block.sendkey(null, exports.keymap.prevblock);
        };
        Form.prototype.nextBlock = function () {
            this._impl_.block.sendkey(null, exports.keymap.nextblock);
        };
        Form.prototype.execute = function (stmt, firstrow, firstcolumn) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    return [2 /*return*/, (this._impl_.execute(stmt, firstrow, firstcolumn))];
                });
            });
        };
        Form.prototype.addFieldTrigger = function (listener, types, fields) {
            this._impl_.addFieldTrigger(this, listener, types, fields);
        };
        Form.prototype.ngOnInit = function () {
            this._impl_.getApplication().setContainer();
        };
        Form.prototype.ngAfterViewInit = function () {
            var container = this._impl_.getApplication().getContainer();
            this._impl_.getApplication().dropContainer();
            this._impl_.newForm(container);
        };
        Form.prototype.alert = function (message, title, width, height) {
            if (title == null)
                title = this.name;
            this._impl_.alert(message, title, width, height);
        };
        return Form;
    }());
    Form.decorators = [
        { type: i0.Component, args: [{ template: '' },] }
    ];
    Form.ctorParameters = function () { return []; };

    (function (Case) {
        Case[Case["upper"] = 0] = "upper";
        Case[Case["lower"] = 1] = "lower";
        Case[Case["mixed"] = 2] = "mixed";
    })(exports.Case || (exports.Case = {}));

    var FieldInstance = /** @class */ (function () {
        function FieldInstance(ctx) {
            this.fgroup$ = null;
            this.valid$ = true;
            this.lvalid = true;
            this.enforce = false;
            this.enabled$ = false;
            this.readonly$ = false;
            this.mandatory$ = false;
            this.firstchange = true;
            this.values = null;
            this.container = null;
            this.state$ = RecordState.na;
            this.options$ = { query: true, insert: true, update: true, navigable: true };
            this.id$ = "";
            this.row$ = -1;
            this.name$ = "";
            this.block$ = "";
            this.group$ = "";
            this.class$ = "";
            this.style$ = "";
            this.size$ = null;
            this.value$ = null;
            this.app = ctx.app["_impl_"];
        }
        Object.defineProperty(FieldInstance.prototype, "id", {
            get: function () {
                return (this.id$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "row", {
            get: function () {
                return (this.row$);
            },
            set: function (row) {
                this.row$ = row;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "seq", {
            get: function () {
                if (this.clazz == null)
                    return (0);
                else
                    return (this.clazz.tabindex);
            },
            set: function (seq) {
                if (this.clazz != null)
                    this.clazz.tabindex = seq;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "name", {
            get: function () {
                return (this.name$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "fname", {
            get: function () {
                var name = this.block$ + "." + this.name;
                if (this.id.length > 0)
                    name += "." + this.id;
                name += "[" + this.row + "](" + this.guid + ")";
                return (name);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "guid", {
            get: function () {
                return (this.guid$);
            },
            set: function (guid) {
                this.guid$ = guid;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "block", {
            get: function () {
                return (this.block$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "group", {
            get: function () {
                return (this.group$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "value", {
            get: function () {
                if (this.clazz == null)
                    return (null);
                var value = this.clazz.value;
                if (("" + value).trim().length == 0)
                    value = null;
                return (value);
            },
            set: function (value) {
                if (value == null)
                    value = "";
                if (this.clazz != null)
                    this.clazz.value = value;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "parent", {
            get: function () {
                return (this.fgroup$);
            },
            set: function (field) {
                this.fgroup$ = field;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "fieldoptions", {
            get: function () {
                return (this.options$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "enabled", {
            get: function () {
                return (this.enabled$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "state", {
            get: function () {
                return (this.state$);
            },
            set: function (state) {
                this.state$ = state;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "readonly", {
            get: function () {
                return (this.readonly$);
            },
            set: function (flag) {
                this.readonly$ = flag;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "mandatory", {
            get: function () {
                return (this.mandatory$);
            },
            set: function (flag) {
                this.mandatory$ = flag;
                if (flag)
                    this.addClass("mandatory");
                else
                    this.removeClass("mandatory");
            },
            enumerable: false,
            configurable: true
        });
        FieldInstance.prototype.setPossibleValues = function (values, enforce) {
            this.enforce = enforce;
            var type = this.clazz.constructor.name;
            if (type == "DropDown")
                this.setDropDownValues(values);
            if (type == "TextField")
                this.setTextFieldValues(values);
        };
        FieldInstance.prototype.setTextFieldValues = function (values) {
            var _this = this;
            var name = this.block + "." + this.name;
            if (this.id.length > 0)
                name += "." + this.id;
            var list = document.getElementById(name);
            if (list == null) {
                var kvpair_1 = true;
                if (values instanceof Map)
                    this.values = new Map(values);
                else {
                    kvpair_1 = false;
                    this.values = new Map();
                    values.forEach(function (val) { return _this.values.set(val, val); });
                }
                list = document.createElement("datalist");
                list.setAttribute("id", name);
                this.values.forEach(function (val, key) {
                    var option = document.createElement("option");
                    option.text = val;
                    if (kvpair_1)
                        option.value = key;
                    list.append(option);
                });
                this.clazz.element.appendChild(list);
            }
            this.clazz.element.setAttribute("list", name);
        };
        FieldInstance.prototype.setDropDownValues = function (xvalues) {
            var _this = this;
            if (xvalues instanceof Map)
                this.values = new Map(xvalues);
            else {
                this.values = new Map();
                xvalues.forEach(function (val) { return _this.values.set(val, val); });
            }
            this.values.forEach(function (val, key) {
                var option = document.createElement("option");
                option.text = val;
                option.value = key;
                _this.clazz.element.appendChild(option);
            });
        };
        FieldInstance.prototype.focus = function () {
            var _this = this;
            if (!this.enabled)
                return (false);
            setTimeout(function () { _this.clazz.focus(); }, 0);
            return (true);
        };
        FieldInstance.prototype.blur = function () {
            var _this = this;
            setTimeout(function () { _this.clazz.element.blur(); }, 0);
        };
        FieldInstance.prototype.addClass = function (clazz) {
            if (this.clazz != null)
                this.clazz.element.classList.add(clazz);
        };
        FieldInstance.prototype.removeClass = function (clazz) {
            if (this.clazz != null)
                this.clazz.element.classList.remove(clazz);
        };
        Object.defineProperty(FieldInstance.prototype, "current", {
            get: function () {
                return (this.guid.startsWith("c"));
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "valid", {
            get: function () {
                return (this.valid$);
            },
            set: function (flag) {
                if (flag == this.valid$)
                    return;
                if (flag) {
                    this.valid$ = flag;
                    this.removeClass("invalid");
                }
                else {
                    if (this.enabled && !this.readonly) {
                        this.valid$ = flag;
                        this.addClass("invalid");
                    }
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(FieldInstance.prototype, "dirty", {
            get: function () {
                return (!this.firstchange);
            },
            enumerable: false,
            configurable: true
        });
        FieldInstance.prototype.validate = function () {
            if (this.state == RecordState.qmode || this.state == RecordState.na)
                return (true);
            if (!this.clazz.validate())
                return (false);
            if (this.mandatory && (this.value == null || ("" + this.value).length == 0))
                return (false);
            if (this.enforce && this.values != null && this.value != null)
                if (!this.values.has(this.value))
                    return (false);
            return (true);
        };
        FieldInstance.prototype.enable = function () {
            this.setInputState();
        };
        FieldInstance.prototype.disable = function () {
            this.valid = true;
            this.enabled$ = false;
            this.readonly$ = true;
            this.state = RecordState.na;
            if (this.clazz != null) {
                this.clazz.enable = false;
                this.clazz.readonly = true;
            }
        };
        FieldInstance.prototype.setInputState = function () {
            this.enabled$ = false;
            if (!this.options$.navigable) {
                if (this.clazz != null)
                    this.clazz.enable = false;
                return;
            }
            if (this.state$ == RecordState.na)
                this.enabled$ = true;
            else if (this.state$ == RecordState.insert && this.options$.insert)
                this.enabled$ = true;
            else if (this.state$ == RecordState.update && this.options$.update)
                this.enabled$ = true;
            else if (this.state$ == RecordState.qmode && this.options$.query)
                this.enabled$ = true;
            if (this.clazz != null) {
                if (!this.enabled$ && this.state$ == RecordState.update) {
                    this.enabled$ = true;
                    this.readonly$ = true;
                }
                this.clazz.enable = this.enabled$;
                this.clazz.readonly = this.readonly$;
            }
        };
        Object.defineProperty(FieldInstance.prototype, "definition", {
            get: function () {
                return (this.def);
            },
            set: function (def) {
                var override = false;
                if (this.def != null) {
                    override = true;
                    if (def.hasOwnProperty("case"))
                        this.def.case = def.case;
                    if (def.hasOwnProperty("mandatory"))
                        this.def.mandatory = def.mandatory;
                    if (def.hasOwnProperty("type"))
                        this.def.type = def.type;
                    if (def.hasOwnProperty("fieldoptions")) {
                        if (def.hasOwnProperty("query"))
                            this.def.fieldoptions.query = def.fieldoptions.query;
                        if (def.hasOwnProperty("insert"))
                            this.def.fieldoptions.insert = def.fieldoptions.insert;
                        if (def.hasOwnProperty("update"))
                            this.def.fieldoptions.update = def.fieldoptions.update;
                        if (def.hasOwnProperty("navigable"))
                            this.def.fieldoptions.navigable = def.fieldoptions.navigable;
                    }
                }
                this.def = def;
                this.setType(def.type);
                if (!this.def.hasOwnProperty("case"))
                    this.def.case = exports.Case.mixed;
                if (this.def.hasOwnProperty("mandatory"))
                    this.mandatory = this.def.mandatory;
                if (this.def.fieldoptions != null) {
                    this.options$ = this.def.fieldoptions;
                    if (!this.options$.hasOwnProperty("query"))
                        this.options$.query = true;
                    if (!this.options$.hasOwnProperty("insert"))
                        this.options$.insert = true;
                    if (!this.options$.hasOwnProperty("update"))
                        this.options$.update = true;
                    if (!this.options$.hasOwnProperty("navigable"))
                        this.options$.navigable = true;
                }
                if (override)
                    this.setInputState();
            },
            enumerable: false,
            configurable: true
        });
        FieldInstance.prototype.setType = function (type) {
            var seq = this.seq;
            this.container.innerHTML = null;
            var cname = FieldImplementation.getClass(exports.FieldType[type]);
            if (cname != null) {
                this.clazz = new cname();
                this.container.innerHTML = this.clazz.html;
                this.clazz.element = this.container.children[0];
                if (this.size$ != null)
                    this.clazz.size = this.size$;
                if (this.value$ != null)
                    this.clazz.value = this.value$;
                if (this.class$ != "")
                    this.clazz.element.classList.add(this.class$);
                if (this.style$ != "")
                    this.clazz.element.style.cssText = this.style$;
                this.seq = seq;
                this.disable();
                this.addTriggers();
                // Ugly, but need to set name
                this.clazz.element.name = this.name;
            }
        };
        FieldInstance.prototype.onEvent = function (event) {
            return __awaiter(this, void 0, void 0, function () {
                var keypress, keydef, map, key, value_1;
                var _this = this;
                return __generator(this, function (_b) {
                    keypress = false;
                    if (this.fgroup$ == null)
                        return [2 /*return*/];
                    if (event.type == "focus") {
                        this.firstchange = true;
                        this.lvalue = this.value;
                        this.lvalid = this.valid$;
                        this.fgroup$["onEvent"](event, this, "focus");
                    }
                    if (event.type == "blur") {
                        if (this.dirty && this.value == this.lvalue && !this.lvalid)
                            this.valid = false;
                        this.fgroup$["onEvent"](event, this, "blur");
                    }
                    if (event.type == "click" || event.type == "dblclick")
                        this.fgroup$["onEvent"](event, this, event.type);
                    if (event.type == "change") {
                        if (this.enabled && !this.readonly)
                            if (!this.valid)
                                this.fgroup$.valid = false;
                        this.valid = this.validate();
                        if (this.clazz instanceof CheckBox)
                            this.value = this.value$;
                        if (this.clazz instanceof RadioButton)
                            this.value = this.value$;
                        this.fgroup$["onEvent"](event, this, "change");
                    }
                    if (event.type == "keydown" && event.keyCode == 8)
                        keypress = true;
                    if (event.type == "keydown" && !keypress) {
                        if (+event.keyCode >= 16 && +event.keyCode <= 20)
                            return [2 /*return*/];
                        keydef = {
                            code: event.keyCode,
                            alt: event.altKey,
                            ctrl: event.ctrlKey,
                            meta: event.metaKey,
                            shift: event.shiftKey
                        };
                        map = KeyMapper.map(keydef);
                        key = KeyMapper.keymap(map);
                        if (key == exports.keymap.undo || key == exports.keymap.paste) {
                            setTimeout(function () { _this.blur(); }, 1);
                            setTimeout(function () { _this.focus(); }, 1);
                            return [2 /*return*/];
                        }
                        if (key != null) {
                            // handled by application
                            if (key == exports.keymap.close ||
                                key == exports.keymap.listval ||
                                key == exports.keymap.connect ||
                                key == exports.keymap.disconnect ||
                                key == exports.keymap.commit ||
                                key == exports.keymap.rollback ||
                                key == exports.keymap.delete ||
                                key == exports.keymap.clearform ||
                                key == exports.keymap.insertafter ||
                                key == exports.keymap.insertbefore ||
                                key == exports.keymap.enterquery ||
                                key == exports.keymap.executequery) {
                                this.fgroup$.copy(this);
                                return [2 /*return*/];
                            }
                            this.fgroup$["onEvent"](event, this, "key", key);
                        }
                    }
                    if (event.type == "keypress" || keypress) {
                        if (this.readonly)
                            return [2 /*return*/];
                        if (this.firstchange && (event.key.length == 1 || event.keyCode == KeyCodes.backspace)) {
                            this.firstchange = false;
                            if (!this.valid)
                                this.fgroup$.valid = true;
                            this.fgroup$["onEvent"](event, this, "fchange");
                        }
                        value_1 = this.value;
                        setTimeout(function () { _this.continious(event, value_1); }, 0);
                    }
                    return [2 /*return*/];
                });
            });
        };
        FieldInstance.prototype.continious = function (event, value) {
            if (this.value == value)
                return;
            if (this.def.type == exports.FieldType.integer) {
                if (!this.valnumber(value))
                    return;
            }
            if (this.def.type == exports.FieldType.decimal) {
                if (!this.valdecimal(value))
                    return;
            }
            if (this.value != null && this.def.case == exports.Case.lower)
                this.value = ("" + this.value).toLowerCase();
            if (this.value != null && this.def.case == exports.Case.upper)
                this.value = ("" + this.value).toUpperCase();
            this.fgroup$.onEvent(event, this, "cchange");
        };
        FieldInstance.prototype.valnumber = function (value) {
            if (this.state == RecordState.qmode)
                return (true);
            var nvalue = this.value;
            if (nvalue == null || nvalue.trim().length == 0)
                return (true);
            var numeric = !isNaN(+nvalue);
            if (!numeric || nvalue.indexOf(".") >= 0) {
                this.value = value;
                return (false);
            }
            return (true);
        };
        FieldInstance.prototype.valdecimal = function (value) {
            if (this.state == RecordState.qmode)
                return (true);
            var nvalue = this.value;
            if (nvalue == null || nvalue.trim().length == 0)
                return (true);
            var numeric = !isNaN(+nvalue);
            if (!numeric) {
                this.value = value;
                return (false);
            }
            return (true);
        };
        FieldInstance.prototype.ngAfterViewInit = function () {
            var _a;
            this.container = (_a = this.containerelem) === null || _a === void 0 ? void 0 : _a.nativeElement;
            this.id$ = this.id$.toLowerCase();
            this.name$ = this.name$.toLowerCase();
            this.block$ = this.block$.toLowerCase();
            this.app.getContainer().register(this);
        };
        FieldInstance.prototype.addTriggers = function () {
            var _this = this;
            var impl = this.container.firstChild;
            if (impl == null)
                return;
            impl.addEventListener("blur", function (event) { _this.onEvent(event); });
            impl.addEventListener("focus", function (event) { _this.onEvent(event); });
            impl.addEventListener("change", function (event) { _this.onEvent(event); });
            impl.addEventListener("click", function (event) { _this.onEvent(event); });
            impl.addEventListener("keydown", function (event) { _this.onEvent(event); });
            impl.addEventListener("keypress", function (event) { _this.onEvent(event); });
            impl.addEventListener("dblclick", function (event) { _this.onEvent(event); });
        };
        return FieldInstance;
    }());
    FieldInstance.decorators = [
        { type: i0.Component, args: [{
                    selector: 'field',
                    template: '<span #container></span>'
                },] }
    ];
    FieldInstance.ctorParameters = function () { return [
        { type: Context }
    ]; };
    FieldInstance.propDecorators = {
        id$: [{ type: i0.Input, args: ["id",] }],
        row$: [{ type: i0.Input, args: ["row",] }],
        name$: [{ type: i0.Input, args: ["name",] }],
        block$: [{ type: i0.Input, args: ["block",] }],
        group$: [{ type: i0.Input, args: ["group",] }],
        class$: [{ type: i0.Input, args: ["class",] }],
        style$: [{ type: i0.Input, args: ["style",] }],
        size$: [{ type: i0.Input, args: ["size",] }],
        value$: [{ type: i0.Input, args: ["value",] }],
        containerelem: [{ type: i0.ViewChild, args: ["container", { read: i0.ElementRef },] }]
    };

    var DateUtils = /** @class */ (function () {
        function DateUtils() {
        }
        DateUtils.prototype.parse = function (datestr, format) {
            return (dates.parse(datestr, format));
        };
        DateUtils.prototype.format = function (date, format) {
            return (dates.format(date, format));
        };
        return DateUtils;
    }());

    var FormList = /** @class */ (function () {
        function FormList(ctx) {
            this.page = "";
            this.ready = false;
            this.name = "/";
            this.conf = ctx.conf;
            this.app = ctx.app["_impl_"];
            this.root = new Folder(this.name);
            this.conf.notify(this, "setColors");
            this.app.setFormList(this);
            this.formsdef = this.app.getFormsList();
            this.parse();
            this.page += "<style>\n";
            this.page += this.styles() + "\n";
            this.page += "</style>\n";
            this.page += "<div class='formlist'>\n";
            this.page += this.print("/", this.root, 0, [true]);
            this.page += "</div>\n";
        }
        FormList.prototype.open = function (folder) {
            var _this = this;
            if (!this.ready) {
                setTimeout(function () { _this.open(folder); }, 10);
                return;
            }
            folder = folder.trim();
            var parts = folder.split("/");
            var current = this.root;
            for (var i = 0; i < parts.length; i++) {
                current = current.findFolder([parts[i]]);
                if (current == null)
                    return;
                if (!current.content.classList.contains("formlist-active")) {
                    current.img.src = "/assets/images/open.jpg";
                    current.content.classList.toggle("formlist-active");
                }
            }
        };
        FormList.prototype.print = function (path, root, level, last) {
            var html = "";
            html += this.folder(path, root, level, last);
            html += "<div class='formlist-folder-content' id='" + path + "-content'>";
            level++;
            last.push(false);
            if (path == "/")
                path = "";
            var subs = root.folders.length;
            var forms = root.forms.length;
            for (var i = 0; i < subs; i++) {
                var folder = root.folders[i];
                if (i == subs - 1 && forms == 0)
                    last[level] = true;
                html += this.print(path + "/" + folder.name, folder, level, last);
            }
            last[level] = false;
            html += this.forms(root, level, last);
            last.pop();
            html += "</div>";
            return (html);
        };
        FormList.prototype.parse = function () {
            for (var i = 0; i < this.formsdef.length; i++) {
                var path = this.formsdef[i].path;
                if (!this.formsdef[i].navigable)
                    continue;
                var form = path;
                var folder = "/";
                var pos = path.lastIndexOf("/");
                if (pos >= 0) {
                    form = path.substring(pos + 1);
                    folder = path.substring(0, pos);
                }
                var current = this.root;
                var parts = folder.split("/");
                for (var p = 1; p < parts.length; p++) {
                    if (parts[p] == "")
                        parts[p] = "/";
                    current = current.getFolder(parts[p].trim());
                }
                current.addForm(form, this.formsdef[i]);
            }
        };
        FormList.prototype.ngAfterViewInit = function () {
            var _this = this;
            var _a;
            this.html = (_a = this.elem) === null || _a === void 0 ? void 0 : _a.nativeElement;
            this.html.innerHTML = this.page;
            var folders = this.html.getElementsByClassName("formlist-folder");
            for (var i = 0; i < folders.length; i++) {
                var container = folders.item(i);
                var content = document.getElementById(container.id + "-content");
                var lnk = container.querySelector("[id='" + container.id + "-lnk']");
                var img = container.querySelector("[id='" + container.id + "-img']");
                var folder = this.root.findFolder(container.id.split("/"));
                folder.img = img;
                folder.lnk = lnk;
                folder.content = content;
                folder.img.addEventListener("click", function (event) { return _this.toggle(event); });
                folder.lnk.addEventListener("click", function (event) { return _this.toggle(event); });
            }
            var forms = this.html.getElementsByClassName("formlist-form");
            for (var i = 0; i < forms.length; i++) {
                var form = forms.item(i);
                var lnk = form.querySelector("[id='" + form.id + "-lnk']");
                lnk.addEventListener("click", function (event) { return _this.show(event); });
            }
            this.setColors();
            this.open("/");
            this.root.lnk.innerHTML = this.name;
            this.ready = true;
        };
        FormList.prototype.setColors = function () {
            var link = this.conf.colors.link;
            var tree = this.conf.colors.foldertree;
            var list = null;
            list = this.html.getElementsByClassName("formlist-txt");
            for (var i = 0; i < list.length; i++)
                list[i].style.color = tree;
            list = this.html.getElementsByClassName("formlist-link");
            for (var i = 0; i < list.length; i++)
                list[i].style.color = link;
            list = this.html.getElementsByClassName("formlist-off");
            for (var i = 0; i < list.length; i++)
                list[i].style.borderLeft = "1px solid " + tree;
            list = this.html.getElementsByClassName("formlist-vln");
            for (var i = 0; i < list.length; i++)
                list[i].style.borderLeft = "1px solid " + tree;
            list = this.html.getElementsByClassName("formlist-cnr");
            for (var i = 0; i < list.length; i++) {
                list[i].style.borderLeft = "1px solid " + tree;
                list[i].style.borderBottom = "1px solid " + tree;
            }
        };
        FormList.prototype.toggle = function (event) {
            var fname = event.target.id;
            fname = fname.substring(0, fname.length - 4);
            var folder = this.root.findFolder(fname.split("/"));
            folder.content.classList.toggle("formlist-active");
            if (folder.content.classList.contains("formlist-active")) {
                folder.img.src = "/assets/images/open.jpg";
            }
            else {
                folder.img.src = "/assets/images/closed.jpg";
            }
        };
        FormList.prototype.show = function (event) {
            var fname = event.target.id;
            fname = fname.substring(0, fname.length - 4);
            this.app.showform(fname, false);
        };
        FormList.prototype.folder = function (path, root, level, last) {
            var html = "";
            html += "<div id='" + path + "' class='formlist-folder'>\n";
            if (level > 0) {
                html += this.half();
                for (var i = 1; i < level; i++)
                    html += this.indent(last[i]);
            }
            if (level > 0)
                html += this.pre(last[level]);
            html += "<img class='formlist-img' id='" + path + "-img' src='/assets/images/closed.jpg'>\n";
            html += "<span class='formlist-txt' id='" + path + "-lnk'>" + root.name + "</span>\n";
            html += "</div>\n";
            return (html);
        };
        FormList.prototype.forms = function (root, level, last) {
            var html = "";
            for (var i = 0; i < root.forms.length; i++) {
                if (i == root.forms.length - 1)
                    last[level] = true;
                html += this.form(root.forms[i], level, last);
            }
            return (html);
        };
        FormList.prototype.form = function (form, level, last) {
            var html = "";
            html += "<div id='" + form.def.name + "' class='formlist-form'>\n";
            html += this.half();
            for (var i = 1; i < level; i++)
                html += this.indent(last[i]);
            if (level > 0)
                html += this.pre(last[last.length - 1]);
            html += "<span class='formlist-link' id='" + form.def.name + "-lnk'> " + form.name + "</span>\n";
            html += "</div>\n";
            return (html);
        };
        FormList.prototype.pre = function (last) {
            var html = "";
            html += "<span class='formlist-lct'>\n";
            html += " <span class='formlist-off'></span>\n";
            html += " <span class='formlist-cnr'></span>\n";
            if (last)
                html += "<span class='formlist-end'></span>\n";
            else
                html += "<span class='formlist-vln'></span>\n";
            html += "</span>\n";
            return (html);
        };
        FormList.prototype.indent = function (skip) {
            var html = "";
            if (skip) {
                html += "<span class='formlist-lct'>\n";
                html += "</span>\n";
                html += " <span class='formlist-ind'></span>\n";
            }
            else {
                html += "<span class='formlist-lct'>\n";
                html += " <span class='formlist-vln'></span>\n";
                html += " <span class='formlist-vln'></span>\n";
                html += " <span class='formlist-vln'></span>\n";
                html += "</span>\n";
                html += " <span class='formlist-ind'></span>\n";
            }
            return (html);
        };
        FormList.prototype.half = function () {
            var html = "";
            html += " <span class='formlist-ind'></span>\n";
            return (html);
        };
        FormList.prototype.styles = function () {
            var styles = "\n\t\t.formlist\n\t\t{\n\t\t\twidth: 1px;\n\t\t\tposition: relative;\n\t\t}\n\n    \t.formlist-folder\n    \t{\n\t\t\tmargin: 0;\n\t\t\tpadding: 0;\n\t\t\twidth: 100%;\n\t\t\theight: 100%;\n\t\t\tfont-size: 0;\n\t\t\tposition: relative;\n\t\t\tborder-collapse: collapse;\n    \t}\n\n\t\t.formlist-folder-content\n\t\t{\n\t\t\tdisplay: none;\n\t\t}\n\n\t\t.formlist-lct\n\t\t{\n\t\t\twidth: 16px;\n\t\t\theight: 24px;\n\t\t\tpointer-events:none;\n\t\t\twhite-space: nowrap;\n\t\t\tdisplay: inline-block;\n\t\t\tvertical-align: middle;\n\t\t}\n\n\t\t.formlist-txt\n\t\t{\n\t\t\twidth: 16px;\n\t\t\theight: 21px;\n\t\t\tfont-size: 15px;\n\t\t\tcursor: pointer;\n\t\t\twhite-space: nowrap;\n\t\t\tdisplay: inline-block;\n\t\t\tvertical-align: bottom;\n\t\t}\n\n\t\t.formlist-off\n\t\t{\n\t\t\twidth: 16px;\n\t\t\theight: 4px;\n\t\t\tdisplay: block;\n\t\t\tpointer-events:none;\n\t\t}\n\n\t\t.formlist-vln\n\t\t{\n\t\t\twidth: 16px;\n\t\t\theight: 12px;\n\t\t\tdisplay: block;\n\t\t\tpointer-events:none;\n\t\t}\n\n\t\t.formlist-cnr\n\t\t{\n\t\t\twidth: 16px;\n\t\t\theight: 8px;\n\t\t\tdisplay: block;\n\t\t\tpointer-events:none;\n\t\t}\n\n\t\t.formlist-end\n\t\t{\n\t\t\twidth: 16px;\n\t\t\theight: 12px;\n\t\t\tdisplay: block;\n\t\t\tpointer-events:none;\n\t\t}\n\n\t\t.formlist-ind\n\t\t{\n\t\t\twidth: 12px;\n\t\t\theight: 24px;\n\t\t\twhite-space: nowrap;\n\t\t\tpointer-events:none;\n\t\t\tdisplay: inline-block;\n\t\t\tvertical-align: middle;\n\t\t}\n\n\t\t.formlist-img\n\t\t{\n\t\t\twidth: 24px;\n\t\t\theight: 24px;\n\t\t\tcursor: pointer;\n\t\t\tvertical-align: middle;\n\t\t}\n\n\t\t.formlist-link\n\t\t{\n\t\t\twidth: 16px;\n\t\t\theight: 22px;\n\t\t\tcursor: pointer;\n\t\t\tfont-size: 15px;\n\t\t\tmargin-left: 8px;\n\t\t\tfont-style: italic;\n\t\t\twhite-space: nowrap;\n\t\t\tdisplay: inline-block;\n\t\t\tvertical-align: bottom;\n\t\t}\n\n\t\t.formlist-form\n\t\t{\n\t\t\tmargin: 0;\n\t\t\tpadding: 0;\n\t\t\tfont-size: 0;\n\t\t\tdisplay: block;\n\t\t\tborder-collapse: collapse;\n\t\t}\n\n\t\t.formlist-active\n\t\t{\n\t\t\tdisplay: block;\n\t\t}\n\t\t";
            return (styles);
        };
        return FormList;
    }());
    FormList.decorators = [
        { type: i0.Component, args: [{
                    selector: 'formlist',
                    template: "\n\t\t<div #html style=\"display: inline-block; white-space: nowrap;\"></div>\n\t"
                },] }
    ];
    FormList.ctorParameters = function () { return [
        { type: Context }
    ]; };
    FormList.propDecorators = {
        name: [{ type: i0.Input, args: ['root',] }],
        elem: [{ type: i0.ViewChild, args: ["html", { read: i0.ElementRef },] }]
    };
    var Folder = /** @class */ (function () {
        function Folder(name) {
            this.forms = [];
            this.folders = [];
            this.name = name;
        }
        Folder.prototype.getFolder = function (next) {
            if (next == this.name)
                return (this);
            for (var i = 0; i < this.folders.length; i++)
                if (this.folders[i].name == next)
                    return (this.folders[i]);
            var folder = new Folder(next);
            this.folders.push(folder);
            return (folder);
        };
        Folder.prototype.findFolder = function (path) {
            while (path[0] == "")
                path.shift();
            if (path.length == 0)
                return (this);
            var next = null;
            for (var i = 0; i < this.folders.length; i++) {
                if (this.folders[i].name == path[0]) {
                    next = this.folders[i];
                    break;
                }
            }
            if (next == null)
                return (null);
            path.shift();
            return (next.findFolder(path));
        };
        Folder.prototype.addForm = function (name, form) {
            this.forms.push({ name: name, def: form });
        };
        Folder.prototype.print = function () {
            console.log("");
            console.log("Folder: " + this.name);
            for (var i = 0; i < this.forms.length; i++)
                console.log("Form: " + this.forms[i].name);
            for (var i = 0; i < this.folders.length; i++)
                this.folders[i].print();
        };
        return Folder;
    }());

    var FormArea = /** @class */ (function () {
        function FormArea(ctx) {
            this.app = null;
            this.app = ctx.app;
        }
        FormArea.prototype.getFormsArea = function () {
            return (this.formarea.nativeElement);
        };
        FormArea.prototype.ngAfterViewInit = function () {
            var impl = this.app["_impl_"];
            impl.setFormArea(this);
        };
        return FormArea;
    }());
    FormArea.decorators = [
        { type: i0.Component, args: [{
                    selector: 'formarea',
                    template: '<div #formarea></div>'
                },] }
    ];
    FormArea.ctorParameters = function () { return [
        { type: Context }
    ]; };
    FormArea.propDecorators = {
        formarea: [{ type: i0.ViewChild, args: ["formarea", { read: i0.ElementRef },] }]
    };

    var MacKeyMap = /** @class */ (function () {
        function MacKeyMap() {
            this.zoom = KeyMapper.map({ code: 90, ctrl: true });
            this.close = KeyMapper.map({ code: 87, ctrl: true });
            this.undo = KeyMapper.map({ code: 90, meta: true });
            this.paste = KeyMapper.map({ code: 86, meta: true });
            this.enter = KeyMapper.map({ code: KeyCodes.enter });
            this.escape = KeyMapper.map({ code: KeyCodes.escape });
            this.listval = KeyMapper.map({ code: 76, shift: true, ctrl: true });
            this.clearblock = KeyMapper.map({ code: KeyCodes.escape, ctrl: true });
            this.clearform = KeyMapper.map({ code: KeyCodes.escape, shift: true, ctrl: true });
            this.insertafter = KeyMapper.map({ code: 73, ctrl: true });
            this.insertbefore = KeyMapper.map({ code: 73, shift: true, ctrl: true });
            this.delete = KeyMapper.map({ code: 68, ctrl: true });
            this.dublicate = KeyMapper.map({ code: 86, ctrl: true });
            this.commit = KeyMapper.map({ code: KeyCodes.enter, ctrl: true });
            this.rollback = KeyMapper.map({ code: KeyCodes.f1, ctrl: true, shift: true });
            this.connect = KeyMapper.map({ code: 67, ctrl: true });
            this.disconnect = KeyMapper.map({ code: 67, shift: true, ctrl: true });
            this.nextfield = KeyMapper.map({ code: KeyCodes.tab });
            this.prevfield = KeyMapper.map({ code: KeyCodes.tab, shift: true });
            this.nextrecord = KeyMapper.map({ code: KeyCodes.down, shift: false });
            this.prevrecord = KeyMapper.map({ code: KeyCodes.up, shift: false });
            this.nextblock = KeyMapper.map({ code: KeyCodes.down, shift: true });
            this.prevblock = KeyMapper.map({ code: KeyCodes.up, shift: true });
            this.pageup = KeyMapper.map({ code: 80, ctrl: true, shift: true });
            this.pagedown = KeyMapper.map({ code: 80, ctrl: true, shift: false });
            this.enterquery = KeyMapper.map({ code: 81, ctrl: true });
            this.executequery = KeyMapper.map({ code: 81, shift: true, ctrl: true });
            this.map =
                "\n            <table>\n                <tr><td class=\"kmtd\">   connect            </td><td>   ctrl-c             </td></tr>\n                <tr><td class=\"kmtd\">   disconnect         </td><td>   ctrl-shift-c       </td></tr>\n                <tr><td class=\"kmtd\">   close              </td><td>   ctrl-w             </td></tr>\n                <tr><td class=\"kmtd\">   zoom               </td><td>   ctrl-z             </td></tr>\n                <tr><td class=\"kmtd\">   datepicker         </td><td>   ctrl-shift-l       </td></tr>\n                <tr><td class=\"kmtd\">   list of values     </td><td>   ctrl-shift-l       </td></tr>\n                <tr><td class=\"kmtd\">   clear block        </td><td>   ctrl-escape        </td></tr>\n                <tr><td class=\"kmtd\">   clear form         </td><td>   ctrl-shift-escape  </td></tr>\n                <tr><td class=\"kmtd\">   insert after       </td><td>   ctrl-i             </td></tr>\n                <tr><td class=\"kmtd\">   insert before      </td><td>   ctrl-shift-i       </td></tr>\n                <tr><td class=\"kmtd\">   delete             </td><td>   ctrl-d             </td></tr>\n                <tr><td class=\"kmtd\">   commit             </td><td>   ctrl-enter         </td></tr>\n                <tr><td class=\"kmtd\">   rollback           </td><td>   ctrl-shift-escape  </td></tr>\n                <tr><td class=\"kmtd\">   next record        </td><td>   key-down           </td></tr>\n                <tr><td class=\"kmtd\">   previous record    </td><td>   key-up             </td></tr>\n                <tr><td class=\"kmtd\">   page down          </td><td>   ctrl-p             </td></tr>\n                <tr><td class=\"kmtd\">   page up            </td><td>   ctrl-shift-p       </td></tr>\n                <tr><td class=\"kmtd\">   next block         </td><td>   shift-key-down     </td></tr>\n                <tr><td class=\"kmtd\">   previous block     </td><td>   shift-key-up       </td></tr>\n                <tr><td class=\"kmtd\">   enter query        </td><td>   ctrl-q             </td></tr>\n                <tr><td class=\"kmtd\">   execute query      </td><td>   ctrl-shift-q       </td ></tr>\n            </table>\n\n            <style>\n              .kmtd\n              {\n                  width: 150px;\n                  display: block;\n              }\n            </style>\n        ";
        }
        ;
        return MacKeyMap;
    }());

    var WinKeyMap = /** @class */ (function () {
        function WinKeyMap() {
            this.zoom = KeyMapper.map({ code: 90, ctrl: true });
            this.close = KeyMapper.map({ code: 87, ctrl: true });
            this.undo = KeyMapper.map({ code: 90, meta: true });
            this.paste = KeyMapper.map({ code: 86, meta: true });
            this.enter = KeyMapper.map({ code: KeyCodes.enter });
            this.escape = KeyMapper.map({ code: KeyCodes.escape });
            this.listval = KeyMapper.map({ code: 76, shift: true, ctrl: true });
            this.clearblock = KeyMapper.map({ code: KeyCodes.escape, ctrl: true });
            this.clearform = KeyMapper.map({ code: KeyCodes.escape, shift: true, ctrl: true });
            this.insertafter = KeyMapper.map({ code: 73, ctrl: true });
            this.insertbefore = KeyMapper.map({ code: 73, shift: true, ctrl: true });
            this.delete = KeyMapper.map({ code: 68, ctrl: true });
            this.dublicate = KeyMapper.map({ code: 86, ctrl: true });
            this.commit = KeyMapper.map({ code: KeyCodes.enter, ctrl: true });
            this.rollback = KeyMapper.map({ code: KeyCodes.f1, ctrl: true, shift: true });
            this.connect = KeyMapper.map({ code: 67, ctrl: true });
            this.disconnect = KeyMapper.map({ code: 67, shift: true, ctrl: true });
            this.nextfield = KeyMapper.map({ code: KeyCodes.tab });
            this.prevfield = KeyMapper.map({ code: KeyCodes.tab, shift: true });
            this.nextrecord = KeyMapper.map({ code: KeyCodes.down, shift: false });
            this.prevrecord = KeyMapper.map({ code: KeyCodes.up, shift: false });
            this.nextblock = KeyMapper.map({ code: KeyCodes.down, shift: true });
            this.prevblock = KeyMapper.map({ code: KeyCodes.up, shift: true });
            this.pageup = KeyMapper.map({ code: 80, ctrl: true, shift: true });
            this.pagedown = KeyMapper.map({ code: 80, ctrl: true, shift: false });
            this.enterquery = KeyMapper.map({ code: 81, ctrl: true });
            this.executequery = KeyMapper.map({ code: 81, shift: true, ctrl: true });
            this.map =
                "\n            <table>\n                <tr><td class=\"kmtd\">   connect            </td><td>   ctrl-c             </td></tr>\n                <tr><td class=\"kmtd\">   disconnect         </td><td>   ctrl-shift-c       </td></tr>\n                <tr><td class=\"kmtd\">   close              </td><td>   ctrl-w             </td></tr>\n                <tr><td class=\"kmtd\">   zoom               </td><td>   ctrl-z             </td></tr>\n                <tr><td class=\"kmtd\">   datepicker         </td><td>   ctrl-shift-l       </td></tr>\n                <tr><td class=\"kmtd\">   list of values     </td><td>   ctrl-shift-l       </td></tr>\n                <tr><td class=\"kmtd\">   clear block        </td><td>   ctrl-escape        </td></tr>\n                <tr><td class=\"kmtd\">   clear form         </td><td>   ctrl-shift-escape  </td></tr>\n                <tr><td class=\"kmtd\">   insert after       </td><td>   ctrl-i             </td></tr>\n                <tr><td class=\"kmtd\">   insert before      </td><td>   ctrl-shift-i       </td></tr>\n                <tr><td class=\"kmtd\">   delete             </td><td>   ctrl-d             </td></tr>\n                <tr><td class=\"kmtd\">   commit             </td><td>   ctrl-enter         </td></tr>\n                <tr><td class=\"kmtd\">   rollback           </td><td>   ctrl-shift-escape  </td></tr>\n                <tr><td class=\"kmtd\">   next record        </td><td>   key-down           </td></tr>\n                <tr><td class=\"kmtd\">   previous record    </td><td>   key-up             </td></tr>\n                <tr><td class=\"kmtd\">   page down          </td><td>   ctrl-p             </td></tr>\n                <tr><td class=\"kmtd\">   page up            </td><td>   ctrl-shift-p       </td></tr>\n                <tr><td class=\"kmtd\">   next block         </td><td>   shift-key-down     </td></tr>\n                <tr><td class=\"kmtd\">   previous block     </td><td>   shift-key-up       </td></tr>\n                <tr><td class=\"kmtd\">   enter query        </td><td>   ctrl-q             </td></tr>\n                <tr><td class=\"kmtd\">   execute query      </td><td>   ctrl-shift-q       </td ></tr>\n            </table>\n\n            <style>\n              .kmtd\n              {\n                  width: 150px;\n                  display: block;\n              }\n            </style>\n        ";
        }
        ;
        return WinKeyMap;
    }());

    var defaultTheme = /** @class */ (function () {
        function defaultTheme() {
            this.name = "default";
            this.link = "blue";
            this.text = "black";
            this.title = "white";
            this.topbar = "#303f9f";
            this.enabled = "white";
            this.disabled = "silver";
            this.menuoption = "white";
            this.buttontext = "white";
            this.foldertree = "#303f9f";
            this.rowindicator = "#303f9f";
        }
        return defaultTheme;
    }());
    var Indigo = /** @class */ (function (_super) {
        __extends(Indigo, _super);
        function Indigo() {
            var _this = _super.apply(this, __spread(arguments)) || this;
            _this.name = "indigo";
            return _this;
        }
        return Indigo;
    }(defaultTheme));
    var Grey = /** @class */ (function (_super) {
        __extends(Grey, _super);
        function Grey() {
            var _this = _super.apply(this, __spread(arguments)) || this;
            _this.name = "grey";
            _this.link = "grey";
            _this.topbar = "grey";
            _this.foldertree = "grey";
            _this.rowindicator = "grey";
            return _this;
        }
        return Grey;
    }(defaultTheme));
    var Pink = /** @class */ (function (_super) {
        __extends(Pink, _super);
        function Pink() {
            var _this = _super.apply(this, __spread(arguments)) || this;
            _this.name = "pink";
            _this.link = "#ff4081";
            _this.topbar = "#ff4081";
            _this.foldertree = "#ff4081";
            _this.rowindicator = "#ff4081";
            return _this;
        }
        return Pink;
    }(defaultTheme));
    var Yellow = /** @class */ (function () {
        function Yellow() {
            this.name = "yellow";
            this.link = "grey";
            this.text = "black";
            this.title = "black";
            this.topbar = "yellow";
            this.foldertree = "grey";
            this.enabled = "black";
            this.disabled = "silver";
            this.menuoption = "black";
            this.buttontext = "black";
            this.rowindicator = "yellow";
        }
        return Yellow;
    }());

    var Config = /** @class */ (function () {
        function Config(client) {
            this.client = client;
            this.config = null;
            this.notifications = [];
            this.invoker = null;
            this.caltitle = "Calendar";
            this.keymaphelp = "Shortkeys";
            this.themes = new Map();
            this.lang = Intl.DateTimeFormat().resolvedOptions().locale;
            this.load();
            this.themes.set("pink", new Pink());
            this.themes.set("grey", new Grey());
            this.themes.set("indigo", new Indigo());
            this.themes.set("yellow", new Yellow());
            this.themes.set("default", new defaultTheme());
            var os = this.os();
            if (os == "Windows")
                this.keymap = new WinKeyMap();
            else
                this.keymap = new MacKeyMap();
            KeyMapper.index(this.keymap);
            this.colors = this.themes.get("default");
        }
        Config.prototype.os = function () {
            var os = "unknown";
            if (navigator.appVersion.indexOf("Mac") != -1)
                os = "MacOS";
            if (navigator.appVersion.indexOf("X11") != -1)
                os = "UNIX";
            if (navigator.appVersion.indexOf("Linux") != -1)
                os = "Linux";
            if (navigator.appVersion.indexOf("Win") != -1)
                os = "Windows";
            return (os);
        };
        Config.prototype.load = function () {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    this.invoker = this.client.get("/assets/config/config.json").toPromise();
                    this.invoker.then(function (data) { _this.loaded(data); }, function (error) { _this.config = {}; console.log("Loading config failed: " + error); });
                    return [2 /*return*/];
                });
            });
        };
        Config.prototype.loaded = function (config) {
            this.config = config;
            this.datefmt$ = this.config["datefmt"];
            dates.setFormat(this.datefmt$);
            if (this.config["locale"] != null)
                this.lang = this.config["locale"];
            if (this.config["calendar"] != null)
                this.caltitle = this.config["calendar"];
            if (this.config["keymap"] != null)
                this.keymaphelp = this.config["keymap"];
        };
        Config.prototype.ready = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!(this.invoker != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.invoker];
                        case 1:
                            _a.sent();
                            this.invoker = null;
                            _a.label = 2;
                        case 2: return [2 /*return*/, (true)];
                    }
                });
            });
        };
        Object.defineProperty(Config.prototype, "locale", {
            get: function () {
                return (this.lang);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Config.prototype, "datefmt", {
            get: function () {
                return (this.datefmt$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Config.prototype, "colors", {
            get: function () {
                return (this.colors$);
            },
            set: function (theme) {
                this.colors$ = theme;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Config.prototype, "others", {
            get: function () {
                return (this.config);
            },
            enumerable: false,
            configurable: true
        });
        Config.prototype.notify = function (instance, func) {
            this.notifications.push({ instance: instance, func: func });
        };
        Config.prototype.setTheme = function (theme) {
            var ttheme = null;
            if (typeof theme == 'object')
                ttheme = theme;
            else
                ttheme = this.themes.get(theme);
            if (ttheme != null) {
                this.colors = ttheme;
                this.notifications.forEach(function (notify) { notify.instance[notify.func](); });
            }
        };
        Object.defineProperty(Config.prototype, "keymapping", {
            get: function () {
                return (this.keymap);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Config.prototype, "keymaptitle", {
            get: function () {
                return (this.keymaphelp);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Config.prototype, "calendarname", {
            get: function () {
                return (this.caltitle);
            },
            enumerable: false,
            configurable: true
        });
        return Config;
    }());
    Config.ɵprov = i0.ɵɵdefineInjectable({ factory: function Config_Factory() { return new Config(i0.ɵɵinject(i1.HttpClient)); }, token: Config, providedIn: "root" });
    Config.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root',
                },] }
    ];
    Config.ctorParameters = function () { return [
        { type: i1.HttpClient }
    ]; };

    var KeyMapHelp = /** @class */ (function () {
        function KeyMapHelp(ctx) {
            this.width = "300px";
            this.height = "475px";
            this.title = "ShortKeys";
            this.html = null;
            this.win = null;
            this.map = null;
            this.okbtn = null;
            this.title = ctx.conf.keymaptitle;
            this.html = ctx.conf.keymapping.map;
        }
        KeyMapHelp.show = function (app) {
            var pinst = new PopupInstance();
            pinst.display(app, KeyMapHelp);
        };
        KeyMapHelp.prototype.close = function (_cancel) {
            this.win.closeWindow();
        };
        KeyMapHelp.prototype.setWin = function (win) {
            this.win = win;
        };
        KeyMapHelp.prototype.ngAfterViewInit = function () {
            var _this = this;
            var _a, _b;
            this.map = (_a = this.mapelem) === null || _a === void 0 ? void 0 : _a.nativeElement;
            this.okbtn = (_b = this.okelem) === null || _b === void 0 ? void 0 : _b.nativeElement;
            this.okbtn.addEventListener("keydown", function () { return _this.close(true); });
            this.okbtn.addEventListener("keypress", function () { return _this.close(true); });
            this.map.innerHTML = this.html;
            this.okbtn.focus();
        };
        return KeyMapHelp;
    }());
    KeyMapHelp.decorators = [
        { type: i0.Component, args: [{
                    template: "\n        <div #keymap></div>\n        <button style=\"width: 100%; height: 1px\" #ok></button>\n    "
                },] }
    ];
    KeyMapHelp.ctorParameters = function () { return [
        { type: Context }
    ]; };
    KeyMapHelp.propDecorators = {
        okelem: [{ type: i0.ViewChild, args: ["ok", { read: i0.ElementRef },] }],
        mapelem: [{ type: i0.ViewChild, args: ["keymap", { read: i0.ElementRef },] }]
    };

    var Builder = /** @class */ (function () {
        function Builder(resolver, injector, app) {
            this.resolver = resolver;
            this.injector = injector;
            this.app = app;
        }
        Builder.prototype.createComponent = function (component) {
            var cref = this.resolver.resolveComponentFactory(component).create(this.injector);
            return (cref);
        };
        Builder.prototype.getAppRef = function () {
            return (this.app);
        };
        return Builder;
    }());
    Builder.ɵprov = i0.ɵɵdefineInjectable({ factory: function Builder_Factory() { return new Builder(i0.ɵɵinject(i0.ComponentFactoryResolver), i0.ɵɵinject(i0.INJECTOR), i0.ɵɵinject(i0.ApplicationRef)); }, token: Builder, providedIn: "root" });
    Builder.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root',
                },] }
    ];
    Builder.ctorParameters = function () { return [
        { type: i0.ComponentFactoryResolver },
        { type: i0.Injector },
        { type: i0.ApplicationRef }
    ]; };

    var LoginForm = /** @class */ (function (_super) {
        __extends(LoginForm, _super);
        function LoginForm(ctx) {
            var _this = _super.call(this) || this;
            _this.top = "20%";
            _this.left = "25%";
            _this.width = "300px";
            _this.height = "150px";
            _this.title = "Login";
            _this.app = ctx.app["_impl_"];
            _this.addKeyTrigger(_this.onEvent, [
                exports.keymap.enter,
                exports.keymap.escape,
                exports.keymap.nextfield,
                exports.keymap.prevfield
            ]);
            return _this;
        }
        LoginForm.prototype.setWin = function (win) {
            this.win = win;
        };
        LoginForm.prototype.close = function (cancel) {
            var _a;
            this.app.enable();
            this.win.closeWindow();
            if (!cancel)
                this.app.appstate.connection.connect(this.usr.value, this.pwd.value);
            (_a = this.app.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.focus();
        };
        LoginForm.prototype.onEvent = function (kevent) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    if (kevent.key == exports.keymap.enter)
                        this.close(false);
                    if (kevent.key == exports.keymap.escape)
                        this.close(true);
                    if (kevent.key == exports.keymap.nextfield && kevent.field == "usr") {
                        kevent.event.preventDefault();
                        this.pwd.focus();
                    }
                    if (kevent.key == exports.keymap.nextfield && kevent.field == "pwd") {
                        kevent.event.preventDefault();
                        this.usr.focus();
                    }
                    if (kevent.key == exports.keymap.prevfield && kevent.field == "usr") {
                        kevent.event.preventDefault();
                        this.pwd.focus();
                    }
                    if (kevent.key == exports.keymap.prevfield && kevent.field == "pwd") {
                        kevent.event.preventDefault();
                        this.usr.focus();
                    }
                    return [2 /*return*/, (true)];
                });
            });
        };
        LoginForm.prototype.ngOnInit = function () {
            this.app.disable();
            this.app.setContainer();
        };
        LoginForm.prototype.ngAfterViewInit = function () {
            var _this = this;
            var container = this.app.getContainer();
            container.finish();
            container.getBlock("").records.forEach(function (rec) { _this["_impl_"].addRecord(new Record(0, rec.fields, rec.index)); });
            this.usr = this["_impl_"].getField(0, "usr");
            this.pwd = this["_impl_"].getField(0, "pwd");
            var usr = { name: "usr", mandatory: true, type: exports.FieldType.text };
            var pwd = { name: "pwd", mandatory: true, type: exports.FieldType.password };
            this.usr.setDefinition(usr, true);
            this.pwd.setDefinition(pwd, true);
            this.usr.enable(false);
            this.pwd.enable(false);
            this.usr.focus();
            this.app.dropContainer();
        };
        return LoginForm;
    }(Block));
    LoginForm.decorators = [
        { type: i0.Component, args: [{
                    selector: '',
                    template: "\n        <table style='margin-top: 20px'>\n          <tr>\n            <td>Username</td><td>: <field name='usr'></field> </td>\n          </tr>\n          <tr>\n            <td>Password</td><td>: <field name='pwd'></field> </td>\n          </tr>\n        </table>\n    "
                },] }
    ];
    LoginForm.ctorParameters = function () { return [
        { type: Context }
    ]; };

    var Wait = /** @class */ (function () {
        function Wait() {
            this.input = null;
            this.canvas = null;
        }
        Wait.show = function (app) {
            if (Wait.displayed)
                return;
            Wait.ready = false;
            Wait.displayed = true;
            Wait.win = app.builder.createComponent(Wait);
            var element = Wait.win.hostView.rootNodes[0];
            app.builder.getAppRef().attachView(Wait.win.hostView);
            document.body.appendChild(element);
            Wait.ready = true;
        };
        Wait.waiting = function () {
            return (Wait.displayed);
        };
        Wait.close = function (app) {
            if (!Wait.displayed)
                return;
            if (!Wait.ready) {
                setTimeout(function () { Wait.close(app); }, 1);
                return;
            }
            Wait.displayed = false;
            var element = Wait.win.hostView.rootNodes[0];
            document.body.removeChild(element);
            app.builder.getAppRef().detachView(Wait.win.hostView);
            Wait.win.destroy();
            app.getCurrentForm().focus();
        };
        Wait.prototype.ngAfterViewInit = function () {
            var _this = this;
            var _a, _b;
            this.input = (_a = this.inputElement) === null || _a === void 0 ? void 0 : _a.nativeElement;
            this.canvas = (_b = this.canvasElement) === null || _b === void 0 ? void 0 : _b.nativeElement;
            var ctx = this.canvas.getContext("2d");
            setTimeout(function () { _this.focus(); }, 10);
            setTimeout(function () { _this.showrunning(ctx, 0); }, 250);
        };
        Wait.prototype.focus = function () {
            var _this = this;
            if (!Wait.displayed)
                return;
            this.input.focus();
            setTimeout(function () { _this.focus(); }, 100);
        };
        Wait.prototype.showrunning = function (ctx, pick) {
            var _this = this;
            if (!Wait.displayed)
                return;
            ctx.lineWidth = 5;
            var pcolor = "black";
            var bcolor = "#DCDCDC";
            pick = pick % 3;
            var rad = 6;
            var off = 64;
            ctx.beginPath();
            ctx.strokeStyle = bcolor;
            if (pick == 0)
                ctx.strokeStyle = pcolor;
            ctx.arc(rad + off, 2 * rad, rad, 0, 2 * Math.PI);
            ctx.stroke();
            ctx.closePath();
            ctx.beginPath();
            ctx.strokeStyle = bcolor;
            if (pick == 1)
                ctx.strokeStyle = pcolor;
            ctx.arc(6 * rad + off, 2 * rad, rad, 0, 2 * Math.PI);
            ctx.stroke();
            ctx.closePath();
            ctx.beginPath();
            ctx.strokeStyle = bcolor;
            if (pick == 2)
                ctx.strokeStyle = pcolor;
            ctx.arc(11 * rad + off, 2 * rad, rad, 0, 2 * Math.PI);
            ctx.stroke();
            ctx.closePath();
            setTimeout(function () { _this.showrunning(ctx, pick + 1); }, 250);
        };
        return Wait;
    }());
    Wait.ready = false;
    Wait.displayed = false;
    Wait.win = null;
    Wait.decorators = [
        { type: i0.Component, args: [{
                    selector: '',
                    template: "\n                <div class=\"wait-modal\">\n                    <canvas #canvas class=\"wait-canvas\" id=\"canvas\"></canvas>\n                    <input #input class=\"wait-input\">\n                </div>\n              ",
                    styles: ["\n        .wait-input\n        {\n            height: 0;\n        }\n\n        .wait-canvas\n        {\n            top: 25%;\n            left: 40%;\n            width: 320px;\n            height: 160px;\n            position: fixed;\n        }\n\n        .wait-modal\n        {\n            top: 0;\n            left: 0;\n            z-index: 1;\n            opacity: 1;\n            width: 100%;\n            height: 100%;\n            display: block;\n            overflow: auto;\n            position: fixed;\n            box-shadow: inset 0px 0px 400px 110px rgba(0, 0, 0, .2);\n        }\n        "]
                },] }
    ];
    Wait.propDecorators = {
        inputElement: [{ type: i0.ViewChild, args: ["input", { read: i0.ElementRef },] }],
        canvasElement: [{ type: i0.ViewChild, args: ["canvas", { read: i0.ElementRef },] }]
    };

    var MenuInterface = /** @class */ (function () {
        function MenuInterface(menu) {
            this.menu$ = menu;
            this.app$ = this.menu$.getApplication()["_impl_"];
        }
        Object.defineProperty(MenuInterface.prototype, "app", {
            get: function () {
                return (this.app$.getApplication());
            },
            enumerable: false,
            configurable: true
        });
        MenuInterface.prototype.isConnected = function () {
            return (this.app$.connected);
        };
        MenuInterface.prototype.enable = function (menu) {
            this.menu$.enable(menu);
        };
        MenuInterface.prototype.disable = function (menu) {
            this.menu$.disable(menu);
        };
        return MenuInterface;
    }());

    var DropDownMenu = /** @class */ (function () {
        function DropDownMenu(ctx) {
            this.ctx = ctx;
            this.options = new Map();
            this.menus = new Map();
            this.conf = ctx.conf;
            this.app$ = ctx.app["_impl_"]; // might not be initialized
            this.instance = "DropDownMenu-" + (DropDownMenu.instances++);
        }
        DropDownMenu.setForm = function (inst, form) {
            if (inst.instance.getMenu() == null) {
                if (DropDownMenu.calls++ > 10)
                    return;
                setTimeout(function () { DropDownMenu.setForm(inst, form); }, 10);
                return;
            }
            inst.instance.getMenu().getHandler().onFormChange(form);
        };
        DropDownMenu.prototype.getMenu = function () {
            return (this.menu);
        };
        DropDownMenu.prototype.getApplication = function () {
            return (this.app$.getApplication());
        };
        DropDownMenu.prototype.enable = function (menu) {
            if (menu == null) {
                this.menus.forEach(function (mopt) {
                    mopt.elem.classList.remove("ddmenu-disabled");
                    mopt.options.forEach(function (opt) { opt.elem.children[0].classList.remove("ddmenu-disabled"); });
                });
                return;
            }
            menu = menu.toLowerCase();
            var mopt = this.menus.get(menu);
            if (mopt != null) {
                mopt.elem.classList.remove("ddmenu-disabled");
                mopt.options.forEach(function (opt) { opt.elem.children[0].classList.remove("ddmenu-disabled"); });
                return;
            }
            var option = menu;
            mopt = this.menus.get(menu.substring(0, menu.lastIndexOf("/")));
            if (mopt == null)
                return;
            var enabled = 0;
            mopt.options.forEach(function (opt) {
                if (opt.elem.id == option)
                    opt.elem.children[0].classList.remove("ddmenu-disabled");
                if (!opt.elem.children[0].classList.contains("ddmenu-disabled"))
                    enabled++;
            });
            if (enabled > 0)
                mopt.elem.classList.remove("ddmenu-disabled");
        };
        DropDownMenu.prototype.disable = function (menu) {
            if (menu == null) {
                this.menus.forEach(function (mopt) {
                    mopt.elem.classList.add("ddmenu-disabled");
                    mopt.options.forEach(function (opt) { opt.elem.children[0].classList.add("ddmenu-disabled"); });
                });
                return;
            }
            menu = menu.toLowerCase();
            var mopt = this.menus.get(menu);
            if (mopt != null) {
                mopt.elem.classList.add("ddmenu-disabled");
                mopt.options.forEach(function (opt) { opt.elem.children[0].classList.add("ddmenu-disabled"); });
                return;
            }
            var option = menu;
            mopt = this.menus.get(menu.substring(0, menu.lastIndexOf("/")));
            if (mopt == null)
                return;
            var enabled = 0;
            mopt.options.forEach(function (opt) {
                if (opt.elem.id == option)
                    opt.elem.children[0].classList.add("ddmenu-disabled");
                if (!opt.elem.children[0].classList.contains("ddmenu-disabled"))
                    enabled++;
            });
            if (enabled == 0)
                mopt.elem.classList.add("ddmenu-disabled");
        };
        DropDownMenu.prototype.display = function (menu) {
            var _this = this;
            if (menu == null)
                return;
            if (this.html == null) {
                setTimeout(function () { _this.display(menu); }, 10);
                return;
            }
            this.app$ = this.ctx.app["_impl_"];
            this.menu = menu;
            var intf = new MenuInterface(this);
            menu.getHandler()["__menu__"] = intf;
            this.menu = menu;
            this.html.innerHTML = this.menuhtml();
            var menus = this.html.getElementsByClassName("ddmenu-menu");
            var options = this.html.getElementsByClassName("ddmenu-option");
            for (var i = 0; i < menus.length; i++) {
                var mopt = new MenuOption(menus[i].children[0]);
                this.menus.set(mopt.elem.id, mopt);
                mopt.elem.classList.add("ddmenu-default");
                mopt.elem.classList.add("ddmenu-disabled");
                mopt.elem.addEventListener("click", function (event) { _this.toggle(event); });
            }
            for (var i = 0; i < options.length; i++) {
                var id = options[i].id;
                var menu_1 = id.substring(0, id.lastIndexOf("/"));
                var opt = this.options.get(id);
                options[i].children[0].classList.add("ddmenu-disabled");
                options[i].addEventListener("click", function (event) { _this.action(event); });
                opt.elem = options[i];
                var mopt = this.menus.get(menu_1);
                mopt.options.push(opt);
            }
            menu.getHandler().onInit();
        };
        DropDownMenu.prototype.onEvent = function (event) {
            if (!event.target.matches('.ddmenu-entry')) {
                this.closeall();
                WindowListener.remove(this.instance, "click");
            }
        };
        DropDownMenu.prototype.action = function (event) {
            var handler = this.menu.getHandler();
            var link = null;
            var text = event.target;
            if (text.classList.contains("ddmenu-linktext")) {
                link = text.parentElement;
            }
            else {
                link = text;
                text = text.children[0];
            }
            if (text.classList.contains("ddmenu-disabled"))
                return;
            var opt = this.options.get(link.id);
            if (opt.option.action != null)
                handler[opt.option.action]();
        };
        DropDownMenu.prototype.toggle = function (event) {
            var menu = event.target;
            var container = menu.parentNode.children[1];
            if (menu.classList.contains("ddmenu-disabled"))
                return;
            container.classList.toggle("ddmenu-show");
            if (container.classList.contains("ddmenu-show")) {
                this.closeall(container);
                WindowListener.add(this.instance, this, "click");
            }
            else {
                container.classList.remove("ddmenu-show");
            }
        };
        DropDownMenu.prototype.closeall = function (except) {
            var open = this.html.getElementsByClassName("ddmenu-show");
            for (var i = 0; i < open.length; i++) {
                if (except == null || open[i].id != except.id)
                    open[i].classList.remove("ddmenu-show");
            }
        };
        DropDownMenu.prototype.menuhtml = function () {
            var html = "";
            html += "<style>\n";
            html += this.styles() + "\n";
            html += "</style>\n";
            html += "<span class='ddmenu-bar'>\n";
            html += this.entries("", "", this.menu.getEntries());
            html += "</span>\n";
            return (html);
        };
        DropDownMenu.prototype.entries = function (indent, path, entries) {
            var html = "";
            for (var i = 0; i < entries.length; i++) {
                var id = path + "/" + entries[i].name.toLowerCase();
                html += indent + "<div class='ddmenu-menu'>\n";
                html += indent + "  <button class='ddmenu-entry' id='" + id + "'>\n";
                html += indent + entries[i].name;
                html += indent + "  </button>\n";
                html += indent + "  <div class='ddmenu-content' id='" + id + "-content'>\n";
                if (entries[i].options != null) {
                    for (var f = 0; f < entries[i].options.length; f++) {
                        var entry = entries[i].options[f];
                        var oid = id + "/" + entry.name.toLowerCase();
                        this.options.set(oid, new Option(entries[i].options[f]));
                        html += indent + "    <a class='ddmenu-option' id='" + oid + "'>\n";
                        html += indent + "      <span class='ddmenu-linktext'>" + entry.name + "</span>\n";
                        html += indent + "    </a>\n";
                    }
                }
                html += indent + "  </div>\n";
                html += indent + "</div>\n";
            }
            return (html);
        };
        DropDownMenu.prototype.styles = function () {
            var style = "\n            .ddmenu-bar\n            {\n                width: 100%;\n                height: 100%;\n                display: flex;\n                position: relative;\n                white-space: nowrap;\n                background: transparent;\n            }\n\n            .ddmenu-entry\n            {\n                padding: 0;\n                border: none;\n                color: " + this.conf.colors.menuoption + ";\n                outline:none;\n                cursor: pointer;\n                font-size: 15px;\n                margin-top: 1px;\n                margin-left: 4px;\n                margin-right: 4px;\n                margin-bottom: 1px;\n                background: transparent;\n            }\n\n            .ddmenu-default\n            {\n                color: " + this.conf.colors.enabled + ";\n            }\n\n            .ddmenu-disabled\n            {\n                color: " + this.conf.colors.disabled + ";\n            }\n\n            .ddmenu-menu\n            {\n                position: relative;\n                display: inline-block;\n            }\n\n            .ddmenu-content\n            {\n                z-index: 1;\n                display: none;\n                overflow: none;\n                min-width: 80px;\n                position: absolute;\n                background-color: #f1f1f1;\n                color: " + this.conf.colors.menuoption + ";\n                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);\n            }\n\n            .ddmenu-option\n            {\n                border: none;\n                color: black;\n                outline:none;\n                cursor: pointer;\n                font-size: 15px;\n                background: transparent;\n            }\n\n            .ddmenu-content .ddmenu-option\n            {\n                color: black;\n                display: block;\n                padding: 12px 16px;\n                text-decoration: none;\n            }\n\n            .ddmenu-content .ddmenu-option:hover\n            {\n                background-color: #ddd;\n            }\n\n            .ddmenu-show\n            {\n                display: block;\n            }\n        ";
            return (style);
        };
        DropDownMenu.prototype.ngAfterViewInit = function () {
            var _a;
            this.html = (_a = this.elem) === null || _a === void 0 ? void 0 : _a.nativeElement;
        };
        return DropDownMenu;
    }());
    DropDownMenu.instances = 0;
    DropDownMenu.calls = 0;
    DropDownMenu.decorators = [
        { type: i0.Component, args: [{
                    selector: '',
                    template: '<div #html></div>'
                },] }
    ];
    DropDownMenu.ctorParameters = function () { return [
        { type: Context }
    ]; };
    DropDownMenu.propDecorators = {
        elem: [{ type: i0.ViewChild, args: ["html", { read: i0.ElementRef },] }]
    };
    var MenuOption = /** @class */ (function () {
        function MenuOption(elem) {
            this.options = [];
            this.elem = elem;
        }
        return MenuOption;
    }());
    var Option = /** @class */ (function () {
        function Option(option) {
            this.option = option;
        }
        return Option;
    }());

    var MenuFactory = /** @class */ (function () {
        function MenuFactory(builder) {
            this.builder = builder;
        }
        MenuFactory.prototype.create = function (menu) {
            var ref = this.builder.createComponent(DropDownMenu);
            ref.instance.display(menu);
            return (ref);
        };
        return MenuFactory;
    }());

    var FormUtil = /** @class */ (function () {
        function FormUtil() {
            this.utils = new Utils();
        }
        FormUtil.prototype.complete = function (options, create) {
            if (options == null) {
                if (create)
                    options = {};
                else
                    return (null);
            }
            if (!options.hasOwnProperty("wizard"))
                options.wizard = false;
            if (!options.hasOwnProperty("inherit"))
                options.inherit = true;
            if (!options.hasOwnProperty("width"))
                options.width = "99.65vw";
            if (!options.hasOwnProperty("height"))
                options.height = "99.5vh";
            if (!options.hasOwnProperty("offsetTop"))
                options.offsetTop = "0";
            if (!options.hasOwnProperty("offsetLeft"))
                options.offsetLeft = "0";
            return (options);
        };
        FormUtil.prototype.convert = function (form) {
            var fname = this.utils.getName(form.component);
            var navigable = true;
            form.windowopts = this.complete(form.windowopts);
            if (form.hasOwnProperty("navigable"))
                navigable = form.navigable;
            var path = "/" + fname;
            if (form.hasOwnProperty("path"))
                path = form.path;
            path = path.trim();
            if (!path.startsWith("/"))
                path = "/" + path;
            var def = {
                name: fname,
                path: form.path,
                title: form.title,
                navigable: navigable,
                component: form.component,
                windowdef: form.windowopts
            };
            return (def);
        };
        FormUtil.prototype.clone = function (base) {
            var clone = {
                name: base.name,
                path: base.path,
                title: base.title,
                windowdef: base.windowdef,
                windowopts: base.windowdef,
                component: base.component,
                navigable: base.navigable
            };
            return (clone);
        };
        return FormUtil;
    }());

    var ModalWindow = /** @class */ (function () {
        function ModalWindow(ctx, change) {
            this.change = change;
            this.top = null;
            this.left = null;
            this.width = "99vw";
            this.height = "98vh";
            this.tmargin = "1vh";
            this.minw = 0;
            this.minh = 0;
            this.offx = 0;
            this.offy = 0;
            this.move = false;
            this.resz = false;
            this.resizex = false;
            this.resizey = false;
            this.conf = ctx.conf;
        }
        Object.defineProperty(ModalWindow.prototype, "tcolor", {
            get: function () {
                return (this.conf.colors.title);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ModalWindow.prototype, "bcolor", {
            get: function () {
                return (this.conf.colors.topbar);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ModalWindow.prototype, "btncolor", {
            get: function () {
                return (this.conf.colors.menuoption);
            },
            enumerable: false,
            configurable: true
        });
        ModalWindow.prototype.setForm = function (form) {
            this.resize(form, true);
            var impl = form.formref.instance["_impl_"];
            impl.setModalWindow(this);
            this.form = form;
        };
        ModalWindow.prototype.getForm = function () {
            return (this.form.formref.instance);
        };
        ModalWindow.prototype.newForm = function (form) {
            var _a;
            if (!((_a = form.windowopts) === null || _a === void 0 ? void 0 : _a.inherit))
                this.resize(form, false);
            var formelem = this.content.firstElementChild;
            if (formelem != null)
                this.content.removeChild(formelem);
            this.app.builder.getAppRef().detachView(this.form.formref.hostView);
            if (this.menuelem != null) {
                var menuelem = this.menu.firstElementChild;
                if (menuelem != null)
                    this.menu.removeChild(this.menuelem);
                this.app.builder.getAppRef().detachView(this.menuref.hostView);
            }
            var impl = form.formref.instance["_impl_"];
            impl.setModalWindow(this);
            this.form = form;
            this.display();
        };
        ModalWindow.prototype.setWinRef = function (winref) {
            this.winref = winref;
        };
        ModalWindow.prototype.setApplication = function (app) {
            this.app = app;
        };
        ModalWindow.prototype.close = function () {
            var impl = this.form.formref.instance["_impl_"];
            this.closeWindow();
            impl.cancel();
        };
        ModalWindow.prototype.closeWindow = function () {
            WindowListener.remove("modal", "mouseup");
            WindowListener.remove("modal", "mousemove");
            WindowListener.remove("modal", "mousedown");
            var formelem = this.content.firstElementChild;
            if (formelem != null)
                this.content.removeChild(formelem);
            this.app.builder.getAppRef().detachView(this.form.formref.hostView);
            var element = this.winref.hostView.rootNodes[0];
            document.body.removeChild(element);
            this.app.builder.getAppRef().detachView(this.winref.hostView);
            this.winref.destroy();
            this.winref = null;
        };
        ModalWindow.prototype.resize = function (form, pos) {
            if (form.windowopts.offsetLeft != null && form.windowopts.offsetLeft.trim().endsWith("%")) {
                var s = form.windowopts.offsetLeft.trim();
                var n = +s.substring(0, s.length - 1);
                form.windowopts.offsetLeft = (window.innerWidth * n / 100) + "px";
            }
            if (form.windowopts.width != null && form.windowopts.width.trim().endsWith("%")) {
                var s = form.windowopts.width.trim();
                var n = +s.substring(0, s.length - 1);
                form.windowopts.width = (window.innerWidth * n / 100) + "px";
            }
            if (form.windowopts.offsetTop != null && form.windowopts.offsetTop.trim().endsWith("%")) {
                var s = form.windowopts.offsetTop.trim();
                var n = +s.substring(0, s.length - 1);
                form.windowopts.offsetTop = (window.innerHeight * n / 100) + "px";
            }
            if (form.windowopts.height != null && form.windowopts.height.trim().endsWith("%")) {
                var s = form.windowopts.height.trim();
                var n = +s.substring(0, s.length - 1);
                form.windowopts.height = (window.innerHeight * n / 100) + "px";
            }
            if (pos) {
                this.top = form.windowopts.offsetTop;
                this.left = form.windowopts.offsetLeft;
                if (this.top == "undefined")
                    this.top = null;
                if (this.left == "undefined")
                    this.left = null;
            }
            this.width = form.windowopts.width;
            this.height = form.windowopts.height;
            if (form.windowopts.width == "") {
                this.left = "0";
                this.width = "100%";
            }
            if (form.windowopts.height == "") {
                this.top = "0";
                this.height = "100%";
            }
            this.change.detectChanges();
        };
        ModalWindow.prototype.display = function () {
            var _this = this;
            if (this.form == null) {
                setTimeout(function () { _this.display(); }, 10);
                return;
            }
            this.element = this.form.formref.hostView.rootNodes[0];
            this.app.builder.getAppRef().attachView(this.form.formref.hostView);
            this.content.appendChild(this.element);
            this.minh = 100;
            this.minw = 450;
            this.showmenu();
            this.change.detectChanges();
            this.posy = this.window.offsetTop;
            this.posx = this.window.offsetLeft;
            this.sizex = this.window.offsetWidth;
            this.sizey = this.window.offsetHeight;
            var resize = false;
            if (this.sizex < this.minw) {
                resize = true;
                this.sizex = this.minw;
                this.width = this.sizex + "px";
            }
            if (this.sizey < this.minh) {
                resize = true;
                this.sizey = this.minh;
                this.height = this.sizey + "px";
            }
            if (this.top == null || this.top.trim().length == 0) {
                resize = true;
                this.top = ((+window.innerHeight - this.sizey) / 3) + "px";
            }
            if (this.left == null || this.left.trim().length == 0) {
                resize = true;
                this.left = ((+window.innerWidth - this.sizex) / 3) + "px";
            }
            if (resize) {
                this.change.detectChanges();
                this.posy = this.window.offsetTop;
                this.posx = this.window.offsetLeft;
                this.sizex = this.window.offsetWidth;
                this.sizey = this.window.offsetHeight;
            }
        };
        ModalWindow.prototype.showmenu = function () {
            var impl = this.form.formref.instance["_impl_"];
            this.menuelem = null;
            this.menuref = impl.getDropDownMenu();
            if (this.menuref == null)
                return;
            this.menuelem = this.menuref.hostView.rootNodes[0];
            this.app.builder.getAppRef().attachView(this.menuref.hostView);
            this.menu.appendChild(this.menuelem);
            var ddmenu = this.menuref.instance;
            this.initmenu(ddmenu);
        };
        ModalWindow.prototype.initmenu = function (ddmenu) {
            var _this = this;
            if (ddmenu.getMenu() == null) {
                setTimeout(function () { _this.initmenu(ddmenu); }, 10);
                return;
            }
            var impl = this.form.formref.instance["_impl_"];
            ddmenu.getMenu().getHandler().onFormChange(impl.form);
            this.minw = this.menu.clientWidth + 50;
            if (this.sizex < this.minw) {
                this.sizex = this.minw;
                this.width = this.sizex + "px";
                this.change.detectChanges();
            }
        };
        ModalWindow.prototype.ngAfterViewInit = function () {
            var _this = this;
            var _a, _b, _c, _d;
            this.menu = (_a = this.menuElement) === null || _a === void 0 ? void 0 : _a.nativeElement;
            this.window = (_b = this.windowElement) === null || _b === void 0 ? void 0 : _b.nativeElement;
            this.topbar = (_c = this.topbarElement) === null || _c === void 0 ? void 0 : _c.nativeElement;
            this.content = (_d = this.contentElement) === null || _d === void 0 ? void 0 : _d.nativeElement;
            this.display();
            WindowListener.add("modal", this, "mouseup");
            WindowListener.add("modal", this, "mousemove");
            WindowListener.add("modal", this, "mousedown");
            this.topbar.addEventListener("mousedown", function (event) { _this.startmove(event); });
        };
        ModalWindow.prototype.onEvent = function (event) {
            switch (event.type) {
                case "mouseup":
                    this.mouseup();
                    break;
                case "mousemove":
                    this.movePopup(event);
                    this.resizePopup(event);
                    this.resizemousemove(event);
                    break;
                case "mousedown":
                    this.startresize(event);
                    break;
            }
        };
        ModalWindow.prototype.startmove = function (event) {
            if (this.resizexy)
                return;
            this.move = true;
            event = event || window.event;
            event.preventDefault();
            this.offy = +event.clientY - this.posy;
            this.offx = +event.clientX - this.posx;
        };
        ModalWindow.prototype.mouseup = function () {
            if (!this.move && !this.resz)
                return;
            this.move = false;
            this.resz = false;
            this.resizexy = false;
            this.window.style.cursor = "default";
            document.body.style.cursor = "default";
        };
        ModalWindow.prototype.movePopup = function (event) {
            if (!this.move)
                return;
            event = event || window.event;
            var deltay = +event.clientY - this.posy;
            var deltax = +event.clientX - this.posx;
            this.posy += (deltay - this.offy);
            this.posx += (deltax - this.offx);
            if (this.posy > 0)
                this.top = this.posy + "px";
            if (this.posx > 0)
                this.left = this.posx + "px";
            this.change.detectChanges();
        };
        ModalWindow.prototype.resizemousemove = function (event) {
            if (this.resz)
                return;
            event = event || window.event;
            var posx = +event.clientX;
            var posy = +event.clientY;
            var offx = this.posx + this.sizex - posx;
            var offy = this.posy + this.sizey - posy;
            var before = false;
            if (this.resizex || this.resizey)
                before = true;
            this.resizex = false;
            this.resizey = false;
            if (offx > -7 && offx < 10 && posy > this.posy - 7 && posy < this.posy + this.sizey + 7)
                this.resizex = true;
            if (offy > -7 && offy < 10 && posx > this.posx - 7 && posx < this.posx + this.sizex + 7)
                this.resizey = true;
            if (this.resizex && this.resizey) {
                this.resizex = true;
                this.resizey = true;
            }
            if (this.resizex && !this.resizey) {
                this.window.style.cursor = "e-resize";
                document.body.style.cursor = "e-resize";
            }
            if (this.resizey && !this.resizex) {
                this.window.style.cursor = "s-resize";
                document.body.style.cursor = "s-resize";
            }
            if (this.resizex && this.resizey) {
                this.window.style.cursor = "se-resize";
                document.body.style.cursor = "se-resize";
            }
            if (before && !this.resizexy) {
                this.window.style.cursor = "default";
                document.body.style.cursor = "default";
            }
        };
        ModalWindow.prototype.startresize = function (event) {
            if (!this.resizexy)
                return;
            this.resz = true;
            event = event || window.event;
            event.preventDefault();
            this.offy = +event.clientY;
            this.offx = +event.clientX;
        };
        ModalWindow.prototype.resizePopup = function (event) {
            if (!this.resz)
                return;
            event = event || window.event;
            var deltay = +event.clientY - this.offy;
            var deltax = +event.clientX - this.offx;
            if (this.resizex && (this.sizex > this.minw || deltax > 0)) {
                this.sizex += deltax;
                this.width = this.sizex + "px";
            }
            if (this.resizey && (this.sizey > this.minh || deltay > 0)) {
                this.sizey += deltay;
                this.height = this.sizey + "px";
            }
            this.offy = +event.clientY;
            this.offx = +event.clientX;
            this.change.detectChanges();
        };
        Object.defineProperty(ModalWindow.prototype, "resizexy", {
            get: function () {
                if (this.resizex || this.resizey)
                    return (true);
                return (false);
            },
            set: function (on) {
                this.resizex = on;
                this.resizey = on;
            },
            enumerable: false,
            configurable: true
        });
        return ModalWindow;
    }());
    ModalWindow.decorators = [
        { type: i0.Component, args: [{
                    selector: 'modalwindow',
                    template: "\n    <div class=\"modalwindow\">\n      <div #window class=\"modalwindow-modal-block\" style=\"top: {{top}}; left: {{left}}\">\n        <div class=\"modalwindow-container\" style=\"width: {{width}}; height: {{height}};\">\n\t\t  <div #topbar class=\"modalwindow-topbar\" style=\"color: {{tcolor}}; background-color: {{bcolor}}\">\n\t\t    <span class=\"modalwindow-center\" style=\"color: {{tcolor}};\">\n\t\t\t\t<span class=\"modalwindow-corner\"></span>\n\t\t\t\t<div #menu></div>\n\t\t\t\t<span class=\"modalwindow-close\">\n\t\t\t\t\t<button class=\"modalwindow-button\" style=\"color: {{btncolor}};\" (click)=\"close()\">X</button>\n\t\t\t\t</span>\n\t\t\t</span>\n\t\t  </div>\n          <div class=\"modalwindow-block\" style=\"margin-top: {{tmargin}};\"><div #content></div></div>\n        </div>\n      </div>\n    </div>\n  ",
                    changeDetection: i0.ChangeDetectionStrategy.OnPush,
                    styles: ["\n    .modalwindow\n    {\n        top: 0;\n        left: 0;\n        z-index: 1;\n        width: 100%;\n        height: 100%;\n        display: block;\n        overflow: auto;\n        position: fixed;\n    }\n\n    .modalwindow-modal-block\n    {\n      position: absolute;\n      background-color: #fefefe;\n    }\n\n    .modalwindow-container\n    {\n        position: relative;\n        border: 2px solid black;\n    }\n\n    .modalwindow-topbar\n    {\n        height: 1.70em;\n        margin-left: 0;\n        margin-right: 0;\n        cursor:default;\n\t\tjustify-content: center;\n        border-bottom: 2px solid black;\n    }\n\n\t.modalwindow-corner\n\t{\n\t\twidth: 2.5em;\n\t\tdisplay: block;\n\t\tposition: relative;\n\t}\n\n\t.modalwindow-close\n\t{\n\t\ttop: 0;\n\t\tright: 0;\n\t\twidth: 1.75em;\n\t\theight: 1.70em;\n\t\tposition: absolute;\n\t\tborder-left: 1px solid black;\n\t}\n\n\t.modalwindow-button\n\t{\n\t\ttop: 50%;\n\t\twidth: 100%;\n\t\theight: 100%;\n\t\toutline:none;\n\t\tfont-size: 0.75em;\n\t\tfont-weight: bold;\n\t\tposition: relative;\n\t\tbackground: transparent;\n\t\ttransform: translateY(-50%);\n\t\tborder: 0px solid transparent;\n\t\tbox-shadow: 0px 0px 0px transparent;\n\t\ttext-shadow: 0px 0px 0px transparent;\n\t}\n\n\t.modalwindow-center\n\t{\n\t\ttop: 0;\n\t\tbottom: 0;\n\t\twidth: 93%;\n\t\theight: 100%;\n\t\tdisplay: flex;\n\t\talign-items: center;\n\t\tjustify-content: center;\n\t}\n\n    .modalwindow-block\n    {\n        left: 0;\n        top: 3vh;\n        right: 0;\n        bottom: 0;\n\t\tdisplay: flex;\n        overflow: auto;\n        position: absolute;\n\t\tjustify-content: center;\n    }\n"]
                },] }
    ];
    ModalWindow.ctorParameters = function () { return [
        { type: Context },
        { type: i0.ChangeDetectorRef }
    ]; };
    ModalWindow.propDecorators = {
        menuElement: [{ type: i0.ViewChild, args: ["menu", { read: i0.ElementRef },] }],
        windowElement: [{ type: i0.ViewChild, args: ["window", { read: i0.ElementRef },] }],
        topbarElement: [{ type: i0.ViewChild, args: ["topbar", { read: i0.ElementRef },] }],
        contentElement: [{ type: i0.ViewChild, args: ['content', { read: i0.ElementRef },] }]
    };

    var FormsControl = /** @class */ (function () {
        function FormsControl(app, builder) {
            this.app = app;
            this.builder = builder;
            this.utils = new Utils();
            this.formlist = [];
            this.forms = new Map();
        }
        FormsControl.prototype.setFormArea = function (formarea) {
            this.formarea = formarea;
        };
        FormsControl.prototype.setFormsDefinitions = function (forms) {
            var futil = new FormUtil();
            for (var i = 0; i < forms.length; i++) {
                var form = forms[i];
                var def = futil.convert(form);
                this.formlist.push(def);
                this.forms.set(def.name, def);
            }
            return (this.forms);
        };
        FormsControl.prototype.findFormByPath = function (path) {
            for (var i = 0; i < this.formlist.length; i++) {
                if (this.formlist[i].path == path)
                    return (this.formlist[i].name);
            }
            return (null);
        };
        FormsControl.prototype.getFormsList = function () {
            return (this.formlist);
        };
        FormsControl.prototype.getFormsDefinitions = function () {
            return (this.forms);
        };
        FormsControl.prototype.closeform = function (form, destroy) {
            var name = this.utils.getName(form);
            var formdef = this.forms.get(name);
            if (formdef == null || formdef.formref == null)
                return;
            this.close(formdef, destroy);
        };
        FormsControl.prototype.close = function (formdef, destroy) {
            if (formdef.formref == null)
                return;
            var formsarea = this.formarea.getFormsArea();
            var element = formdef.formref.hostView.rootNodes[0];
            if (this.current != null && this.current.element == element) {
                this.current = null;
                formsarea.removeChild(element);
                this.builder.getAppRef().detachView(formdef.formref.hostView);
            }
            if (destroy) {
                formdef.formref.destroy();
                formdef.windowopts = null;
                formdef.formref = null;
            }
        };
        FormsControl.prototype.display = function (formdef) {
            if (formdef == null || formdef.formref == null)
                return;
            var formsarea = this.formarea.getFormsArea();
            var element = formdef.formref.hostView.rootNodes[0];
            var impl = formdef.formref.instance["_impl_"];
            if (formdef.windowopts == null) {
                this.current = { formdef: formdef, element: element };
                this.builder.getAppRef().attachView(formdef.formref.hostView);
                formsarea.appendChild(element);
            }
            else {
                var id = {
                    impl: impl,
                    ref: formdef.formref,
                    name: formdef.name,
                    modalopts: formdef.windowopts
                };
                impl.setInstanceID(id);
                var win = this.createWindow();
                win.setForm(formdef);
                win.setApplication(this.app);
            }
        };
        FormsControl.prototype.createWindow = function () {
            var winref = this.app.builder.createComponent(ModalWindow);
            var win = winref.instance;
            win.setWinRef(winref);
            var element = winref.hostView.rootNodes[0];
            this.builder.getAppRef().attachView(winref.hostView);
            document.body.appendChild(element);
            return (win);
        };
        FormsControl.prototype.getFormInstance = function (form) {
            var name = this.utils.getName(form);
            var formdef = this.forms.get(name);
            if (formdef == null)
                return (null);
            if (formdef.formref == null) {
                formdef.formref = this.createForm(formdef.component);
                if (formdef.windowdef != null && formdef.windowdef.wizard)
                    formdef.windowopts = formdef.windowdef;
            }
            return (formdef);
        };
        FormsControl.prototype.createForm = function (component) {
            var ref = this.builder.createComponent(component);
            if (!(ref.instance instanceof Form)) {
                var name = ref.instance.constructor.name;
                console.log("Component " + name + " is not an instance of Form");
                return;
            }
            var impl = ref.instance["_impl_"];
            impl.setApplication(this.app);
            return (ref);
        };
        return FormsControl;
    }());

    var Connection = /** @class */ (function () {
        function Connection(app) {
            this.app = app;
            this.url = null;
            this.conn = null;
            this.keepalive = 0;
            this.client = null;
            this.stmtid = 0;
            this.waitlim = 250;
            this.running = new Map();
            this.client = app.client;
        }
        Connection.prototype.connect = function (usr, pwd) {
            return __awaiter(this, void 0, void 0, function () {
                var conf, credentials, response;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!(this.url == null)) return [3 /*break*/, 3];
                            return [4 /*yield*/, this.app.config.ready()];
                        case 1:
                            _a.sent();
                            return [4 /*yield*/, this.app.config.others];
                        case 2:
                            conf = _a.sent();
                            this.url = conf["database.js"];
                            if (this.url == null || this.url.length == 0)
                                this.url = window.location.origin;
                            _a.label = 3;
                        case 3:
                            if (this.conn != null) {
                                this.alert("Already logged on");
                                return [2 /*return*/];
                            }
                            if (usr == null || pwd == null) {
                                this.alert("Username and password must be specified to logon");
                                return [2 /*return*/];
                            }
                            credentials = { usr: usr, pwd: pwd };
                            return [4 /*yield*/, this.invoke("connect", credentials)];
                        case 4:
                            response = _a.sent();
                            if (response["status"] == "failed") {
                                this.alert(response["message"]);
                                return [2 /*return*/];
                            }
                            this.conn = response["id"];
                            ;
                            this.keepalive = response["keep-alive"];
                            this.app.appstate.onConnect();
                            this.keepAlive();
                            return [2 /*return*/, (response)];
                    }
                });
            });
        };
        Connection.prototype.commit = function () {
            return __awaiter(this, void 0, void 0, function () {
                var response;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!(this.conn != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.invoke("commit", {})];
                        case 1:
                            response = _a.sent();
                            if (response["status"] != "ok")
                                this.alert(JSON.stringify(response));
                            this.app.appstate.transactionChange(false);
                            return [2 /*return*/, (false)];
                        case 2: return [2 /*return*/, (true)];
                    }
                });
            });
        };
        Connection.prototype.rollback = function () {
            return __awaiter(this, void 0, void 0, function () {
                var response;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!(this.conn != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.invoke("rollback", {})];
                        case 1:
                            response = _a.sent();
                            if (response["status"] != "ok") {
                                this.alert(JSON.stringify(response));
                                return [2 /*return*/, (false)];
                            }
                            this.app.appstate.transactionChange(false);
                            return [2 /*return*/, (false)];
                        case 2: return [2 /*return*/, (true)];
                    }
                });
            });
        };
        Object.defineProperty(Connection.prototype, "connected", {
            get: function () {
                return (this.conn != null);
            },
            enumerable: false,
            configurable: true
        });
        Connection.prototype.disconnect = function () {
            return __awaiter(this, void 0, void 0, function () {
                var response;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (this.conn == null) {
                                this.alert("not logged on");
                                return [2 /*return*/];
                            }
                            return [4 /*yield*/, this.invoke("disconnect", {})];
                        case 1:
                            response = _a.sent();
                            if (response["status"] != "ok")
                                this.alert(JSON.stringify(response));
                            this.conn = null;
                            this.keepalive = 0;
                            this.app.appstate.transactionChange(false);
                            this.app.appstate.onDisconnect();
                            return [2 /*return*/];
                    }
                });
            });
        };
        Connection.prototype.keepAlive = function () {
            return __awaiter(this, void 0, void 0, function () {
                var response_1, body;
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!(this.conn != null && +this.keepalive > 0)) return [3 /*break*/, 2];
                            response_1 = null;
                            body = { "keep-alive": true };
                            return [4 /*yield*/, this.client.post(this.url + "/" + this.conn + "/ping", body).toPromise().then(function (data) { response_1 = data; }, function (error) { response_1 = error; })];
                        case 1:
                            _a.sent();
                            if (response_1["status"] != "ok") {
                                this.keepalive = 0;
                                this.alert(JSON.stringify(response_1), "KeepAlive stopped");
                            }
                            setTimeout(function () { _this.keepAlive(); }, this.keepalive * 1000);
                            _a.label = 2;
                        case 2: return [2 /*return*/];
                    }
                });
            });
        };
        Connection.prototype.invokestmt = function (stmt) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    return [2 /*return*/, (this.invoke(SQLType[stmt.type], stmt.build()))];
                });
            });
        };
        Connection.prototype.invoke = function (cmd, body) {
            return __awaiter(this, void 0, void 0, function () {
                var url, stid, start;
                var _this = this;
                return __generator(this, function (_a) {
                    url = this.url + "/";
                    if (this.conn != null)
                        url = url + this.conn + "/";
                    if (this.conn == null && cmd != "connect")
                        return [2 /*return*/, ({ status: "failed", message: "Not logged on" })];
                    if (cmd == "lock" || cmd == "insert" || cmd == "update" || cmd == "delete")
                        this.app.appstate.transactionChange(true);
                    stid = this.stmtid++;
                    start = new Date().getTime();
                    this.running.set(stid, start);
                    setTimeout(function () { _this.showwait(); }, +this.waitlim + +10);
                    return [2 /*return*/, (this.client.post(url + cmd, body).toPromise().then(function (data) { return (_this.onReply(stid, data)); }, function (error) { return (_this.onReply(stid, error)); }))];
                });
            });
        };
        Connection.prototype.onReply = function (stid, data) {
            var response = null;
            this.running.delete(stid);
            this.showwait();
            if (!(data instanceof i1.HttpErrorResponse))
                response = data;
            else
                response = { status: "failed", error: "500", message: JSON.stringify(data.message) };
            return (response);
        };
        Connection.prototype.alert = function (msg, title) {
            if (title == null)
                title = "Database Call Failed";
            MessageBox.show(this.app, msg, title);
        };
        Connection.prototype.showwait = function () {
            var now = new Date().getTime();
            var min = now;
            this.running.forEach(function (start) {
                if (+start < +min)
                    min = start;
            });
            var show = false;
            if (now - min > +this.waitlim)
                show = true;
            if (show)
                Wait.show(this.app);
            else
                Wait.close(this.app);
        };
        return Connection;
    }());

    var ApplicationState = /** @class */ (function () {
        function ApplicationState(app) {
            this.app = app;
            this.menu = null;
            this.form = null;
            this.transaction = false;
            this.appmenu = null;
            this.forms = new Map();
            this.menus = new Map();
            this.menu = new DefaultMenu();
            this.connection = new Connection(app);
        }
        ApplicationState.prototype.addForm = function (form) {
            this.forms.set(form.guid, form);
        };
        ApplicationState.prototype.dropForm = function (form) {
            this.forms.delete(form.guid);
        };
        ApplicationState.prototype.addMenu = function (menu) {
            var mhdl = menu.getHandler();
            this.menus.set(mhdl.guid, mhdl);
        };
        ApplicationState.prototype.dropMenu = function (menu) {
            if (menu != null) {
                var mhdl = menu.getHandler();
                this.menus.delete(mhdl.guid);
            }
        };
        ApplicationState.prototype.clearAllForms = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    this.forms.forEach(function (form) { form.clear(); });
                    return [2 /*return*/];
                });
            });
        };
        ApplicationState.prototype.onConnect = function () {
            return __awaiter(this, void 0, void 0, function () {
                var forms, f, funcs, i;
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            this.menus.forEach(function (mhdl) { mhdl.onConnect(); });
                            forms = [];
                            this.forms.forEach(function (form) { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
                                forms.push(form);
                                return [2 /*return*/];
                            }); }); });
                            f = 0;
                            _a.label = 1;
                        case 1:
                            if (!(f < forms.length)) return [3 /*break*/, 6];
                            funcs = FormDefinitions.getOnConnect(forms[f].name);
                            i = 0;
                            _a.label = 2;
                        case 2:
                            if (!(i < funcs.length)) return [3 /*break*/, 5];
                            return [4 /*yield*/, this.app.execfunc(forms[f], funcs[i])];
                        case 3:
                            _a.sent();
                            _a.label = 4;
                        case 4:
                            i++;
                            return [3 /*break*/, 2];
                        case 5:
                            f++;
                            return [3 /*break*/, 1];
                        case 6: return [2 /*return*/, (true)];
                    }
                });
            });
        };
        ApplicationState.prototype.transactionChange = function (trans) {
            if (!trans)
                this.forms.forEach(function (form) { form.onCommit(); });
            if (trans + "" != this.transaction + "") {
                this.transaction = trans;
                this.menus.forEach(function (mhdl) { mhdl.onTransactionChange(); });
            }
        };
        ApplicationState.prototype.onDisconnect = function () {
            return __awaiter(this, void 0, void 0, function () {
                var forms, f, funcs, i;
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            this.menus.forEach(function (mhdl) { mhdl.onDisconnect(); });
                            forms = [];
                            this.forms.forEach(function (form) { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
                                forms.push(form);
                                return [2 /*return*/];
                            }); }); });
                            f = 0;
                            _a.label = 1;
                        case 1:
                            if (!(f < forms.length)) return [3 /*break*/, 6];
                            funcs = FormDefinitions.getOnDisconnect(forms[f].name);
                            i = 0;
                            _a.label = 2;
                        case 2:
                            if (!(i < funcs.length)) return [3 /*break*/, 5];
                            return [4 /*yield*/, this.app.execfunc(forms[f], funcs[i])];
                        case 3:
                            _a.sent();
                            _a.label = 4;
                        case 4:
                            i++;
                            return [3 /*break*/, 2];
                        case 5:
                            f++;
                            return [3 /*break*/, 1];
                        case 6: return [2 /*return*/, (true)];
                    }
                });
            });
        };
        Object.defineProperty(ApplicationState.prototype, "connected", {
            get: function () {
                return (this.connection.connected);
            },
            enumerable: false,
            configurable: true
        });
        ApplicationState.prototype.alert = function (message, title, width, height) {
            MessageBox.show(this.app, message, title, width, height);
        };
        return ApplicationState;
    }());

    var InstanceControl = /** @class */ (function () {
        function InstanceControl(ctrl) {
            this.ctrl = ctrl;
            this.utils = new Utils();
            this.futil = new FormUtil();
        }
        InstanceControl.prototype.setFormsDefinitions = function (forms) {
            this.forms = forms;
        };
        InstanceControl.prototype.getNewInstance = function (form, modal) {
            var name = this.utils.getName(form);
            if (name == null)
                return (null);
            var def = this.forms.get(name);
            if (def == null)
                return (null);
            var ref = this.ctrl.createForm(def.component);
            if (ref == null)
                return (null);
            var impl = ref.instance["_impl_"];
            if (modal == null)
                modal = def.windowdef;
            modal = this.futil.complete(modal, true);
            var id = {
                ref: ref,
                impl: impl,
                name: def.name,
                modalopts: modal
            };
            impl.setInstanceID(id);
            return (id);
        };
        InstanceControl.prototype.getInstance = function (id) {
            var def = this.forms.get(id.name);
            var instance = this.futil.clone(def);
            if (id.ref == null)
                id.ref = this.ctrl.createForm(def.component);
            instance.formref = id.ref;
            instance.windowopts = id.modalopts;
            return (instance);
        };
        InstanceControl.prototype.closeInstance = function (id, destroy) {
            var inst = this.getInstance(id);
            if (destroy) {
                inst.formref.destroy();
                inst.windowopts = null;
                inst.formref = null;
            }
        };
        return InstanceControl;
    }());

    var Field = /** @class */ (function () {
        function Field(name, row) {
            this.seq = 0;
            this.value$ = "";
            this.current$ = false;
            this.enabled$ = false;
            this.field = null;
            this.fields$ = [];
            this.cfields$ = [];
            this.state$ = RecordState.na;
            this.ids = new Map();
            this.index = new Map();
            this.row$ = row;
            this.name$ = name;
        }
        ;
        Object.defineProperty(Field.prototype, "name", {
            get: function () {
                return (this.name$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "row", {
            get: function () {
                return (this.row$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "block", {
            get: function () {
                return (this.block$);
            },
            set: function (block) {
                this.block$ = block;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "fields", {
            get: function () {
                return (this.fields$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "cfields", {
            get: function () {
                return (this.cfields$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "valid", {
            set: function (valid) {
                this.fields.forEach(function (inst) { inst.valid = valid; });
                if (this.current)
                    this.cfields.forEach(function (inst) { inst.valid = valid; });
            },
            enumerable: false,
            configurable: true
        });
        Field.prototype.getInstance = function (guid) {
            return (this.index.get(guid));
        };
        Field.prototype.getFirstInstance = function () {
            if (this.fields.length > 0)
                return (this.fields[0]);
            if (this.current && this.cfields.length > 0) {
                var inst = this.cfields[0];
                inst.row = this.row;
                return (inst);
            }
            return (null);
        };
        Object.defineProperty(Field.prototype, "state", {
            get: function () {
                return (this.state$);
            },
            set: function (state) {
                this.state$ = state;
                this.fields.forEach(function (field) { field.state = state; });
                if (this.current)
                    this.cfields.forEach(function (field) { field.state = state; });
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "readonly", {
            get: function () {
                for (var i = 0; i < this.fields.length; i++) {
                    if (this.fields[i].enabled) {
                        if (!this.fields[i].readonly)
                            return (false);
                    }
                }
                if (this.current$) {
                    for (var i = 0; i < this.cfields.length; i++) {
                        if (this.cfields[i].enabled) {
                            if (!this.cfields[i].readonly)
                                return (false);
                        }
                    }
                }
                return (true);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "current", {
            get: function () {
                return (this.current$);
            },
            set: function (flag) {
                var _this = this;
                this.current$ = flag;
                if (!flag)
                    this.cfields.forEach(function (inst) {
                        inst.value = null;
                        inst.disable();
                    });
                else
                    this.cfields.forEach(function (inst) {
                        inst.parent = _this;
                        inst.row = _this.row;
                        inst.value = _this.value$;
                        inst.state = _this.state;
                        inst.readonly = _this.readonly;
                        inst.enable();
                    });
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "value", {
            get: function () {
                return (this.value$);
            },
            set: function (value) {
                this.value$ = value;
                this.fields.forEach(function (inst) { inst.value = value; });
                if (this.current)
                    this.cfields.forEach(function (inst) { inst.value = value; });
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Field.prototype, "enabled", {
            get: function () {
                return (this.enabled$);
            },
            enumerable: false,
            configurable: true
        });
        Field.prototype.focus = function () {
            if (this.field != null && this.field.enabled) {
                if (this.field.focus())
                    return (true);
            }
            for (var i = 0; i < this.fields.length; i++) {
                if (this.fields[i].enabled) {
                    if (this.fields[i].focus())
                        return (true);
                }
            }
            if (this.current$) {
                for (var i = 0; i < this.cfields.length; i++) {
                    if (this.cfields[i].enabled) {
                        if (this.cfields[i].focus())
                            return (true);
                    }
                }
            }
            return (false);
        };
        Field.prototype.add = function (field) {
            field.parent = this;
            if (field.row == -1) {
                this.cfields.push(field);
                if (field.guid == null)
                    field.guid = "c:" + (this.seq++);
            }
            else {
                this.fields.push(field);
                field.guid = "f:" + (this.seq++);
            }
            this.index.set(field.guid, field);
            if (field.id.length > 0)
                this.ids.set(field.id, field);
        };
        Object.defineProperty(Field.prototype, "definition", {
            get: function () {
                return (this.def);
            },
            enumerable: false,
            configurable: true
        });
        Field.prototype.setDefinition = function (def, cascade) {
            this.def = def;
            if (cascade) {
                for (var i = 0; i < this.fields.length; i++)
                    this.fields[i].definition = def;
                for (var i = 0; i < this.cfields.length; i++)
                    this.cfields[i].definition = def;
            }
        };
        Field.prototype.enable = function (readonly) {
            this.enabled$ = true;
            this.fields.forEach(function (field) { field.readonly = readonly; field.enable(); });
            if (this.current)
                this.cfields.forEach(function (field) { field.readonly = readonly; field.enable(); });
        };
        Field.prototype.disable = function () {
            this.enabled$ = false;
            this.fields.forEach(function (field) { field.disable(); });
            if (this.current)
                this.cfields.forEach(function (field) { field.disable(); });
        };
        Field.prototype.validate = function () {
            var valid = true;
            var inst = null;
            for (var i = 0; i < this.fields.length; i++) {
                inst = this.fields[i];
                if (!this.fields[i].validate()) {
                    valid = false;
                    break;
                }
            }
            if (valid && this.current) {
                for (var i = 0; i < this.cfields.length; i++) {
                    inst = this.cfields[i];
                    if (!this.cfields[i].validate()) {
                        valid = false;
                        break;
                    }
                }
            }
            this.valid = valid;
            if (inst != null)
                this.copy(inst);
            return (valid);
        };
        Field.prototype.onEvent = function (event, field, type, key) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    if (type == "blur")
                        this.field = null;
                    if (type == "focus")
                        this.field = field;
                    if (type == "cchange" || type == "change")
                        this.copy(field);
                    if (this.block$ != null)
                        this.block$.onEvent(event, field, type, key);
                    return [2 /*return*/];
                });
            });
        };
        Field.prototype.copy = function (field) {
            var _this = this;
            this.value$ = field.value;
            this.fields.forEach(function (inst) {
                if (inst != field)
                    inst.value = _this.value$;
            });
            this.cfields.forEach(function (inst) {
                if (inst != field)
                    inst.value = _this.value$;
            });
        };
        return Field;
    }());

    var Container = /** @class */ (function () {
        function Container() {
            this.fields$ = [];
            this.blocks = new Map();
        }
        Container.prototype.register = function (field) {
            var bname = field.block;
            var block = this.blocks.get(bname);
            if (block == null) {
                block = new ContainerBlock(bname);
                this.blocks.set(bname, block);
            }
            block.add(field);
            block.fields.push(field);
            this.fields$.push(field);
        };
        Object.defineProperty(Container.prototype, "fields", {
            get: function () {
                return (this.fields$);
            },
            enumerable: false,
            configurable: true
        });
        Container.prototype.getBlock = function (block) {
            return (this.blocks.get(block.toLowerCase()));
        };
        Container.prototype.getBlocks = function () {
            var blocks = [];
            this.blocks.forEach(function (blk) { blocks.push(blk); });
            return (blocks);
        };
        Container.prototype.finish = function () {
            this.blocks.forEach(function (block) { block["finish"](); });
        };
        return Container;
    }());
    var ContainerBlock = /** @class */ (function () {
        function ContainerBlock(name) {
            this.rows$ = 0;
            this.fields$ = [];
            this.current$ = [];
            this.records$ = new Map();
            this.name$ = name;
        }
        Object.defineProperty(ContainerBlock.prototype, "name", {
            get: function () {
                return (this.name$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ContainerBlock.prototype, "rows", {
            get: function () {
                return (this.rows$);
            },
            enumerable: false,
            configurable: true
        });
        ContainerBlock.prototype.add = function (field) {
            var row = field.row;
            if (field.row == -1) {
                this.current$.push(field);
                return;
            }
            var rec = this.records$.get(+row);
            if (rec == null) {
                rec = new ContainerRecord(row);
                this.records$.set(+row, rec);
                if (field.row > this.rows$)
                    this.rows$ = field.row;
            }
            rec.add(field);
        };
        Object.defineProperty(ContainerBlock.prototype, "fields", {
            get: function () {
                return (this.fields$);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ContainerBlock.prototype, "records", {
            get: function () {
                var recs = [];
                this.records$.forEach(function (rec) { recs.push(rec); });
                var sorted = recs.sort(function (a, b) { return (a.row - b.row); });
                return (sorted);
            },
            enumerable: false,
            configurable: true
        });
        ContainerBlock.prototype.getRecord = function (row) {
            return (this.records$.get(+row));
        };
        ContainerBlock.prototype.finish = function () {
            var _this = this;
            if (this.rows$ == 0) {
                var rec_1 = new ContainerRecord(0);
                this.records$.set(0, rec_1);
                this.current$.forEach(function (field) {
                    field.row = 0;
                    rec_1.add(field);
                });
                this.current$ = [];
            }
            else {
                this.records$.forEach(function (rec) {
                    _this.current$.forEach(function (inst) {
                        var group = rec.index.get(inst.name);
                        if (group != null)
                            group.add(inst);
                        else
                            rec.add(inst);
                    });
                });
            }
        };
        return ContainerBlock;
    }());
    var ContainerRecord = /** @class */ (function () {
        function ContainerRecord(row) {
            this.fields = [];
            this.index = new Map();
            this.row = row;
        }
        ContainerRecord.prototype.add = function (field) {
            var group = this.index.get(field.name);
            if (group == null) {
                group = new Field(field.name, this.row);
                this.index.set(field.name, group);
                this.fields.push(group);
            }
            group.add(field);
        };
        return ContainerRecord;
    }());

    var ContainerControl = /** @class */ (function () {
        function ContainerControl(builder) {
            this.builder = builder;
        }
        ContainerControl.prototype.setContainer = function (container) {
            if (container == null)
                container = new Container();
            this.container = container;
        };
        ContainerControl.prototype.getContainer = function () {
            var cont = this.container;
            return (cont);
        };
        ContainerControl.prototype.dropContainer = function () {
            this.container = null;
        };
        return ContainerControl;
    }());

    var ApplicationImpl = /** @class */ (function () {
        function ApplicationImpl(ctx, client, builder) {
            this.client = client;
            this.builder = builder;
            this.ready = 2;
            this.config$ = null;
            this.marea = null;
            this.apptitle = null;
            this.formlist = null;
            this.mfactory = null;
            this.formsctl = null;
            this.state = null;
            this.contctl = null;
            this.instances = null;
            this.app = ctx.app;
            this.config$ = ctx.conf;
            this.enable();
            this.loadConfig();
            this.state = new ApplicationState(this);
            this.contctl = new ContainerControl(builder);
            this.mfactory = new MenuFactory(this.builder);
            this.formsctl = new FormsControl(this, builder);
            this.instances = new InstanceControl(this.formsctl);
            this.setFormsDefinitions(FormDefinitions.getForms());
            this.state.appmenu = this.createmenu(this.state.menu);
        }
        ApplicationImpl.prototype.loadConfig = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, this.config$.ready()];
                        case 1:
                            _b.sent();
                            if (this.config$.others.hasOwnProperty("title"))
                                this.setTitle(this.config$.others["title"]);
                            if (this.config$.others.hasOwnProperty("theme"))
                                this.config$.setTheme(this.config$.others["theme"]);
                            this.ready--;
                            this.showLinkedForm();
                            return [2 /*return*/];
                    }
                });
            });
        };
        Object.defineProperty(ApplicationImpl.prototype, "config", {
            get: function () {
                return (this.config$);
            },
            enumerable: false,
            configurable: true
        });
        ApplicationImpl.prototype.enable = function () {
            WindowListener.add("app", this, "keydown");
        };
        ApplicationImpl.prototype.disable = function () {
            WindowListener.remove("app", "keydown");
        };
        Object.defineProperty(ApplicationImpl.prototype, "appstate", {
            get: function () {
                return (this.state);
            },
            enumerable: false,
            configurable: true
        });
        ApplicationImpl.prototype.getApplication = function () {
            return (this.app);
        };
        ApplicationImpl.prototype.setTitle = function (title) {
            this.apptitle = title;
            this.showTitle(title);
        };
        ApplicationImpl.prototype.close = function () {
            this.closeform(this.state.form, true);
        };
        ApplicationImpl.prototype.setMenu = function (menu) {
            this.deletemenu(this.state.menu);
            this.state.menu = menu;
            this.state.appmenu = this.createmenu(menu);
            this.showMenu(this.state.appmenu);
        };
        ApplicationImpl.prototype.getMenu = function () {
            return (this.state.menu);
        };
        ApplicationImpl.prototype.showTitle = function (title) {
            if (title == null)
                title = this.apptitle;
            document.title = title;
        };
        ApplicationImpl.prototype.showPath = function (name, path) {
            var state = { additionalInformation: 'None' };
            var url = window.location.protocol + '//' + window.location.host;
            window.history.replaceState(state, name, url + path);
        };
        ApplicationImpl.prototype.getFormsList = function () {
            return (this.formsctl.getFormsList());
        };
        ApplicationImpl.prototype.getFormsDefinitions = function () {
            return (this.formsctl.getFormsDefinitions());
        };
        ApplicationImpl.prototype.setFormList = function (formlist) {
            this.formlist = formlist;
        };
        ApplicationImpl.prototype.setMenuArea = function (area) {
            this.marea = area;
            this.showMenu(this.state.appmenu);
        };
        ApplicationImpl.prototype.setFormArea = function (area) {
            this.formsctl.setFormArea(area);
            this.ready--;
        };
        ApplicationImpl.prototype.setContainer = function (container) {
            this.contctl.setContainer(container);
        };
        ApplicationImpl.prototype.getContainer = function () {
            return (this.contctl.getContainer());
        };
        ApplicationImpl.prototype.dropContainer = function () {
            this.contctl.dropContainer();
        };
        Object.defineProperty(ApplicationImpl.prototype, "connection", {
            get: function () {
                return (this.appstate.connection);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ApplicationImpl.prototype, "connected", {
            get: function () {
                return (this.appstate.connected);
            },
            enumerable: false,
            configurable: true
        });
        ApplicationImpl.prototype.disconnect = function () {
            var _a;
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0: return [4 /*yield*/, this.appstate.connection.disconnect()];
                        case 1:
                            _b.sent();
                            (_a = this.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.focus();
                            return [2 /*return*/];
                    }
                });
            });
        };
        ApplicationImpl.prototype.newForm = function (impl) {
            return __awaiter(this, void 0, void 0, function () {
                var funcs, i, i;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            funcs = FormDefinitions.getOnInit(impl.name);
                            i = 0;
                            _b.label = 1;
                        case 1:
                            if (!(i < funcs.length)) return [3 /*break*/, 4];
                            return [4 /*yield*/, this.execfunc(impl, funcs[i])];
                        case 2:
                            _b.sent();
                            _b.label = 3;
                        case 3:
                            i++;
                            return [3 /*break*/, 1];
                        case 4:
                            funcs = FormDefinitions.getOnShow(impl.name);
                            i = 0;
                            _b.label = 5;
                        case 5:
                            if (!(i < funcs.length)) return [3 /*break*/, 8];
                            return [4 /*yield*/, this.execfunc(impl, funcs[i])];
                        case 6:
                            _b.sent();
                            _b.label = 7;
                        case 7:
                            i++;
                            return [3 /*break*/, 5];
                        case 8:
                            impl.onShow();
                            return [2 /*return*/];
                    }
                });
            });
        };
        ApplicationImpl.prototype.preform = function (impl, parameters, formdef, path) {
            return __awaiter(this, void 0, void 0, function () {
                var funcs, i;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            impl.setParameters(parameters);
                            if (!impl.initiated()) {
                                impl.path = formdef.path;
                                impl.title = formdef.title;
                                this.state.addForm(impl);
                                this.showTitle(formdef.title);
                                if (path)
                                    this.showPath(impl.name, formdef.path);
                                return [2 /*return*/];
                            }
                            this.showTitle(impl.title);
                            if (path)
                                this.showPath(impl.name, impl.path);
                            funcs = FormDefinitions.getOnShow(impl.name);
                            i = 0;
                            _b.label = 1;
                        case 1:
                            if (!(i < funcs.length)) return [3 /*break*/, 4];
                            return [4 /*yield*/, this.execfunc(impl, funcs[i])];
                        case 2:
                            _b.sent();
                            _b.label = 3;
                        case 3:
                            i++;
                            return [3 /*break*/, 1];
                        case 4:
                            impl.onShow();
                            return [2 /*return*/];
                    }
                });
            });
        };
        ApplicationImpl.prototype.postform = function (impl, destroy) {
            return __awaiter(this, void 0, void 0, function () {
                var funcs, i, funcs_1, i;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            impl.onHide();
                            funcs = FormDefinitions.getOnHide(impl.name);
                            i = 0;
                            _b.label = 1;
                        case 1:
                            if (!(i < funcs.length)) return [3 /*break*/, 4];
                            return [4 /*yield*/, this.execfunc(impl, funcs[i])];
                        case 2:
                            _b.sent();
                            _b.label = 3;
                        case 3:
                            i++;
                            return [3 /*break*/, 1];
                        case 4:
                            if (!destroy) return [3 /*break*/, 8];
                            this.state.dropForm(impl);
                            funcs_1 = FormDefinitions.getOnDestroy(impl.name);
                            i = 0;
                            _b.label = 5;
                        case 5:
                            if (!(i < funcs_1.length)) return [3 /*break*/, 8];
                            return [4 /*yield*/, this.execfunc(impl, funcs_1[i])];
                        case 6:
                            _b.sent();
                            _b.label = 7;
                        case 7:
                            i++;
                            return [3 /*break*/, 5];
                        case 8: return [2 /*return*/];
                    }
                });
            });
        };
        ApplicationImpl.prototype.execfunc = function (impl, func) {
            return __awaiter(this, void 0, void 0, function () {
                var error_1;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            _b.trys.push([0, 2, , 3]);
                            return [4 /*yield*/, impl.form[func]()];
                        case 1:
                            _b.sent();
                            return [3 /*break*/, 3];
                        case 2:
                            error_1 = _b.sent();
                            console.log(error_1);
                            return [3 /*break*/, 3];
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        ApplicationImpl.prototype.callform = function (form, destroy, parameters) {
            return __awaiter(this, void 0, void 0, function () {
                var curr;
                var _this = this;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (this.ready != 0) {
                                setTimeout(function () { _this.callform(form, destroy, parameters); }, 10);
                                return [2 /*return*/];
                            }
                            if (!(this.state.form != null)) return [3 /*break*/, 3];
                            return [4 /*yield*/, this.state.form.validate()];
                        case 1:
                            // Make sure changes has been validated
                            if (!(_b.sent()))
                                return [2 /*return*/];
                            curr = this.state.form.getChain();
                            // let form handle the showform
                            return [4 /*yield*/, curr.callform(form, destroy, parameters)];
                        case 2:
                            // let form handle the showform
                            _b.sent();
                            _b.label = 3;
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        ApplicationImpl.prototype.getCurrentForm = function () {
            if (this.ready != 0)
                return (null);
            if (this.state.form == null)
                return (null);
            return (this.state.form.getChain());
        };
        ApplicationImpl.prototype.showform = function (form, destroy, parameters) {
            var _a;
            return __awaiter(this, void 0, void 0, function () {
                var curr, formdef, impl, fmenu;
                var _this = this;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (this.ready != 0) {
                                setTimeout(function () { _this.showform(form, destroy, parameters); }, 10);
                                return [2 /*return*/];
                            }
                            if (!(this.state.form != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.state.form.validate()];
                        case 1:
                            // Make sure changes has been validated
                            if (!(_b.sent()))
                                return [2 /*return*/];
                            curr = this.state.form.getChain();
                            if (curr != this.state.form) {
                                // let form handle the showform
                                curr.showform(form, destroy, parameters);
                                return [2 /*return*/];
                            }
                            if (this.state.form.getModalWindow() != null)
                                return [2 /*return*/];
                            this.closeform(this.state.form, false);
                            _b.label = 2;
                        case 2:
                            if (destroy)
                                this.formsctl.closeform(form, destroy);
                            formdef = this.getFormInstance(form);
                            if (formdef == null)
                                return [2 /*return*/];
                            impl = formdef.formref.instance["_impl_"];
                            return [4 /*yield*/, this.preform(impl, parameters, formdef, true)];
                        case 3:
                            _b.sent();
                            this.state.form = impl;
                            fmenu = impl.getDropDownMenu();
                            if (!((_a = formdef.windowopts) === null || _a === void 0 ? void 0 : _a.wizard))
                                this.showMenu(fmenu);
                            DropDownMenu.setForm(fmenu, formdef.formref.instance);
                            this.formsctl.display(formdef);
                            return [2 /*return*/];
                    }
                });
            });
        };
        ApplicationImpl.prototype.showinstance = function (inst) {
            var _this = this;
            if (this.ready == 0)
                this.formsctl.display(inst);
            else
                setTimeout(function () { _this.showinstance(inst); }, 10);
        };
        ApplicationImpl.prototype.closeform = function (impl, destroy) {
            if (impl == null)
                return;
            this.postform(impl, destroy);
            this.formsctl.closeform(impl.name, destroy);
            if (this.state.appmenu != null)
                DropDownMenu.setForm(this.state.appmenu, null);
            this.showPath("", "");
            this.showTitle(null);
            this.state.form = null;
            this.showMenu(this.state.appmenu);
        };
        ApplicationImpl.prototype.getFormInstance = function (form) {
            return (this.formsctl.getFormInstance(form));
        };
        ApplicationImpl.prototype.getNewInstance = function (form, modal) {
            return (this.instances.getNewInstance(form, modal));
        };
        ApplicationImpl.prototype.getInstance = function (id) {
            return (this.instances.getInstance(id));
        };
        ApplicationImpl.prototype.closeInstance = function (id, destroy) {
            this.postform(id.impl, destroy);
            this.instances.closeInstance(id, destroy);
        };
        ApplicationImpl.prototype.showMenu = function (menu) {
            if (this.marea != null)
                this.marea.display(menu);
        };
        ApplicationImpl.prototype.deletemenu = function (menu) {
            this.state.dropMenu(menu);
        };
        ApplicationImpl.prototype.createmenu = function (menu) {
            if (menu == null)
                return (null);
            this.state.addMenu(menu);
            var ddmenu = this.mfactory.create(menu);
            return (ddmenu);
        };
        ApplicationImpl.prototype.setFormsDefinitions = function (forms) {
            for (var i = 0; i < forms.length; i++) {
                var fname = forms[i].component.name.toLowerCase();
                forms[i].windowopts = FormDefinitions.getWindowOpts(fname);
                forms[i].databaseusage = DatabaseDefinitions.getFormUsage(fname);
            }
            var formsmap = this.formsctl.setFormsDefinitions(forms);
            this.instances.setFormsDefinitions(formsmap);
        };
        ApplicationImpl.prototype.showLinkedForm = function () {
            var _this = this;
            if (this.ready != 0) {
                // Make time for application setup
                setTimeout(function () { _this.showLinkedForm(); }, 500);
                return;
            }
            var form = decodeURI(window.location.pathname);
            if (form.length > 0)
                form = this.formsctl.findFormByPath(form);
            if (form != null) {
                var inst = this.formsctl.getFormsDefinitions().get(form);
                if (inst == null || !inst.navigable) {
                    this.showPath("", "");
                    return;
                }
                var params_1 = new Map();
                var urlparams = new URLSearchParams(window.location.search);
                urlparams.forEach(function (value, key) { params_1.set(key, value); });
                this.showform(form, false, params_1);
            }
        };
        ApplicationImpl.prototype.onEvent = function (event) {
            return __awaiter(this, void 0, void 0, function () {
                var keydef, map, key, form;
                return __generator(this, function (_b) {
                    if (Wait.waiting())
                        return [2 /*return*/];
                    keydef = {
                        code: event.keyCode,
                        alt: event.altKey,
                        ctrl: event.ctrlKey,
                        meta: event.metaKey,
                        shift: event.shiftKey
                    };
                    map = KeyMapper.map(keydef);
                    key = KeyMapper.keymap(map);
                    if (key == exports.keymap.connect) {
                        this.app.connect();
                        return [2 /*return*/];
                    }
                    if (key == exports.keymap.disconnect) {
                        this.app.disconnect();
                        return [2 /*return*/];
                    }
                    if (key == exports.keymap.close ||
                        key == exports.keymap.delete ||
                        key == exports.keymap.listval ||
                        key == exports.keymap.commit ||
                        key == exports.keymap.rollback ||
                        key == exports.keymap.clearform ||
                        key == exports.keymap.insertafter ||
                        key == exports.keymap.insertbefore ||
                        key == exports.keymap.enterquery ||
                        key == exports.keymap.executequery) {
                        event.preventDefault();
                        form = this.getCurrentForm();
                        if (form != null)
                            form.sendkey(event, key);
                    }
                    return [2 /*return*/];
                });
            });
        };
        return ApplicationImpl;
    }());

    var Application = /** @class */ (function () {
        // dont rename impl as it is read behind the scenes
        function Application(ctx, conf, client, builder) {
            this.conf = conf;
            ctx.app = this;
            ctx.conf = conf;
            this._impl_ = new ApplicationImpl(ctx, client, builder);
        }
        Object.defineProperty(Application.prototype, "title", {
            get: function () {
                return (this.title$);
            },
            set: function (title) {
                this.title$ = title;
                this._impl_.setTitle(title);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Application.prototype, "form", {
            get: function () {
                var _a;
                return ((_a = this._impl_.getCurrentForm()) === null || _a === void 0 ? void 0 : _a.form);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Application.prototype, "menu", {
            get: function () {
                return (this._impl_.getMenu());
            },
            set: function (menu) {
                this._impl_.setMenu(menu);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Application.prototype, "transaction", {
            get: function () {
                return (this._impl_.appstate.transaction);
            },
            enumerable: false,
            configurable: true
        });
        Application.prototype.newform = function (form, parameters) {
            this._impl_.showform(form, true, parameters);
        };
        Application.prototype.showform = function (form, parameters) {
            this._impl_.showform(form, false, parameters);
        };
        Application.prototype.callform = function (form, parameters) {
            this._impl_.callform(form, false, parameters);
        };
        Object.defineProperty(Application.prototype, "colors", {
            get: function () {
                return (this.conf.colors);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Application.prototype, "theme", {
            set: function (theme) {
                var _this = this;
                setTimeout(function () { _this.conf.setTheme(theme); }, 50);
            },
            enumerable: false,
            configurable: true
        });
        Application.prototype.closeform = function (destroy) {
            if (destroy == undefined)
                destroy = false;
            var form = this._impl_.getCurrentForm();
            if (form != null)
                form.close(destroy);
        };
        Application.prototype.connect = function () {
            if (!this._impl_.connected) {
                var pinst = new PopupInstance();
                pinst.display(this._impl_, LoginForm);
            }
        };
        Application.prototype.disconnect = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (!this._impl_.connected) return [3 /*break*/, 4];
                            return [4 /*yield*/, this._impl_.appstate.clearAllForms()];
                        case 1:
                            _b.sent();
                            return [4 /*yield*/, this._impl_.connection.rollback()];
                        case 2:
                            _b.sent();
                            return [4 /*yield*/, this._impl_.disconnect()];
                        case 3:
                            _b.sent();
                            _b.label = 4;
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        Application.prototype.commit = function () {
            return __awaiter(this, void 0, void 0, function () {
                var form;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (!this._impl_.connected)
                                return [2 /*return*/];
                            form = this._impl_.getCurrentForm();
                            if (!(form != null)) return [3 /*break*/, 2];
                            return [4 /*yield*/, form.validate()];
                        case 1:
                            if (!(_b.sent()))
                                return [2 /*return*/];
                            _b.label = 2;
                        case 2:
                            this._impl_.connection.commit();
                            return [2 /*return*/];
                    }
                });
            });
        };
        Application.prototype.rollback = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            if (!this._impl_.connected) return [3 /*break*/, 3];
                            return [4 /*yield*/, this._impl_.appstate.clearAllForms()];
                        case 1:
                            _b.sent();
                            return [4 /*yield*/, this._impl_.connection.rollback()];
                        case 2:
                            _b.sent();
                            _b.label = 3;
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        Application.prototype.showKeyMap = function () {
            KeyMapHelp.show(this._impl_);
        };
        Application.prototype.alert = function (message, title, width, height) {
            MessageBox.show(this._impl_, message, title, width, height);
        };
        return Application;
    }());
    Application.ɵprov = i0.ɵɵdefineInjectable({ factory: function Application_Factory() { return new Application(i0.ɵɵinject(Context), i0.ɵɵinject(Config), i0.ɵɵinject(i1.HttpClient), i0.ɵɵinject(Builder)); }, token: Application, providedIn: "root" });
    Application.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root',
                },] }
    ];
    Application.ctorParameters = function () { return [
        { type: Context },
        { type: Config },
        { type: i1.HttpClient },
        { type: Builder }
    ]; };

    var FormsLibrary = /** @class */ (function () {
        function FormsLibrary() {
        }
        return FormsLibrary;
    }());
    FormsLibrary.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [FormList, FormArea, ModalWindow, MenuArea, LoginForm, FieldInstance, ListOfValuesImpl, Wait],
                    exports: [FormList, FormArea, MenuArea, FieldInstance],
                    imports: [common.CommonModule, i1.HttpClientModule]
                },] }
    ];

    /**
     * Generated bundle index. Do not edit.
     */

    exports.Application = Application;
    exports.Block = Block;
    exports.Condition = Condition;
    exports.DateUtils = DateUtils;
    exports.DefaultMenu = DefaultMenu;
    exports.DefaultMenuHandler = DefaultMenuHandler;
    exports.FieldInstance = FieldInstance;
    exports.FieldTriggerEvent = FieldTriggerEvent;
    exports.Form = Form;
    exports.FormArea = FormArea;
    exports.FormList = FormList;
    exports.FormsLibrary = FormsLibrary;
    exports.KeyTriggerEvent = KeyTriggerEvent;
    exports.MenuArea = MenuArea;
    exports.MenuHandler = MenuHandler;
    exports.SQLTriggerEvent = SQLTriggerEvent;
    exports.Statement = Statement;
    exports.TriggerEvent = TriggerEvent;
    exports.alias = alias;
    exports.block = block;
    exports.column = column;
    exports.connect = connect;
    exports.database = database;
    exports.destroy = destroy;
    exports.disconnect = disconnect;
    exports.field = field;
    exports.form = form;
    exports.hide = hide;
    exports.init = init;
    exports.join = join;
    exports.key = key;
    exports.keytrigger = keytrigger;
    exports.listofvalues = listofvalues;
    exports.show = show;
    exports.table = table;
    exports.trigger = trigger;
    exports.window = window$1;
    exports.wizard = wizard;
    exports.ɵa = Context;
    exports.ɵb = Config;
    exports.ɵc = Builder;
    exports.ɵd = ModalWindow;
    exports.ɵe = LoginForm;
    exports.ɵf = ListOfValuesImpl;
    exports.ɵg = Wait;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=forms.umd.js.map
